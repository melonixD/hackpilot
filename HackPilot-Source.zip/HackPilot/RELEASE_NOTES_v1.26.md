# HackPilot 1.26 — deeper failure recovery audit

This release keeps every page accessible and strengthens the real operation checks.

- Malformed engine/USBToolBox cache metadata is treated as untrusted instead of
  crashing startup or status refresh. Invalid validator metadata triggers a fresh
  lookup while retaining the old binary until replacement succeeds.
- Corrupt and excessively nested USB transfer records are shown as damaged,
  preventing unsafe automatic repair without taking down the interface.
- Optional cache files denied by Windows permissions no longer stop startup or
  status refresh. Inaccessible recovery remains unverified.
- USB identity is rechecked between EFI commit and rollback renames and before
  each cleanup step. A simulated replacement USB is left untouched.
- Enumeration timeouts become identity-check failures, preserving the original
  interrupted transaction for deliberate repair.
- Transfer file counts and aggregate size are bounded before copying or backup.
- ZIP file/directory collisions are rejected before any archive entries are
  extracted, including case-insensitive parent-path conflicts.
- Malformed validator release feeds stop before downloading or executing files.
- Hardware scanner timeout/elevation errors provide a specific instruction and
  preserve the previously saved report.

Validation includes malformed-cache startup, unavailable cache permissions,
interrupted journals, release schemas, archive conflicts, scanner failures, USB
swaps during commit/rollback, existing recovery behavior and UI navigation.
Simulated USB volumes only; physical formatting and macOS boot remain untested.
