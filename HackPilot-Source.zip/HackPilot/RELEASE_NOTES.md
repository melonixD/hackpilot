# HackPilot release notes

**Latest: [v1.17 — EFI Integrity Boundary and Cache Hardening](RELEASE_NOTES_v1.17.md)**.

Historical release notes are preserved as `RELEASE_NOTES_v1.1.md` through `RELEASE_NOTES_v1.16.md`. For the current supported workflow and unresolved hardware release gates, see [README.md](README.md) and [COMPATIBILITY_AND_RELEASE_GATES.md](COMPATIBILITY_AND_RELEASE_GATES.md).
