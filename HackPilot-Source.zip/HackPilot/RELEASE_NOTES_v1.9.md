# HackPilot v1.9 — Additional Hardening

This is a source preview, **not** a boot-tested Hackintosh or a compiled Windows executable.

## Actual bugs fixed

- Invalid local API JSON (arrays, scalars, malformed objects) now returns a readable HTTP 400 instead of closing the request with an unhandled exception. Invalid length and content type are also rejected before mutation.
- The GUI's recovery status safely handles disappearing or inaccessible cached recovery files rather than throwing during status polling. Full recovery hashes are still checked before USB writes.
- Saved USB maps are not classified as ready unless their complete codeless `.kext` bundle is present and well-formed. Extra executables, unexpected paths, malformed Info.plists and links prevent reuse.
- An enabled i386-only kext is rejected on the 64-bit macOS targets rather than silently ignored.
- One app instance can no longer replace shared hardware reports, EFI builds or cached tools while a second app instance is modifying the same workspace. The lock is released by the OS after a crash. USB transfer locks remain separate.
- Invalid `target_darwin` values in an EFI manifest now produce validation errors rather than crashing the component audit.
- Pathological Darwin/kext version strings no longer trigger huge integer conversions or interpreter digit-limit exceptions.
- Oversized SSDTs and config/kext plist files are rejected early, avoiding unbounded allocation in the component audit.

## Verification

- 277 passing automated regression/unit tests on Linux, including 21 new tests.
- Python compilation, GUI JavaScript syntax, app self-test, and clean ZIP extraction checks.
- The production Windows scanner, Windows GUI EXE, physical USB writes, Apple Recovery downloads and macOS boot cannot be verified in this environment. Do not interpret the test count as boot compatibility evidence.

## Remaining blockers

- Produce and test a Windows-built standalone `HackPilot.exe` on a physical Windows PC.
- Verify actual Intel/AMD hardware scanning, SSDT and kext generation, recovery installation, USB-port mapping and boot behavior against hardware test matrices.
- The current USB writer still requires an existing removable FAT32 volume; no automated formatting or offline full installer is included.
- macOS software licensing and hardware support may restrict use.
