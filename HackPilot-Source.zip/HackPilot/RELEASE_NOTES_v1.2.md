# HackPilot v1.2 — EFI component verification

Source release only. No native Windows binary or real macOS boot has been verified in this environment.

## Fixed and improved

- Guided selection of GPU, Wi-Fi and Bluetooth actually disables unselected upstream devices. Previously an apparent selection could leave conflicting controllers enabled.
- Generated EFI builds now undergo independent checks of boot files, UEFI driver and optional tool PE/COFF x86_64 architecture and EFI subsystems, ACPI/SSDT header lengths and checksums, kext Info.plist contents and x86_64 Mach-O binary headers, kext load order, duplicate bundle identifiers, and required drivers.
- A missing or disabled HFS+ driver or OpenRuntime driver is an error when building the internet-recovery EFI, even if `ocvalidate` passes.
- Temporary `UTBDefault.kext` and tested `UTBMap.kext` cannot both be enabled, and a missing physical USB mapping is clearly warned rather than claimed to be ready.
- Additional generated build files get the component checks again when users click Validate or Prepare USB.
- Apple recovery downloads are selected by the **actual generated Darwin/macOS version** using the documented OpenCore `macrecovery` profiles, without a mandatory manual SMBIOS board ID. Saved recovery metadata remains target-bound to avoid mismatched versions.
- Unrecognized macOS targets or malformed kext dependencies fail clearly, not with uncaught exceptions.
- UI keeps the white background and bold black text. The board ID entry is advanced/optional.

## Regression verification

- 138 automated tests passed in Linux; Python compilation, launcher self-test and JavaScript syntax checks passed.
- The packaged archive is additionally tested by extraction and rerunning the suite.

## Still not guaranteed

- SSDTs that are checksum-correct can still be incompatible with a specific motherboard. Kexts can be valid x86_64 Mach-O files but incompatible with the chosen macOS kernel or hardware. All USB ports require physical test/mapping and some systems need BIOS changes.
- Automatic USB formatting/partitioning is not present; a removable FAT32 partition is required. Apple internet recovery requires a connection. Native EXE generation is available through the Windows GitHub Actions workflow but not built here.
- No simulated test substitutes for booting real Intel/AMD hardware. No claim of universal compatibility or zero defects is made.

## Audited public upstream references

- OpCore-Simplify: https://github.com/lzhoang2801/OpCore-Simplify
- OpenCorePkg + macrecovery: https://github.com/acidanthera/OpenCorePkg
- Dortania OpenCore Install Guide: https://dortania.github.io/OpenCore-Install-Guide/
- USBToolBox: https://github.com/USBToolBox/tool
