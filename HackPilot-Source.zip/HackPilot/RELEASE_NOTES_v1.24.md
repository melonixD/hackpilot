# HackPilot 1.24 — suggested order, free navigation

All setup pages and progress links are accessible immediately. The home screen
continues to recommend hardware scanning first, but completing an earlier UI step
is no longer required to open EFI, USB ports, installer USB or USB drive tools.
Compatibility findings and changed settings do not redirect navigation.

USB formatting, access restoration, Rufus, EFI engine installation, recovery
download and saved-EFI validation can be reached independently of the suggested
setup sequence. Starting an automatic EFI build directly explains that it will
collect a hardware scan if needed and describes any temporary USB configuration.

Actual operations still enforce their real prerequisites: safe disk identity and
erase confirmations, hardware-bound EFI manifests, validation and matching Apple
recovery. Changing macOS/device choices still requires rebuilding before copying.
Demo restrictions and concurrent-operation protection remain in place.

Validation: 14 frontend behavior checks cover free navigation, independent USB
access recovery, direct EFI setup, stale build prevention, recovery target binding,
failed tasks, fast completions and in-flight action handling. The full Python and
Windows packaging checks run before distributing the executable.
