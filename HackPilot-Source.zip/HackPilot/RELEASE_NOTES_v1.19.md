# HackPilot 1.19

- Bound board-ID config reads to 8 MiB, including growth during reading.
- Reject deeply nested recovery metadata without an uncaught recursion error.
- Ignore deeply nested saved scans at startup.
- Reject deeply nested API JSON with a malformed-JSON response.
- Add corrupted-file regression tests.

Physical USB writes and macOS boots remain unverified.
