@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m hackpilot.main
) else (
  python -m hackpilot.main
)
if errorlevel 1 pause
