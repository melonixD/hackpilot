'use strict';
const TOKEN=document.querySelector('meta[name="hackpilot-token"]').content;
const ICONS={
 home:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
 cpu:'<rect x="5" y="5" width="14" height="14" rx="2"/><path d="M9 9h6v6H9zM9 1v4M15 1v4M9 19v4M15 19v4M1 9h4M1 15h4M19 9h4M19 15h4"/>',
 layers:'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 8h8v8H8z"/>',
 usb:'<path d="M12 2v14m0-14-3 3m3-3 3 3M5 12h14M5 12v4m14-4v4M5 16a2 2 0 1 0 0 4 2 2 0 0 0 0-4m12 0h4v4h-4zM12 16v6"/>',
 terminal:'<rect x="2" y="4" width="20" height="16" rx="3"/><path d="m6 9 3 3-3 3m6 0h6"/>',
 arrow:'<path d="M5 12h14m-6-6 6 6-6 6"/>',
 check:'<path d="m5 12 5 5L20 7"/>',
 chevron:'<path d="m6 9 6 6 6-6"/>',
 refresh:'<path d="M20 11a8 8 0 0 0-14-5L4 8m0-5v5h5M4 13a8 8 0 0 0 14 5l2-2m0 5v-5h-5"/>',
 warning:'<path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5m0 4h.01"/>',
 info:'<circle cx="12" cy="12" r="10"/><path d="M12 11v6m0-10h.01"/>',
 folder:'<path d="M3 6h7l2 2h9v11H3z"/>',
 download:'<path d="M12 3v12m-4-4 4 4 4-4M4 18v3h16v-3"/>',
 search:'<circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/>',
 shield:'<path d="m12 2 9 4v6c0 5-3.5 8.4-9 10-5.5-1.6-9-5-9-10V6z"/>',
 harddrive:'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 13h18m-14 4h.01m4 0h.01"/>'
};
const icon=(name,cls='')=>`<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name]||ICONS.info}</svg>`;
const esc=x=>String(x??'—').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const id=x=>document.getElementById(x);
let S={hardware:null,compatibility:{findings:[],can_attempt:false},tasks:{}},view='home',usb=[],priorTasks={},signature='',fields={target:'auto',board:'',drive:'',selections:{}},toastTimer,renderedView=null;
const expandedPanels=new Map();
async function get(path){const r=await fetch('/api/'+path,{cache:'no-store'});const data=await r.json();if(!r.ok)throw new Error(data.error||'Request failed');return data}
async function post(path,body={}){const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json','X-HackPilot-Token':TOKEN},body:JSON.stringify(body)});const data=await r.json();if(!r.ok)throw new Error(data.error||'Operation failed');return data}
function toast(message,error=false){const t=id('toast');t.textContent=(error?'Error · ':'')+message;t.className='toast'+(error?' error':'');t.style.display='block';clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.style.display='none',6500)}
const running=()=>Object.values(S.tasks||{}).find(t=>t.state==='running');
const blocked=()=>S.compatibility?.status==='blocked';
const ready=()=>!!(S.deep_scan_ready&&S.engine_ready&&S.compatibility?.can_attempt&&!S.hardware?.origin?.startsWith('Synthetic'));
function shortStatus(){if(running())return ['Working','warn'];if(blocked())return ['Needs review','bad'];if(S.last_build?.valid)return ['EFI checked','good'];if(ready())return ['Scan complete','good'];if(S.hardware)return ['Scanned','warn'];return ['Not scanned','idle']}
function captureFields(){const t=id('macos-target'),b=id('board-id'),d=id('usb-target');if(t)fields.target=t.value;if(b)fields.board=b.value;if(d)fields.drive=d.value;document.querySelectorAll('[data-device-choice]').forEach(el=>{if(el.value)fields.selections[el.dataset.deviceChoice]=el.value;else delete fields.selections[el.dataset.deviceChoice]})}
function btn(label,action,kind='secondary',disabled=false,extra=''){return `<button class="btn btn-${kind}" type="button" data-action="${esc(action)}" ${disabled?'disabled':''} ${extra}>${label}</button>`}
function pageHeading(title,actions=''){return `<div class="page-heading"><h1>${title}</h1><div class="btn-row">${actions}</div></div>`}
function taskBanner(){const task=running();if(!task)return '';const pct=Math.max(0,Math.min(100,Number(task.percent)||0));return `<div class="task-indicator" role="status"><span class="spinner"></span><div class="task-body"><div class="task-row"><strong>${esc(task.message||task.name)}</strong><span>${pct?pct+'%':'Working'}</span></div><div class="task-track"><span style="width:${pct}%"></span></div></div></div>`}
function taskError(){const t=Object.values(S.tasks||{}).slice(-1)[0];return t?.state==='error'?notice(t.message,'block'):''}
function demoNotice(){return S.hardware?.origin?.startsWith('Synthetic')?'<div class="notice">Demo hardware · Generation disabled</div>':''}
function notice(message,kind='info'){return `<div class="notice ${kind}">${esc(message)}</div>`}
function stateMark(ok){return ok?`<span class="status-text good">${icon('check')} Done</span>`:'<span class="status-text subtle">Pending</span>'}
function step(itemNo,name,description,done,action){return `<button class="progress-item" type="button" data-action="${esc(action)}"><span class="progress-left"><span class="progress-index ${done?'complete':''}">${done?icon('check'):itemNo}</span><span><span class="progress-name">${name}</span>${description?`<span class="progress-secondary">${description}</span>`:''}</span></span><span class="progress-right">${done?'<span class="status-text good">Done</span>':icon('arrow')}</span></button>`}
function usbOptions(){
  return usb.map(d=>`<option value="${esc(d.drive_letter)}">${esc(d.drive_letter)}: · ${esc(d.name||'USB')} · ${Math.round(Number(d.capacity||0)/1073741824)} GB</option>`).join('');
}
function nextAction(){
  if(running())return ['Working','navigate-diagnostics','Preparing files'];
  if(blocked())return ['Review hardware','navigate-hardware','Needs review'];
  if(S.usb_prepared)return ['View USB','navigate-usb','USB files verified'];
  if(S.demo)return ['View hardware','navigate-hardware','Demo mode'];
  if(!usb.length)return ['Refresh','refresh-usb','Insert USB'];
  return ['Prepare USB','one-click','Ready to prepare'];
}
function overview(){
  const h=S.hardware||{},[button,act,title]=nextAction();
  return `${pageHeading('Overview')}${demoNotice()}${taskBanner()}${taskError()}
<section class="hero one-click-hero">
  <div class="one-click-heading"><div class="hero-overline">HACKPILOT</div><h2>${esc(title)}</h2></div>
  <div class="one-click-controls"><div class="one-click-selectors">
    <div class="field"><label for="usb-target">USB drive</label><select id="usb-target" ${!usb.length?'disabled':''}>${usb.length?(usb.length>1?'<option value="">Choose USB</option>':'')+usbOptions():'<option value="">Insert FAT32 USB</option>'}</select></div>
    <div class="field"><label for="macos-target">macOS</label><select id="macos-target"><option value="auto">Automatic</option><option value="25">Tahoe</option><option value="24">Sequoia</option><option value="23">Sonoma</option><option value="22">Ventura</option><option value="21">Monterey</option><option value="20">Big Sur</option></select></div>
  </div><div class="hero-actions">${btn(esc(button)+' '+icon('arrow'),act,'primary',!!running()||(act==='one-click'&&usb.length>1&&!fields.drive))}</div></div>
</section>
<details class="guide one-click-advanced"><summary>Advanced ${icon('chevron')}</summary><div class="field" style="max-width:350px;margin-top:12px"><label for="board-id">Recovery board ID · optional</label><input id="board-id" spellcheck="false" autocomplete="off" placeholder="Automatic by macOS version"></div></details>
${!usb.length?`<div class="minor usb-tip">Use a removable FAT32 USB drive. No drives are erased automatically.</div>`:''}${!S.usb_mapping?.map_ready?`<div class="map-hint">USB ports not mapped. ${btn('Map ports '+icon('arrow'),'navigate-usbmap','outline')}</div>`:S.usb_mapping?.unseen_selected?`<div class="map-hint">${S.usb_mapping.unseen_selected} selected ports have not been physically tested. ${btn('Review ports '+icon('arrow'),'navigate-usbmap','outline')}</div>`:''}
${S.usb_prepared?`<div class="minor usb-tip">Last USB copy verified. Boot and network support remain untested.</div>`:''}
<div class="section-bar"><h2 class="section-title">Setup</h2><span class="minor">${[!!S.deep_scan_ready,!!S.usb_mapping?.map_ready&&!S.usb_mapping?.unseen_selected,!!S.last_build?.valid,!!S.usb_prepared].filter(Boolean).length} / 4</span></div>
<div class="progress-list">
${step('1','Hardware','',!!S.deep_scan_ready,'navigate-hardware')}
${step('2','USB mapping','',!!S.usb_mapping?.map_ready&&!S.usb_mapping?.unseen_selected,'navigate-usbmap')}
${step('3','EFI','',!!S.last_build?.valid,'navigate-build')}
${step('4','USB','',!!S.usb_prepared,'navigate-usb')}
</div>
<div class="section-bar"><h2 class="section-title">System</h2>${btn('Details '+icon('arrow'),'navigate-hardware','quiet')}</div>
<div class="metric-grid"><div class="metric"><span class="label">CPU</span><strong>${esc(h.cpu?.name||'Not scanned')}</strong></div><div class="metric"><span class="label">GPU</span><strong>${esc(h.gpus?.[0]?.name||'—')}</strong></div><div class="metric"><span class="label">EFI</span><strong>${S.last_build?.valid?'Validated':S.build_exists?'Check required':'Not generated'}</strong></div></div>
${blocked()?notice('Hardware is not ready for an unattended installation.','block'):''}`;
}
function component(name,items,total){const visible=(items||[]).slice(0,120),count=Number(total??items?.length??0);return `<details class="device-group"><summary>${esc(name)}<span class="summary-right">${count} ${icon('chevron','chev')}</span></summary><ul class="device-list">${visible.length?visible.map(d=>`<li>${esc(d.name||'Unnamed device')}</li>`).join(''):'<li>Not detected</li>'}${count>visible.length?`<li>${count-visible.length} more devices in full scan</li>`:''}</ul></details>`}
function deviceSelector(){const groups=S.device_choices||{};const entries=Object.entries(groups);if(!entries.length)return '';return `<div class="surface"><div class="surface-top"><h2>Device selection</h2></div><div class="device-select-grid">${entries.map(([group,choices])=>`<div class="field"><label for="device-choice-${esc(group)}">${esc(group)}</label><select data-device-choice="${esc(group)}" id="device-choice-${esc(group)}"><option value="">Choose device</option>${choices.map(name=>`<option value="${esc(name)}">${esc(name)}</option>`).join('')}</select></div>`).join('')}</div></div>`}
function findings(){const f=S.compatibility?.findings||[];if(!f.length)return '<div class="minor">Run a scan first.</div>';return `<ul class="review-list">${f.map(x=>`<li class="${x.level==='block'?'block':''}">${icon(x.level==='block'?'warning':'info')}<div><b>${esc(x.label)}</b><small>${esc(x.detail)}</small></div></li>`).join('')}</ul>`}
function hardware(){const h=S.hardware||{};return `${pageHeading('Hardware',`${btn(`${icon('refresh')} Scan`,'scan','secondary',!!running())}${btn('Deep scan','deep-scan','primary',!!running())}`)}${demoNotice()}${taskBanner()}${taskError()}
${!S.hardware?`<div class="empty-state">${icon('cpu')}No hardware detected.</div>`:`<div class="surface"><div class="surface-top"><h2>System</h2><span class="status-text ${blocked()?'bad':'warn'}">${blocked()?'Review required':'Detected'}</span></div><div class="dim-hardware">
<div class="hardware-row"><span>CPU</span><strong>${esc(h.cpu?.name)}</strong></div>
<div class="hardware-row"><span>GPU</span><strong>${esc(h.gpus?.length?([...(h.gpus||[]).slice(0,3).map(x=>x.name),...((h.device_counts?.gpus||h.gpus.length)>3?[`+ ${(h.device_counts?.gpus||h.gpus.length)-3} more`]:[])].join(', ')):'—')}</strong></div>
<div class="hardware-row"><span>Motherboard</span><strong>${esc([h.motherboard?.manufacturer,h.motherboard?.name].filter(Boolean).join(' '))}</strong></div>
<div class="hardware-row"><span>Firmware</span><strong>${esc(h.firmware?.type||'—')}</strong></div>
<div class="hardware-row"><span>Platform</span><strong>${esc(h.motherboard?.platform||'—')}</strong></div>
<div class="hardware-row"><span>Secure Boot</span><strong>${esc(h.firmware?.secure_boot||'Unknown')}</strong></div>
</div></div>
${deviceSelector()}<div class="two-col"><section class="surface"><div class="surface-top"><h2>Devices</h2></div>${component('Graphics',h.gpus,h.device_counts?.gpus)}${component('Network',h.network,h.device_counts?.network)}${component('Audio',h.audio,h.device_counts?.audio)}${component('Storage',h.storage,h.device_counts?.storage)}${component('USB',h.usb,h.device_counts?.usb)}</section><section class="surface"><div class="surface-top"><h2>Compatibility</h2></div>${findings()}</section></div>`}
<div class="surface"><div class="surface-top"><h2>Tools</h2><span class="status-text ${S.deep_scan_ready?'good':'subtle'}">${S.deep_scan_ready?'ACPI ready':'ACPI not collected'}</span></div><div class="btn-row">${btn(`${icon('download')} Import report`,'import','outline')}${S.demo?btn('Demo hardware','demo','outline'):''}</div><input type="file" id="import-file" accept=".json,application/json" hidden><details class="guide"><summary>${icon('info')} Scan guide ${icon('chevron')}</summary><ol><li>Scan detects basic hardware.</li><li>Deep scan collects ACPI files for SSDTs. It downloads and runs Hardware Sniffer with your permission.</li><li>Some systems require administrator access.</li></ol></details></div>`}
function prerequisite(label,description,ok,action,actionText){return `<div class="build-row"><div><div class="build-row-name">${label}</div><div class="build-row-desc">${description}</div></div><div class="right">${ok?stateMark(true):btn(actionText,action,'secondary',!!running())}</div></div>`}
function build(){const b=S.last_build,can=ready();return `${pageHeading('Generate EFI',btn(`${icon('folder')} Open files`,'open-output','outline'))}${taskBanner()}${taskError()}${demoNotice()}
${deviceSelector()}<div class="surface"><div class="surface-top"><h2>Requirements</h2><span class="status-text ${can?'good':'warn'}">${can?'Ready':'Incomplete'}</span></div>
${prerequisite('Deep scan','Hardware + ACPI',S.deep_scan_ready,'deep-scan','Scan')}
${prerequisite('EFI engine','OpCore-Simplify',S.engine_ready,'engine','Download')}
${prerequisite('Compatibility',blocked()?'Hardware blocker detected':'Hardware review',!!S.compatibility?.can_attempt,'navigate-hardware','Review')}
<div class="hr"></div><div class="form-section"><div class="field"><label for="macos-target">macOS version</label><select id="macos-target"><option value="auto">Automatic</option><option value="25">macOS 26 Tahoe</option><option value="24">macOS 15 Sequoia</option><option value="23">macOS 14 Sonoma</option><option value="22">macOS 13 Ventura</option><option value="21">macOS 12 Monterey</option><option value="20">macOS 11 Big Sur</option></select></div><div class="btn-row" style="margin-top:17px">${btn(`${icon('layers')} Generate EFI`,'build','primary',!can||!!running())}${btn('Auto setup','auto-setup','secondary',!!running()||S.demo||blocked())}${btn('Validate','validate','outline',!S.build_exists||!!running())}</div></div>
<details class="guide"><summary>${icon('info')} Build guide ${icon('chevron')}</summary><ol><li>Deep scan and download the engine.</li><li>Choose a macOS version or use Automatic.</li><li>Generate EFI; only validated EFI files can be copied to USB.</li></ol></details></div>
${b?`<div class="surface"><div class="surface-top"><h2>Validation</h2><span class="status-text ${b.valid?'good':'bad'}">${b.valid?'Passed':'Failed'}</span></div>${b.valid?'<span class="minor">EFI files and configuration checked.</span>':''}${(b.errors||[]).length?`<ul class="review-list">${b.errors.map(e=>`<li class="block">${icon('warning')}<div>${esc(e)}</div></li>`).join('')}</ul>`:''}${(b.warnings||[]).length?`<details class="guide"><summary>Warnings (${b.warnings.length}) ${icon('chevron')}</summary><ul class="review-list">${b.warnings.map(e=>`<li>${icon('info')}<div>${esc(e)}</div></li>`).join('')}</ul></details>`:''}<div class="btn-row" style="margin-top:18px">${btn('Open logs','navigate-diagnostics','outline')}</div></div>`:''}
${blocked()?notice('Generation is blocked until the hardware compatibility issue is resolved.','block'):''}`}
function usbView(){const pending=(S.usb_recovery||[]);return `${pageHeading('USB',btn(`${icon('refresh')} Refresh`,'refresh-usb','outline'))}${taskBanner()}${taskError()}${pending.length?`<div class="notice block">${esc(pending.length)} interrupted USB transfer(s) · ${esc(pending.map(x=>x.letter).join(', '))}</div><div class="btn-row">${pending.map(x=>btn('Repair '+esc(x.letter)+':','repair-usb-'+esc(x.letter),'outline',!!running()||x.phase==='corrupt')).join('')}</div>`:''}
<div class="surface"><div class="surface-top"><h2>Copy EFI</h2><span class="status-text ${S.last_build?.valid?'good':'warn'}">${S.last_build?.valid?'EFI checked':'Validation required'}</span></div><div class="form-section"><div class="field"><label for="usb-target">USB drive · FAT32</label><select id="usb-target">${usb.length?(usb.length>1?'<option value="">Choose USB</option>':'')+usb.map(d=>`<option value="${esc(d.drive_letter)}">${esc(d.drive_letter)}: · ${esc(d.name||'USB drive')} (${esc(d.filesystem||'FAT32')})</option>`).join(''):'<option value="">No removable FAT32 drive</option>'}</select></div><div class="btn-row" style="margin-top:17px">${btn(`${icon('usb')} ${S.recovery_ready?'Copy EFI + recovery':'Copy EFI'}`,'usb-copy','primary',!usb.length||!S.last_build?.valid||!!running())}${btn(`${icon('folder')} Open EFI`,'open-output','outline')}</div></div><details class="guide"><summary>${icon('info')} USB guide ${icon('chevron')}</summary><ol><li>Use an existing FAT32 partition on a removable USB.</li><li>Copying backs up an existing EFI folder. It does not format the disk.</li><li>A macOS recovery or installer is also required.</li></ol></details></div>
<div class="two-col"><section class="surface"><div class="surface-top"><h2>Recovery</h2><span class="status-text ${S.recovery_ready?'good':'subtle'}">${S.recovery_ready?'Signature verified':'Optional'}</span></div><div class="field"><label for="board-id">Recovery board ID (optional)</label><input id="board-id" spellcheck="false" autocomplete="off" placeholder="Automatic from EFI target"></div><div class="btn-row" style="margin-top:15px">${btn(`${icon('download')} Download`,'recovery','secondary',!!running())}</div><details class="guide"><summary>${icon('info')} Recovery guide ${icon('chevron')}</summary><p>A recovery source is selected automatically from your generated macOS version. Advanced users may specify a documented board ID.</p></details></section>
<section class="surface"><div class="surface-top"><h2>BIOS checklist</h2></div>${S.bios_checklist?.length?`<details class="device-group"><summary>Review settings <span class="summary-right">${S.bios_checklist.length} ${icon('chevron','chev')}</span></summary><ul class="review-list">${S.bios_checklist.map(x=>`<li>${icon('info')}<div><b>${esc(x.title)}</b><small>${esc(x.detail)}</small></div></li>`).join('')}</ul></details>`:'<span class="minor">Scan to view firmware guidance.</span>'}</section></div>`}

function usbMapView(){
  const m=S.usb_mapping||{},controllers=m.controllers||[];
  const types=[[0,'USB 2 Type-A'],[3,'USB 3 Type-A'],[8,'USB-C (USB 2)'],[9,'USB-C (switch)'],[10,'USB-C (no switch)'],[255,'Internal'],[1,'Mini-AB'],[2,'ExpressCard'],[4,'USB 3 Type-B'],[5,'Micro-B'],[6,'Micro-AB'],[7,'USB 3 Power-B']];
  return `${pageHeading('USB Mapping',btn(`${icon('refresh')} Scan ports`,'usb-map-scan','primary',!!running()))}${taskBanner()}${taskError()}
<div class="surface"><div class="surface-top"><h2>Ports</h2><span class="status-text">${m.map_ready?(m.unseen_selected?`${m.unseen_selected} untested`: 'Map ready'):`${m.verified_ports||0} discovered`}</span></div>
${!controllers.length?'<div class="empty-state">Scan ports to begin.</div>':controllers.map(c=>`<div class="map-controller"><h3>${esc(c.name)}</h3><div class="map-port-list">${c.ports.map(p=>`<div class="map-port"><label class="map-port-label"><input type="checkbox" data-map-toggle="1" data-controller="${esc(c.id)}" data-port="${p.index}" ${p.selected?'checked':''} ${running()?'disabled':''}><strong>Port ${p.index}</strong><span class="map-port-seen">${p.active?'Connected':p.physically_seen?'Tested before':p.seen?'Companion inferred':'Not tested'}</span></label><select aria-label="Connector for port ${p.index}" data-map-type="1" data-controller="${esc(c.id)}" data-port="${p.index}" ${running()?'disabled':''}>${p.connector===null?'<option value="" selected>Choose type</option>':''}${types.map(([code,label])=>`<option value="${code}" ${p.connector===code?'selected':''}>${esc(label)}</option>`).join('')}</select></div>`).join('')}</div></div>`).join('')}
<div class="btn-row" style="margin-top:16px">${btn(`${icon('layers')} Build USB map`,'usb-map-build','primary',!controllers.length||!!running())}${m.map_ready?`<span class="status-text">${m.unseen_selected?'Review untested ports':'UTBMap.kext ready'}</span>`:''}</div>
<details class="guide"><summary>Quick guide ${icon('chevron')}</summary><ol><li>Plug a USB device into each port, then choose Scan ports again.</li><li>Check USB-C and internal connector types.</li><li>Build USB map. The next EFI generation adds UTBMap.kext automatically.</li></ol></details></div>`;
}
function diagnostics(){const b=S.last_build;return `${pageHeading('Logs',btn(`${icon('refresh')} Refresh`,'refresh-log','outline'))}${taskBanner()}${taskError()}
<div class="surface"><div class="surface-top"><h2>Build</h2><span class="status-text ${b?.valid?'good':b?'bad':'subtle'}">${b?.valid?'Passed':b?'Failed':'Not validated'}</span></div><div class="btn-row">${btn('Validate EFI','validate','secondary',!S.build_exists||!!running())}${btn(`${icon('folder')} Open files`,'open-output','outline')}${btn('Open log','open-log','outline')}</div><div class="hr"></div><pre class="logs" id="log-content">Loading log…</pre><details class="guide"><summary>${icon('info')} Sharing logs ${icon('chevron')}</summary><p>Remove serial numbers, UUIDs and other identifiers before sharing.</p></details></div><div class="surface"><div class="surface-top"><h2>Boot log</h2></div><div class="btn-row">${btn('Analyze log','import-boot-log','outline')}</div><input type="file" id="boot-log-file" accept=".txt,.log,text/plain" hidden>${S.diagnosis?`<ul class="review-list">${(S.diagnosis.findings||[]).map(x=>`<li>${icon('info')}<div><b>${esc(x.problem)}</b><small>${esc(x.next_step)}</small></div></li>`).join('')||'<li>No known patterns detected.</li>'}</ul>`:''}</div><div class="minor mono">${esc(S.paths?.output||'')}</div>`}
const pages={home:overview,hardware,build,usbmap:usbMapView,usb:usbView,diagnostics};
const titles={home:'Overview',hardware:'Hardware',build:'EFI',usbmap:'USB Map',usb:'USB',diagnostics:'Logs'};
function render(){
  captureFields();
  const active=document.activeElement;
  const activeId=active?.closest('#page')&&active.id;
  const selection=(activeId&&typeof active.selectionStart==='number')?[active.selectionStart,active.selectionEnd]:null;
  if(renderedView){
    document.querySelectorAll('#page details').forEach((el,i)=>expandedPanels.set(`${renderedView}-${i}`,el.open));
  }
  id('current-label').textContent='HackPilot';
  if(id('app-version')&&S.version)id('app-version').textContent='v'+String(S.version).split('-')[0];
  const [st,kind]=shortStatus();
  id('header-status').textContent=st;
  id('header-status-dot').className='status-dot '+kind;
  document.querySelectorAll('[data-view]').forEach(b=>{
    const selected=b.dataset.view===view;
    b.classList.toggle('active',selected);
    b.setAttribute('aria-current',selected?'page':'false');
  });
  id('page').innerHTML=pages[view]();
  renderedView=view;
  document.querySelectorAll('#page details').forEach((el,i)=>{
    if(expandedPanels.has(`${view}-${i}`))el.open=expandedPanels.get(`${view}-${i}`);
  });
  if(id('macos-target'))id('macos-target').value=fields.target;
  document.querySelectorAll('[data-device-choice]').forEach(el=>{if(fields.selections[el.dataset.deviceChoice]&&Array.from(el.options).some(x=>x.value===fields.selections[el.dataset.deviceChoice]))el.value=fields.selections[el.dataset.deviceChoice]});
  if(id('board-id'))id('board-id').value=fields.board;
  if(id('usb-target')&&fields.drive&&Array.from(id('usb-target').options).some(x=>x.value===fields.drive))id('usb-target').value=fields.drive;
  if(activeId){const next=id(activeId);if(next){next.focus({preventScroll:true});if(selection)try{next.setSelectionRange(...selection)}catch(_){}}}
}
async function refresh(show=true){try{const old=priorTasks;const next=await get('status');const nextSig=JSON.stringify(next);const changed=signature!==nextSig;S=next;signature=nextSig;Object.entries(S.tasks||{}).forEach(([key,t])=>{if(old[key]?.state==='running'&&t.state!=='running'){toast(t.state==='done'?`${t.name} complete`:t.message,t.state!=='done');if(t.name==='Automatic EFI build'||t.name==='Auto setup')view=t.state==='done'?'build':'diagnostics';if(t.name==='One-click USB setup')view=t.state==='done'?'home':'diagnostics'}});priorTasks=JSON.parse(JSON.stringify(S.tasks||{}));if(changed&&show){render();if(view==='diagnostics')await loadLog()}}catch(e){toast(e.message,true)}}
async function loadLog(){try{const data=await get('build-log');if(id('log-content'))id('log-content').textContent=data.log||'No logs yet.'}catch(e){if(id('log-content'))id('log-content').textContent=e.message}}
async function switchView(to){captureFields();view=to;render();if(to==='usb')await refreshUsb();if(to==='diagnostics')await loadLog()}
async function refreshUsb(){try{const result=await get('usb');usb=(result.usb||[]).filter(d=>String(d.filesystem).toUpperCase()==='FAT32');if(!usb.some(d=>String(d.drive_letter).toUpperCase()===fields.drive)){fields.drive=usb.length===1?String(usb[0].drive_letter).toUpperCase():'';}if(view==='usb'||view==='home')render()}catch(e){usb=[];if(view==='usb'||view==='home')render();toast(e.message,true)}}
async function act(name){try{if(name.startsWith('navigate-'))return await switchView(name.slice(9));
if(name==='one-click'){
  captureFields();const letter=String(fields.drive||id('usb-target')?.value||'').toUpperCase().trim();
  if(!/^[A-Z]$/.test(letter))throw new Error('Select a USB drive');
  const target=usb.find(d=>String(d.drive_letter).toUpperCase()===letter);
  if(!target)throw new Error('USB disconnected. Refresh the USB list.');
  if(!S.usb_mapping?.map_ready&&!confirm('USB ports have not been mapped. You can map them inside HackPilot first. Continue with a temporary USB configuration?'))return;
  if(!confirm(`Prepare USB ${letter}: (${target.name||'removable USB'})?\n\nHackPilot will scan, generate and validate EFI, download Apple recovery, and copy both to this USB. Existing EFI files will be backed up.\n\nThe drive will NOT be formatted or erased.`))return;
  await post('one-click',{consent:true,letter,confirm:`PREPARE ${letter}:`,target:fields.target||'auto',board_id:fields.board.trim(),selections:fields.selections});
  toast('Preparing EFI and USB');return await switchView('home');
}
if(name==='usb-map-scan'){if(!confirm('Scan USB ports using USBToolBox? The app downloads its open-source scanner and reads USB controller data. It does not modify disks.'))return;await post('usb-map-scan',{consent:true});toast('USB scan started');return await switchView('usbmap')}
if(name==='usb-map-build'){await post('usb-map-build');toast('Building USB map');return await switchView('usbmap')}
if(name==='auto-setup'){captureFields();if(!confirm('Auto setup will download and run Hardware Sniffer and OpCore-Simplify. It will generate an EFI locally but will NOT touch any USB or system disks. Continue?'))return;await post('auto-setup',{consent:true,target:fields.target||'auto',selections:fields.selections});toast('Auto setup started');return await switchView('home')}
if(name==='scan'){await post('scan');toast('Scanning hardware');return await switchView('hardware')}
if(name==='deep-scan'){if(!confirm('Deep scan downloads and runs Hardware Sniffer. It may need administrator access. Continue?'))return;await post('deep-scan',{consent:true});toast('Deep scan started');return await switchView('hardware')}
if(name==='engine'){if(!confirm('Download and run the OpCore-Simplify engine from GitHub?'))return;await post('engine',{consent:true});toast('Preparing engine');return await switchView('build')}
if(name==='build'){captureFields();if(!confirm('Generate EFI with the detected hardware? No disks will be changed.'))return;await post('build',{target:fields.target||'auto',selections:fields.selections});toast('Generating EFI');return await switchView('build')}
if(name==='validate'){await post('validate');toast('Validating EFI');return await switchView('build')}
if(name==='demo'){await post('demo');await refresh();return await switchView('hardware')}
if(name==='import'){id('import-file')?.click();return}
if(name==='import-boot-log'){id('boot-log-file')?.click();return}
if(name==='open-output'||name==='open-log'){await post(name);return}
if(name==='refresh-usb'){await refreshUsb();return}
if(name==='recovery'){captureFields();const board=fields.board.trim();if(board&&!/^Mac-[A-Fa-f0-9]{8,20}$/.test(board))throw new Error('Enter a valid Mac board ID');if(!confirm('Download macOS recovery files from Apple using OpenCore macrecovery?'))return;await post('recovery',{board_id:board,consent:true});toast('Recovery download started');return}
if(name.startsWith('repair-usb-')){const letter=name.slice(11).toUpperCase();const check=`REPAIR ${letter}:`;const typed=prompt(`Restore or finish the interrupted USB transfer on ${letter}:?\n\nType ${check}`);if(typed===null)return;await post('usb-repair',{letter,confirm:typed});toast('USB repair started');return await switchView('usb')}
if(name==='usb-copy'){captureFields();const letter=(fields.drive||id('usb-target')?.value||'').toUpperCase();if(!letter)throw new Error('Select a USB drive');const check=`COPY TO ${letter}:`;const typed=prompt(`Copy to ${letter}:? Existing EFI will be backed up. No formatting or partition changes.\n\nType ${check}`);if(typed===null)return;await post('usb-copy',{letter,confirm:typed});toast('USB copy started');return}
if(name==='refresh-log'){await loadLog();return}
}catch(e){toast(e.message,true)}}
document.querySelectorAll('[data-icon]').forEach(el=>el.innerHTML=icon(el.dataset.icon));
document.addEventListener('click',event=>{const v=event.target.closest('[data-view]');if(v)return void switchView(v.dataset.view);const a=event.target.closest('[data-action]');if(a&&!a.disabled)void act(a.dataset.action)});
document.addEventListener('change',async event=>{if(event.target.dataset.mapToggle||event.target.dataset.mapType){const el=event.target;const c=el.dataset.controller;const port=Number(el.dataset.port);const row=el.closest('.map-port');const checkbox=row?.querySelector('[data-map-toggle]');const connector=row?.querySelector('[data-map-type]');if(!checkbox||!connector||connector.value===''){toast('Choose a connector type');return;}try{await post('usb-map-port',{controller:c,index:port,selected:checkbox.checked,connector:Number(connector.value)});await refresh()}catch(e){toast(e.message,true);await refresh()}return;}if(event.target.id==='macos-target')fields.target=event.target.value;if(event.target.id==='board-id')fields.board=event.target.value;if(event.target.id==='usb-target')fields.drive=event.target.value;if(event.target.dataset.deviceChoice){if(event.target.value)fields.selections[event.target.dataset.deviceChoice]=event.target.value;else delete fields.selections[event.target.dataset.deviceChoice]}if(event.target.id==='boot-log-file'){const file=event.target.files?.[0];if(!file)return;try{if(file.size>250000)throw new Error('Boot log must be under 250 KB');await post('diagnose',{log:await file.text()});await refresh();toast('Boot log analyzed')}catch(e){toast(e.message,true)}return}
if(event.target.id!=='import-file')return;const file=event.target.files?.[0];if(!file)return;try{const report=JSON.parse(await file.text());await post('import',report);await refresh();toast('Hardware report imported')}catch(e){toast(e.message,true)}});
document.addEventListener('input',event=>{if(event.target.id==='board-id')fields.board=event.target.value});
void refresh();void refreshUsb();setInterval(()=>void refresh(),3000);setInterval(()=>{if(view==='home'||view==='usb')void refreshUsb()},15000);
