'use strict';
const TOKEN=document.querySelector('meta[name="hackpilot-token"]').content;
const ICONS={
 home:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
 cpu:'<rect x="5" y="5" width="14" height="14" rx="2"/><path d="M9 9h6v6H9zM9 1v4M15 1v4M9 19v4M15 19v4M1 9h4M1 15h4M19 9h4M19 15h4"/>',
 layers:'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 8h8v8H8z"/>',
 usb:'<path d="M12 2v14m0-14-3 3m3-3 3 3M5 12h14M5 12v4m14-4v4M5 16a2 2 0 1 0 0 4 2 2 0 0 0 0-4m12 0h4v4h-4zM12 16v6"/>',
 terminal:'<rect x="2" y="4" width="20" height="16" rx="3"/><path d="m6 9 3 3-3 3m6 0h6"/>',
 arrow:'<path d="M5 12h14m-6-6 6 6-6 6"/>',
 check:'<path d="m5 12 5 5L20 7"/>',
 chevron:'<path d="m6 9 6 6 6-6"/>',
 refresh:'<path d="M20 11a8 8 0 0 0-14-5L4 8m0-5v5h5M4 13a8 8 0 0 0 14 5l2-2m0 5v-5h-5"/>',
 warning:'<path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5m0 4h.01"/>',
 info:'<circle cx="12" cy="12" r="10"/><path d="M12 11v6m0-10h.01"/>',
 folder:'<path d="M3 6h7l2 2h9v11H3z"/>',
 download:'<path d="M12 3v12m-4-4 4 4 4-4M4 18v3h16v-3"/>',
 search:'<circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/>',
 shield:'<path d="m12 2 9 4v6c0 5-3.5 8.4-9 10-5.5-1.6-9-5-9-10V6z"/>',
 harddrive:'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 13h18m-14 4h.01m4 0h.01"/>'
};
const icon=(name,cls='')=>`<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name]||ICONS.info}</svg>`;
const esc=x=>String(x??'—').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const id=x=>document.getElementById(x);
let S={hardware:null,compatibility:{findings:[],can_attempt:false},tasks:{}},view='home',usb=[],usbDisks=[],priorTasks={},signature='',fields={target:'auto',board:'',drive:'',selections:{}},toastTimer,renderedView=null, mappingSkipped=false, buildOptionsDirty=false, pendingAction=false, statusEpoch=0;
const expandedPanels=new Map();
async function get(path){const r=await fetch('/api/'+path,{cache:'no-store'});const data=await r.json();if(!r.ok)throw new Error(data.error||'Request failed');return data}
async function post(path,body={}){const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json','X-HackPilot-Token':TOKEN},body:JSON.stringify(body)});const data=await r.json();if(!r.ok)throw new Error(data.error||'Operation failed');if(data.task_id){statusEpoch++;priorTasks[data.task_id]={state:'running'};S.tasks[data.task_id]={name:({'deep-scan':'Deep hardware scan','scan':'Hardware scan','auto-setup':'Auto setup','build':'Automatic EFI build','recovery':'Apple recovery download','usb-copy':'Safe USB copy'})[path]||'Setup task',state:'running',message:'Starting…'};}return data}
function toast(message,error=false){const t=id('toast');t.textContent=(error?'Error · ':'')+message;t.className='toast'+(error?' error':'');t.style.display='block';clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.style.display='none',6500)}
const running=()=>Object.values(S.tasks||{}).find(t=>t.state==='running');
const blocked=()=>S.compatibility?.status==='blocked';
const ready=()=>!!(S.deep_scan_ready&&S.engine_ready&&S.compatibility?.can_attempt&&!S.hardware?.origin?.startsWith('Synthetic'));
function shortStatus(){if(running())return ['Working','warn'];if(blocked())return ['Needs review','bad'];if(S.last_build?.valid&&!buildOptionsDirty)return ['EFI checked','good'];if(ready())return ['Scan complete','good'];if(S.hardware)return ['Scanned','warn'];return ['Not scanned','idle']}
function captureFields(){for(const [element,key] of [['format-filesystem','formatFilesystem'],['format-style','formatStyle']]){const el=id(element);if(el)fields[key]=el.value;}const f=id('format-disk');if(f)fields.formatDisk=f.value;const t=id('macos-target'),b=id('board-id'),d=id('usb-target');if(t)fields.target=t.value;if(b)fields.board=b.value;if(d)fields.drive=d.value;document.querySelectorAll('[data-device-choice]').forEach(el=>{if(el.value)fields.selections[el.dataset.deviceChoice]=el.value;else delete fields.selections[el.dataset.deviceChoice]})}
function btn(label,action,kind='secondary',disabled=false,extra=''){return `<button class="btn btn-${kind}" type="button" data-action="${esc(action)}" ${disabled?'disabled':''} ${extra}>${label}</button>`}
function pageHeading(title,actions=''){return `<div class="page-heading"><h1>${title}</h1><div class="btn-row">${actions}</div></div>`}
function taskBanner(){const task=running();if(!task)return '';const pct=Math.max(0,Math.min(100,Number(task.percent)||0));return `<div class="task-indicator" role="status"><span class="spinner"></span><div class="task-body"><div class="task-row"><strong>${esc(task.message||task.name)}</strong><span>${pct?pct+'%':'Working'}</span></div><div class="task-track"><span style="width:${pct}%"></span></div></div></div>`}
function taskError(){const t=Object.values(S.tasks||{}).slice(-1)[0];return t?.state==='error'?notice(t.message,'block'):''}
function demoNotice(){return S.hardware?.origin?.startsWith('Synthetic')?'<div class="notice">Demo hardware · Generation disabled</div>':''}
function notice(message,kind='info'){return `<div class="notice ${kind}">${esc(message)}</div>`}
function stateMark(ok){return ok?`<span class="status-text good">${icon('check')} Done</span>`:'<span class="status-text subtle">Pending</span>'}
function usbOptions(){
  return usb.map(d=>`<option value="${esc(d.drive_letter)}">${esc(d.drive_letter)}: · ${esc(d.name||'USB')} · ${Math.round(Number(d.capacity||0)/1073741824)} GB</option>`).join('');
}
// Keep the recommended path explicit, while leaving logs available for failures.
const scanComplete=()=>!!(S.deep_scan_ready&&S.hardware&&!S.hardware.origin?.startsWith('Synthetic'));
const mapComplete=()=>!!(scanComplete()&&S.usb_mapping?.map_ready&&!S.usb_mapping?.unseen_selected);
const efiReady=()=>!!(scanComplete()&&S.last_build?.valid&&!buildOptionsDirty);
const recoveryReady=()=>!!S.recovery_for_efi;
const portDecision=()=>mapComplete()||mappingSkipped;
function viewAllowed(to){
  if(['home','hardware','diagnostics'].includes(to))return true;
  if(to==='usbtools')return scanComplete();
  if(!scanComplete()||blocked()||!S.compatibility?.can_attempt)return false;
  if(to==='usbmap')return true;
  if(to==='build')return portDecision();
  if(to==='usb')return portDecision()&&efiReady();
  return false;
}
function setupStage(){
  if(!scanComplete()||blocked()||!S.compatibility?.can_attempt)return 0;
  if(!portDecision())return 1;
  if(!efiReady())return 2;
  return 3;
}
const stageViews=['hardware','usbmap','build','usb'];
function flowCard(number,title,description,label,action,disabled=false,secondary=''){
  return `<section class="hero flow-hero"><div class="flow-copy"><div class="hero-overline">STEP ${number} OF 4</div><h2>${esc(title)}</h2><p>${esc(description)}</p></div><div class="flow-actions">${label?btn(esc(label)+' '+icon('arrow'),action,'primary',disabled||!!running()||pendingAction):''}${secondary}</div></section>`;
}
function overview(){
  const stage=setupStage(),finished=stage===3&&S.usb_prepared;
  const choices=[['Scan this PC first','Detect your hardware and collect the ACPI files needed for your EFI.','Scan hardware','deep-scan'],['Map your USB ports','Test your ports before building the EFI, or explicitly continue with a temporary configuration.','Set up USB ports','navigate-usbmap'],['Create your EFI','Choose macOS, then generate and validate the files for this PC.','Set up EFI','navigate-build'],['Prepare your installer USB','Download Apple recovery, choose a USB and copy the checked files.','Continue to USB','navigate-usb']];
  let [title,description,label,action]=choices[stage];
  if(stage===0&&scanComplete()) [title,description,label,action]=['Review hardware','Resolve the compatibility findings before continuing.','Review findings','navigate-hardware'];
  if(finished)[title,description,label,action]=['USB files verified','EFI and recovery were copied and checked. Review the BIOS checklist before trying to boot.','Review boot checklist','navigate-usb'];
  return `${pageHeading('Your setup')}${demoNotice()}${taskBanner()}${taskError()}${flowCard(finished?4:stage+1,title,description,label,action)}
<div class="section-bar"><h2 class="section-title">Your path</h2><span class="minor">${finished?'Files ready':`Step ${stage+1} of 4`}</span></div><div class="progress-list">${[
 ['Hardware','Scan and review this PC',scanComplete(),'hardware'],
 ['USB ports',mappingSkipped&&!mapComplete()?(S.usb_mapping?.map_ready?'Untested ports accepted':'Temporary configuration chosen'):'Test ports and build a map',portDecision(),'usbmap'],
 ['EFI','Generate and validate your configuration',efiReady(),'build'],
 ['Installer USB','Apple recovery and verified file copy',efiReady()&&S.usb_prepared,'usb']
 ].map(([name,description,done,to],i)=>`<button class="progress-item ${stage===i?'current':''}" type="button" data-action="navigate-${to}" ${!viewAllowed(to)?'disabled':''}><span class="progress-left"><span class="progress-index ${done?'complete':''}">${done?icon('check'):i+1}</span><span><span class="progress-name">${name}</span><span class="progress-secondary">${description}</span></span></span><span class="progress-right">${done?'Done':!viewAllowed(to)?'Later':stage===i?'Current':icon('arrow')}</span></button>`).join('')}</div>
${scanComplete()?`<div class="section-bar"><h2 class="section-title">This PC</h2>${btn('Review hardware','navigate-hardware','quiet')}</div><div class="metric-grid"><div class="metric"><span class="label">CPU</span><strong>${esc(S.hardware.cpu?.name)}</strong></div><div class="metric"><span class="label">GPU</span><strong>${esc(S.hardware.gpus?.[0]?.name)}</strong></div><div class="metric"><span class="label">EFI</span><strong>${efiReady()?'Checked':'Not ready'}</strong></div></div>`:''}`;
}
function component(name,items,total){const visible=(items||[]).slice(0,120),count=Number(total??items?.length??0);return `<details class="device-group"><summary>${esc(name)}<span class="summary-right">${count} ${icon('chevron','chev')}</span></summary><ul class="device-list">${visible.length?visible.map(d=>`<li>${esc(d.name||'Unnamed device')}</li>`).join(''):'<li>Not detected</li>'}${count>visible.length?`<li>${count-visible.length} more devices in full scan</li>`:''}</ul></details>`}
function deviceSelector(){const groups=S.device_choices||{};const entries=Object.entries(groups);if(!entries.length)return '';return `<div class="surface"><div class="surface-top"><h2>Device selection</h2></div><div class="device-select-grid">${entries.map(([group,choices])=>`<div class="field"><label for="device-choice-${esc(group)}">${esc(group)}</label><select data-device-choice="${esc(group)}" id="device-choice-${esc(group)}"><option value="">Choose device</option>${choices.map(name=>`<option value="${esc(name)}">${esc(name)}</option>`).join('')}</select></div>`).join('')}</div></div>`}
function findings(){const f=S.compatibility?.findings||[];if(!f.length)return '<div class="minor">Run a scan first.</div>';return `<ul class="review-list">${f.map(x=>`<li class="${x.level==='block'?'block':''}">${icon(x.level==='block'?'warning':'info')}<div><b>${esc(x.label)}</b><small>${esc(x.detail)}</small></div></li>`).join('')}</ul>`}
function hardware(){const h=S.hardware||{};return `${pageHeading('Hardware')}${demoNotice()}${taskBanner()}${taskError()}${flowCard(1,scanComplete()?'Review your hardware':'Scan this PC',scanComplete()?(blocked()?'Review the compatibility findings below. Setup cannot continue while a blocker remains.':'Check the detected components below, then continue to USB ports.'):'One full scan detects components and collects ACPI files. Your USB is not needed yet.',scanComplete()?'Continue to USB ports':'Scan hardware',scanComplete()?'navigate-usbmap':'deep-scan',scanComplete()&&(!S.compatibility?.can_attempt||blocked()))}
${!S.hardware?`<div class="empty-state">${icon('cpu')}No hardware detected.</div>`:`<div class="surface"><div class="surface-top"><h2>System</h2><span class="status-text ${blocked()?'bad':'warn'}">${blocked()?'Review required':'Detected'}</span></div><div class="dim-hardware">
<div class="hardware-row"><span>CPU</span><strong>${esc(h.cpu?.name)}</strong></div>
<div class="hardware-row"><span>GPU</span><strong>${esc(h.gpus?.length?([...(h.gpus||[]).slice(0,3).map(x=>x.name),...((h.device_counts?.gpus||h.gpus.length)>3?[`+ ${(h.device_counts?.gpus||h.gpus.length)-3} more`]:[])].join(', ')):'—')}</strong></div>
<div class="hardware-row"><span>Motherboard</span><strong>${esc([h.motherboard?.manufacturer,h.motherboard?.name].filter(Boolean).join(' '))}</strong></div>
<div class="hardware-row"><span>Firmware</span><strong>${esc(h.firmware?.type||'—')}</strong></div>
<div class="hardware-row"><span>Platform</span><strong>${esc(h.motherboard?.platform||'—')}</strong></div>
<div class="hardware-row"><span>Secure Boot</span><strong>${esc(h.firmware?.secure_boot||'Unknown')}</strong></div>
</div></div>
${deviceSelector()}<div class="two-col"><section class="surface"><div class="surface-top"><h2>Devices</h2></div>${component('Graphics',h.gpus,h.device_counts?.gpus)}${component('Network',h.network,h.device_counts?.network)}${component('Audio',h.audio,h.device_counts?.audio)}${component('Storage',h.storage,h.device_counts?.storage)}${component('USB',h.usb,h.device_counts?.usb)}</section><section class="surface"><div class="surface-top"><h2>Compatibility</h2></div>${findings()}</section></div>`}
<details class="surface advanced-tools"><summary>Advanced hardware tools ${icon('chevron')}</summary><div class="surface-top"><h2>Scan tools</h2><span class="status-text ${S.deep_scan_ready?'good':'subtle'}">${S.deep_scan_ready?'ACPI ready':'ACPI not collected'}</span></div><div class="btn-row">${btn('Rescan hardware','deep-scan','outline',!!running())}${btn('Basic scan only','scan','outline',!!running())}${scanComplete()?btn('USB drive tools','navigate-usbtools','outline',!!running()):''}${btn(`${icon('download')} Import report`,'import','outline',!!running())}${S.demo?btn('Demo hardware','demo','outline'):''}</div><input type="file" id="import-file" accept=".json,application/json" hidden><details class="guide"><summary>${icon('info')} Scan guide ${icon('chevron')}</summary><ol><li>Scan detects basic hardware.</li><li>Deep scan collects ACPI files for SSDTs. It downloads and runs Hardware Sniffer with your permission.</li><li>Some systems require administrator access.</li></ol></details></details>`}
function prerequisite(label,description,ok,action,actionText){return `<div class="build-row"><div><div class="build-row-name">${label}</div><div class="build-row-desc">${description}</div></div><div class="right">${ok?stateMark(true):btn(actionText,action,'secondary',!!running())}</div></div>`}
function build(){const b=S.last_build,valid=efiReady();return `${pageHeading('Create your EFI')}${taskBanner()}${taskError()}${demoNotice()}
${valid?flowCard(3,'EFI checked','Your configuration passed validation. Continue with this EFI to prepare the installer USB.','Continue to installer USB','navigate-usb'):flowCard(3,'Generate and check your EFI','Choose macOS below. HackPilot prepares the EFI engine, builds for the scanned hardware and runs validation.','','')}
${mappingSkipped&&!mapComplete()?notice(S.usb_mapping?.map_ready?'You accepted untested ports in the USB map. Physically test those ports before relying on this configuration.':'USB port mapping was skipped. The EFI will use a temporary USB configuration; finish mapping before relying on it for daily use.'):''}
${buildOptionsDirty?notice('Your choices changed. Generate and check the EFI again before continuing.'):''}
${deviceSelector()}<section class="surface"><div class="surface-top"><h2>macOS and configuration</h2></div><div class="form-section"><div class="field"><label for="macos-target">macOS version</label><select id="macos-target"><option value="auto">Automatic · based on this hardware</option><option value="25">macOS 26 Tahoe</option><option value="24">macOS 15 Sequoia</option><option value="23">macOS 14 Sonoma</option><option value="22">macOS 13 Ventura</option><option value="21">macOS 12 Monterey</option><option value="20">macOS 11 Big Sur</option></select></div><div class="btn-row" style="margin-top:17px">${btn(valid?'Rebuild EFI':'Generate and check EFI','auto-setup',valid?'outline':'primary',!!running()||S.demo||blocked()||!scanComplete())}</div></div>
<details class="guide"><summary>Advanced EFI tools ${icon('chevron')}</summary>${prerequisite('Full hardware scan','Hardware and ACPI collected',S.deep_scan_ready,'deep-scan','Scan')}${prerequisite('EFI engine','OpCore-Simplify',S.engine_ready,'engine','Download')}<div class="btn-row" style="margin-top:15px">${btn('Generate with installed engine','build','outline',!ready()||!!running())}${btn('Validate existing EFI','validate','outline',!S.build_exists||!!running())}${btn('Open files','open-output','outline')}</div></details></section>
${b?`<section class="surface"><div class="surface-top"><h2>Validation result</h2><span class="status-text">${buildOptionsDirty?'Rebuild required':b.valid?'Passed':'Needs attention'}</span></div>${b.valid?'<p class="minor">EFI files and configuration checked. Boot compatibility still requires testing on this PC.</p>':''}${(b.errors||[]).length?`<ul class="review-list">${b.errors.map(e=>`<li>${icon('warning')}<div>${esc(e)}</div></li>`).join('')}</ul>`:''}${(b.warnings||[]).length?`<details class="guide"><summary>Warnings (${b.warnings.length}) ${icon('chevron')}</summary><ul class="review-list">${b.warnings.map(e=>`<li>${icon('info')}<div>${esc(e)}</div></li>`).join('')}</ul></details>`:''}${btn('View logs','navigate-diagnostics','outline')}</section>`:''}`}
function formatterView(){const available=usbDisks.some(d=>!d.reason);return `<section class="surface"><div class="surface-top"><h2>USB tools & recovery</h2></div><p>USB missing from File Explorer? Select the physical disk below and try <strong>Restore access</strong> first. It only assigns a drive letter to an existing recognized data volume.</p><div class="field"><label for="format-disk">Physical USB disk</label><select id="format-disk"><option value="">Choose a USB disk</option>${usbDisks.map(d=>`<option value="${esc(d.number)}" ${d.reason?'disabled':''}>Disk ${esc(d.number)} · ${esc(d.name||'USB')} · ${(Number(d.size)/1073741824).toFixed(1)} GiB · ${esc((d.partitions||[]).map(p=>(p.letter?p.letter+': ':'No letter · ')+(p.filesystem||'RAW')).join(', ')||'Unallocated / no partitions')}${d.reason?' — '+esc(d.reason):''}</option>`).join('')}</select></div><div class="btn-row" style="margin-top:12px">${btn('Restore access · no erase','usb-restore-access','primary',!!running()||S.demo||!available)}${btn('Refresh USB disks','refresh-usb','outline')}</div><details class="guide"><summary>Erase / rebuild USB and advanced tools</summary><p><strong>Erasing deletes every file and partition on the selected USB.</strong> If you need lost files, stop and use a data recovery tool first.</p><div class="two-col"><div class="field"><label for="format-filesystem">Filesystem</label><select id="format-filesystem"><option value="FAT32">FAT32 · HackPilot boot USB</option><option value="NTFS">NTFS · full-capacity ordinary storage</option><option value="exFAT">exFAT · full-capacity ordinary storage</option></select></div><div class="field"><label for="format-style">Partition scheme</label><select id="format-style"><option value="MBR">MBR · compatible default</option><option value="GPT">GPT · UEFI</option></select></div></div><p class="minor">FAT32 uses up to 30 GiB; remaining capacity stays unallocated. NTFS/exFAT use available capacity but cannot be selected for HackPilot EFI copying.</p><div class="btn-row">${btn('Erase and rebuild USB','usb-format','outline',!!running()||S.demo||!available)}${btn('Open official Rufus · advanced','open-rufus','outline',!!running()||S.demo)}</div><p class="minor">ISO/DD image writing, bad-block checks and other Rufus features open in the official Rufus window. HackPilot stays busy until that window closes.</p></details>${!usbDisks.length?'<p class="minor">No physical USB disks detected. Reconnect the USB and refresh. A missing drive letter alone should not hide a disk here.</p>':''}</section>`}

function usbToolsView(){return `${pageHeading('USB drive tools',btn('Back to setup','navigate-home','outline'))}${taskBanner()}${taskError()}${formatterView()}`}
function usbView(){const pending=S.usb_recovery||[],complete=S.usb_prepared&&efiReady();return `${pageHeading('Prepare installer USB')}${taskBanner()}${taskError()}
${complete?flowCard(4,'USB files verified','EFI and Apple recovery were copied and read-back checked. Review the BIOS settings below before booting.','',''):flowCard(4,recoveryReady()?'Copy to your USB':'Download Apple recovery',recoveryReady()?'Choose the FAT32 USB below, then copy and verify your installer files.':'Download recovery for the generated EFI first. Keep the app open until verification finishes.',recoveryReady()?'':'Download recovery',recoveryReady()?'':'recovery')}
${pending.length?`<div class="notice block">${esc(pending.length)} interrupted USB transfer(s) · ${esc(pending.map(x=>x.letter).join(', '))}</div><div class="btn-row">${pending.map(x=>btn('Repair '+esc(x.letter)+':','repair-usb-'+esc(x.letter),'outline',!!running()||x.phase==='corrupt')).join('')}</div>`:''}
<section class="surface"><div class="surface-top"><h2>${recoveryReady()?'Choose the installer USB':'Next: choose the installer USB'}</h2>${btn(`${icon('refresh')} Refresh drives`,'refresh-usb','quiet',!!running())}</div>
<p class="minor">${recoveryReady()?'Apple recovery is verified. Copying backs up an existing EFI folder and does not format the disk.':'Finish the recovery download above to enable copying.'}</p>
<div class="form-section"><div class="field"><label for="usb-target">Removable USB · FAT32</label><select id="usb-target">${usb.length?(usb.length>1?'<option value="">Choose USB</option>':'')+usbOptions():'<option value="">No ready FAT32 USB detected</option>'}</select></div><div class="btn-row" style="margin-top:17px">${btn(complete?'Copy to another USB':'Copy and verify installer files','usb-copy',complete?'outline':'primary',!usb.length||!recoveryReady()||!efiReady()||!!running()||(usb.length>1&&!fields.drive))}</div></div>
${!usb.length?'<p class="minor">USB missing or not FAT32? Open USB drive tools below. Formatting always requires a separate erase confirmation.</p>':''}
<details class="guide"><summary>USB drive tools and recovery options ${icon('chevron')}</summary>${formatterView()}<div class="field"><label for="board-id">Recovery board ID · optional</label><input id="board-id" spellcheck="false" autocomplete="off" placeholder="Automatic from your EFI"></div><div class="btn-row" style="margin-top:15px">${btn('Download recovery again','recovery','outline',!!running())}${btn('Copy available files · advanced','usb-copy-efi','outline',!usb.length||!efiReady()||!!running())}${btn('Open EFI files','open-output','outline')}</div></details></section>
<section class="surface"><div class="surface-top"><h2>Before you boot</h2></div>${complete?'<p class="minor">File preparation is complete. Actual boot and network support need testing on your PC.</p>':''}${S.bios_checklist?.length?`<details class="device-group" ${complete?'open':''}><summary>BIOS checklist <span class="summary-right">${S.bios_checklist.length} settings ${icon('chevron','chev')}</span></summary><ul class="review-list">${S.bios_checklist.map(x=>`<li>${icon('info')}<div><b>${esc(x.title)}</b><small>${esc(x.detail)}</small></div></li>`).join('')}</ul></details>`:'<p class="minor">Firmware guidance appears after scanning.</p>'}</section>`}

function usbMapView(){
  const m=S.usb_mapping||{},controllers=m.controllers||[];
  const types=[[0,'USB 2 Type-A'],[3,'USB 3 Type-A'],[8,'USB-C (USB 2)'],[9,'USB-C (switch)'],[10,'USB-C (no switch)'],[255,'Internal'],[1,'Mini-AB'],[2,'ExpressCard'],[4,'USB 3 Type-B'],[5,'Micro-B'],[6,'Micro-AB'],[7,'USB 3 Power-B']];
  return `${pageHeading('Map USB ports')}${taskBanner()}${taskError()}${flowCard(2,mapComplete()?'USB map ready':'Test the ports you use',mapComplete()?'Your selected ports have a map. Continue to include it in the EFI.':'Plug a USB device into each port and rescan. Review connector types, then build the map.',mapComplete()?'Continue to EFI':controllers.length?'Build USB map':'Scan USB ports',mapComplete()?'navigate-build':controllers.length?'usb-map-build':'usb-map-scan',false,!mapComplete()?btn(m.map_ready?'Continue with untested ports':'Continue without a map','skip-mapping','quiet',!!running()):'')}
<div class="surface"><div class="surface-top"><h2>Ports</h2><span class="status-text">${m.map_ready?(m.unseen_selected?`${m.unseen_selected} untested`: 'Map ready'):`${m.verified_ports||0} discovered`}</span></div>
${!controllers.length?'<div class="empty-state">Scan ports to begin.</div>':controllers.map(c=>`<div class="map-controller"><h3>${esc(c.name)}</h3><div class="map-port-list">${c.ports.map(p=>`<div class="map-port"><label class="map-port-label"><input type="checkbox" data-map-toggle="1" data-controller="${esc(c.id)}" data-port="${p.index}" ${p.selected?'checked':''} ${running()?'disabled':''}><strong>Port ${p.index}</strong><span class="map-port-seen">${p.active?'Connected':p.physically_seen?'Tested before':p.seen?'Companion inferred':'Not tested'}</span></label><select aria-label="Connector for port ${p.index}" data-map-type="1" data-controller="${esc(c.id)}" data-port="${p.index}" ${running()?'disabled':''}>${p.connector===null?'<option value="" selected>Choose type</option>':''}${types.map(([code,label])=>`<option value="${code}" ${p.connector===code?'selected':''}>${esc(label)}</option>`).join('')}</select></div>`).join('')}</div></div>`).join('')}
<div class="btn-row" style="margin-top:16px">${btn(`${icon('refresh')} Rescan ports`,'usb-map-scan','secondary',!!running())}${btn(`${icon('layers')} Build USB map`,'usb-map-build','outline',!controllers.length||!!running())}${m.map_ready?`<span class="status-text">${m.unseen_selected?'Review untested ports':'UTBMap.kext ready'}</span>`:''}</div>
<details class="guide"><summary>Quick guide ${icon('chevron')}</summary><ol><li>Plug a USB device into each port, then choose Scan ports again.</li><li>Check USB-C and internal connector types.</li><li>Build USB map. The next EFI generation adds UTBMap.kext automatically.</li></ol></details></div>`;
}
function diagnostics(){const b=S.last_build;return `${pageHeading('Logs',btn(`${icon('refresh')} Refresh`,'refresh-log','outline'))}${taskBanner()}${taskError()}
<div class="surface"><div class="surface-top"><h2>Build</h2><span class="status-text ${b?.valid?'good':b?'bad':'subtle'}">${b?.valid?'Passed':b?'Failed':'Not validated'}</span></div><div class="btn-row">${btn('Validate EFI','validate','secondary',!S.build_exists||!!running())}${btn(`${icon('folder')} Open files`,'open-output','outline')}${btn('Open log','open-log','outline')}</div><div class="hr"></div><pre class="logs" id="log-content">Loading log…</pre><details class="guide"><summary>${icon('info')} Sharing logs ${icon('chevron')}</summary><p>Remove serial numbers, UUIDs and other identifiers before sharing.</p></details></div><div class="surface"><div class="surface-top"><h2>Boot log</h2></div><div class="btn-row">${btn('Analyze log','import-boot-log','outline')}</div><input type="file" id="boot-log-file" accept=".txt,.log,text/plain" hidden>${S.diagnosis?`<ul class="review-list">${(S.diagnosis.findings||[]).map(x=>`<li>${icon('info')}<div><b>${esc(x.problem)}</b><small>${esc(x.next_step)}</small></div></li>`).join('')||'<li>No known patterns detected.</li>'}</ul>`:''}</div><div class="minor mono">${esc(S.paths?.output||'')}</div>`}
const pages={home:overview,hardware,build,usbmap:usbMapView,usb:usbView,usbtools:usbToolsView,diagnostics};
const titles={home:'Setup',hardware:'Hardware',build:'EFI',usbmap:'USB ports',usb:'Installer USB',usbtools:'USB tools',diagnostics:'Logs'};
function render(){
  captureFields();
  const active=document.activeElement;
  const activeId=active?.closest('#page')&&active.id;
  const selection=(activeId&&typeof active.selectionStart==='number')?[active.selectionStart,active.selectionEnd]:null;
  if(renderedView){
    document.querySelectorAll('#page details').forEach((el,i)=>expandedPanels.set(`${renderedView}-${i}`,el.open));
  }
  if(!viewAllowed(view))view=stageViews[setupStage()];
  id('current-label').textContent=titles[view];
  if(id('app-version')&&S.version)id('app-version').textContent='v'+String(S.version).split('-')[0];
  const [st,kind]=shortStatus();
  id('header-status').textContent=st;
  id('header-status-dot').className='status-dot '+kind;
  document.querySelectorAll('[data-view]').forEach(b=>{
    const selected=b.dataset.view===view;
    b.classList.toggle('active',selected);
    b.setAttribute('aria-current',selected?'page':'false');
    b.disabled=!viewAllowed(b.dataset.view);
    b.title=b.disabled?(scanComplete()?'Complete the earlier setup step first':'Scan this PC first'):titles[b.dataset.view];
  });
  id('page').innerHTML=pages[view]();
  document.querySelectorAll('#page select, #page input, #page button').forEach(el=>{if(running()||pendingAction)el.disabled=true;});
  renderedView=view;
  document.querySelectorAll('#page details').forEach((el,i)=>{
    if(expandedPanels.has(`${view}-${i}`))el.open=expandedPanels.get(`${view}-${i}`);
  });
  if(id('macos-target'))id('macos-target').value=fields.target;
  document.querySelectorAll('[data-device-choice]').forEach(el=>{if(fields.selections[el.dataset.deviceChoice]&&Array.from(el.options).some(x=>x.value===fields.selections[el.dataset.deviceChoice]))el.value=fields.selections[el.dataset.deviceChoice]});
  if(id('board-id'))id('board-id').value=fields.board;
  for(const [element,key,fallback] of [['format-filesystem','formatFilesystem','FAT32'],['format-style','formatStyle','MBR']]){if(id(element))id(element).value=fields[key]||fallback;}
  if(id('format-disk')&&fields.formatDisk&&Array.from(id('format-disk').options).some(x=>x.value===fields.formatDisk))id('format-disk').value=fields.formatDisk;
  if(id('usb-target')&&fields.drive&&Array.from(id('usb-target').options).some(x=>x.value===fields.drive))id('usb-target').value=fields.drive;
  if(activeId){const next=id(activeId);if(next){next.focus({preventScroll:true});if(selection)try{next.setSelectionRange(...selection)}catch(_){}}}
}
async function refresh(show=true){try{const epoch=statusEpoch;const next=await get('status');if(epoch!==statusEpoch)return;const old=priorTasks;const nextSig=JSON.stringify(next);const changed=signature!==nextSig;S=next;signature=nextSig;if(!scanComplete())mappingSkipped=false;Object.entries(S.tasks||{}).forEach(([key,t])=>{if(old[key]?.state==='running'&&t.state!=='running'){toast(t.state==='done'?`${t.name} complete`:t.message,t.state!=='done');if(t.state==='done'&&(t.name==='Automatic EFI build'||t.name==='Auto setup'))buildOptionsDirty=false;if((t.name.startsWith('Format USB')||t.name==='Restore USB access'||t.name.startsWith('Official Rufus'))){fields.drive=t.result?.letter||'';setTimeout(()=>void refreshUsb(),0)}if(t.name==='One-click USB setup')view=t.state==='done'?'home':'diagnostics'}});priorTasks=JSON.parse(JSON.stringify(S.tasks||{}));if(changed&&show){render();if(view==='diagnostics')await loadLog()}}catch(e){toast(e.message,true)}}
async function loadLog(){try{const data=await get('build-log');if(id('log-content'))id('log-content').textContent=data.log||'No logs yet.'}catch(e){if(id('log-content'))id('log-content').textContent=e.message}}
async function switchView(to){captureFields();if(!viewAllowed(to)){toast(scanComplete()?'Complete the earlier setup step first.':'Scan this PC before continuing.');to=stageViews[setupStage()];}view=to;render();id('page').focus({preventScroll:true});window.scrollTo({top:0,behavior:'auto'});if(to==='usb'||to==='usbtools')await refreshUsb();if(to==='diagnostics')await loadLog()}
async function refreshUsb(){const [volumes,physical]=await Promise.allSettled([get('usb'),get('usb-disks')]);usb=volumes.status==='fulfilled'?(volumes.value.usb||[]).filter(d=>String(d.filesystem).toUpperCase()==='FAT32'):[];usbDisks=physical.status==='fulfilled'?(physical.value.disks||[]):[];if(!usb.some(d=>String(d.drive_letter).toUpperCase()===fields.drive))fields.drive=usb.length===1?String(usb[0].drive_letter).toUpperCase():'';if(view==='usb'||view==='usbtools')render();if(physical.status==='rejected')toast('Physical USB detection failed: '+physical.reason.message,true);else if(volumes.status==='rejected')toast('Mounted-volume detection failed. Physical USB disks remain listed below.',true)}

async function act(name){try{if(name.startsWith('navigate-'))return await switchView(name.slice(9));
if(pendingAction||running())return;
if(!['scan','deep-scan','demo','import','import-boot-log','refresh-log','open-log','open-output'].includes(name)&&!scanComplete())throw new Error('Scan this PC before continuing.');
if(['auto-setup','build','engine'].includes(name)&&!viewAllowed('build'))throw new Error('Review USB port mapping before generating EFI.');
if(['recovery','usb-copy','usb-copy-efi','one-click'].includes(name)&&!viewAllowed('usb'))throw new Error('Generate and check the EFI before preparing a USB.');
if(name==='skip-mapping'){if(!confirm(S.usb_mapping?.map_ready?'Continue with untested ports in the USB map? These selected ports have not all been physically tested and may not work as expected.':'Continue without a USB port map? The EFI will use a temporary USB configuration. USB ports may not work reliably until mapping is completed.'))return;mappingSkipped=true;return await switchView('build');}

if(name==='usb-map-scan'){if(!confirm('Scan USB ports using USBToolBox? The app downloads its open-source scanner and reads USB controller data. It does not modify disks.'))return;await post('usb-map-scan',{consent:true});toast('USB scan started');return await switchView('usbmap')}
if(name==='usb-map-build'){await post('usb-map-build');toast('Building USB map');return await switchView('usbmap')}
if(name==='auto-setup'){captureFields();if(!confirm('Generate EFI for the hardware you just reviewed? HackPilot downloads and runs the OpCore-Simplify engine if needed, then validates the result. No USB files will be changed.'))return;buildOptionsDirty=true;await post('auto-setup',{consent:true,target:fields.target||'auto',selections:fields.selections});toast('Generating and checking EFI');return await switchView('build')}
if(name==='scan'){mappingSkipped=false;buildOptionsDirty=false;await post('scan');toast('Scanning hardware');return await switchView('hardware')}
if(name==='deep-scan'){if(!confirm('Deep scan downloads and runs Hardware Sniffer. It may need administrator access. Continue?'))return;mappingSkipped=false;buildOptionsDirty=false;await post('deep-scan',{consent:true});toast('Deep scan started');return await switchView('hardware')}
if(name==='engine'){if(!confirm('Download and run the OpCore-Simplify engine from GitHub?'))return;await post('engine',{consent:true});toast('Preparing engine');return await switchView('build')}
if(name==='build'){captureFields();if(!confirm('Generate EFI with the detected hardware? No disks will be changed.'))return;buildOptionsDirty=true;await post('build',{target:fields.target||'auto',selections:fields.selections});toast('Generating EFI');return await switchView('build')}
if(name==='validate'){await post('validate');toast('Validating EFI');return await switchView('build')}
if(name==='demo'){await post('demo');await refresh();return await switchView('hardware')}
if(name==='import'){id('import-file')?.click();return}
if(name==='import-boot-log'){id('boot-log-file')?.click();return}
if(name==='open-output'||name==='open-log'){await post(name);return}
if(name==='open-rufus'){if(!confirm('Download and open official Rufus 4.15 from its GitHub release? HackPilot verifies its checksum and publisher signature. Rufus has its own disk selection and erase confirmations. Close Rufus before continuing in HackPilot.'))return;await post('rufus',{consent:true});toast('Opening official Rufus. Close its window to continue.');return;}
if(name==='usb-format'||name==='usb-restore-access'){
 const restore=name==='usb-restore-access';
 captureFields();const value=id('format-disk')?.value;
 if(!value)throw new Error('Choose the physical USB disk first');
 const plan=await post('usb-format-plan',{number:Number(value),filesystem:fields.formatFilesystem||'FAT32',style:fields.formatStyle||'MBR',restore});
 const disk=plan.disk;const volumes=(disk.partitions||[]).map(p=>(p.letter?p.letter+': ':'')+(p.filesystem||'RAW')).join(', ')||'Unallocated';
 const typed=prompt(`${restore?'RESTORE ACCESS TO':'ERASE'} Disk ${disk.number}: ${disk.name}\nCapacity: ${(Number(disk.size)/1073741824).toFixed(1)} GiB\nCurrent partitions: ${volumes}\n\n${plan.note}\n\n${restore?'No formatting or partition deletion will be attempted.':'This cannot be undone. Back up anything you need first.'}\nType ${plan.confirmation} to continue:`);
 if(typed===null)return;
 if(typed!==plan.confirmation)throw new Error('Confirmation did not match. No operation was started.');
 await post('usb-format',{token:plan.token,confirm:typed,consent:true});
 fields.drive='';fields.formatDisk='';toast(restore?'Restoring access. Approve the Windows administrator prompt.':'Formatting started. Approve the Windows administrator prompt. Do not unplug the USB.');return await switchView(view==='usbtools'?'usbtools':'usb');
}
if(name==='refresh-usb'){await refreshUsb();return}
if(name==='recovery'){captureFields();const board=fields.board.trim();if(board&&!/^Mac-[A-Fa-f0-9]{8,20}$/.test(board))throw new Error('Enter a valid Mac board ID');if(!confirm('Download macOS recovery files from Apple using OpenCore macrecovery?'))return;await post('recovery',{board_id:board,consent:true});toast('Recovery download started');return}
if(name.startsWith('repair-usb-')){const letter=name.slice(11).toUpperCase();const check=`REPAIR ${letter}:`;const typed=prompt(`Restore or finish the interrupted USB transfer on ${letter}:?\n\nType ${check}`);if(typed===null)return;await post('usb-repair',{letter,confirm:typed});toast('USB repair started');return await switchView('usb')}
if(name==='usb-copy'||name==='usb-copy-efi'){if(name==='usb-copy'&&!recoveryReady())throw new Error('Download and verify Apple recovery before copying.');captureFields();const letter=(fields.drive||id('usb-target')?.value||'').toUpperCase();if(!letter)throw new Error('Select a USB drive');const check=`COPY TO ${letter}:`;const typed=prompt(`${name==='usb-copy'?'Copy EFI and verified Apple recovery':'Copy available EFI files'} to ${letter}:? Existing EFI will be backed up. No formatting or partition changes.\n\nType ${check}`);if(typed===null)return;await post('usb-copy',{letter,confirm:typed});toast('USB copy started');return}
if(name==='refresh-log'){await loadLog();return}
}catch(e){toast(e.message,true)}}
const performAction=async name=>{if(name.startsWith('navigate-')||name==='import'||name==='import-boot-log')return act(name);if(pendingAction||running())return;const result=act(name);pendingAction=true;render();try{await result;await refresh();}finally{pendingAction=false;render();}};
document.querySelectorAll('[data-icon]').forEach(el=>el.innerHTML=icon(el.dataset.icon));
document.addEventListener('click',event=>{const v=event.target.closest('[data-view]');if(v)return void switchView(v.dataset.view);const a=event.target.closest('[data-action]');if(a&&!a.disabled)void performAction(a.dataset.action)});
document.addEventListener('change',async event=>{if(event.target.dataset.mapToggle||event.target.dataset.mapType){const el=event.target;const c=el.dataset.controller;const port=Number(el.dataset.port);const row=el.closest('.map-port');const checkbox=row?.querySelector('[data-map-toggle]');const connector=row?.querySelector('[data-map-type]');if(!checkbox||!connector||connector.value===''){toast('Choose a connector type');return;}try{await post('usb-map-port',{controller:c,index:port,selected:checkbox.checked,connector:Number(connector.value)});await refresh()}catch(e){toast(e.message,true);await refresh()}return;}if(event.target.id==='format-filesystem')fields.formatFilesystem=event.target.value;if(event.target.id==='format-style')fields.formatStyle=event.target.value;if(event.target.id==='format-disk')fields.formatDisk=event.target.value;if(event.target.id==='macos-target'){fields.target=event.target.value;if(S.last_build?.valid)buildOptionsDirty=true;}if(event.target.id==='board-id')fields.board=event.target.value;if(event.target.id==='usb-target')fields.drive=event.target.value;if(event.target.dataset.deviceChoice){if(S.last_build?.valid)buildOptionsDirty=true;if(event.target.value)fields.selections[event.target.dataset.deviceChoice]=event.target.value;else delete fields.selections[event.target.dataset.deviceChoice]}if(event.target.id==='macos-target'||event.target.dataset.deviceChoice)render();if(event.target.id==='usb-target'&&view==='usb')render();if(event.target.id==='boot-log-file'){const file=event.target.files?.[0];if(!file)return;try{if(file.size>250000)throw new Error('Boot log must be under 250 KB');await post('diagnose',{log:await file.text()});await refresh();toast('Boot log analyzed')}catch(e){toast(e.message,true)}return}
if(event.target.id!=='import-file')return;const file=event.target.files?.[0];if(!file)return;try{const report=JSON.parse(await file.text());await post('import',report);await refresh();toast('Hardware report imported')}catch(e){toast(e.message,true)}});
document.addEventListener('input',event=>{if(event.target.id==='board-id')fields.board=event.target.value});
void refresh();setInterval(()=>void refresh(),3000);setInterval(()=>{if((view==='usb'||view==='usbtools')&&!running()&&!pendingAction)void refreshUsb()},15000);
