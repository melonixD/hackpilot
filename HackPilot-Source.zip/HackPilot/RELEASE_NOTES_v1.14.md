# HackPilot v1.14 — Recovery Reliability & Stability Preflight

## Changes

1. Pinned OpenCorePkg macrecovery script to a particular Git commit and pinned both its SHA-256 and Git blob hash. Script changes cannot silently enter the cache and run.
2. Recovery workspace now requires at least 2 GiB of free space before starting, with a descriptive failure. Recovery is not downloaded directly onto the selected USB.
3. Added two independently staged attempts for failed/expired download workers or invalid DMG/chunklist signatures. Old verified recovery remains unchanged on failure; failed attempts are deleted. Attempt logs are preserved.
4. Detects exactly one recovery DMG + chunklist pair; rejects symlinks and ambiguous multiple pairs.
5. Reuses an existing cached helper with the exact audited content even if an earlier version stored a moving-branch URL. No additional GitHub request is needed when the bytes match.
6. Blocks `XhciPortLimit=True` for macOS 11.3 and newer; missing or misordered `USBToolBox.kext` for `UTBMap.kext` also blocks validation.
7. Reports Wi-Fi-only Internet Recovery risk and Intel VMD/RST/RAID storage risk rather than presenting those configurations as stable by default.
8. Added regression cases for checksum mismatch, low disk space, symlink/ambiguous pairs, interrupted download and timed-out attempts, forged image signatures, offline cache upgrade and boot-risk checks.

## Verification and limits

- Local automated tests, Python compilation, JavaScript syntax, application self-test, plus clean ZIP extraction were performed in the Linux build environment.
- **Not performed:** live Apple recovery download, Windows-only hardware scan, Windows EXE execution, physical USB transfer, UEFI/macOS boot or post-install power, graphics and audio validation.
- Recovery is online, not a full macOS installer. Downloads can fail when Apple servers or GitHub are unavailable. A passing EFI audit does not imply universally supported hardware or a stable installed macOS.
