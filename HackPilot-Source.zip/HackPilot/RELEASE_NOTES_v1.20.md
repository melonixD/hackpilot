# HackPilot 1.20

The packaged worker smoke check now exercises a disposable demo server over loopback: homepage/session token injection, frontend assets, status JSON, rejection of missing tokens and deeply nested JSON. It also launches actual recovery-worker subprocesses with spaces and Unicode in filenames, checks standard-library imports, verifies log output, and requires success and failure exit codes to propagate correctly.

No hardware scans, external downloads, removable-drive writes or macOS boots are performed by this check.

Additional fixes: status polling tolerates deeply nested USB mapping and changed scan JSON; diagnostics match literal .aml/.efi extensions correctly; ACPI enumeration stops at its limit before sorting; scan roots reject Windows reparse points. Seven regression cases cover these changes.
