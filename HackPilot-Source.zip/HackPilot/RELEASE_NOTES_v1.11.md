# HackPilot v1.11 — Large-PC compatibility audit

This release improves complex-hardware triage, not macOS support for unsupported components.

## Changes

1. GUI hardware summaries cap individual component lists while keeping the original full Hardware Sniffer JSON for the EFI engine. Device counts remain accurate.
2. A usable candidate appearing after hundreds of unsupported GPUs or virtual NICs is still surfaced in the summary.
3. Hardware selection avoids exponential combinations and fails explicitly if one of multiple compatible GPUs needs a choice.
4. Expanded conservative GPU detection for workstation RTX/Quadro, Radeon Pro Navi3x/Navi24, newer Radeon generations, Intel Arc and Iris Xe.
5. Internet-recovery preflight no longer counts virtual-only or tunnel-only network hardware as physical connectivity.
6. USB discovery history is not retained across changed controller identifiers or port speeds.
7. Device-choice lists are cached based on the report file metadata, reducing repeated reads on UI refresh.

## Checks

- 316 automated tests passed on Linux, including 25 new/expanded scenarios from v1.10 (291 tests).
- Python compilation and GUI JavaScript syntax checks passed.
- These tests cannot confirm macOS driver attachment, SSDT behavior, physical USB function, or successful installation.

## Release blockers

A real Windows GUI executable must still be built and tested. Full Windows scanning, recovery downloads, physical USB transfers, and Intel/AMD laptop/desktop boot verification remain outstanding. The app requires an existing FAT32 USB and does not create a full offline installer. No universal compatibility or near-zero failure guarantee is claimed.
