# Supported workflow and release gates

**User-facing design:** Select a removable FAT32 USB, click **Prepare USB**, confirm the device identity, and let the app scan, generate, validate, fetch internet recovery, and copy and verify files. Never auto-erase storage without explicit consent.

| Stage | Automatically checked | Must still be verified on Windows/hardware |
|---|---|---|
| Hardware | Sniffer report schema; CPU/GPU/UEFI compatibility; device selection | BIOS settings, physical ports, chipset features, laptop display routing |
| ACPI | Presence of DSDT; compiled table headers/checksums and references | Firmware-specific SSDT effects and potential conflicts |
| Kexts | Enabled order, Info.plist, Mach-O CPU architecture, dependencies, Darwin load-range | Real driver attachment, Wi-Fi/network/audio/USB/trackpad support |
| OpenCore | Binary type, matching ocvalidate, cross-component hashes, config syntax | Firmware boot, Secure Boot policy, runtime quirks |
| Recovery | Known board profile; matching image/chunklist hashes and cached metadata | Exact Apple-served OS identity; network in macOS recovery |
| USB | Removable-disk identity, filesystem, staging, read-back checks, backups, rollback journal | Disk disconnection, power loss, Windows access restrictions, boot order |
| macOS | No end-to-end automated installation | Installer steps, formatting target disk, post-install EFI transfer |

## Public release blockers

1. Build and self-test a GUI-only Windows EXE on both Windows 10 and 11 without separately installed Python.
2. Test device scanning and EFI build on actual supported Intel and AMD machines, including hybrid GPU laptops.
3. Complete disposable-drive write/restore testing, including unplugging at every transaction boundary.
4. Boot Apple recovery, identify the actual installer OS, confirm network, then install macOS and verify USB, graphics, power, audio, networking and sleep.
5. Record a hardware/OS/kext-version compatibility matrix; allow public release only for individually validated combinations.
6. Add a properly tested FAT32 preparation flow with explicit selected-drive confirmation before any formatting.
7. Sign and distribute a verified standalone Windows release.

Do not advertise **ready to boot on every PC** or **one-click installation** before the release gates pass.

## v1.4 machine affinity test gate

On two genuinely different PCs, capture Hardware Sniffer + ACPI scans, build an EFI on the first, and verify a manual USB copy on the second is refused until it has a fresh matching scan and a new build. Check SSDT function on the actual firmware, including ACPI rename/disable rules. USB mapping, display outputs, macOS Recovery network drivers and first boot remain separate pass/fail release gates.

## v1.5 integrated USB mapping

HackPilot can now discover Windows USB controllers in its own GUI and generate a UTBMap.kext. **This does not remove the need to physically probe every port and USB-C orientation.** A saved map is topology-bound and may be invalidated by BIOS changes or a different system. Before calling the feature tested, complete the Windows physical tests in WINDOWS_TEST_CHECKLIST.md and verify kext loading in macOS.


## Large-hardware testing gate (v1.11)

Test real workstations with multiple discrete GPUs, virtual adapters, USB controllers and dock changes; hybrid-display laptops with an unsupported dGPU and usable iGPU; Wi-Fi-only machines; and RAID/VMD/NVMe configurations. Verify that the full hardware report is preserved, unsupported GPUs are not advertised as native, and network candidates actually work inside macOS Recovery. Synthetic scale tests do not replace this hardware matrix.


## v1.12 integrity release gate

The v2 generated EFI manifest must bind the complete EFI tree to a current machine-specific Hardware Sniffer/ACPI scan; legacy manifests require regeneration. Confirm rollback, scanner-release SHA checks, physically observed vs inferred USB map ports, and strict recovery folder allowlisting on real Windows hardware. These static safeguards **do not** certify macOS boot or peripheral functionality.


### v1.13 release gates

- [ ] On Windows, unplug the USB during EFI backup, staging, post-rename and recovery copying; verify a new USB assigned the same letter is **never modified** by rollback.
- [ ] Reinsert the original USB and test journal-driven recovery, including disk UniqueId / partition changes.
- [ ] Verify a real Apple-signed `.chunklist` and matching recovery DMG, then deliberately corrupt one image chunk to confirm rejection.
- [ ] Check complete and failed recovery downloads, including unsigned caches, on Windows.
- [ ] Test true FAT32 versus FAT16, exFAT and NTFS volumes.


### v1.14 recovery/stability release gates

- Run the exact pinned `macrecovery.py` helper on Windows to download real Recovery DMGs for each advertised OS profile. Verify the actual produced DMG against its Apple-signed chunklist and confirm the OS version from a booted environment; board-ID selection alone is not evidence of the returned major version.
- Test DNS failures, GitHub blocked, Apple endpoint 503/timeouts, lost connectivity mid-download, full output disk, and USB <4 GiB file limit. Confirm retries do not affect previously verified recovery.
- Boot physical Intel and AMD test systems, confirm OpenCore picker, installer networking, storage visibility, actual per-port USB mapping, display acceleration, audio, sleep/wake, NVRAM, power management, and updates before any stability claims.
- Check VMD/RST/RAID devices and Wi-Fi-only laptops. Never automatically change firmware storage modes; doing so can prevent Windows from booting.
- Build/sign or explicitly label the Windows executable and exercise a full USB workflow on hardware. This source build is not a tested standalone EXE.


### v1.15 Windows worker and recovery release gates

- [ ] Package the GUI EXE on Windows, then run `HackPilot.exe --worker-smoke <output-path>` and inspect the generated `hackpilot-worker-ok` marker.
- [ ] Force WebView2 failure and verify the normal browser fallback opens the local UI.
- [ ] Trigger a controlled OpenCore adapter failure and confirm `build.log` includes the traceback from the **compiled windowed EXE**.
- [ ] Disconnect during Apple Recovery download and verify macrecovery's log, retry and nonzero exit code remain visible from the EXE worker.
- [ ] Run USBToolBox discovery through the compiled EXE and verify its output file, multi-controller parsing, selected-port persistence and `UTBMap.kext` on real Windows hardware.
- [ ] Use a disposable USB to simulate an interrupted transfer with a pre-existing recovery folder, and confirm Repair USB does not quarantine or delete that original folder.

## Additional v1.16 release gates

- [ ] On Windows, download a real Apple recovery via the pinned helper and verify the **published** DMG/chunklist after writing. Check the resulting macOS version manually against the requested target.
- [ ] Simulate power loss and antivirus locks during recovery replacement; ensure the original verified image and metadata remain usable.
- [ ] Test USBToolBox backend upgrades and impossible rollbacks on a real NTFS system, confirming the previous source remains for repair.
- [ ] Run the packaged, unsigned GUI EXE under standard-user and administrator contexts; verify scan permissions and WebView2 fallback.
- [ ] Connect multiple removable drives, including FAT16, FAT32, exFAT and system-disk USB adaptors; confirm only the eligible FAT32 volumes can be chosen and no implicit erase occurs.
- [ ] Boot real supported Intel and AMD machines and verify EFI, USB mapping, storage, network, GPU acceleration, audio, Bluetooth, shutdown and sleep/wake.


## v1.17 integrity and recovery regression gates

- [x] Synthetic test proves older EFI fingerprint serialization could hash distinct file contents identically; v1.17 rejects the mutation.
- [x] Separate limits for small EFI trees and larger Apple Recovery transfer trees; large/sparse input is rejected by the appropriate guard before expensive hashing.
- [x] USB map revalidation handles malformed/oversized/disappearing manifest files and disables the obsolete port-limit workaround when injecting a proper map.
- [ ] Download a real Apple-signed recovery image and verify it end to end on Windows, including USB read-back verification for DMGs above 1 GiB.
- [ ] Test actual Windows GUI executable and first macOS boot on representative Intel and AMD computers.
