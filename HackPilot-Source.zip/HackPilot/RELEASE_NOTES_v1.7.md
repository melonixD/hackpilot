# HackPilot v1.7 — Safety Refinement

## Code fixes

1. Reject concurrent HFS+ drivers to prevent conflicting filesystem driver loading.
2. Require a stable USB disk number and volume ID for all copy paths.
3. Preflight the source EFI fingerprint and verify its contents during USB staging even without an external caller-supplied fingerprint.
4. Prevent USB companion port associations across ambiguous hub names.
5. Reject out-of-range PCI BDF identifiers for USB controller matching.
6. Refuse USB mapping when selected ports have unknown speed or when a selected controller's type is unknown.
7. Do not report incomplete/unverified Apple recovery files as ready.
8. Show a minimal warning when a selected USB port has not been physically observed.

## Verification

234 automated tests passed on the development machine, including 18 new v1.7 regression cases. Windows EXE and physical macOS boot have not been verified.

## Scope

The app continues to create OpenCore EFI and Apple internet-recovery files on existing FAT32 USB volumes; it does not format disks or create full offline installers. Every device and macOS version still requires actual boot and functional testing before being described as supported.
