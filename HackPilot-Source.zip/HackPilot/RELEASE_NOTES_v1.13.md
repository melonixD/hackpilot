# HackPilot v1.13 — Removable-Device Identity & Signed Recovery

**Status:** Windows source preview. No compiled or tested Windows EXE; real USB and macOS boot testing is still outstanding. This release does **not** imply zero error probability.

## Bugs and gaps fixed

1. **Unsafe rollback after a USB swap.** An unexpected drive-letter reassignment during staging, commit or failure cleanup could cause the application to rename or delete folders on a newly connected USB. Every rollback and cleanup operation now refuses to touch an unverified or replaced volume. The interrupted transaction remains journaled for explicit recovery with the original device reinserted. Repair operations now re-check volume identity before potentially destructive changes.
2. **Weak disk identity continuity.** Windows enumeration includes removable disk UniqueId, partition number and partition offset. When these are available, copy and repair compare them in addition to disk number and volume ID. The journal retains them across application restarts; malformed optional identifiers are rejected. This reduces risk of drive-number/letter reuse, although hardware can misreport identifiers and physical testing is still needed.
3. **FAT16 accepted as FAT32.** Filesystems reported as `FAT` are now rejected: the app requires an existing `FAT32` volume.
4. **Previous machine shown after failed scan.** A failed basic or ACPI scan now clears the earlier machine's in-memory report and ACPI paths instead of leaving stale device names in the current status.
5. **Unbounded early plist parse.** The first config parser now rejects `config.plist` files above 8 MiB before calling `plistlib.load`, matching the independent EFI component audit.
6. **Forged local recovery checksum.** Previously, altering both a downloaded recovery image and its local checksum receipt could bypass cache verification. The actual download, cache-reuse, startup and USB-copy paths now require independent Apple-signed CNKL chunklist verification and chunk-by-chunk DMG SHA-256 checks. This uses the same public RSA key and chunklist format as OpenCorePkg's `macrecovery` utility. Unsigned, truncated or corrupted recovery images are rejected even if their local cache hashes have been rewritten.

## Verification performed

- 375 automated Python tests in the working source tree, including a synthetic 2048-bit RSA signed chunklist test vector (no Apple recovery image bundled), USB device-swap and power-interruption simulations, stale-scan tests and malformed journal checks.
- Python compilation, `--self-test`, and frontend JavaScript syntax check.
- Tests will be re-run after clean ZIP extraction.

## Known limits and release blockers

- No successful Windows physical USB transfer or macOS recovery boot was performed; these are still mandatory before shipping to end users.
- A USB scan alone cannot prove physical USB ports, Wi-Fi, graphics acceleration, ACPI runtime behavior, sleep, or firmware settings.
- A signed Apple recovery image may be valid yet not usable on the selected hardware or represent a complete offline installer.
- There is no blank-drive formatting or partitioning; users must supply a removable FAT32 volume.
- The source ZIP contains a Windows build workflow, **not** a compiled native `.exe`.
