# HackPilot v1.6 — Deep EFI Validation

## Code changes

- Strengthened Mach-O kext executable validation: full 64-bit header,
  supported file type, bounded load commands, and bounded FAT/universal slices.
  Truncated files that previously passed an eight-byte signature test are rejected.
- Strengthened x86_64 UEFI PE/COFF validation: required executable flag,
  nonempty section table, bounded optional header, EFI subsystem, and section
  offsets that do not extend beyond the file.
- Honor OpenCore `Kernel/Add` `Arch` values when deciding whether a required
  kext can load on a 64-bit macOS target. Invalid values and contradictory
  `MinKernel`/`MaxKernel` intervals produce errors.
- Validate persisted USB mapping snapshots before using them in the GUI or
  generating a USB map. Reject oversized or malformed JSON and stale maps.
- Reject incomplete or damaged saved maps rather than silently generating a
  fallback EFI with `UTBDefault`.
- Harden ZIP extraction against Windows-reserved paths and confirm the
  standalone upstream worker uses the same safe extraction logic.
- Replace premature `Ready` status on the header with `Scan complete`.

## Verification performed

- 216 unit and regression tests passed (191 original + 25 new checks).
- `python -m compileall -q hackpilot` passed.
- `node --check web/app.js` passed.
- `python -m hackpilot.main --self-test` passed.
- Clean ZIP extraction and extracted-project regression run passed.

## Not yet verified / release blockers

- Windows PyInstaller executable is **not compiled or hardware-tested** here.
- No real Windows Hardware Sniffer run, EFI build/download cycle, USB flash
  transfer, firmware launch, or macOS boot was tested in this environment.
- USB port mapping must be physically checked per socket; ACPI correctness,
  graphics acceleration, Wi-Fi, audio, sleep and update behavior cannot be
  guaranteed by static validation alone.
- A preformatted FAT32 removable USB and Apple internet recovery are still
  required. This is not a full offline installer or a universal one-click OS setup.
- Vendor licensing restrictions may apply to installing macOS on non-Apple hardware.

See `WINDOWS_TEST_CHECKLIST.md` for steps required before a trustworthy
Windows installer release.
