# HackPilot v1.17 — Integrity Boundary and Cache Hardening

## Fixed

1. **EFI tree-hash ambiguity:** Bound filenames and file sizes into a new domain-separated SHA-256 input format. A regression test demonstrates an actual collision in the *input serialization* used by v1.16 (not a SHA-256 cryptographic collision).
2. **Large Apple Recovery compatibility:** Split the 1 GiB EFI safety cap from the 8 GiB generic USB read-back cap. Recovery DMGs can exceed 1 GiB, so incorrectly applying EFI limits to them would break valid installations.
3. **Bounded EFI and cache inventory:** EFI limited to 20,000 entries; OpenCore cache to 20,000 resources / 600 MiB; USBToolBox cache to 20,000 files / 200 MiB; map manifest to 128 KiB.
4. **USB-map metadata validation:** Reject damaged or unexpectedly executable map bundles before modifying the staged EFI.
5. **Port-limit safety:** When injecting a user-generated `UTBMap.kext`, turn off `XhciPortLimit` to avoid known modern macOS boot risks.
6. **Disappearing manifest:** Treat a USB-map manifest that vanishes during a readiness check as not ready rather than returning a server error.
7. **New regression tests:** Fake EFI metadata-boundary collisions, oversized sparse test files, malformed mappings, cache excesses, map-status file deletion and driver-quirk cleanup.

## Verification

- 436 automated tests passed in Linux, both from project source and after clean ZIP extraction.
- Python syntax/bytecode compilation, app `--self-test`, background `--worker-smoke`, and Node.js syntax check passed.

## Required hardware validation

No real macOS Recovery download, compiled Windows GUI launch, disposable-USB transfer, OpenCore boot, or extended macOS stability testing was possible in this environment. The archive is a **Windows source project**, not a certified installer or compiled `.exe`. Regenerate older EFIs because the fingerprint encoding changed.
