# HackPilot security and disk handling

- **No automatic disk erasure.** Only copies to an explicitly selected, Windows-reported removable USB FAT/FAT32 volume; rejects Windows boot/system disks according to PowerShell disk metadata.
- **Validation before copy.** Structural EFI check and an `ocvalidate` binary whose SHA-256 is recorded together with the matching OpenCore.efi release hash. Files are fingerprinted again just before transfer.
- **Two-step USB commit.** Stage and verify files first; archive a previous EFI off the removable disk; record transaction phases in `%LOCALAPPDATA%\\HackPilot\\Backups\\transactions`.
- **Interrupted transfer?** Do not boot that USB. Use **Repair USB** for the same recognized volume and verify recovery result. If data, backup integrity or volume identity is uncertain, the software refuses to overwrite anything and requires manual inspection.
- **Downloads.** Obtains HTTPS-hosted open-source upstream binaries only with consent. This protects against accidental substitution but does not eliminate all upstream supply-chain risk.
- **Cache integrity.** Checks downloaded engine Python source **and data assets** against its stored manifest on every use. Stale bytecode is cleared before executing the engine. Cached recovery tool and hardware sniffer hashes are checked before execution.
- **No telemetry.** UI runs locally; local HTTP mutation calls require a per-session token. Logs and report files may include identifiers; avoid uploading them without redaction.
- **No bootability guarantee.** Static validation cannot test firmware, physical USB ports, graphics acceleration or installation success.

- **Per-version validators.** A new OpenCore release has its own validator cache; an update does not replace the validator needed to re-check an earlier EFI.
- **Stricter USB repair.** Both original EFI directories and backup archives must fingerprint-match the recorded pre-copy EFI before restoration.
