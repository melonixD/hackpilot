@echo off
setlocal
cd /d "%~dp0"
py -3 -m pip install -r requirements.txt
if errorlevel 1 goto fail
py -3 -m pip install "pyinstaller>=6,<8" pytest
if errorlevel 1 goto fail
py -3 -m pytest -q
if errorlevel 1 goto fail
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name HackPilot --collect-all webview --collect-all wmi --collect-submodules win32com --collect-submodules hackpilot --add-data "web;web" --add-data "examples;examples" --add-data "hackpilot/windows_scan.ps1;hackpilot" --add-data "hackpilot/usb_list.ps1;hackpilot" hackpilot_launcher.py
if errorlevel 1 goto fail
dist\HackPilot.exe --self-test
if errorlevel 1 goto fail
dist\HackPilot.exe --worker-smoke dist\worker-smoke.txt
if errorlevel 1 goto fail
findstr /c:"hackpilot-worker-ok" dist\worker-smoke.txt >nul
if errorlevel 1 goto fail
echo EXE created and worker-tested in dist\HackPilot.exe
pause
exit /b 0
:fail
echo Build failed. Read the errors above.
pause
exit /b 1
