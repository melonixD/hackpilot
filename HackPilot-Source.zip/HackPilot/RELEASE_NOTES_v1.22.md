# HackPilot 1.22: USB permission-error fix and recovery tools

- Remove the elevated result.json file and TemporaryDirectory cleanup entirely. The elevated tool posts bounded authenticated results to a temporary loopback HTTP receiver held in memory.
- Run a real Windows PowerShell transport check both in tests and in the packaged EXE, without invoking storage commands.
- Keep physical-disk discovery independent from mounted-volume discovery. A volume-list error no longer hides all physical USB disks.
- Add Restore access for one existing normal FAT32/NTFS/exFAT data volume; assign a missing drive letter without erasing partitions or formatting. RAW/missing/ambiguous partitions require explicit review, not an automatic erase fallback.
- Add confirmed filesystem choices (FAT32, NTFS, exFAT) and MBR/GPT partition schemes. FAT32 remains capped at 30 GiB; NTFS/exFAT use available capacity for ordinary storage, not HackPilot EFI copying.
- Add a verified official Rufus 4.15 portable launcher for full advanced Rufus functionality in its own window. Pin the official GitHub release SHA-256 and require a valid Akeo Consulting Authenticode signature before launch. HackPilot remains busy until Rufus closes.
- Report the exact failed stage and never retry an erase automatically.

No physical USB formatting or actual administrator/UAC interaction has been validated on the affected PC. Restore access cannot recover deleted files or reconstruct a deleted filesystem. Do not erase media containing needed files.
