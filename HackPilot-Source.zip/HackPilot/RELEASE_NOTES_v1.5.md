# HackPilot v1.5 — Built-in USB mapping

**Source preview — not a hardware-validated release or a compiled Windows EXE.**

## New

- A **USB Map** screen in the existing pure-white, black-text HackPilot GUI. It discovers Windows USB controllers and ports using the open-source USBToolBox backend. Users no longer need to launch USBToolBox separately.
- `Scan ports` downloads a pinned USBToolBox tool revision after consent and runs its Windows discovery executable in a bounded child process. A cache manifest binds source code and discovery binary to SHA-256 hashes. Optional Windows WMI enrichment obtains PCI/ACPI controller information.
- Plug a USB device into each physical socket, choose **Scan ports** again, and HackPilot remembers observed ports. Known companion ports are selected together. It lets users include/exclude ports and choose USB-A, USB-C or internal connector types.
- **Build USB map** generates a real, codeless `UTBMap.kext` with USBToolBox-compatible controller matches and per-port definitions. It enforces a maximum of 15 selected ports per controller and refuses an unknown connector type or ambiguous controller identity.
- The next **Generate EFI / Prepare USB** flow checks the saved mapping against the current controller topology and inserts `UTBMap.kext` **after** `USBToolBox.kext` in `Kernel/Add`. It disables/removes the temporary `UTBDefault.kext` and revalidates the staged EFI before publishing it.
- The manual USB copy path rejects an EFI built with a stale or different USB map. Changing port selections clears the previous validation status.
- Added source/cache and EFI bundle integrity checks, failure-path regression tests, and a native-window navigation entry.

## How to use

1. Open **USB Map** in HackPilot and click **Scan ports**. Allow the USBToolBox backend download when asked.
2. Plug a USB device into **each physical USB port** on the PC; click **Scan ports** after moving it. Test front-panel sockets, rear sockets, USB-C orientations, and internal ports as applicable. Review connector types.
3. Click **Build USB map**. This creates `UTBMap.kext` in HackPilot's local USBMapping output folder.
4. Click **Prepare USB** on Overview. A new EFI is generated and the saved USB map is integrated automatically if the live controller topology still matches.

### Important limitations

- A computer cannot reliably identify every unoccupied physical socket, USB-C wiring, and internal header without probing/physical testing. HackPilot does **not** invent those mappings. Unobserved ports stay unverified; the user can explicitly include them, but their functionality is not certified.
- The custom kext uses **USBToolBox.kext**, which must be present and enabled in the generated EFI. Hardware/controller support depends on upstream releases, macOS, and motherboard firmware.
- No physical Windows USB scan, live device unplug/replug sequence, generated OpenCore boot, or successful macOS installation was tested in the build environment. Do not equate the static validation suite with real USB/macos functionality.
- A USB remains subject to the earlier restrictions: a removable **FAT32 volume** is needed; the tool does not format drives and uses Apple internet recovery, not a full offline installer.
- Windows-only USB discovery; the repo includes the Windows build workflow, but there is no verified precompiled `HackPilot.exe` in this archive.

Upstream sources: https://github.com/USBToolBox/tool (MIT) and https://github.com/USBToolBox/kext. No standalone USBToolBox UI is required; its detection backend is used by HackPilot after explicit consent.
