# HackPilot v1.15 — Worker Reliability and Crash-Safe Recovery

This update fixes reproducible code paths; it does not claim a universally bootable Hackintosh.

## Changes

1. Frozen Windows EXE worker launches no longer depend on a console. The OpenCore adapter writes its build output and tracebacks to an explicit log path and reports a failing exit code. The Apple Recovery worker writes a dedicated log while preserving its native exit status. USB mapping writes bounded JSON to a temporary result file and logs errors separately.
2. The Windows build workflow checks `HackPilot.exe --worker-smoke` with a tangible output file after packaging. The local `Build-Windows-EXE.bat` does the same.
3. A checksum-verified `macrecovery.py` cached helper can repair malformed/older metadata offline. Linked and unreasonably large helper manifests cannot be followed or read into memory before an update.
4. An interrupted EFI transfer now records whether recovery was already present on the USB. `Repair USB` keeps that pre-existing recovery in place, while quarantining recovery newly added by an incomplete transfer.
5. A failed USB stage is not marked rolled back if partial files could not be deleted. The journal remains actionable for explicit USB repair.
6. Saved hardware reports and tool manifests have bounded reads to avoid GUI-startup crashes caused by malformed local files.
7. Native webview initialization errors fall back to the browser UI. A browser-launch failure closes the local server with a clear error instead of remaining hidden in memory.

## Validation

- 407 automated Python tests passed (baseline 389 + 18 new targeted tests), plus Python compilation, application self-test, and JavaScript syntax checks.
- The distribution ZIP was extracted and checked separately.
- Not verified: a physical Windows scan or real USB transfer, a live Apple recovery download, OpenCore boot on a real motherboard, display/audio/wireless/USB stability, or a compiled Windows EXE in this Linux environment.

## Next required real-world release gates

- Compile with the included Windows runner, pass the executable worker self-test, and run `Prepare USB` on a disposable drive.
- Confirm complete EFI/Recovery boot and correct installer network and storage detection on supported Intel and AMD test machines.
- Validate macOS graphics acceleration, sleep/wake, USB mapping, audio, NVRAM, and update behavior for each supported hardware family.
- Sign the Windows EXE or clearly label the executable as unsigned.
