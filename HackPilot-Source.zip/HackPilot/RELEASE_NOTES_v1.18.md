# HackPilot 1.18

- Clear the busy state if Windows cannot start a background worker thread.
- Retain discovered USB topology when optional WMI/COM enrichment fails.
- Add regression tests for both failures.
- Correct the Windows validator filename in the oversized-metadata fixture.

These checks do not establish physical USB or macOS boot compatibility.
