# HackPilot v1.8 — Deep Reliability Audit

## Fixes

1. Transactional Hardware Sniffer update and offline verified-cache reuse. A failed manifest commit restores the previous scanner executable.
2. USBToolBox code integrity rejects untracked bytecode. OpenCore source execution cleans root-level and nested bytecode caches.
3. Cross-process advisory lock prevents duplicate HackPilot instances copying or repairing the same USB simultaneously.
4. USB transfer receipts now validate phase, drive identity, SHA-256 fingerprints, shape and size before recovery code can act on them.
5. Every HackPilot-built EFI must carry a complete machine-specific build manifest, including the hardware/ACPI scan seal.

## Verification in this environment

- 256 Python tests passing, including new failure-path and injection-style cases.
- Python compilation and JavaScript syntax checks.
- Local application self-test and clean ZIP extraction test.

## Not verified

No standalone Windows EXE was compiled in this Linux environment, and the app has not been tested on physical Windows/UEFI PCs or successfully booted a macOS installer. This is a Windows source preview, not a certified one-click Hackintosh installer. The integrated USB mapping feature still requires physical port probing.
