# HackPilot 1.21: guided USB formatter

- Detect physical USB disks, including RAW/unallocated media, independently from ready FAT32 volumes.
- Plan whole-disk erase with device name, size, current partitions and typed confirmation. Plans expire after five minutes and are single-use.
- Request UAC only for the formatter; recheck USB identity, Windows/boot flags, pagefile and app/temp locations before destructive steps.
- Create an MBR FAT32 partition up to 30 GiB; larger remaining capacity stays unallocated. Supports eligible 2 GiB to 2 TiB USB disks.
- Copying and one-click EFI preparation do not erase drives automatically.
- Real physical USB formatting remains unverified; automated checks cover guards, plans and PowerShell syntax without erasing disks.
