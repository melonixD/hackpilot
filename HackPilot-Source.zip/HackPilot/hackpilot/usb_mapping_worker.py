"""Headless adapter to the USBToolBox Windows usbdump discovery engine.

No USBToolBox menu launches; detection runs as a bounded subprocess.
"""
import json
import os
from pathlib import Path
import sys


def main():
    if os.name!='nt':raise RuntimeError('USB port discovery is Windows only')
    root=Path(sys.argv[1]).resolve()
    if not (root/'resources'/'usbdump.exe').is_file():
        raise RuntimeError('USBToolBox discovery executable missing')
    os.chdir(root)
    sys.path.insert(0,str(root))
    # The vendored USBToolBox source uses sys._MEIPASS for its own standalone
    # executable. HackPilot is frozen separately, so use the downloaded tool
    # directory as resource root, not HackPilot's own temporary bundle.
    frozen=getattr(sys,'frozen',False)
    try:
        if frozen:sys.frozen=False
        from Scripts import usbdump
        original=usbdump.subprocess.run
        def bounded(*args,**kwargs):
            kwargs['timeout']=min(float(kwargs.get('timeout',30)),30)
            kwargs['check']=True
            return original(*args,**kwargs)
        usbdump.subprocess.run=bounded
        try:
            rows=usbdump.get_controllers()
        finally:
            usbdump.subprocess.run=original
        # Enrich the USBToolBox topology with Windows PnP metadata when
        # available; avoid the terminal frontend and its optional console
        # dependencies entirely. Missing WMI data is not a fabricated match.
        try:
            import wmi
            client=wmi.WMI()
            for controller in rows:
                ids=controller.get('identifiers',{})
                instance=ids.get('instance_id','')
                if not isinstance(instance,str) or not instance:
                    continue
                try:
                    # PNPDeviceID is quoted as a WQL string, never a shell
                    # expression. A failed lookup simply leaves PCI IDs.
                    escaped=instance.replace('\\','\\\\').replace("'", "''")
                    items=client.query("SELECT * FROM Win32_PnPEntity WHERE PNPDeviceID = '"+escaped+"'")
                    if not items:continue
                    device=items[0]
                    def property_value(key):
                        try:return device.GetDeviceProperties([key])[0][0].Data
                        except (IndexError,AttributeError,TypeError):return None
                    path=property_value('DEVPKEY_Device_BiosDeviceName')
                    if isinstance(path,str) and path.strip():ids['acpi_path']=path
                    friendly=property_value('DEVPKEY_Device_FriendlyName')
                    if isinstance(friendly,str) and friendly.strip():controller['name']=friendly
                    iface=property_value('DEVPKEY_PciDevice_ProgIf')
                    try:controller['class']=int(iface) if iface is not None else controller.get('class',9999)
                    except (ValueError,TypeError):pass
                    if controller.get('class') in (None,'',9999):
                        service=property_value('DEVPKEY_Device_Service')
                        controller['class']={'USBXHCI':48,'USBEHCI':32,'USBOHCI':16,'USBUHCI':0}.get(str(service).upper(),9999)
                except Exception:
                    continue
        except Exception:
            # WMI can raise COM/provider errors during initialization. It is
            # optional enrichment; keep the topology already discovered.
            pass
        if len(sys.argv) >= 3:
            # In a windowed EXE stdout may be None even when redirected. The
            # main app passes a private result path so JSON is never lost.
            result_path = Path(sys.argv[2])
            pending = result_path.with_suffix('.incoming')
            try:
                pending.write_text(json.dumps(rows), encoding='utf-8')
                os.replace(pending, result_path)
            finally:
                pending.unlink(missing_ok=True)
        else:
            print(json.dumps(rows))
    finally:
        if frozen:sys.frozen=True

if __name__=='__main__':
    try:main()
    except Exception as e:
        print(str(e),file=sys.stderr)
        raise SystemExit(1)
