"""USB transfers: no disk formatting; staged, verified copies with rollback."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import zipfile
import subprocess
from datetime import datetime
from contextlib import contextmanager
from .efi import efi_tree_fingerprint
from .usb_journal import write_receipt, pending_receipts, checksum

USB_SCRIPT = Path(__file__).with_name('usb_list.ps1')


@contextmanager
def _transfer_lock(backup_dir, letter):
    """Cross-process drive lock, automatically released even after a crash.

    Two GUI instances sharing the same application home must never both
    replace one drive's EFI simultaneously. Advisory OS locks avoid stale
    lockfiles that require manual cleanup after power loss.
    """
    letter = str(letter).strip().upper().replace(':', '')
    if len(letter) != 1 or not letter.isascii() or not letter.isalpha():
        raise ValueError('Invalid USB drive letter')
    locks = Path(backup_dir) / 'transactions'
    locks.mkdir(parents=True, exist_ok=True)
    path = locks / f'usb-{letter}.lock'
    if _is_link(path):
        raise RuntimeError('USB transaction lockfile is linked; repair the application folder')
    with path.open('a+b') as stream:
        stream.seek(0, os.SEEK_END)
        if stream.tell() == 0:
            stream.write(b'\x00')
            stream.flush()
        stream.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, BlockingIOError) as exc:
            raise RuntimeError(f'Another HackPilot window is already using USB {letter}:') from exc
        try:
            yield
        finally:
            if os.name == 'nt':
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def _usb_volume_root(letter):
    # Separated for safe testing: simulated transfers never touch a real drive.
    return Path(f'{letter}:/')


def list_usb():
    if os.name != 'nt':
        return []
    result = subprocess.run(
        ['powershell.exe', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
         '-File', str(USB_SCRIPT)], capture_output=True, timeout=30,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if result.returncode:
        raise RuntimeError('Cannot list USB partitions: ' + result.stderr.decode(errors='replace')[-600:])
    output = result.stdout.decode('utf-8-sig', errors='replace').strip()
    if not output:
        return []
    data = json.loads(output)
    return data if isinstance(data, list) else [data]


def _is_link(path):
    path = Path(path)
    if path.is_symlink():
        return True
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    return bool(getattr(info, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0))


def _checked_tree(root):
    """Only ordinary files/folders; reject links, junctions, and device nodes."""
    root = Path(root)
    if not root.is_dir() or _is_link(root):
        raise RuntimeError('Missing or linked source directory')
    total = 0
    for item in root.rglob('*'):
        if _is_link(item):
            raise RuntimeError('Refusing to follow linked files or directories')
        if item.is_file():
            if not stat.S_ISREG(item.stat().st_mode):
                raise RuntimeError('Unexpected file type in transfer')
            size = item.stat().st_size
            if size > (4 * 1024**3 - 1):
                raise RuntimeError('FAT32 cannot store files larger than 4 GiB; choose smaller recovery files')
            total += size
        elif not item.is_dir():
            raise RuntimeError('Unexpected file type in transfer')
    return total


def _sha256_file(file):
    digest = hashlib.sha256()
    with Path(file).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.digest()


def _verified_copy(source, target):
    _checked_tree(source)
    shutil.copytree(source, target)
    for item in Path(source).rglob('*'):
        if not item.is_file():
            continue
        copied = Path(target) / item.relative_to(source)
        if not copied.is_file() or item.stat().st_size != copied.stat().st_size:
            raise RuntimeError('USB read-back verification failed: ' + item.name)
        if _sha256_file(item) != _sha256_file(copied):
            raise RuntimeError('USB read-back hash mismatch: ' + item.name)


def _verified_backup(source, destination):
    """Preserve existing USB EFI off-device; ensure the ZIP has every original byte."""
    source = Path(source)
    _checked_tree(source)
    archive_path = Path(str(destination) + '.zip')
    try:
        shutil.make_archive(str(destination), 'zip', str(source.parent), source.name)
        with zipfile.ZipFile(archive_path) as archive:
            expected_files = [p for p in source.rglob('*') if p.is_file()]
            expected_names = {'EFI/' + p.relative_to(source).as_posix() for p in expected_files}
            actual_names = {name for name in archive.namelist() if not name.endswith('/')}
            if actual_names != expected_names:
                raise RuntimeError('USB EFI backup is missing or contains unexpected files')
            for file in expected_files:
                with archive.open('EFI/' + file.relative_to(source).as_posix()) as saved:
                    digest = hashlib.sha256()
                    for block in iter(lambda: saved.read(1024 * 1024), b''):
                        digest.update(block)
                if digest.digest() != _sha256_file(file):
                    raise RuntimeError('USB EFI backup checksum mismatch')
        return archive_path
    except Exception:
        archive_path.unlink(missing_ok=True)
        raise


def _same_device(letter, original):
    """Check volume identity before committing, reducing drive-letter reuse risk."""
    selected = [drive for drive in list_usb()
                if str(drive.get('drive_letter', '')).upper() == letter]
    if len(selected) != 1:
        raise RuntimeError('USB drive disconnected or drive letter reassigned')
    current = selected[0]
    # Drive letters are reusable and FAT32 media can disappear/reappear during
    # copying. Both identifiers must be present in *every* transfer mode, not
    # just the automated one-click path.
    if original.get('disk_number') is None or not original.get('volume_id'):
        raise RuntimeError('USB volume identity is unavailable; transfer stopped')
    if current.get('disk_number') is None or not current.get('volume_id'):
        raise RuntimeError('USB volume identity was lost; transfer stopped')
    for field in ('disk_number', 'volume_id'):
        if current[field] != original[field]:
            raise RuntimeError('USB drive identity changed; transfer stopped')
    # Verify additional Windows disk/partition identity when available. Disk
    # number and volume ID alone can be reused after unplug/replug or cloning.
    for field in ('disk_unique_id', 'partition_number', 'partition_offset'):
        previous = original.get(field)
        if previous is not None and str(previous).strip():
            if str(current.get(field) or '').strip() != str(previous).strip():
                raise RuntimeError('USB disk or partition identity changed; transfer stopped')
    if str(current.get('filesystem', '')).upper() != 'FAT32':
        raise RuntimeError('USB filesystem changed during transfer')
    return current


def safe_usb_copy(build_dir, drive_letter, acknowledgement, backup_dir, recovery_dir=None, expected_fingerprint=None, expected_disk=None):
    with _transfer_lock(backup_dir, drive_letter):
        return _safe_usb_copy_impl(build_dir, drive_letter, acknowledgement, backup_dir,
                                   recovery_dir, expected_fingerprint, expected_disk)


def _safe_usb_copy_impl(build_dir, drive_letter, acknowledgement, backup_dir, recovery_dir=None, expected_fingerprint=None, expected_disk=None):
    letter = str(drive_letter).upper().strip().replace(':', '').replace('\\', '')
    if len(letter) != 1 or not letter.isascii() or not letter.isalpha():
        raise ValueError('Invalid USB drive letter')
    expected = f'COPY TO {letter}:'
    if acknowledgement != expected:
        raise ValueError('Type exactly ' + expected + ' to confirm the selected drive')
    drives = [drive for drive in list_usb()
              if str(drive.get('drive_letter', '')).upper() == letter]
    if len(drives) != 1:
        raise RuntimeError('Selected drive is not on a safe removable USB disk')
    disk = drives[0]
    if disk.get('disk_number') is None or not disk.get('volume_id'):
        raise RuntimeError('USB volume identity is unavailable; transfer stopped before writing')
    if expected_disk is not None:
        if not expected_disk.get('volume_id') or expected_disk.get('disk_number') is None:
            raise RuntimeError('Selected USB does not have a verifiable disk identity')
        for key in ('disk_number', 'volume_id', 'disk_unique_id',
                    'partition_number', 'partition_offset'):
            original_value = expected_disk.get(key)
            if key in ('disk_number', 'volume_id') or (original_value is not None and str(original_value).strip()):
                if str(disk.get(key)) != str(original_value):
                    raise RuntimeError('USB identity changed during setup; no files were written')
    if str(disk.get('filesystem', '')).upper() != 'FAT32':
        raise RuntimeError('USB partition must already be FAT32; HackPilot never formats drives')
    target = _usb_volume_root(letter)
    if not target.is_dir() or _is_link(target):
        raise RuntimeError('USB drive is missing or linked')
    source = Path(build_dir) / 'EFI'
    if not (source / 'OC' / 'config.plist').is_file():
        raise RuntimeError('No assembled EFI folder to copy')
    source_size = _checked_tree(source)
    initial_fingerprint = efi_tree_fingerprint(source)
    if expected_fingerprint and initial_fingerprint != expected_fingerprint:
        raise RuntimeError('EFI changed after validation; USB was not modified')
    recovery = Path(recovery_dir) if recovery_dir else None
    if recovery and recovery.is_dir():
        if not all((recovery / name).is_file() for name in ('BaseSystem.dmg', 'BaseSystem.chunklist')):
            raise RuntimeError('Recovery is incomplete; refusing partial USB transfer')
        recovery_size = _checked_tree(recovery)
    elif recovery:
        raise RuntimeError('Recovery folder was removed; re-download it before copying')
    else:
        recovery_size = 0
    dest_efi = target / 'EFI'
    dest_recovery = target / 'com.apple.recovery.boot'
    temp_efi = target / 'EFI.hackpilot-incoming'
    temp_recovery = target / 'com.apple.recovery.boot.hackpilot-incoming'
    old_efi = target / 'EFI.hackpilot-previous'
    for path in (dest_efi, dest_recovery, temp_efi, temp_recovery, old_efi):
        if _is_link(path):
            raise RuntimeError('Refusing linked USB folder: ' + path.name)
    if any(j.get('phase') == 'corrupt' or str(j.get('letter','')).upper() == letter for j in pending_receipts(Path(backup_dir)/'transactions')):
        raise RuntimeError('Unfinished USB transfer detected. Use Repair USB before copying again.')
    if old_efi.exists() or temp_efi.exists() or temp_recovery.exists():
        raise RuntimeError('Previous transfer folders detected; inspect them before retrying')
    recovery_present = False
    # Keep the expected hash even when the USB already contains an identical
    # recovery image. Otherwise it is excluded from both the final verification
    # and a crash-recovery receipt.
    expected_recovery_fingerprint = efi_tree_fingerprint(recovery) if recovery else None
    if recovery and dest_recovery.exists():
        _checked_tree(dest_recovery)
        if efi_tree_fingerprint(dest_recovery) != expected_recovery_fingerprint:
            raise RuntimeError('USB has a different recovery image. Review it before replacing.')
        # Repeated EFI updates should not fail because the same recovery is already present.
        recovery = None
        recovery_size = 0
        recovery_present = True
    if int(disk.get('free_bytes', 0)) < source_size + recovery_size + 64 * 1024 * 1024:
        raise RuntimeError('Insufficient space on USB (64 MiB safety margin required)')
    backup = Path(backup_dir)
    backup.mkdir(parents=True, exist_ok=True)
    journal_root = backup/'transactions'
    # A past crash must be repaired explicitly before changing this drive again.
    if any(j.get('phase') == 'corrupt' or str(j.get('letter','')).upper() == letter for j in pending_receipts(journal_root)):
        raise RuntimeError('Unfinished USB transfer detected. Use Repair USB before copying again.')
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    receipt_file = journal_root/f'usb-{letter}-{stamp}.json'
    receipt = {'letter':letter, 'disk_number':disk.get('disk_number'),
               'volume_id':disk.get('volume_id'),
               'disk_unique_id':disk.get('disk_unique_id'),
               'partition_number':disk.get('partition_number'),
               'partition_offset':disk.get('partition_offset'),
               'phase':'starting',
               'expected_fingerprint':initial_fingerprint,
               'recovery_fingerprint':expected_recovery_fingerprint,
               # If this exact recovery was already on the USB before the
               # transaction, repair must NEVER quarantine it during EFI
               # rollback. Newly copied recovery is handled separately.
               'recovery_preexisting':recovery_present,
               'had_original': dest_efi.exists(),
               'original_fingerprint': efi_tree_fingerprint(dest_efi) if dest_efi.exists() else None,
               'backup':None}
    write_receipt(receipt_file, receipt)
    def step(phase):
        receipt['phase'] = phase
        write_receipt(receipt_file, receipt)
    backup_file = None
    try:
        if dest_efi.exists():
            _checked_tree(dest_efi)
            _same_device(letter, disk)
            backup_file = _verified_backup(dest_efi, backup / f'usb-{letter}-efi-{stamp}')
            receipt['backup'] = str(backup_file)
            receipt['backup_sha256'] = checksum(backup_file)
            step('backup_verified')
    except Exception:
        # No removable-drive files have changed at this point. A failed
        # backup must not leave a misleading interrupted transfer receipt.
        step('preflight_failed')
        raise
    # Stage both EFI and recovery before replacing the boot files.
    try:
        _verified_copy(source, temp_efi)
        if efi_tree_fingerprint(temp_efi) != initial_fingerprint:
            raise RuntimeError('EFI changed during USB transfer; no boot files replaced')
        if recovery:
            _verified_copy(recovery, temp_recovery)
        _same_device(letter, disk)
        step('staged')
        if efi_tree_fingerprint(source) != initial_fingerprint:
            raise RuntimeError('Source EFI changed during USB transfer; no boot files replaced')
    except Exception as stage_error:
        # The drive may have disappeared or another USB may now occupy the
        # letter. Never delete *any* USB paths until the original disk is
        # identified again. Leave an unfinished journal for explicit repair.
        try:
            _same_device(letter, disk)
        except RuntimeError as identity_error:
            raise RuntimeError(
                'USB identity lost during staging. No rollback or cleanup was '
                'attempted on the reassigned drive. Reinsert the original USB '
                'and use Repair USB.') from identity_error
        # Do not mark a failed stage as rolled back if cleanup failed. That
        # would suppress the journal and leave an apparently unexplained
        # partial EFI on the removable drive.
        cleanup_failures = []
        for pending in (temp_efi, temp_recovery):
            if pending.exists():
                try:
                    _same_device(letter, disk)
                    shutil.rmtree(pending)
                except (OSError, RuntimeError) as exc:
                    cleanup_failures.append(f'{pending.name}: {exc}')
        if cleanup_failures:
            step('cleanup_needed')
            raise RuntimeError('USB staging failed and partial files require Repair USB: ' +
                               '; '.join(cleanup_failures)) from stage_error
        step('rolled_back')
        raise
    moved_old = False
    committed_new = False
    committed_recovery = False
    try:
        _same_device(letter, disk)
        if dest_efi.exists():
            dest_efi.rename(old_efi)
            moved_old = True
            step('old_moved')
        temp_efi.rename(dest_efi)
        committed_new = True
        step('new_moved')
        if recovery:
            _same_device(letter, disk)
            temp_recovery.rename(dest_recovery)
            committed_recovery = True
        _same_device(letter, disk)
        if efi_tree_fingerprint(dest_efi) != receipt['expected_fingerprint']:
            raise RuntimeError('USB EFI verification after commit failed')
        if expected_recovery_fingerprint and (
            not dest_recovery.is_dir() or
            efi_tree_fingerprint(dest_recovery) != expected_recovery_fingerprint
        ):
            raise RuntimeError('USB recovery verification after commit failed')
        step('committed')
    except Exception as exc:
        # A USB removed during commit could have been replaced by another
        # volume with the same letter. NEVER roll back to that new volume.
        # The original USB can be repaired once reinserted and reidentified.
        try:
            _same_device(letter, disk)
        except RuntimeError as identity_error:
            raise RuntimeError(
                'USB identity lost during commit; automatic rollback is unsafe. '
                'No further USB files were modified. Reinsert the original '
                'device and use Repair USB.') from identity_error
        # Keep the old bootable EFI in place if a commit fails.
        try:
            if committed_recovery and dest_recovery.exists():
                # Recovery is paired with the new EFI, not necessarily with
                # the old EFI restored below. Quarantine it on failure.
                failed_recovery = target / ('com.apple.recovery.boot.hackpilot-failed-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
                dest_recovery.rename(failed_recovery)
            if committed_new and dest_efi.exists():
                failed = target / ('EFI.hackpilot-failed-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
                dest_efi.rename(failed)
            if moved_old and old_efi.exists():
                old_efi.rename(dest_efi)
            step('rolled_back')
        except OSError as rollback_error:
            raise RuntimeError('USB transfer failed; automatic EFI rollback also failed. '
                               'Do not boot this USB until inspected: ' + str(rollback_error)) from exc
        raise
    finally:
        # Do not clean temporary paths if a different USB has inherited the
        # drive letter while this transfer was in progress.
        try:
            _same_device(letter, disk)
        except RuntimeError:
            pass
        else:
            if temp_efi.exists():
                shutil.rmtree(temp_efi, ignore_errors=True)
            if temp_recovery.exists():
                shutil.rmtree(temp_recovery, ignore_errors=True)
    warning = 'EFI files copied and verified. Installation still requires compatible macOS recovery and hardware.'
    if moved_old and old_efi.exists():
        # The original is now verified in the local backup archive. Clear the
        # temporary USB rollback folder, otherwise future copies are blocked.
        try:
            _same_device(letter, disk)
            _checked_tree(old_efi)
            shutil.rmtree(old_efi)
        except (OSError, RuntimeError) as exc:
            warning += ' Previous EFI remains on USB; remove EFI.hackpilot-previous manually before another copy.'
    step('complete' if not old_efi.exists() else 'cleanup_needed')
    return {'drive':f'{letter}:', 'copied_efi':True, 'copied_recovery':bool(recovery),
            'recovery_present':recovery_present, 'backup':str(backup_file) if backup_file else None,
            'warning':warning}


def repair_usb(drive_letter, acknowledgement, backup_dir):
    with _transfer_lock(backup_dir, drive_letter):
        return _repair_usb_impl(drive_letter, acknowledgement, backup_dir)


def _repair_usb_impl(drive_letter, acknowledgement, backup_dir):
    """Explicitly complete a verified transfer or restore the previous EFI. Never format."""
    letter = str(drive_letter).strip().upper().rstrip(':')
    if len(letter) != 1 or not letter.isascii() or not letter.isalpha():
        raise ValueError('Invalid USB drive letter')
    if acknowledgement != f'REPAIR {letter}:':
        raise ValueError(f'Type REPAIR {letter}: to confirm USB recovery')
    directory = Path(backup_dir)/'transactions'
    receipts = pending_receipts(directory)
    if any(j.get('phase') == 'corrupt' for j in receipts):
        raise RuntimeError('A damaged or ambiguous USB transfer journal requires manual inspection before repair')
    matches = [j for j in receipts if str(j.get('letter','')).upper() == letter]
    if len(matches) != 1 or matches[0].get('phase') == 'corrupt':
        raise RuntimeError('USB recovery journal is missing, corrupted, or ambiguous; manual inspection required')
    j = matches[0]
    path = directory/(j['journal_id'] + '.json')
    disk = {'drive_letter':letter, 'disk_number':j.get('disk_number'),
            'volume_id':j.get('volume_id'),
            'disk_unique_id':j.get('disk_unique_id'),
            'partition_number':j.get('partition_number'),
            'partition_offset':j.get('partition_offset')}
    _same_device(letter, disk)
    root = _usb_volume_root(letter)
    if not root.is_dir() or _is_link(root):
        raise RuntimeError('USB volume is unavailable or linked')
    current, old = root/'EFI', root/'EFI.hackpilot-previous'
    def guard_usb():
        _same_device(letter, disk)
    def quarantine_new_recovery():
        if j.get('recovery_fingerprint') and not j.get('recovery_preexisting', False):
            recovery_folder = root/'com.apple.recovery.boot'
            if recovery_folder.exists():
                _checked_tree(recovery_folder)
                target = root/('com.apple.recovery.boot.hackpilot-failed-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
                guard_usb()
                recovery_folder.rename(target)
    incoming = root/'EFI.hackpilot-incoming'
    recovery_incoming = root/'com.apple.recovery.boot.hackpilot-incoming'
    for item in (current, old, incoming, recovery_incoming):
        if _is_link(item):
            raise RuntimeError('USB includes linked files; manual recovery required')
    good_new = current.is_dir() and efi_tree_fingerprint(current) == j['expected_fingerprint']
    if j.get('recovery_fingerprint'):
        recovery = root/'com.apple.recovery.boot'
        good_new = good_new and recovery.is_dir() and efi_tree_fingerprint(recovery) == j['recovery_fingerprint']
    if good_new:
        backup = Path(j['backup']) if j.get('backup') else None
        if old.exists():
            if not backup or not backup.is_file() or checksum(backup) != j.get('backup_sha256'):
                raise RuntimeError('Previous EFI backup is not verified; old EFI preserved')
            _checked_tree(old)
            guard_usb()
            shutil.rmtree(old)
        for path_to_clean in (incoming, recovery_incoming):
            if path_to_clean.exists():
                _checked_tree(path_to_clean)
                guard_usb()
                shutil.rmtree(path_to_clean)
        j['phase'] = 'complete'
        write_receipt(path,j)
        return {'drive':f'{letter}:', 'action':'completed', 'backup':j.get('backup')}
    if current.is_dir() and j.get('original_fingerprint') and efi_tree_fingerprint(current) == j['original_fingerprint']:
        for item in (incoming, recovery_incoming):
            if item.exists():
                _checked_tree(item)
                guard_usb()
                shutil.rmtree(item)
        quarantine_new_recovery()
        j['phase'] = 'rolled_back'
        write_receipt(path,j)
        return {'drive':f'{letter}:', 'action':'already_restored'}
    if not j.get('had_original'):
        if not current.exists():
            for item in (incoming, recovery_incoming):
                if item.exists():
                    _checked_tree(item)
                    guard_usb()
                    shutil.rmtree(item)
            quarantine_new_recovery()
            j['phase']='cancelled'
            write_receipt(path,j)
            return {'drive':f'{letter}:', 'action':'cancelled'}
        raise RuntimeError('No previous EFI exists to restore. Manually inspect the USB before booting.')
    original_fingerprint = j.get('original_fingerprint')
    old_is_verified = False
    if old.is_dir():
        _checked_tree(old)
        old_is_verified = (bool(original_fingerprint) and
                           efi_tree_fingerprint(old) == original_fingerprint)
    if old_is_verified:
        restore_source = old
    else:
        # A power loss or disk fault can corrupt the relocated original EFI.
        # Never restore it solely because the folder exists.
        archive = Path(j['backup']) if j.get('backup') else None
        if not archive or not archive.is_file() or checksum(archive) != j.get('backup_sha256'):
            raise RuntimeError('Original USB EFI is damaged and no verified backup is available; manual inspection required')
        from .engine import safe_unzip
        temp = root/'EFI.hackpilot-restore'
        if temp.exists():
            raise RuntimeError('Existing restore folder requires manual inspection')
        temp.mkdir()
        try:
            safe_unzip(archive, temp)
            restore_source = temp/'EFI'
            _checked_tree(restore_source)
            if efi_tree_fingerprint(restore_source) != original_fingerprint:
                raise RuntimeError('EFI backup contents do not match the original EFI fingerprint')
        except Exception:
            shutil.rmtree(temp, ignore_errors=True)
            raise
    _same_device(letter,disk)
    if current.exists():
        _checked_tree(current)
        failed = root/('EFI.hackpilot-failed-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
        guard_usb()
        current.rename(failed)
    if old.is_dir() and not old_is_verified:
        # Preserve damaged source for inspection without obstructing a future transfer.
        damaged = root/('EFI.hackpilot-damaged-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
        guard_usb()
        old.rename(damaged)
    guard_usb()
    restore_source.rename(current)
    # When restoring from ZIP, the now-empty extraction root is disposable.
    if not old_is_verified and temp.exists():
        guard_usb()
        shutil.rmtree(temp)
    for item in (incoming, recovery_incoming):
        if item.exists():
            _checked_tree(item)
            guard_usb()
            shutil.rmtree(item)
    quarantine_new_recovery()
    j['phase'] = 'rolled_back'
    write_receipt(path,j)
    return {'drive':f'{letter}:', 'action':'restored', 'backup':j.get('backup')}
