"""Durable USB transfer receipts; no automatic disk changes on application startup."""
import hashlib
import json
import os
import re
from pathlib import Path
import tempfile

FINAL = {'complete', 'rolled_back', 'cancelled', 'preflight_failed'}
PHASES = FINAL | {'starting', 'backup_verified', 'staged', 'old_moved',
                  'new_moved', 'committed', 'cleanup_needed'}
MAX_RECEIPT_BYTES = 256 * 1024


def _valid_receipt(data, path):
    # A syntactically valid JSON object is not necessarily a usable recovery
    # receipt. Refuse it before any USB rename or deletion is attempted.
    if not isinstance(data, dict) or data.get('phase') not in PHASES:
        return False
    if not re.fullmatch(r'[A-Z]', str(data.get('letter', ''))):
        return False
    if type(data.get('disk_number')) is not int or data['disk_number'] < 0:
        return False
    if not isinstance(data.get('volume_id'), str) or not data['volume_id'].strip():
        return False
    # v1.13 journals retain extra removable-disk identity for safe repair.
    # Older valid receipts may omit these optional Windows identifiers.
    unique = data.get('disk_unique_id')
    if unique is not None and (not isinstance(unique, str) or len(unique) > 512):
        return False
    partition = data.get('partition_number')
    if partition is not None and (type(partition) is not int or partition < 0):
        return False
    offset = data.get('partition_offset')
    if offset is not None and (not isinstance(offset, str) or
                              len(offset) > 24 or not offset.isascii() or
                              not offset.isdecimal()):
        return False
    def digest(value):
        return isinstance(value, str) and re.fullmatch(r'[0-9a-f]{64}', value) is not None
    if not digest(data.get('expected_fingerprint')):
        return False
    if type(data.get('had_original')) is not bool:
        return False
    if data['had_original'] and not digest(data.get('original_fingerprint')):
        return False
    # Old journals omit this flag; absence retains the conservative legacy
    # repair policy. New journals explicitly distinguish a pre-existing Apple
    # Recovery folder from one copied by the interrupted transaction.
    if 'recovery_preexisting' in data and type(data['recovery_preexisting']) is not bool:
        return False
    if data.get('recovery_preexisting') and not digest(data.get('recovery_fingerprint')):
        return False
    for optional in ('recovery_fingerprint', 'backup_sha256'):
        if data.get(optional) is not None and not digest(data[optional]):
            return False
    if data.get('backup') is not None and (not isinstance(data['backup'], str) or not data['backup']):
        return False
    return True


def write_receipt(path, receipt):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, filename = tempfile.mkstemp(prefix='journal-', suffix='.tmp', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(receipt, stream, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(filename, path)
    finally:
        if os.path.exists(filename):
            os.unlink(filename)


def pending_receipts(folder):
    results = []
    for path in sorted(Path(folder).glob('usb-*.json')) if Path(folder).is_dir() else []:
        try:
            if path.is_symlink() or path.stat().st_size > MAX_RECEIPT_BYTES:
                raise ValueError('Untrusted or oversized USB journal')
            data = json.loads(path.read_text(encoding='utf-8'))
            if not _valid_receipt(data, path):
                raise ValueError('Malformed USB transaction journal')
            if data['phase'] not in FINAL:
                results.append({**data, 'journal_id': path.stem})
        except (OSError, ValueError, UnicodeError):
            # Malformed but parseable journals are as dangerous as bad JSON:
            # neither should be treated as completed or used to rename files.
            results.append({'journal_id': path.stem, 'phase': 'corrupt', 'letter': 'unknown'})
    return results


def checksum(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
