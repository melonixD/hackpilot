"""Download open-source upstream engine on demand; run it in a separate process."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import urllib.parse
import zipfile

ENGINE_REPO = 'lzhoang2801/OpCore-Simplify'
SNIFFER_REPO = 'lzhoang2801/Hardware-Sniffer'
MAX_ARCHIVE = 120 * 1024 * 1024
USER_AGENT = 'HackPilot/1.10 (local EFI research tool)'


def request_json(url):
    if urllib.parse.urlsplit(url).scheme.lower() != 'https':
        raise ValueError('Only HTTPS metadata requests are allowed')
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT, 'Accept': 'application/vnd.github+json'})
    with urllib.request.urlopen(req, timeout=40) as response:
        if urllib.parse.urlsplit(response.geturl()).scheme.lower() != 'https':
            raise ValueError('Insecure metadata redirect refused')
        if int(response.headers.get('Content-Length', '0')) > 16 * 1024 * 1024:
            raise ValueError('Upstream metadata is too large')
        raw = response.read(16 * 1024 * 1024 + 1)
        if len(raw) > 16 * 1024 * 1024:
            raise ValueError('Upstream metadata is too large')
        return json.loads(raw)


def download(url, target, max_bytes=MAX_ARCHIVE):
    """HTTPS only, bounded streaming download, atomic replacement and SHA-256 manifest."""
    if urllib.parse.urlsplit(url).scheme.lower() != 'https' or not urllib.parse.urlsplit(url).hostname:
        raise ValueError('Only HTTPS downloads are allowed')
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix='hackpilot-', dir=str(target.parent))
    digest, size = hashlib.sha256(), 0
    try:
        with os.fdopen(fd, 'wb') as out:
            req = urllib.request.Request(url, headers={'User-Agent':USER_AGENT, 'Accept':'application/octet-stream'})
            with urllib.request.urlopen(req, timeout=60) as response:
                if urllib.parse.urlsplit(response.geturl()).scheme.lower() != 'https':
                    raise ValueError('Insecure download redirect refused')
                if int(response.headers.get('Content-Length', '0')) > max_bytes:
                    raise ValueError('Download exceeds size limit')
                while True:
                    block = response.read(1024 * 1024)
                    if not block: break
                    size += len(block)
                    if size > max_bytes: raise ValueError('Download exceeds size limit')
                    out.write(block)
                    digest.update(block)
        os.replace(temp_name, target)
    finally:
        if os.path.exists(temp_name): os.remove(temp_name)
    return {'sha256':digest.hexdigest(), 'bytes':size, 'url':url}


def safe_unzip(zip_path, destination):
    destination=Path(destination)
    destination.mkdir(parents=True,exist_ok=True)
    root=destination.resolve()
    with zipfile.ZipFile(zip_path) as archive:
        entries = archive.infolist()
        if len(entries) > 12000:
            raise ValueError('Archive contains too many files')
        if sum(i.file_size for i in entries) > 550*1024*1024:
            raise ValueError('Uncompressed archive too large')
        seen = set()
        # Validate the whole manifest first, before creating any extracted files.
        for item in entries:
            clean = item.filename.replace('\\', '/')
            parts = clean.rstrip('/').split('/')
            # Windows treats trailing dots/spaces, reserved device names and
            # colons as special paths; ZIP names must be portable to FAT32.
            try:
                from hackpilot.efi import _safe_relative
            except ModuleNotFoundError:
                # The EFI builder also invokes this helper from a standalone
                # worker process, with hackpilot/ on sys.path instead of the
                # package parent. Both import contexts must behave identically.
                from efi import _safe_relative
            if not _safe_relative(clean.rstrip('/')):
                raise ValueError('Unsafe ZIP archive path')
            folded = clean.rstrip('/').casefold()
            if folded in seen:
                raise ValueError('Duplicate or case-colliding ZIP entry')
            seen.add(folded)
            safe_target = (destination / clean).resolve()
            if root not in safe_target.parents:
                raise ValueError('Unsafe ZIP archive path')
            if (item.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('ZIP symlinks are not permitted')
        for item in entries:
            safe_target=(destination / item.filename.replace('\\', '/')).resolve()
            if item.is_dir():
                safe_target.mkdir(parents=True, exist_ok=True)
                continue
            safe_target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(item) as src, open(safe_target, 'wb') as dst:
                shutil.copyfileobj(src,dst)


def engine_tree_hash(root):
    """Hash *all* installed Scripts assets, not just .py files.

    Upstream also loads JSON/plist/text tables. Those are execution inputs: a
    modified compatibility database can generate an unsafe EFI without changing
    a single Python source file. Bytecode caches and build output are excluded.
    """
    root = Path(root)
    if not root.is_dir() or root.is_symlink() or bool(getattr(root.lstat(), 'st_file_attributes', 0) & 0x400):
        raise RuntimeError('Upstream engine root is missing or linked')
    scripts = root / 'Scripts'
    required = [root / 'OpCore-Simplify.py', root / 'LICENSE']
    if (not scripts.is_dir() or scripts.is_symlink() or
        any(not f.is_file() or f.is_symlink() for f in required)):
        raise RuntimeError('Upstream engine source is incomplete or linked')
    entries = sorted(scripts.rglob('*'), key=lambda x: x.relative_to(scripts).as_posix())
    files = list(required)
    # The upstream entry point imports root-level modules such as updater.py.
    # A cache checksum limited to Scripts/ would miss tampering with them.
    for entry in sorted(root.iterdir(), key=lambda x: x.name.casefold()):
        if entry in required:
            continue
        if entry.is_symlink():
            raise RuntimeError('Linked engine resources are not allowed')
        if entry.is_file() and entry.suffix.lower() in {
            '.py', '.pyw', '.json', '.plist', '.toml', '.ini', '.cfg',
            '.dll', '.pyd', '.exe', '.so', '.dylib'
        }:
            files.append(entry)
    for entry in entries:
        if entry.is_symlink():
            raise RuntimeError('Linked engine resources are not allowed')
        if '__pycache__' in entry.relative_to(scripts).parts:
            continue
        if entry.suffix in ('.pyc', '.pyo'):
            raise RuntimeError('Unexpected executable bytecode in engine resources')
        if entry.is_symlink():
            raise RuntimeError('Linked engine resources are not allowed')
        if entry.is_dir():
            continue
        if not entry.is_file():
            raise RuntimeError('Unexpected engine resource type')
        files.append(entry)
    if len(files) < 3:
        raise RuntimeError('Upstream engine scripts are missing')
    # This is also called while checking cached tools on startup. A damaged
    # cache must not force the UI to hash an unlimited number of huge files.
    if len(files) > 20_000:
        raise RuntimeError('OpenCore engine cache contains too many resources')
    total_size = 0
    for file in files:
        total_size += file.stat().st_size
        if total_size > 600 * 1024 * 1024:
            raise RuntimeError('OpenCore engine cache exceeds the 600 MiB limit')
    digest = hashlib.sha256()
    for file in files:
        digest.update(file.relative_to(root).as_posix().encode('utf-8') + b'\0')
        with file.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(block)
    return digest.hexdigest()


MAX_CACHE_MANIFEST_BYTES = 128 * 1024


def _bounded_manifest_bytes(path, limit=MAX_CACHE_MANIFEST_BYTES):
    """Fail closed before following links or reading attacker-sized cache files."""
    path = Path(path)
    if path.is_symlink():
        raise RuntimeError('Linked cached-tool manifest is not trusted')
    if not path.exists():
        return None
    if not path.is_file() or not 2 <= path.stat().st_size <= limit:
        raise RuntimeError('Cached-tool manifest is empty or exceeds its size limit')
    with path.open('rb') as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise RuntimeError('Cached-tool manifest exceeds its size limit')
    return data


def cached_engine_verified(cache_dir):
    base=Path(cache_dir)
    manifest_file=base/'engine-manifest.json'
    root=base/'opcore-simplify'
    try:
        payload = _bounded_manifest_bytes(manifest_file)
        if payload is None:
            return False
        meta=json.loads(payload.decode('utf-8'))
        return (meta.get('repository')==ENGINE_REPO and
                isinstance(meta.get('commit'),str) and len(meta['commit'])==40 and
                meta.get('source_tree_sha256')==engine_tree_hash(root))
    except (OSError, ValueError, RuntimeError, TypeError):
        return False


def _atomic_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmpname = tempfile.mkstemp(prefix='manifest-', suffix='.tmp', dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as out:
            json.dump(payload,out,indent=2)
            out.flush()
            os.fsync(out.fileno())
        os.replace(tmpname,path)
    finally:
        if os.path.exists(tmpname):
            os.unlink(tmpname)


def setup_engine(cache_dir, refresh=False):
    """Install an explicitly pinned upstream commit without deleting a working cache on failure."""
    base = Path(cache_dir)
    base.mkdir(parents=True, exist_ok=True)
    root = base / 'opcore-simplify'
    manifest_file = base / 'engine-manifest.json'
    if not refresh and cached_engine_verified(base):
        return {'root':str(root),'cached':True}
    meta = request_json(f'https://api.github.com/repos/{ENGINE_REPO}/commits/main')
    commit = str(meta.get('sha', ''))
    if len(commit) != 40 or any(c not in '0123456789abcdef' for c in commit.lower()):
        raise RuntimeError('Unexpected upstream revision; engine not installed')
    url = f'https://github.com/{ENGINE_REPO}/archive/{commit}.zip'
    zip_path = base / 'engine.zip'
    downloaded = download(url, zip_path)
    extracted = Path(tempfile.mkdtemp(prefix='engine-extract-', dir=str(base)))
    previous = None
    try:
        safe_unzip(zip_path, extracted)
        candidates = list(extracted.glob('*/OpCore-Simplify.py'))
        if len(candidates) != 1:
            raise RuntimeError('Upstream archive layout changed')
        candidate = candidates[0].parent
        if not (candidate/'LICENSE').is_file() or not (candidate/'Scripts').is_dir():
            raise RuntimeError('Upstream archive is incomplete or missing its license')
        # Hash the staged source before touching the existing working cache.
        manifest = {'repository': ENGINE_REPO, 'commit':commit,
                    'source_tree_sha256':engine_tree_hash(candidate), **downloaded}
        prior_manifest = _bounded_manifest_bytes(manifest_file)
        if root.exists():
            previous = base / ('engine-previous-' + os.urandom(5).hex())
            root.rename(previous)
        try:
            shutil.move(str(candidate), str(root))
            _atomic_json(manifest_file,manifest)
        except Exception:
            # Two-part commit: roll back BOTH folder and manifest on failure.
            if root.exists():
                shutil.rmtree(root)
            if previous and previous.exists():
                previous.rename(root)
            if prior_manifest is None:
                manifest_file.unlink(missing_ok=True)
            else:
                fd, name=tempfile.mkstemp(prefix='manifest-restore-',dir=str(base))
                try:
                    with os.fdopen(fd,'wb') as restore:
                        restore.write(prior_manifest)
                        restore.flush();os.fsync(restore.fileno())
                    os.replace(name,manifest_file)
                finally:
                    if os.path.exists(name):os.unlink(name)
            raise
        if previous:
            shutil.rmtree(previous, ignore_errors=True)
        return {'root':str(root),'commit':commit,'cached':False}
    finally:
        shutil.rmtree(extracted,ignore_errors=True)


def deep_scan(cache_dir, report_dir):
    """Capture into a disposable folder; a failed scan cannot destroy a good report."""
    if os.name != 'nt':
        raise RuntimeError('Deep scan requires Windows')
    base = Path(cache_dir)
    base.mkdir(parents=True, exist_ok=True)
    binary = base / 'Hardware-Sniffer-CLI.exe'
    manifest_path = base / 'sniffer-manifest.json'
    rollback = base / 'Hardware-Sniffer-CLI.exe.rollback'
    incoming = base / 'Hardware-Sniffer-CLI.exe.incoming'
    if rollback.exists() or incoming.exists():
        raise RuntimeError('Interrupted Hardware Sniffer update detected; cached scanner needs repair')
    prior_manifest = _bounded_manifest_bytes(manifest_path)
    try:
        saved_manifest = json.loads(prior_manifest) if prior_manifest else {}
    except (ValueError, TypeError, UnicodeError):
        saved_manifest = {}
    trusted_cached = False
    expected = saved_manifest.get('sha256') if isinstance(saved_manifest, dict) else None
    if binary.is_file() and isinstance(expected, str) and len(expected) == 64:
        with binary.open('rb') as stream:
            trusted_cached = hashlib.file_digest(stream, 'sha256').hexdigest() == expected
    # A previously verified scanner should work during a temporary network outage.
    try:
        release = request_json(f'https://api.github.com/repos/{SNIFFER_REPO}/releases/latest')
    except (OSError, ValueError, TimeoutError):
        if not trusted_cached:
            raise RuntimeError('Cannot obtain Hardware Sniffer release and no verified cache is available')
        release = None
    asset = None
    if release is not None:
        if not isinstance(release, dict):
            raise RuntimeError('Invalid Hardware Sniffer release metadata')
        assets = release.get('assets', [])
        if not isinstance(assets, list):
            raise RuntimeError('Invalid Hardware Sniffer release assets')
        asset = next((item for item in assets if isinstance(item, dict) and
                      str(item.get('name', '')).lower() == 'hardware-sniffer-cli.exe'), None)
        if not asset:
            if not trusted_cached:
                raise RuntimeError('Official Hardware Sniffer CLI release unavailable')
            release = None
    # GitHub release assets now expose their publisher-side SHA-256 digest.
    # Checking only our own post-download hash does *not* establish that the
    # bytes match the published release, or that a previously cached binary
    # still matches a changed asset under the same tag.
    published_digest = None
    if asset is not None:
        published = asset.get('digest')
        if published is not None:
            if (not isinstance(published, str) or not published.startswith('sha256:') or
                    len(published) != 71 or any(c not in '0123456789abcdefABCDEF' for c in published[7:])):
                raise RuntimeError('Hardware Sniffer release has a malformed publisher SHA-256 digest')
            published_digest = published[7:].lower()
    use_cached = trusted_cached and (release is None or
        (saved_manifest.get('tag') == release.get('tag_name') and
         (published_digest is None or saved_manifest.get('sha256') == published_digest)))
    if not use_cached:
        if not asset or not isinstance(asset.get('browser_download_url'), str):
            raise RuntimeError('Hardware Sniffer release asset missing')
        previous_binary = binary.is_file()
        try:
            dl = download(asset['browser_download_url'], incoming, 60 * 1024 * 1024)
            with incoming.open('rb') as stream:
                new_digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            if new_digest != dl.get('sha256'):
                raise RuntimeError('Hardware Sniffer download digest mismatch')
            if published_digest is not None and new_digest != published_digest:
                raise RuntimeError('Hardware Sniffer download does not match its published SHA-256 digest')
            if previous_binary:
                os.replace(binary, rollback)
            try:
                os.replace(incoming, binary)
                _atomic_json(manifest_path, {'tag': release.get('tag_name'),
                                             'publisher_sha256': published_digest, **dl})
            except Exception:
                if previous_binary and rollback.exists():
                    os.replace(rollback, binary)
                elif not previous_binary:
                    binary.unlink(missing_ok=True)
                if prior_manifest is None:
                    manifest_path.unlink(missing_ok=True)
                else:
                    fd, tmp = tempfile.mkstemp(prefix='sniffer-restore-', dir=str(base))
                    try:
                        with os.fdopen(fd, 'wb') as out:
                            out.write(prior_manifest)
                            out.flush(); os.fsync(out.fileno())
                        os.replace(tmp, manifest_path)
                    finally:
                        if os.path.exists(tmp): os.unlink(tmp)
                raise
            rollback.unlink(missing_ok=True)
        finally:
            incoming.unlink(missing_ok=True)
    report_dir = Path(report_dir)
    report_dir.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix='hackpilot-report-', dir=str(report_dir.parent)))
    previous = None
    try:
        process = subprocess.run([str(binary), '-e', '-o', str(staging)],
                                 capture_output=True, timeout=180,
                                 creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        report = staging / 'Report.json'
        acpi = staging / 'ACPI'
        if process.returncode or not report.is_file() or not acpi.is_dir():
            detail = process.stderr.decode(errors='replace')[-400:]
            raise RuntimeError('Hardware scan incomplete. Administrator access may be needed. ' + detail)
        from .hardware_scale import MAX_DEEP_REPORT_BYTES
        if report.stat().st_size > MAX_DEEP_REPORT_BYTES:
            raise RuntimeError('Hardware report is unexpectedly large or malformed; refusing unbounded scan data')
        data = json.loads(report.read_text(encoding='utf-8-sig'))
        if not isinstance(data, dict) or not isinstance(data.get('CPU'), dict) or not data.get('GPU'):
            raise RuntimeError('Hardware scan missing CPU or graphics details')
        if not any(acpi.rglob('*.aml')):
            raise RuntimeError('ACPI tables are missing')
        # Check the report and bind every AML table before publishing this scan.
        from .hardware import sniffer_summary
        from .scan_seal import seal_scan
        summary = sniffer_summary(data)
        scan_fingerprint = seal_scan(report, acpi)
        if report_dir.exists():
            previous = report_dir.with_name(report_dir.name + '-old-' + os.urandom(5).hex())
            report_dir.rename(previous)
        try:
            staging.rename(report_dir)
        except Exception:
            if previous and previous.exists():
                previous.rename(report_dir)
            raise
        if previous:
            shutil.rmtree(previous, ignore_errors=True)
        return {'report': str(report_dir / 'Report.json'), 'acpi': str(report_dir / 'ACPI'),
                'data': data, 'summary': summary, 'scan_seal': scan_fingerprint, 'sniffer': {'cached': use_cached}}
    finally:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)



def setup_validator(cache_dir, refresh=False, expected_opencore=None):
    """Install ocvalidate from the SAME official release as the selected OpenCore.efi.

    A SHA-256 identity pairing is stronger than comparing a version label: upstream
    revisions can change while keeping similar filenames. Never use an unmatched tool.
    """
    expected_sha = None
    if expected_opencore is not None:
        with Path(expected_opencore).open('rb') as stream:
            expected_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    # Different OpenCore releases need different ocvalidate binaries. Never
    # invalidate an older working build while preparing a new one.
    base = Path(cache_dir) / 'validators' / expected_sha if expected_sha else Path(cache_dir) / 'validator'
    base.mkdir(parents=True, exist_ok=True)
    name = 'ocvalidate.exe' if os.name == 'nt' else 'ocvalidate'
    binary = base / name
    manifest_file = base / 'validator-manifest.json'
    if not refresh and binary.is_file() and manifest_file.is_file() and not (base / (name + '.rollback')).exists():
        try:
            payload = _bounded_manifest_bytes(manifest_file)
            manifest = json.loads(payload.decode('utf-8'))
            with binary.open('rb') as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            if (manifest.get('binary_sha256') == digest and manifest.get('opencore_sha256') and
                (not expected_sha or manifest['opencore_sha256'] == expected_sha)):
                return {'root':str(base), 'binary':str(binary), 'cached':True}
        except (ValueError, OSError, TypeError):
            pass
    feed = request_json('https://raw.githubusercontent.com/dortania/build-repo/builds/latest.json')
    releases = (feed.get('OpenCorePkg') or {}).get('versions') or []
    if not releases:
        raise RuntimeError('OpenCore validator releases are unavailable')
    found = False
    # A bounded search prevents untrusted feeds from causing unlimited downloads.
    for info in releases[:6] if expected_sha else releases[:1]:
        url = (info.get('links') or {}).get('release')
        expected_archive = ((info.get('hashes') or {}).get('release') or {}).get('sha256')
        if (not isinstance(url,str) or not isinstance(expected_archive,str) or
            len(expected_archive) != 64 or any(c not in '0123456789abcdefABCDEF' for c in expected_archive)):
            raise RuntimeError('Validator release is missing a valid download or SHA-256')
        with tempfile.TemporaryDirectory(prefix='hackpilot-validator-', dir=str(base)) as tempdir:
            temp = Path(tempdir)
            archive = temp/'OpenCorePkg.zip'
            receipt = download(url, archive)
            if receipt['sha256'].lower() != expected_archive.lower():
                raise RuntimeError('OpenCorePkg checksum does not match the published build feed')
            extracted = temp/'unpacked'
            safe_unzip(archive, extracted)
            matches = [f for f in extracted.rglob(name) if f.is_file() and
                       'utilities' in [x.lower() for x in f.parts] and
                       'ocvalidate' in [x.lower() for x in f.parts]]
            bootloaders = [f for f in extracted.rglob('OpenCore.efi') if f.is_file() and
                           [part.lower() for part in f.parts[-3:]] == ['efi','oc','opencore.efi'] and
                           'x64' in [part.lower() for part in f.parts]]
            if len(matches) != 1 or matches[0].stat().st_size < 10000 or len(bootloaders) != 1:
                raise RuntimeError('OpenCore archive is missing a matching X64 bootloader and ocvalidate')
            with bootloaders[0].open('rb') as stream:
                opencore_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
            # When supplied, bind the EFI entrypoint and runtime driver to
            # the same upstream OpenCore release as the validator/bootloader.
            base_efi = bootloaders[0].parent.parent
            sibling_files = {'bootx64_sha256': base_efi/'BOOT'/'BOOTx64.efi',
                             'openruntime_sha256': bootloaders[0].parent/'Drivers'/'OpenRuntime.efi'}
            component_hashes = {}
            for key, component in sibling_files.items():
                if component.is_file():
                    with component.open('rb') as component_file:
                        component_hashes[key] = hashlib.file_digest(component_file,'sha256').hexdigest()
            if expected_sha and expected_sha != opencore_sha:
                continue
            candidate = matches[0]
            incoming = base / (name + '.incoming')
            rollback_binary = base / (name + '.rollback')
            prior_manifest = _bounded_manifest_bytes(manifest_file)
            previous_binary = binary.is_file()
            if rollback_binary.exists():
                # A prior interrupted validator update must not be silently overwritten.
                raise RuntimeError('Validator update recovery file found; manual review required')
            try:
                shutil.copy2(candidate, incoming)
                if os.name != 'nt':
                    incoming.chmod(incoming.stat().st_mode | 0o111)
                with incoming.open('rb') as stream:
                    binary_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
                manifest = {'url': url, 'archive_sha256': expected_archive,
                            'binary_sha256': binary_sha, 'opencore_sha256': opencore_sha,
                            'version': info.get('version', 'unknown'), **component_hashes}
                if previous_binary:
                    # Preserve old binary until manifest and new executable are committed.
                    shutil.copy2(binary, rollback_binary)
                try:
                    os.replace(incoming, binary)
                    _atomic_json(manifest_file, manifest)
                except Exception:
                    if previous_binary and rollback_binary.is_file():
                        os.replace(rollback_binary, binary)
                    elif not previous_binary:
                        binary.unlink(missing_ok=True)
                    if prior_manifest is None:
                        manifest_file.unlink(missing_ok=True)
                    else:
                        fd, prior_tmp = tempfile.mkstemp(prefix='validator-restore-', dir=str(base))
                        try:
                            with os.fdopen(fd, 'wb') as stream:
                                stream.write(prior_manifest)
                                stream.flush()
                                os.fsync(stream.fileno())
                            os.replace(prior_tmp, manifest_file)
                        finally:
                            if os.path.exists(prior_tmp):
                                os.unlink(prior_tmp)
                    raise
                if rollback_binary.exists():
                    rollback_binary.unlink()
            finally:
                incoming.unlink(missing_ok=True)
            found = True
            break
    if not found:
        raise RuntimeError('No version-matched ocvalidate release found; existing EFI preserved')
    return {'root':str(base), 'binary':str(binary), 'cached':False}


def clean_engine_bytecode(root):
    """Remove stale Python caches so modified .pyc files cannot bypass source integrity."""
    scripts = Path(root) / 'Scripts'
    if scripts.is_symlink() or not scripts.is_dir():
        raise RuntimeError('Engine Scripts folder is missing or linked')
    # The engine imports updater.py at repository root. Its bytecode cache
    # must be treated exactly like Scripts/__pycache__, not left executable.
    for cache in sorted(Path(root).rglob('__pycache__'), key=lambda p: len(p.parts), reverse=True):
        if cache.is_symlink() or not cache.is_dir():
            raise RuntimeError('Unexpected linked Python cache in engine')
        shutil.rmtree(cache)
    for top in (Path(root), scripts):
        for bytecode in top.glob('*.pyc'):
            if bytecode.is_symlink() or not bytecode.is_file():
                raise RuntimeError('Unexpected linked bytecode in engine')
            bytecode.unlink()


def run_auto_builder(engine_root, report_file, acpi_dir, output_dir, log_file, target_darwin="auto", validator_dir=None, selections=None, usb_map_path=None):
    """Invoke adapter in child process. Only validated complete output is published."""
    clean_engine_bytecode(engine_root)
    adapter = Path(__file__).with_name('upstream_adapter.py')
    selected_json = json.dumps(selections or {})
    if getattr(sys,'frozen',False):
        args=[sys.executable,'--worker-adapter',str(engine_root),str(report_file),str(acpi_dir),str(output_dir),str(target_darwin),str(validator_dir or ""),selected_json,str(usb_map_path or ''),'--worker-log',str(log_file)]
    else:
        args=[sys.executable,'-u',str(adapter),str(engine_root),str(report_file),str(acpi_dir),str(output_dir),str(target_darwin),str(validator_dir or ""),selected_json,str(usb_map_path or '')]
    env=os.environ.copy();env['PYTHONIOENCODING']='utf-8'
    env['PYTHONDONTWRITEBYTECODE']='1'
    Path(log_file).parent.mkdir(parents=True,exist_ok=True)
    with open(log_file,'w',encoding='utf-8') as log:
        result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=1800,env=env)
    if result.returncode:
        with Path(log_file).open('rb') as reader:
            reader.seek(0, os.SEEK_END)
            reader.seek(max(0, reader.tell() - 6400))
            tail=reader.read(6400).decode('utf-8',errors='replace')[-1600:]
        raise RuntimeError(f'Automatic build stopped safely. Review the build log.\n{tail}')
    if not (Path(output_dir)/'EFI'/'OC'/'config.plist').exists():
        raise RuntimeError('Engine exited without producing an EFI')
    return {'output':str(output_dir),'log':str(log_file)}
