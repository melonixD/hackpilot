"""Offline integration checks of the packaged server and real child workers.

Uses a disposable demo workspace, loopback HTTP and synthetic recovery helpers.
Never scans hardware, contacts Apple or writes a removable drive.
"""
import json
import re
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import urllib.error
import urllib.request

from .server import State, create_server


def check_runtime():
    with tempfile.TemporaryDirectory(prefix='hackpilot-runtime-') as temporary:
        home = Path(temporary)
        server = create_server(State(demo=True, home=home / 'workspace'))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        base = f'http://127.0.0.1:{server.server_port}'
        try:
            with opener.open(base + '/', timeout=10) as response:
                page = response.read()
                if b'__TOKEN__' in page or b'HackPilot' not in page:
                    raise RuntimeError('Packaged homepage or session token is missing')
                match = re.search(br'name="hackpilot-token" content="([^"]+)"', page)
                if match is None:
                    raise RuntimeError('Packaged session token is missing')
                token = match[1].decode('ascii')
            with opener.open(base + '/api/status', timeout=10) as response:
                status = json.load(response)
                if status.get('compatibility', {}).get('can_attempt') is not False:
                    raise RuntimeError('Empty demo workspace unexpectedly permits setup')
            request = urllib.request.Request(base + '/api/scan', data=b'{}',
                                             headers={'Content-Type': 'application/json'})
            try:
                opener.open(request, timeout=10).close()
            except urllib.error.HTTPError as exc:
                if exc.code != 403:
                    raise
            else:
                raise RuntimeError('Packaged API accepted a request without a session token')
            request = urllib.request.Request(
                base + '/api/scan', data=b'[' * 10000 + b'0' + b']' * 10000,
                headers={'Content-Type': 'application/json', 'X-HackPilot-Token': token})
            try:
                opener.open(request, timeout=10).close()
            except urllib.error.HTTPError as exc:
                if exc.code != 400:
                    raise
            else:
                raise RuntimeError('Malformed API body was accepted')
            for asset in ('app.js', 'app.css'):
                with opener.open(base + '/' + asset, timeout=10) as response:
                    if not response.read():
                        raise RuntimeError('Packaged frontend asset is empty')
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=10)
        if sys.platform == 'win32':
            from .usb_format import result_channel, FORMAT, encoded
            with result_channel() as channel:
                # Exercise the exact elevated response writer without UAC or
                # any disk commands, inside the packaged executable.
                writer = FORMAT[FORMAT.index('$json=$answer'):]
                script = "$resultUrl='"+channel.url+"';$answer=@{ok=$true;letter='E';filesystem='FAT32'};"+writer
                result = subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',encoded(script)],capture_output=True,timeout=20)
                if result.returncode or channel.state['result'] is None or channel.state['result'].get('letter') != 'E':
                    raise RuntimeError('Packaged Windows USB result-channel check failed')
        worker = home / 'worker path Ω'
        worker.mkdir()
        script = worker / 'recovery test.py'
        # Exercise imports used by the pinned macrecovery helper. PyInstaller
        # cannot discover imports in a script downloaded after packaging.
        script.write_text(
            'import argparse, hashlib, json, linecache, os, random, shutil, struct, string, sys\n'
            'from urllib.request import Request, HTTPError, urlopen\n'
            'from urllib.parse import urlparse\n'
            "print('recovery-worker-ok')\n"
            'raise SystemExit(int(sys.argv[1]))\n', encoding='utf-8')
        command = ([sys.executable] if getattr(sys, 'frozen', False)
                   else [sys.executable, '-m', 'hackpilot.main'])
        for expected in (0, 7):
            log = worker / f'exit-{expected}.log'
            result = subprocess.run(
                [*command, '--worker-recovery', str(script), str(expected),
                 '--worker-log', str(log)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=45)
            if result.returncode != expected or 'recovery-worker-ok' not in log.read_text(encoding='utf-8'):
                raise RuntimeError(f'Packaged recovery worker exit/log check failed ({expected})')
