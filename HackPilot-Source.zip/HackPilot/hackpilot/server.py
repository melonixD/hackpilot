"""Local desktop HTTP bridge. Explicit CSRF token; no network listener or arbitrary shell calls."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import copy
import json
import hashlib
import os
import secrets
import shutil
import tempfile
import threading
import traceback
import urllib.parse
import webbrowser

from .hardware import scan_windows, sniffer_summary, imported_native
from .compat import assess
from .bios import checklist
from .engine import deep_scan, setup_engine, setup_validator, run_auto_builder, cached_engine_verified
from .efi import validate_efi, efi_fingerprint, load_build_manifest
from .usb import list_usb, safe_usb_copy, repair_usb
from .recovery import download_recovery, board_id_from_efi, verify_recovery, profile_for_darwin
from .guided import available_choices, validate_selections
from .usb_journal import pending_receipts
from .workspace_lock import workspace_lock
from .diagnostics import analyze_log
from .scan_seal import seal_scan, assert_scan_seal
from .hardware_scale import network_preflight, MAX_DEEP_REPORT_BYTES
from .usb_mapping import (backend_verified, install_backend, discover_controllers,
    normalize_snapshot, merge_snapshots, update_port_selection, generate_utbmap,
    selection_hash, map_is_ready, controller_topology, valid_saved_snapshot)

def _bounded_text_tail(path, limit=14000):
    """Read only the end of a potentially huge native-worker log file."""
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        return ''
    with path.open('rb') as stream:
        stream.seek(0, os.SEEK_END)
        stream.seek(max(0, stream.tell() - limit * 4))
        tail = stream.read(limit * 4)
    return tail.decode('utf-8', errors='replace')[-limit:]


BASE=Path(__file__).resolve().parent.parent
STATIC=BASE/'web'
APP_HOME=Path(os.environ.get('LOCALAPPDATA') or Path.home()/'.hackpilot')/'HackPilot'

class State:
    def __init__(self,demo=False,home=None):
        self.demo=demo;self.home=Path(home) if home else APP_HOME
        self.home.mkdir(parents=True,exist_ok=True)
        self.cache=self.home/'cache';self.cache.mkdir(exist_ok=True)
        self.mapping_dir=self.home/'USBMapping';self.mapping_dir.mkdir(exist_ok=True)
        self.report_dir=self.home/'SystemReport'
        self.output=self.home/'Output';self.output.mkdir(exist_ok=True)
        self.build_dir=self.output/'LatestBuild'
        self.logfile=self.home/'logs'/'build.log'
        self.hardware=None;self.sniffer_file=None;self.acpi_dir=None;self.deep_scan_verified=False;self.scan_seal=None;self.engine_dir=None;self.recovery_dir=None;self.validator_dir=None
        self.last_build=None;self.usb_copied=False;self.usb_prepared=False;self.recovery_verified=False;self.recovery_profile=None;self.diagnosis=None;self.tasks={};self.lock=threading.Lock();self._task_context=threading.local();self._device_choices_cache=None
        cached=self.cache/'opcore-simplify'
        if cached_engine_verified(self.cache): self.engine_dir=str(cached)
        validator=self.cache/'validator'
        bootloader=self.build_dir/'EFI'/'OC'/'OpenCore.efi'
        if bootloader.is_file():
            try:
                with bootloader.open('rb') as stream:
                    sha=hashlib.file_digest(stream,'sha256').hexdigest()
                versioned = self.cache/'validators'/sha
                if (versioned/('ocvalidate.exe' if os.name=='nt' else 'ocvalidate')).is_file():
                    validator=versioned
            except OSError:
                pass
        if (validator/('ocvalidate.exe' if os.name=='nt' else 'ocvalidate')).is_file():
            self.validator_dir=str(validator)
        saved_recovery=self.output/'Recovery'/'com.apple.recovery.boot'
        if (saved_recovery.is_dir() and not saved_recovery.is_symlink() and
            all((saved_recovery/name).is_file() and (saved_recovery/name).stat().st_size > 0
                for name in ('BaseSystem.dmg','BaseSystem.chunklist'))):
            self.recovery_dir=str(saved_recovery)
            self.recovery_verified=verify_recovery(saved_recovery, require_apple_signature=True)
        prior=self.report_dir/'Report.json'; acpi=self.report_dir/'ACPI'
        # A malformed previous report must not make the GUI allocate huge
        # amounts of memory or follow a linked file merely to show a preview.
        if (prior.is_file() and not prior.is_symlink() and
            2 <= prior.stat().st_size <= MAX_DEEP_REPORT_BYTES and
            acpi.is_dir() and not acpi.is_symlink()):
            try:
                self.hardware=sniffer_summary(json.loads(prior.read_text(encoding='utf-8-sig')))
                self.sniffer_file=str(prior);self.acpi_dir=str(acpi)
            except (ValueError,UnicodeError,KeyError,TypeError,OSError): pass
    def status(self):
        with self.lock:
            tasks=copy.deepcopy(self.tasks)
        return {'hardware':self.hardware,'compatibility':assess(self.hardware),'bios_checklist':checklist(self.hardware),
            'device_choices':self.device_choices(), 'diagnosis':self.diagnosis,
            'usb_recovery':pending_receipts(self.home/'Backups'/'transactions'),
            'deep_scan_ready':bool(self.deep_scan_verified and self.sniffer_file and Path(self.sniffer_file).is_file() and
                                   self.acpi_dir and Path(self.acpi_dir).is_dir()),
            'engine_ready':bool(self.engine_dir),'usb_copied':bool(self.usb_copied), 'usb_prepared':bool(self.usb_prepared), 'build_exists':(self.build_dir/'EFI'/'OC'/'config.plist').exists(),
            'last_build':self.last_build,'tasks':tasks,'paths':{'output':str(self.output),'log':str(self.logfile)},
            'demo':self.demo,'usb_mapping':self.usb_mapping_status(), 'recovery_verified':bool(self.recovery_verified),
            # File presence does not mean Apple Recovery was verified. A
            # partial download must never be shown as 'Downloaded' in the GUI.
            # Avoid gigabyte-size rehashes on each status poll: the write path
            # independently calls verify_recovery before copying.
            'recovery_ready':self._cached_recovery_present(), 'version':'1.18-windows-runtime'}
    def _cached_recovery_present(self):
        # Polling the UI must not fail because removable/recovery files vanish
        # between is_file() and stat() calls. Full hashes are rechecked on write.
        if not self.recovery_verified or not self.recovery_dir:
            return False
        try:
            folder = Path(self.recovery_dir)
            return (folder.is_dir() and not folder.is_symlink() and all(
                (folder / name).is_file() and not (folder / name).is_symlink() and
                (folder / name).stat().st_size > 0
                for name in ('BaseSystem.dmg', 'BaseSystem.chunklist')))
        except (OSError, ValueError):
            return False

    def device_choices(self):
        if not self.sniffer_file or not Path(self.sniffer_file).is_file():
            return {}
        try:
            p=Path(self.sniffer_file)
            stat=p.stat()
            key=(str(p), stat.st_mtime_ns, stat.st_size)
            if self._device_choices_cache and self._device_choices_cache[0]==key:
                return self._device_choices_cache[1]
            if stat.st_size>32*1024*1024:
                return {}
            choices=available_choices(json.loads(p.read_text(encoding='utf-8-sig')))
            self._device_choices_cache=(key,choices)
            return choices
        except (ValueError, OSError, UnicodeError, TypeError, KeyError):
            return {}

    def assert_idle(self):
        with self.lock:
            if any(task['state'] == 'running' for task in self.tasks.values()):
                raise RuntimeError('Another operation is running')

    def progress(self, label, percent=None):
        key = getattr(self._task_context, 'task_id', None)
        if key:
            with self.lock:
                if key in self.tasks and self.tasks[key]['state'] == 'running':
                    self.tasks[key]['message'] = label
                    if percent is not None:
                        self.tasks[key]['percent'] = percent

    def start(self,name,call):
        with self.lock:
            if any(x['state']=='running' for x in self.tasks.values()):
                raise RuntimeError('Another operation is running')
            # Keep recent operations only; avoid unbounded history on long-lived sessions.
            for old in list(self.tasks)[:-11]:
                if self.tasks[old]['state'] != 'running':
                    del self.tasks[old]
            key=secrets.token_hex(5)
            self.tasks[key]={'name':name,'state':'running','message':'Starting','percent':0}
        def job():
            self._task_context.task_id=key
            try:
                # Only one GUI instance may modify the same report, EFI,
                # recovery cache, or USB mapping workspace at a time.
                with workspace_lock(self.home):
                    value=call()
                with self.lock: self.tasks[key]={'name':name,'state':'done','result':value,'message':'Completed','percent':100}
            except Exception as e:
                with self.lock: self.tasks[key]={'name':name,'state':'error','message':str(e)[-2500:]}
            finally:
                self._task_context.task_id=None
        try:
            threading.Thread(target=job,daemon=True).start()
        except Exception as exc:
            # A failed thread launch must not leave the app permanently busy.
            with self.lock:
                self.tasks[key]={'name':name,'state':'error','message':str(exc)[-2500:]}
            raise
        return {'task_id':key}
    def scan(self):
        # Even a failed basic scan invalidates readiness derived from an old
        # machine. Displaying the old report as current would be misleading.
        self.deep_scan_verified=False;self.scan_seal=None;self.last_build=None
        self.usb_copied=False;self.usb_prepared=False;self._device_choices_cache=None
        self.sniffer_file=None;self.acpi_dir=None;self.hardware=None
        self.hardware=scan_windows()
        return {'hardware':self.hardware,'compatibility':assess(self.hardware)}
    def deep_scan(self):
        # Clear all readiness claims *before* refreshing the hardware scan.
        # A failed scan must not leave the previous PC's scan or EFI shown as
        # verified, even though the old report itself is preserved on disk.
        self.deep_scan_verified=False
        self.scan_seal=None
        # An interrupted fresh scan is not evidence for the previously
        # detected machine. Keep old files on disk but clear in-memory claims.
        self.sniffer_file=None;self.acpi_dir=None;self.hardware=None
        self.last_build=None
        self.usb_copied=False
        self.usb_prepared=False
        self._device_choices_cache=None
        result=deep_scan(self.cache,self.report_dir)
        self.sniffer_file=result['report'];self.acpi_dir=result['acpi'];self.deep_scan_verified=True
        self.scan_seal=result.get('scan_seal') or seal_scan(self.sniffer_file, self.acpi_dir)
        self.hardware=result.get('summary') or sniffer_summary(result['data'])
        self.last_build=None;self.usb_copied=False;self.usb_prepared=False
        return {'hardware':self.hardware,'compatibility':assess(self.hardware)}
    def install_engine(self):
        result=setup_engine(self.cache)
        self.engine_dir=result['root']
        return result
    def build(self,target="auto", selections=None):
        if self.demo: raise RuntimeError('EFI generation is disabled in demo mode')
        self.last_build = None
        self.usb_copied = False
        self.usb_prepared = False
        if target not in ("auto","20","21","22","23","24","25"):
            raise ValueError("Unsupported macOS selection")
        if not self.deep_scan_verified or not self.sniffer_file or not Path(self.sniffer_file).is_file() or not self.acpi_dir or not Path(self.acpi_dir).is_dir():
            raise RuntimeError('A valid Hardware Sniffer report and ACPI tables are required for SSDT generation')
        if not self.engine_dir or not cached_engine_verified(self.cache):
            self.engine_dir = None
            raise RuntimeError('OpenCore engine cache is missing or modified. Re-download the engine.')
        if not assess(self.hardware)['can_attempt']:
            raise RuntimeError('Blocking compatibility problems; build refused')
        # A report copied from another PC or edited after the scan cannot be
        # silently reused to generate ACPI and hardware-specific kexts.
        if self.scan_seal is not None:
            assert_scan_seal(self.sniffer_file, self.acpi_dir, self.scan_seal)
        selections = validate_selections(self.device_choices(), selections or {})
        # A new attempt must not inherit the previous EFI's successful result.
        # If the engine or validator fails, the UI must show 'check required',
        # never a stale verified/USB-ready state.
        self.last_build = None
        self.usb_copied = False
        self.usb_prepared = False
        # The adapter downloads the validator only after it knows exactly which
        # OpenCore.efi the upstream build selected. Never install a random latest
        # validator before generating the EFI.
        validator_root=self.cache/'validator'
        map_file=None
        mapping=self._read_usb_map()
        # A missing ports.json must not silently cause the builder to replace
        # a previously generated custom map with the generic UTBDefault kext.
        map_artifacts = ('ports.json', 'UTBMap.kext', 'usb-map-manifest.json')
        if mapping is None and any((self.mapping_dir/name).exists() or
                                   (self.mapping_dir/name).is_symlink()
                                   for name in map_artifacts):
            raise RuntimeError('Saved USB mapping scan is damaged or missing. Scan ports and rebuild the map.')
        if mapping and not map_is_ready(self.mapping_dir,mapping):
            raise RuntimeError('USB mapping is incomplete or changed. Finish Build USB map before generating EFI.')
        if mapping and map_is_ready(self.mapping_dir,mapping):
            if not backend_verified(self.cache):
                raise RuntimeError('USB mapping backend has changed; reinstall and scan ports')
            current=normalize_snapshot(discover_controllers(self.cache))
            if controller_topology(current)!=controller_topology(mapping):
                raise RuntimeError('USB controller topology changed since mapping. Refresh the USB map.')
            map_file=str(self.mapping_dir/'UTBMap.kext')
        result=run_auto_builder(self.engine_dir,self.sniffer_file,self.acpi_dir,self.build_dir,self.logfile,target,str(validator_root),selections,**({'usb_map_path':map_file} if map_file else {}))
        # The external EFI builder records the scan it actually consumed.
        # Never present a build as machine-specific if that identity differs.
        manifest_path = self.build_dir/'build-manifest.json'
        if not manifest_path.is_file() or manifest_path.is_symlink():
            raise RuntimeError('Generated EFI has no hardware-bound build manifest; refusing unverified build')
        try:
            build_manifest = load_build_manifest(self.build_dir)
        except (ValueError, OSError, UnicodeError, RuntimeError) as exc:
            raise RuntimeError('Generated EFI has an unreadable hardware manifest') from exc
        if (not isinstance(build_manifest, dict) or
            build_manifest.get('engine') != 'OpCore-Simplify' or
            build_manifest.get('needs_oclp') is not False or
            not isinstance(build_manifest.get('target_darwin'), str) or
            not isinstance(build_manifest.get('smbios_model'), str) or
            not build_manifest['smbios_model'] or
            not isinstance(build_manifest.get('component_inventory'), dict) or
            build_manifest.get('scan_seal') is None):
            raise RuntimeError('Generated EFI manifest is incomplete; refusing unverified build')
        # The v1.12 build worker must publish both scan and EFI content
        # identities. A missing hash would make the manifest a false attestation.
        if build_manifest.get('manifest_version') == 2:
            if build_manifest.get('efi_sha256') != efi_fingerprint(self.build_dir):
                raise RuntimeError('Generated EFI content differs from its build manifest')
        assert_scan_seal(self.sniffer_file, self.acpi_dir, build_manifest['scan_seal'])
        if self.scan_seal is not None and build_manifest['scan_seal'] != self.scan_seal:
            raise RuntimeError('EFI was built with different scan data; build refused')
        validator=setup_validator(self.cache,expected_opencore=self.build_dir/'EFI'/'OC'/'OpenCore.efi')
        self.validator_dir=validator['root']
        validation=validate_efi(self.build_dir,self.validator_dir)
        self.last_build=validation
        self.usb_copied=False;self.usb_prepared=False
        result['validation']=validation
        return result
    def auto_setup(self, target='auto', selections=None):
        """Single-click guarded path: no writes to removable drives."""
        if self.demo:
            raise RuntimeError('Auto setup is disabled in demo mode')
        if target not in ('auto', '20', '21', '22', '23', '24', '25'):
            raise ValueError('Unsupported macOS selection')
        if self.deep_scan_verified and self.hardware and not assess(self.hardware)['can_attempt']:
            raise RuntimeError('Hardware blockers detected. Review Hardware before building.')
        if not self.deep_scan_verified or not self.sniffer_file or not Path(self.sniffer_file).is_file() or not self.acpi_dir or not Path(self.acpi_dir).is_dir():
            self.progress('Scanning hardware and ACPI', 12)
            self.deep_scan()
        if not assess(self.hardware)['can_attempt']:
            raise RuntimeError('Hardware blockers detected. Review Hardware before building.')
        if not self.engine_dir or not cached_engine_verified(self.cache):
            self.progress('Preparing OpenCore engine', 38)
            self.install_engine()
        self.progress('Generating EFI', 62)
        result = self.build(target, selections)
        self.progress('Validating EFI', 90)
        if not self.last_build['valid']:
            raise RuntimeError('EFI generated, but validation did not pass. Open Logs for details.')
        return result

    def validate(self):
        # A new EFI validation result supersedes earlier readiness indicators.
        # A failed revalidation must never leave the current EFI marked ready.
        self.last_build = None
        self.usb_copied = False
        self.usb_prepared = False
        result=validate_efi(self.build_dir,self.validator_dir or self.engine_dir)
        self.last_build=result;return result
    def expected_recovery_profile(self):
        """Tie recovery to the generated build, never to an earlier app session."""
        manifest = self.build_dir / 'build-manifest.json'
        if not manifest.is_file() and not manifest.is_symlink():
            return None
        try:
            info = load_build_manifest(self.build_dir)
            if not isinstance(info, dict) or not info.get('target_darwin'):
                raise ValueError('missing target_darwin')
            return profile_for_darwin(info['target_darwin'])
        except (OSError, ValueError, TypeError, RuntimeError) as exc:
            raise RuntimeError('Cannot select Apple recovery for the generated EFI: ' + str(exc)) from exc

    def recovery(self,board_id):
        if self.demo:
            raise RuntimeError('Recovery downloads disabled in demo mode')
        board_id = str(board_id or '').strip()
        profile = self.expected_recovery_profile()
        if profile and board_id and board_id.casefold() != profile['board_id'].casefold():
            raise RuntimeError('Recovery board ID conflicts with the generated macOS version')
        if not board_id:
            # OpenCore's normal PlatformInfo/Automatic SMBIOS does not carry a
            # literal Mac board ID. Select the documented Apple recovery profile
            # from the generated macOS version rather than asking the user to
            # find a technically unrelated board identifier.
            manifest = self.build_dir / 'build-manifest.json'
            if manifest.is_file() or manifest.is_symlink():
                try:
                    info = load_build_manifest(self.build_dir)
                    if not isinstance(info, dict) or not info.get('target_darwin'):
                        raise ValueError('missing target_darwin')
                    profile = profile_for_darwin(info['target_darwin'])
                except (ValueError, TypeError, OSError, RuntimeError) as exc:
                    raise RuntimeError('Cannot select Apple recovery for this EFI: '+str(exc)) from exc
                board_id = profile['board_id']
            else:
                profile = None
                board_id = board_id_from_efi(self.build_dir)
                if not board_id:
                    raise ValueError('Recovery target is unknown. Generate an EFI or enter a documented Mac board ID.')
        elif profile is not None and board_id.casefold() != profile['board_id'].casefold():
            # A manually entered board ID represents a different recovery
            # source; never attribute its files to the previous auto profile.
            profile = None
        self.recovery_profile = profile
        self.recovery_verified = False
        if profile is not None:
            result = download_recovery(self.cache, self.output/'Recovery', board_id,
                                       profile['os_type'], profile['darwin_major'])
        else:
            result = download_recovery(self.cache, self.output/'Recovery', board_id)
        self.recovery_dir = result['folder']
        if profile is not None:
            self.recovery_verified = verify_recovery(self.recovery_dir, board_id,
                                                      profile['darwin_major'], profile['os_type'], require_apple_signature=True)
        else:
            self.recovery_verified = verify_recovery(self.recovery_dir, board_id, require_apple_signature=True)
        if not self.recovery_verified:
            raise RuntimeError('Downloaded macOS recovery failed the local integrity check')
        return result
    def one_click(self, letter, confirmation, target='auto', selections=None, board_id=''):
        """One guarded operation: scan, build, Apple recovery, verified USB copy.

        Only an existing FAT32 USB is eligible; there is no implicit erase.
        A disk identity captured before scanning must match at commit time.
        """
        if self.demo:
            raise RuntimeError('USB setup is disabled in demo mode')
        letter = str(letter).strip().upper().rstrip(':')
        if len(letter) != 1 or not letter.isascii() or not letter.isalpha():
            raise ValueError('Select a USB drive')
        if confirmation != f'PREPARE {letter}:':
            raise ValueError(f'Confirm the USB target with PREPARE {letter}:')
        if target not in ('auto', '20', '21', '22', '23', '24', '25'):
            raise ValueError('Invalid macOS selection')
        drives = [x for x in list_usb() if str(x.get('drive_letter', '')).upper() == letter]
        if len(drives) != 1:
            raise RuntimeError('USB drive not found or unsafe. Insert a removable USB and refresh.')
        selected = drives[0]
        if selected.get('disk_number') is None or not selected.get('volume_id'):
            raise RuntimeError('USB identity is unavailable; cannot prepare it safely')
        if str(selected.get('filesystem', '')).upper() != 'FAT32':
            raise RuntimeError('The USB must be FAT32. Automatic erasing/formatting is disabled for safety.')
        if int(selected.get('free_bytes') or 0) < 1024 * 1024 * 1024:
            raise RuntimeError('USB needs at least 1 GiB of free space for recovery and EFI')
        # Clear success from a previous run before starting this USB's setup.
        self.usb_copied = False
        self.usb_prepared = False
        # Capture target volume before running anything that can take several minutes.
        self.progress('Scanning hardware and ACPI', 8)
        self.deep_scan()
        if not assess(self.hardware)['can_attempt']:
            raise RuntimeError('Incompatible hardware detected. No USB files were changed.')
        # Online recovery cannot install macOS when the target has no detected
        # network hardware. Exact macOS driver support still needs boot testing.
        network_devices = self.hardware.get('network') if isinstance(self.hardware,dict) else None
        network=network_preflight(network_devices)
        if not network['candidate']:
            raise RuntimeError(network['reason'] + '. Internet recovery requires physical network hardware; USB was not changed.')
        if not self.engine_dir or not cached_engine_verified(self.cache):
            self.progress('Preparing OpenCore', 28)
            self.install_engine()
        self.progress('Generating EFI', 45)
        result = self.build(target, selections)
        if not result.get('validation', {}).get('valid'):
            raise RuntimeError('EFI validation failed; USB was not changed')
        self.progress('Downloading macOS recovery', 70)
        # Prefer the exact EFI board ID. A manual ID is allowed only if it
        # doesn't conflict with a known EFI identity; never infer a random ID.
        # Source the recovery from the generated macOS target, not SMBIOS.
        # With PlatformInfo/Automatic, SMBIOS may not contain a literal board ID.
        # An installer recovery download board ID is not the machine's SMBIOS.
        manifest_path = self.build_dir/'build-manifest.json'
        self.recovery_profile = None
        if manifest_path.is_file() or manifest_path.is_symlink():
            try:
                build_info = load_build_manifest(self.build_dir)
                version = build_info.get('target_darwin') if isinstance(build_info,dict) else None
                if not version:
                    raise ValueError('Missing generated Darwin target')
                self.recovery_profile = profile_for_darwin(version)
            except (ValueError, OSError, TypeError, RuntimeError) as exc:
                raise RuntimeError('Cannot identify the generated macOS version for recovery: ' + str(exc))
            if board_id and board_id.casefold() != self.recovery_profile['board_id'].casefold():
                raise RuntimeError('Custom recovery board ID conflicts with the selected macOS recovery channel')
            chosen_board = self.recovery_profile['board_id']
        else:
            # Existing imported or test builds retain the explicit-board fallback.
            detected_board = board_id_from_efi(self.build_dir)
            board_id = str(board_id or '').strip()
            if board_id and detected_board and board_id.casefold() != detected_board.casefold():
                raise RuntimeError('Entered Mac board ID does not match the generated EFI')
            chosen_board = detected_board or board_id
            if not chosen_board:
                raise RuntimeError('Mac board ID is unavailable. Open Advanced and enter the verified board ID for this EFI.')
        self.recovery(chosen_board)
        if not verify_recovery(self.recovery_dir, chosen_board, require_apple_signature=True):
            raise RuntimeError('Recovery is not verified for this EFI. No USB files were changed.')
        self.progress('Checking selected USB', 82)
        selected_again = [x for x in list_usb() if str(x.get('drive_letter', '')).upper() == letter]
        if len(selected_again) != 1 or any(selected_again[0].get(k) != selected.get(k)
                                       for k in ('disk_number', 'volume_id')):
            raise RuntimeError('USB identity changed during setup; no USB files were changed')
        # Final EFI is revalidated and both EFI and recovery are hash-verified on-device.
        self.progress('Writing and verifying USB', 90)
        fingerprint = self.last_build.get('fingerprint')
        if not fingerprint or efi_fingerprint(self.build_dir) != fingerprint:
            raise RuntimeError('EFI changed since validation; USB was not changed')
        current = validate_efi(self.build_dir, self.validator_dir or self.engine_dir)
        if not current.get('valid') or current.get('fingerprint') != fingerprint:
            raise RuntimeError('Final EFI validation failed; USB was not changed')
        copied = safe_usb_copy(self.build_dir, letter, f'COPY TO {letter}:',
                               self.home/'Backups', self.recovery_dir, fingerprint,
                               expected_disk=selected)
        if (not isinstance(copied, dict) or copied.get('copied_efi') is not True or
            not (copied.get('copied_recovery') is True or copied.get('recovery_present') is True)):
            raise RuntimeError('USB transfer did not confirm both EFI and recovery; inspect the USB before booting')
        self.usb_copied = True
        self.usb_prepared = True
        return {'prepared':True, 'drive':f'{letter}:', 'efi_validated':True,
                'recovery_verified':True, 'usb':copied,
                'note':'OpenCore EFI and Apple recovery copied and read-back verified; macOS boot compatibility is not guaranteed.'}

    def copy_usb(self,letter,confirmation):
        if self.demo: raise RuntimeError('USB copy disabled in demo mode')
        # A completed EFI must remain tied to the machine's original scan.
        # After restarting HackPilot, a new deep scan is required; blindly
        # copying last week's EFI to a different PC is not a one-click setup.
        manifest_path = self.build_dir/'build-manifest.json'
        if manifest_path.is_file() or manifest_path.is_symlink():
            try:
                info = load_build_manifest(self.build_dir)
            except (OSError, ValueError, UnicodeError, RuntimeError) as exc:
                raise RuntimeError('EFI hardware manifest cannot be read') from exc
            if isinstance(info, dict) and info.get('scan_seal') is not None:
                if not self.deep_scan_verified or self.scan_seal is None or not self.sniffer_file or not self.acpi_dir:
                    raise RuntimeError('Rescan this PC before copying a hardware-bound EFI')
                assert_scan_seal(self.sniffer_file, self.acpi_dir, info['scan_seal'])
                if self.scan_seal != info['scan_seal']:
                    raise RuntimeError('EFI belongs to a different hardware scan; regenerate it')
        # A newly generated map must be included in the EFI, and a map
        # built with old port choices must not be silently copied to USB.
        mapping=self._read_usb_map()
        map_ready=bool(mapping and map_is_ready(self.mapping_dir,mapping))
        if manifest_path.is_file() or manifest_path.is_symlink():
            if not isinstance(info,dict):
                raise RuntimeError('EFI hardware manifest is malformed')
            built_map_sha=info.get('usb_map_sha256')
            if bool(built_map_sha)!=map_ready:
                raise RuntimeError('USB mapping changed after EFI generation. Rebuild EFI before USB copy.')
            if map_ready:
                from .usb_mapping import _hash_file
                current_map_sha=_hash_file(self.mapping_dir/'UTBMap.kext'/'Contents'/'Info.plist')
                if current_map_sha!=built_map_sha:
                    raise RuntimeError('USB map in EFI is outdated. Rebuild EFI before USB copy.')
        self.usb_copied = False
        self.usb_prepared = False
        if not self.last_build or not self.last_build['valid']:
            raise RuntimeError('EFI must pass ocvalidate before USB copy')
        # A pass from yesterday is NOT valid if somebody has modified the EFI since.
        previous = self.last_build.get('fingerprint')
        if not previous or efi_fingerprint(self.build_dir) != previous:
            self.last_build = None
            raise RuntimeError('EFI files changed after validation. Revalidate before copying.')
        current = validate_efi(self.build_dir, self.validator_dir or self.engine_dir)
        if not current['valid'] or current.get('fingerprint') != previous:
            self.last_build = current
            raise RuntimeError('EFI revalidation failed. Open Logs and fix the configuration.')
        if self.recovery_dir:
            profile = self.expected_recovery_profile()
            if not profile:
                raise RuntimeError('Cannot copy recovery with an unversioned EFI; generate a versioned EFI first')
            if not verify_recovery(self.recovery_dir, profile['board_id'],
                                   profile['darwin_major'], profile['os_type'], require_apple_signature=True):
                self.recovery_verified=False
                raise RuntimeError('Recovery does not match the EFI macOS target or failed its integrity check')
        # Manual copying is not an escape hatch for unbound, generic EFIs.
        # HackPilot builds always contain a manifest tying them to a fresh
        # Hardware Sniffer / ACPI scan; imported legacy files do not.
        if (not manifest_path.is_file() or not isinstance(info, dict) or
            info.get('engine') != 'OpCore-Simplify' or info.get('manifest_version') != 2 or
            not isinstance(info.get('scan_seal'), dict) or info.get('efi_sha256') != previous):
            raise RuntimeError('EFI lacks a current machine-bound content manifest. Rebuild this EFI before copying.')
        result=safe_usb_copy(self.build_dir,letter,confirmation,self.home/'Backups',self.recovery_dir,previous)
        self.usb_copied=True
        self.usb_prepared = bool(self.recovery_dir and self.recovery_verified and
                                 (result.get('copied_recovery') or result.get('recovery_present')))
        return result
    def repair_usb(self,letter,confirmation):
        if self.demo: raise RuntimeError('USB repair disabled in demo mode')
        result = repair_usb(letter,confirmation,self.home/'Backups')
        self.usb_copied = result.get('action') == 'completed'
        self.usb_prepared = False
        return result

    def _read_usb_map(self):
        file=self.mapping_dir/'ports.json'
        if not file.is_file() or file.is_symlink():return None
        try:
            if file.stat().st_size > 4 * 1024 * 1024:
                return None
            data=json.loads(file.read_text(encoding='utf-8'))
            if not valid_saved_snapshot(data):
                return None
            return data
        except (OSError,ValueError,UnicodeError,TypeError):return None

    def usb_mapping_status(self):
        data=self._read_usb_map() or {'controllers':[]}
        return {'backend_ready':backend_verified(self.cache),
                'controllers':data['controllers'],
                'map_ready':map_is_ready(self.mapping_dir,data),
                'verified_ports':sum(1 for c in data['controllers'] for p in c['ports'] if p.get('physically_seen', False)),
                'selected_ports':sum(1 for c in data['controllers'] for p in c['ports'] if p.get('selected')),
                'unseen_selected':sum(1 for c in data['controllers'] for p in c['ports']
                                      if p.get('selected') and not p.get('physically_seen', False)),
                'source':'USBToolBox/tool'}

    def scan_usb_ports(self):
        if self.demo:raise RuntimeError('USB mapping disabled in demo mode')
        # Port history can change on refresh. A previously verified EFI or USB
        # status must not remain current until the new map is rebuilt/reviewed.
        self.last_build = None
        self.usb_copied = False
        self.usb_prepared = False
        self.progress('Preparing USB port scanner',10)
        install_backend(self.cache)
        previous=self._read_usb_map()
        self.progress('Discovering USB ports',60)
        current=normalize_snapshot(discover_controllers(self.cache))
        result=merge_snapshots(previous,current)
        _file=self.mapping_dir/'ports.json'
        from .engine import _atomic_json
        _atomic_json(_file,result)
        return self.usb_mapping_status()

    def choose_usb_port(self,controller_id,index,enabled,connector=None):
        self.assert_idle()
        original=self._read_usb_map()
        if not original:raise RuntimeError('Scan USB ports first')
        changed=update_port_selection(original,controller_id,index,enabled,connector)
        from .engine import _atomic_json
        _atomic_json(self.mapping_dir/'ports.json',changed)
        self.last_build=None;self.usb_copied=False;self.usb_prepared=False
        return self.usb_mapping_status()

    def generate_usb_map(self):
        if self.demo:raise RuntimeError('USB mapping disabled in demo mode')
        snapshot=self._read_usb_map()
        if not snapshot:raise RuntimeError('Scan USB ports first')
        if not backend_verified(self.cache):
            raise RuntimeError('USBToolBox scanner is missing or modified')
        current=normalize_snapshot(discover_controllers(self.cache))
        if controller_topology(current)!=controller_topology(snapshot):
            raise RuntimeError('USB topology changed. Refresh the port scan and retry.')
        # A map and its manifest form one unit. Generate and verify BOTH in a
        # separate directory before touching the previously working map.
        from .engine import _atomic_json
        with tempfile.TemporaryDirectory(prefix='hp-map-stage-', dir=str(self.mapping_dir.parent)) as staging_path:
            stage = Path(staging_path)
            result = generate_utbmap(snapshot, stage)
            _atomic_json(stage/'usb-map-manifest.json', {
                'source': 'USBToolBox/tool', 'sha256': result['sha256'],
                'selection_sha256': selection_hash(snapshot),
                'observed_ports': sum(1 for c in snapshot['controllers'] for p in c['ports'] if p.get('physically_seen', False))})
            if not map_is_ready(stage, snapshot):
                raise RuntimeError('New USB map and manifest failed verification; previous map was preserved')
            # Two filesystem renames cannot be atomic together. Keep both old
            # objects safely off to the side until the new pair verifies.
            rollback = Path(tempfile.mkdtemp(prefix='hp-map-rollback-', dir=str(self.mapping_dir.parent)))
            old_items = []
            new_items = []
            committed = False
            try:
                for name in ('UTBMap.kext', 'usb-map-manifest.json'):
                    existing = self.mapping_dir/name
                    if existing.exists() or existing.is_symlink():
                        existing.rename(rollback/name)
                        old_items.append(name)
                for name in ('UTBMap.kext', 'usb-map-manifest.json'):
                    (stage/name).rename(self.mapping_dir/name)
                    new_items.append(name)
                if not map_is_ready(self.mapping_dir, snapshot):
                    raise RuntimeError('Published USB map failed integrity validation')
                committed = True
            except Exception as error:
                failures = []
                for name in reversed(new_items):
                    dest = self.mapping_dir/name
                    try:
                        if dest.is_symlink() or dest.is_file(): dest.unlink()
                        elif dest.is_dir(): shutil.rmtree(dest)
                    except OSError as exc: failures.append(str(exc))
                for name in reversed(old_items):
                    try: (rollback/name).rename(self.mapping_dir/name)
                    except OSError as exc: failures.append(str(exc))
                if failures:
                    # Retain the rollback directory for manual restoration.
                    raise RuntimeError('USB map update failed and rollback needs repair at '
                                       + str(rollback) + ': ' + '; '.join(failures)) from error
                raise
            finally:
                # Keep the previous map only while a failed rollback needs
                # manual repair. After success (or clean rollback) remove the
                # stale transaction directory.
                if committed or not any(rollback.iterdir()):
                    shutil.rmtree(rollback)
            # The map now lives in the persistent application folder.
            result['path'] = str(self.mapping_dir/'UTBMap.kext')
        self.last_build=None;self.usb_copied=False;self.usb_prepared=False
        return {'map':result,'status':self.usb_mapping_status()}

    def import_report(self,content):
        self.assert_idle()
        if not isinstance(content, dict):
            raise ValueError('Report must be a JSON object')
        if 'CPU' in content:
            new_hardware = sniffer_summary(content)
            message = 'Hardware Sniffer report imported for review; ACPI scan still required'
        else:
            new_hardware = imported_native(content)
            message = 'HackPilot report imported for review'
        self.hardware = new_hardware
        self.last_build = None
        self.usb_copied = False;self.usb_prepared = False
        self.sniffer_file = None
        self.acpi_dir = None
        self.deep_scan_verified = False
        self.scan_seal = None
        return {'imported':message}

    def demo_scan(self):
        if not self.demo:
            raise ValueError('Demo mode not enabled')
        self.assert_idle()
        fixture = BASE/'examples'/'demo-hardware.json'
        hardware = json.loads(fixture.read_text())
        self.hardware = hardware
        self.last_build = None
        self.usb_copied = False;self.usb_prepared = False
        self.sniffer_file = None
        self.acpi_dir = None
        self.deep_scan_verified = False
        self.scan_seal = None
        return {'demo':True}



def create_server(state=None,port=0):
    state=state or State()
    token=secrets.token_urlsafe(24)
    class Handler(BaseHTTPRequestHandler):
        server_version='HackPilot/1.18-windows-runtime'
        def log_message(self,*args):pass
        def _trusted_host(self):
            return self.headers.get('Host','') == f'127.0.0.1:{self.server.server_port}'
        def send_json(self,payload,status=200):
            data=json.dumps(payload,ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Length',str(len(data)))
            self.end_headers();self.wfile.write(data)
        def do_GET(self):
            path=urllib.parse.urlparse(self.path).path
            if not self._trusted_host(): return self.send_json({'error':'Invalid host'},403)
            try:
                if path=='/api/status':return self.send_json(state.status())
                if path=='/api/usb':return self.send_json({'usb':list_usb()})
                if path=='/api/usb-map':return self.send_json(state.usb_mapping_status())
                if path=='/api/build-log':
                    result=_bounded_text_tail(state.logfile)
                    return self.send_json({'log':result})
                map_files={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/app.css':'app.css'}
                if path not in map_files: return self.send_json({'error':'Not found'},404)
                content=(STATIC/map_files[path]).read_bytes()
                if path in ('/','/index.html'):
                    content=content.replace(b'__TOKEN__',token.encode())
                self.send_response(200)
                self.send_header('Content-Type','text/html; charset=utf-8' if path in ('/','/index.html') else ('text/javascript; charset=utf-8' if path.endswith('js') else 'text/css; charset=utf-8'))
                self.send_header('Cache-Control','no-store')
                self.send_header('X-Content-Type-Options','nosniff')
                self.send_header('Content-Length',str(len(content)))
                self.end_headers();self.wfile.write(content)
            except Exception as e: self.send_json({'error':str(e)},500)
        def do_POST(self):
            path=urllib.parse.urlparse(self.path).path
            if not self._trusted_host(): return self.send_json({'error':'Invalid host'},403)
            if self.headers.get('X-HackPilot-Token')!=token:
                return self.send_json({'error':'Invalid local session'},403)
            origin=self.headers.get('Origin')
            if origin and origin!=f'http://127.0.0.1:{self.server.server_port}':
                return self.send_json({'error':'Origin not allowed'},403)
            try:
                # A browser bridge is not an arbitrary JSON RPC endpoint. Bad
                # framing/JSON must be rejected *before* any state mutation.
                if self.headers.get('Transfer-Encoding'):
                    return self.send_json({'error':'Chunked requests are not supported'},400)
                raw_length = self.headers.get('Content-Length')
                if raw_length is None or not raw_length.isascii() or not raw_length.isdecimal():
                    return self.send_json({'error':'Invalid Content-Length'},400)
                length = int(raw_length)
                if length > 2 * 1024 * 1024:
                    return self.send_json({'error':'Payload too large'},413)
                if length and self.headers.get_content_type() != 'application/json':
                    return self.send_json({'error':'Expected application/json'},415)
                try:
                    data=json.loads(self.rfile.read(length)) if length else {}
                except (ValueError, UnicodeError):
                    return self.send_json({'error':'Malformed JSON'},400)
                if not isinstance(data,dict):
                    return self.send_json({'error':'JSON body must be an object'},400)
                if path=='/api/scan':value=state.start('Hardware scan',state.scan)
                elif path=='/api/deep-scan':
                    if not data.get('consent'):raise ValueError('Consent to download and run Hardware Sniffer is required')
                    value=state.start('Deep hardware scan',state.deep_scan)
                elif path=='/api/engine':
                    if not data.get('consent'):raise ValueError('Consent to download BSD-licensed EFI engine is required')
                    value=state.start('Prepare EFI engine',state.install_engine)
                elif path=='/api/build':value=state.start('Automatic EFI build',lambda:state.build(data.get('target','auto'),data.get('selections',{})))
                elif path=='/api/one-click':
                    if not data.get('consent'):
                        raise ValueError('Consent to download and execute OpenCore tools is required')
                    value=state.start('One-click USB setup',lambda:state.one_click(
                        data.get('letter',''),data.get('confirm',''),data.get('target','auto'),data.get('selections',{}),data.get('board_id','')))
                elif path=='/api/auto-setup':
                    if not data.get('consent'):raise ValueError('Consent to download and run upstream tools is required')
                    value=state.start('Auto setup',lambda:state.auto_setup(data.get('target','auto'),data.get('selections',{})))
                elif path=='/api/validate':value=state.start('EFI validation',state.validate)
                elif path=='/api/usb-map-scan':
                    if not data.get('consent'):raise ValueError('Permission to download and run the USBToolBox scanner is required')
                    value=state.start('USB port scan',state.scan_usb_ports)
                elif path=='/api/usb-map-port':
                    with workspace_lock(state.home):
                        value=state.choose_usb_port(data.get('controller',''),data.get('index'),data.get('selected'),data.get('connector'))
                elif path=='/api/usb-map-build':value=state.start('Build USB map',state.generate_usb_map)
                elif path=='/api/usb-copy':value=state.start('Safe USB copy',lambda:state.copy_usb(data.get('letter',''),data.get('confirm','')))
                elif path=='/api/diagnose':
                    state.diagnosis=analyze_log(data.get('log',''))
                    value=state.diagnosis
                elif path=='/api/usb-repair':value=state.start('Repair USB',lambda:state.repair_usb(data.get('letter',''),data.get('confirm','')))
                elif path=='/api/recovery':
                    if not data.get('consent'):raise ValueError('Consent to run OpenCore macrecovery is required')
                    value=state.start('Apple recovery download',lambda:state.recovery(data.get('board_id','')))
                elif path=='/api/import':value=state.import_report(data)
                elif path=='/api/demo':value=state.demo_scan()
                elif path=='/api/open-output':
                    if os.name=='nt':os.startfile(str(state.output))
                    else: webbrowser.open(state.output.as_uri())
                    value={'opened':True}
                elif path=='/api/open-log':
                    if not state.logfile.exists():raise RuntimeError('No build log yet')
                    if os.name=='nt':os.startfile(str(state.logfile))
                    else: webbrowser.open(state.logfile.as_uri())
                    value={'opened':True}
                else:return self.send_json({'error':'Not found'},404)
                return self.send_json(value)
            except (ValueError,RuntimeError) as e:return self.send_json({'error':str(e)},400)
            except Exception as e:return self.send_json({'error':str(e)},500)
    return ThreadingHTTPServer(('127.0.0.1',port),Handler)
