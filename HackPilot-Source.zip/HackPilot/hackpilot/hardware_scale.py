"""Bounded presentation and conservative device preflight for large PC inventories.

This is intentionally not a hardware support database. The EFI engine always
consumes the unabridged Hardware Sniffer report, never these display summaries.
"""
from itertools import islice
import re

DISPLAY_LIMIT = 120
MAX_DEEP_REPORT_BYTES = 32 * 1024 * 1024

VIRTUAL_NET_MARKERS = (
    'virtual', 'vmware', 'virtualbox', 'hyper-v', 'vethernet',
    'loopback', 'tunnel', 'teredo', 'isatap', 'vpn', 'wireguard',
    'tap-windows', 'tailscale', 'zerotier', 'docker', 'wsl',
    'wan miniport', 'wi-fi direct', 'wifi direct',
    'bluetooth device (personal area network)', 'bluetooth pan',
    'npcap', 'hamachi', 'radmin', 'openvpn',
)


def text_value(value, limit=200):
    """Normalize presentation values without coercing enormous nested objects."""
    if value is None:
        return ''
    if not isinstance(value, (str, int, float, bool)):
        return ''
    return str(value)[:limit]


def bounded_devices(devices, make_item, limit=DISPLAY_LIMIT):
    """A display-only preview; retain complete counts, without losing EFI inputs."""
    if not isinstance(devices, (list, dict)):
        raise ValueError('Hardware section must be a list or an object')
    source = devices.items() if isinstance(devices, dict) else enumerate(devices)
    preview = [make_item(name, props) for name, props in islice(source, limit)]
    return preview, len(devices)


def representative_devices(devices, make_item, preferred, limit=DISPLAY_LIMIT):
    """Show a bounded inventory but retain a rare usable device past the cap.

    E.g. an actual Ethernet NIC can appear after hundreds of virtual adapters,
    or the working GPU can be last in a multi-GPU report. The EFI engine still
    receives the entire original inventory.
    """
    preview, count = bounded_devices(devices, make_item, limit)
    if count <= limit or not preview or any(preferred(item) for item in preview):
        return preview, count
    source = devices.items() if isinstance(devices, dict) else enumerate(devices)
    for name, value in islice(source, limit, None):
        candidate = make_item(name, value)
        if preferred(candidate):
            preview[-1] = candidate
            break
    return preview, count


def is_virtual_network(device):
    if not isinstance(device, dict):
        return False
    combined = ' '.join(text_value(device.get(k), 256) for k in ('name', 'manufacturer', 'device_id', 'vendor')).lower()
    return any(needle in combined for needle in VIRTUAL_NET_MARKERS)


def network_preflight(devices):
    """Avoid treating a VPN/virtual-only inventory as internet recovery access.

    A plausible physical NIC is *not* proof macOS has a working driver.
    """
    if not isinstance(devices, list) or not devices:
        return {'candidate': False, 'reason': 'No network adapter detected'}
    candidates = [item for item in devices if isinstance(item, dict) and not is_virtual_network(item)
                  and text_value(item.get('name'), 256).strip()]
    if not candidates:
        return {'candidate': False, 'reason': 'Only virtual or tunnel network adapters were detected'}
    return {'candidate': True, 'reason': 'Network hardware found; macOS driver support remains unverified'}


def unsupported_gpu(name):
    """Known lack of standard native acceleration, never a promise of support."""
    n = text_value(name, 256).lower()
    # Workstation labels such as 'Quadro RTX 5000' and 'RTX A4000'
    # must not bypass the consumer RTX safety check.
    if re.search(r'\brtx\s*(?:a\s*)?\d{3,5}\b', n):
        return True
    if re.search(r'\b(?:nvidia\s*)?(?:geforce\s*)?gtx\s*(?:9\d\d|10\d\d|16\d\d)\b', n):
        return True
    if re.search(r'\b(?:intel\s+)?arc\s+[a-z]\d{2,4}\b|\biris\s+xe\b|\buhd\s*(?:730|750|770)\b', n):
        return True
    # RDNA3/Navi3x, Navi24 and experimental Navi22 are not a safe native default.
    if re.search(r'\brx\s*(?:6300|6400|6500|6700|6750|7600|7700|7800|7900|8\d{3}|9\d{3})(?:\s*(?:xt|xtx|gre))?\b', n):
        return True
    # Workstation equivalents of unsupported Navi 24/Navi 3x GPUs.
    if re.search(r'\bradeon\s+pro\s+w(?:6300|6400|7500|7600|7700|7800|7900)\b', n):
        return True
    if 'microsoft basic display' in n:
        return True
    return False
