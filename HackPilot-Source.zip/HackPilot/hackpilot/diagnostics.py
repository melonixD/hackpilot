"""Conservative OpenCore log triage, never automatic config modification."""
import re

RULES = [
    (r'OC: Failed to load configuration|OCS: No schema', 'OpenCore configuration',
     'Validate config.plist with the matching ocvalidate release. Compare against the OpenCore sample configuration.'),
    (r'OC: Failed to find.*(?:SSDT|ACPI)|Failed to load.*\\.aml', 'Missing SSDT or ACPI reference',
     'Check ACPI/Add paths and filenames. Do not add generic SSDTs without checking your DSDT.'),
    (r'OCB: StartImage failed|OCB: LoadImage failed', 'Boot image loading failed',
     'Check the boot picker entry, macOS recovery files, and BIOS boot options. The line alone does not establish the cause.'),
    (r'EXITBS:START|ExitBootServices', 'Stalled near ExitBootServices',
     'Review firmware version, memory map, and OpenCore Booter quirks against your motherboard guide.'),
    (r'Still waiting for root device|AppleUSBHostPort.*not found', 'Storage or USB access',
     'Try a USB 2.0 port and verify USB controller support and the installer media. Do not change SATA mode blindly.'),
    (r'OC: Failed to load.*kext|Kext.*dependency.*missing', 'Kext loading',
     'Check Kernel/Add dependencies, ordering, enabled entries, and kext versions.'),
    (r'OC: Failed to find.*driver|OpenRuntime\\.efi.*missing', 'Missing EFI driver',
     'Verify UEFI/Drivers entries and the referenced EFI files.'),
]


def analyze_log(log):
    if not isinstance(log,str):
        raise ValueError('Log must be text')
    if len(log) > 250_000:
        raise ValueError('Log exceeds 250 KB; use the relevant boot section')
    hits = []
    for pattern, title, advice in RULES:
        if re.search(pattern, log, flags=re.IGNORECASE):
            hits.append({'problem':title, 'next_step':advice})
    if not log.strip():
        raise ValueError('Log is empty')
    return {'findings':hits[:6], 'recognized':bool(hits),
            'note':'Patterns suggest where to look, not a confirmed diagnosis. No EFI files were modified.'}
