"""Bind a generated EFI to the exact local hardware report and ACPI dump.

This proves which scan inputs were used; it does NOT prove the firmware can boot.
No hardware serial numbers or Wi-Fi credentials are included in the manifest.
"""
import hashlib
import struct
from pathlib import Path

MAX_TABLES = 1024
MAX_TABLE_BYTES = 16 * 1024 * 1024
MAX_TOTAL_BYTES = 64 * 1024 * 1024
MAX_REPORT_BYTES = 32 * 1024 * 1024  # Same limit as hardware_scale.MAX_DEEP_REPORT_BYTES


def _sha256_file(path, limit):
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise RuntimeError(f'Scan input missing or linked: {path.name}')
    if path.stat().st_size > limit:
        raise RuntimeError(f'Scan input is unexpectedly large: {path.name}')
    digest = hashlib.sha256()
    total = 0
    with path.open('rb') as src:
        for block in iter(lambda: src.read(65536), b''):
            total += len(block)
            if total > limit:
                raise RuntimeError(f'Scan input is unexpectedly large: {path.name}')
            digest.update(block)
    if not total:
        raise RuntimeError(f'Scan input is empty: {path.name}')
    return digest.hexdigest(), total


def seal_scan(report_file, acpi_dir):
    """Return deterministic hashes for every scan input used to make the EFI."""
    report_hash, _ = _sha256_file(report_file, MAX_REPORT_BYTES)
    directory = Path(acpi_dir)
    if not directory.is_dir() or directory.is_symlink():
        raise RuntimeError('ACPI dump is missing or linked')
    # Only valid AML dump files can influence DSDT/SSDT generation. Refuse
    # links and reparse points rather than following an untrusted dump tree.
    entries = sorted(directory.rglob('*'), key=lambda p: p.relative_to(directory).as_posix().casefold())
    if len(entries) > MAX_TABLES * 3:
        raise RuntimeError('ACPI dump contains too many entries')
    for entry in entries:
        if entry.is_symlink() or bool(getattr(entry.lstat(), 'st_file_attributes', 0) & 0x400):
            raise RuntimeError('ACPI dump contains linked entries')
        if not entry.is_file() and not entry.is_dir():
            raise RuntimeError('Unexpected ACPI dump entry type')
    tables = [p for p in entries if p.is_file() and p.suffix.lower() == '.aml']
    if not tables or len(tables) > MAX_TABLES:
        raise RuntimeError('No usable ACPI tables or too many tables')
    digest = hashlib.sha256()
    seen = set()
    total = 0
    for file in tables:
        name = file.relative_to(directory).as_posix()
        if name.casefold() in seen:
            raise RuntimeError('Duplicate ACPI table names')
        seen.add(name.casefold())
        sha, size = _sha256_file(file, MAX_TABLE_BYTES)
        total += size
        if total > MAX_TOTAL_BYTES:
            raise RuntimeError('ACPI dump exceeds size limit')
        digest.update(name.encode('utf-8') + b'\0' + bytes.fromhex(sha) + b'\0')
    return {'report_sha256': report_hash, 'acpi_sha256': digest.hexdigest(), 'acpi_tables': len(tables)}


def assert_scan_seal(report_file, acpi_dir, expected):
    if not isinstance(expected, dict) or set(expected) != {'report_sha256', 'acpi_sha256', 'acpi_tables'}:
        raise RuntimeError('Hardware scan fingerprint missing or invalid; rescan this PC')
    actual = seal_scan(report_file, acpi_dir)
    if actual != expected:
        raise RuntimeError('Hardware report or ACPI tables changed; rescan this PC before building or copying EFI')
    return actual


def require_valid_dsdt(acpi_dir):
    """Require an intact real DSDT table before generating machine-specific SSDTs.

    Unlike a generic/only-SSDT fallback, a valid DSDT lets the ACPI patch
    engine inspect the actual namespace. This still cannot prove each patch
    will behave correctly on physical firmware.
    """
    directory = Path(acpi_dir)
    if not directory.is_dir() or directory.is_symlink():
        raise RuntimeError('ACPI dump is missing')
    for path in sorted(p for p in directory.rglob('*') if p.is_file() and p.suffix.lower() == '.aml'):
        if path.is_symlink():
            raise RuntimeError('Linked ACPI table is not trusted')
        if path.stat().st_size < 36 or path.stat().st_size > MAX_TABLE_BYTES:
            continue
        with path.open('rb') as stream:
            data = stream.read(MAX_TABLE_BYTES + 1)
        if data[:4] != b'DSDT':
            continue
        if len(data) >= 36 and struct.unpack_from('<I', data, 4)[0] == len(data) and sum(data) % 256 == 0:
            return str(path)
    raise RuntimeError('Valid DSDT table missing from this PC. Re-run the ACPI scan; generic SSDTs are not safe.')
