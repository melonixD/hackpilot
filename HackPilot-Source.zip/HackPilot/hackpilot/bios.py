"""Conservative firmware-preparation checklist, never change firmware automatically."""
def checklist(report):
    if not report:return []
    items=[]
    add=lambda title,detail,level='review':items.append({'title':title,'detail':detail,'level':level})
    fw=report.get('firmware') or {}
    boot=str(fw.get('type','Unknown')).lower()
    if boot!='uefi':add('UEFI boot mode','Current firmware mode is not confirmed UEFI. Verify native UEFI support and disable CSM only if your Windows install remains bootable.','important')
    else:add('UEFI mode detected','Confirm the USB boot entry uses UEFI rather than legacy/CSM mode.')
    secure=str(fw.get('secure_boot','')).lower()
    if secure=='true':add('Secure Boot currently enabled','Check whether the selected OpenCore setup supports your Secure Boot configuration; changing it may trigger BitLocker recovery.','important')
    else:add('Secure Boot configuration','Check the motherboard firmware setting against OpenCore requirements; do not change Windows security settings blindly.')
    add('Storage controller / RAID','Verify your SATA or VMD/RAID controller is supported. Switching storage mode can make Windows unbootable; prepare and back up Windows first.','important')
    add('IOMMU / VT-d','Do not disable virtualisation blindly. The correct setting depends on CPU and OpenCore DisableIoMapper choices.')
    add('USB controller setup','Check XHCI/USB settings and plan physical USB mapping after first boot.')
    add('Backup & boot picker','Save Windows recovery media and BitLocker recovery keys before changing firmware or installing another OS.','important')
    return items
