"""Independent EFI component audit.

OpenCore's ocvalidate checks config.plist; this module additionally verifies
that referenced boot files, kext bundles, and ACPI patches are internally
consistent. It does NOT test real firmware or macOS driver compatibility.
"""
from collections import defaultdict
from pathlib import Path
import plistlib
import struct
import uuid


def _uefi_x64(path):
    """Check PE32+ EFI architecture, headers, and section table bounds.

    A Windows PE can have a forged EFI subsystem without being a complete,
    loadable image. This catches obvious truncation; it cannot emulate UEFI.
    """
    try:
        size = Path(path).stat().st_size
        if size < 256:
            return 'truncated PE/COFF EFI executable'
        with Path(path).open('rb') as source:
            first = source.read(64)
            if len(first) < 64 or first[:2] != b'MZ':
                return 'not a PE/COFF executable'
            offset = struct.unpack_from('<I', first, 0x3c)[0]
            if offset < 64 or offset > 8 * 1024 * 1024 or offset + 24 > size:
                return 'invalid PE header offset'
            source.seek(offset)
            header = source.read(24)
            if len(header) != 24 or header[:4] != b'PE\x00\x00':
                return 'missing PE signature'
            machine, sections, _, _, _, optional_size, flags = struct.unpack_from('<HHIIIHH',header,4)
            if machine != 0x8664:
                return 'not an x86_64 EFI executable'
            if not 1 <= sections <= 96 or not 72 <= optional_size <= 4096:
                return 'invalid PE section count or optional header size'
            if offset + 24 + optional_size + sections*40 > size:
                return 'truncated PE optional header or section table'
            optional = source.read(optional_size)
            if struct.unpack_from('<H',optional,0)[0] != 0x20b:
                return 'invalid PE32+ optional header'
            subtype = struct.unpack_from('<H',optional,68)[0]
            if subtype not in (10, 11, 12):
                return 'PE subsystem is not EFI firmware code'
            if not (flags & 0x0002):
                return 'PE image is not marked executable'
            table = source.read(sections*40)
            if len(table) != sections*40:
                return 'truncated PE section table'
            for index in range(sections):
                start = index*40
                raw_size = struct.unpack_from('<I',table,start+16)[0]
                raw_offset = struct.unpack_from('<I',table,start+20)[0]
                if raw_size and (raw_offset < 1 or raw_offset+raw_size > size):
                    return 'PE section extends beyond the executable'
    except (OSError, ValueError, struct.error):
        return 'unreadable EFI executable'
    return None


def _macho_x64(path):
    """Check x86_64 Mach-O slices and their declared load-command bounds.

    Recognising the eight-byte magic and CPU header is insufficient: it would
    otherwise accept truncated or deliberately fabricated kext executables.
    This is structural validation, not an assurance of driver compatibility.
    """
    try:
        size = Path(path).stat().st_size
        if size < 32:
            return 'truncated Mach-O executable'
        with Path(path).open('rb') as file:
            def thin(offset, extent):
                if extent < 32 or offset < 0 or offset + extent > size:
                    return 'truncated Mach-O slice'
                file.seek(offset)
                header = file.read(32)
                if len(header) != 32:
                    return 'truncated Mach-O header'
                magic = header[:4]
                if magic not in (b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf'):
                    return 'not a recognized 64-bit Mach-O executable'
                byte_order = '<' if magic == b'\xcf\xfa\xed\xfe' else '>'
                cpu, subtype, filetype, count, command_size = struct.unpack_from(byte_order + 'IIIII',header,4)
                if cpu != 0x01000007:
                    return 'wrong Mach-O CPU architecture'
                # MH_KEXT_BUNDLE (0xb) is the loadable-kernel-extension type.
                # A perfectly well-formed userspace Mach-O must not pass here.
                if filetype != 0x0b:
                    return 'Mach-O is not a kernel extension bundle'
                if not (1 <= count <= 10000) or command_size < count * 8 or command_size > extent - 32:
                    return 'invalid or truncated Mach-O load commands'
                commands = file.read(command_size)
                if len(commands) != command_size:
                    return 'truncated Mach-O load commands'
                position = 0
                for _ in range(count):
                    if position + 8 > len(commands):
                        return 'truncated Mach-O command'
                    _, length = struct.unpack_from(byte_order + 'II',commands,position)
                    if length < 8 or position + length > command_size or length % 4:
                        return 'invalid Mach-O load command length'
                    position += length
                return None if position == command_size else 'Mach-O load command size mismatch'

            file.seek(0)
            header = file.read(8)
            if header[:4] in (b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf'):
                return thin(0, size)
            formats = {
                b'\xca\xfe\xba\xbe':('>',20), b'\xca\xfe\xba\xbf':('>',32),
                b'\xbe\xba\xfe\xca':('<',20), b'\xbf\xba\xfe\xca':('<',32),
            }
            if header[:4] not in formats:
                return 'not a recognized 64-bit Mach-O executable'
            byte_order, entry_size = formats[header[:4]]
            count = struct.unpack_from(byte_order+'I',header,4)[0]
            if count < 1 or count > 64 or 8 + count * entry_size > size:
                return 'invalid Mach-O architecture count'
            entries = file.read(count * entry_size)
            has_x64 = False
            for i in range(count):
                at = i * entry_size
                cpu = struct.unpack_from(byte_order+'I',entries,at)[0]
                if entry_size == 20:
                    offset, extent = struct.unpack_from(byte_order+'II',entries,at+8)
                else:
                    offset, extent = struct.unpack_from(byte_order+'QQ',entries,at+8)
                if offset < 8+count*entry_size or extent <= 0 or offset+extent > size:
                    return 'invalid Mach-O universal slice bounds'
                if cpu == 0x01000007:
                    has_x64 = True
                    problem = thin(offset, extent)
                    if problem:
                        return problem
            return None if has_x64 else 'no x86_64 slice in universal Mach-O'
    except (OSError, ValueError, struct.error):
        return 'unreadable kext executable'


def _acpi_table(path):
    """Validate an ACPI table's 36-byte header, length and checksum."""
    try:
        # A manually altered EFI can contain a multi-gigabyte .aml file.
        # Never allocate it in RAM just to check a 36-byte header/checksum.
        if Path(path).stat().st_size > 16 * 1024 * 1024:
            return 'ACPI table exceeds 16 MiB safety limit'
        data = Path(path).read_bytes()
        if len(data) < 36:
            return 'table is shorter than the ACPI header'
        signature = data[:4]
        if not all(0x20 <= x < 0x7f for x in signature):
            return 'invalid ACPI signature'
        declared = struct.unpack_from('<I', data, 4)[0]
        if declared != len(data):
            return 'ACPI header length does not match file length'
        if sum(data) % 256:
            return 'ACPI table checksum is incorrect'
    except OSError:
        return 'unreadable ACPI table'
    return None


def _kernel_version_tuple(value):
    """Validate OpenCore Darwin min/max values, returning an ordered tuple."""
    if not isinstance(value, str) or not value:
        raise ValueError('invalid Darwin kernel version')
    parts = value.split('.')
    if not 1 <= len(parts) <= 3 or any(not part.isascii() or not part.isdecimal() for part in parts):
        raise ValueError('invalid Darwin kernel version')
    if any(len(part) > 3 or int(part) > 999 for part in parts):
        raise ValueError('Darwin kernel version component out of range')
    return tuple(int(part) for part in (parts + ['0'] * (3-len(parts))))


def _applies_to_kernel(row, target):
    """Enabled alone does not mean a kext loads for the selected macOS."""
    current = _kernel_version_tuple(str(target))
    minimum = row.get('MinKernel', '')
    maximum = row.get('MaxKernel', '')
    low = _kernel_version_tuple(minimum) if minimum not in ('', None) else None
    high = _kernel_version_tuple(maximum) if maximum not in ('', None) else None
    if low and high and low > high:
        raise ValueError('MinKernel is newer than MaxKernel')
    return (low is None or current >= low) and (high is None or current <= high)


def _numeric_bundle_version(value):
    """Compare standard numeric CFBundleVersion values conservatively.

    Some vendor builds use custom version strings; they need review rather
    than arbitrary lexical comparison.
    """
    if not isinstance(value, str) or not value:
        return None
    parts = value.split('.')
    if len(parts) > 4 or any(not part.isascii() or not part.isdecimal() for part in parts):
        return None
    if any(len(part) > 6 or int(part) > 999999 for part in parts):
        return None
    return tuple(int(p) for p in (parts + ['0'] * (4 - len(parts))))


def audit_efi_components(build_dir, target_darwin=None):
    """Fail closed on inconsistent components, but do not claim boot success."""
    root = Path(build_dir) / 'EFI'
    oc = root / 'OC'
    errors, warnings = [], []
    inventory = {'ssdt': 0, 'kexts': 0, 'drivers': 0, 'tools': 0}
    # All paths have already been checked for traversal and links by validate_efi.
    # Recheck in this module too because it may be called independently.
    try:
        from hackpilot.efi import _safe_relative, _linked, efi_tree_fingerprint
    except ModuleNotFoundError:
        from efi import _safe_relative, _linked, efi_tree_fingerprint
    try:
        efi_tree_fingerprint(root)
    except (OSError, RuntimeError) as exc:
        return {'errors':[str(exc)],'warnings':warnings,'inventory':inventory}
    config = oc/'config.plist'
    try:
        if config.stat().st_size > 8 * 1024 * 1024:
            raise ValueError('config.plist exceeds 8 MiB safety limit')
        with config.open('rb') as src:
            data = plistlib.load(src)
        if not isinstance(data, dict):
            raise ValueError('root is not a dictionary')
    except (OSError, TypeError, ValueError, plistlib.InvalidFileException):
        return {'errors':['Cannot inspect malformed config.plist'], 'warnings':warnings,'inventory':inventory}
    for file in (root/'BOOT'/'BOOTx64.efi', oc/'OpenCore.efi'):
        if not file.is_file() or _linked(file):
            errors.append('Missing or linked required EFI binary: ' + file.name)
        else:
            issue = _uefi_x64(file)
            if issue:
                errors.append(f'{file.name}: {issue}')
    def enabled_rows(section, key):
        records = data.get(section, {})
        records = records.get(key, []) if isinstance(records, dict) else []
        if not isinstance(records, list):
            errors.append(f'Invalid {section}/{key} entries')
            return []
        result = []
        for row in records:
            if not isinstance(row, dict):
                errors.append(f'Invalid {section}/{key} entry type')
            elif row.get('Enabled', True) is True:
                result.append(row)
            elif row.get('Enabled', True) is not False:
                errors.append(f'Non-boolean Enabled in {section}/{key}')
        return result
    if target_darwin is not None:
        try:
            _kernel_version_tuple(target_darwin)
        except (ValueError, TypeError, OverflowError) as exc:
            errors.append('Invalid build manifest target_darwin: ' + str(exc))
            # Further kernel-window checks have no meaningful target without
            # a valid Darwin release. Never crash the entire validation job.
            target_darwin = None
    if target_darwin is not None:
        platform = data.get('PlatformInfo')
        generic = platform.get('Generic') if isinstance(platform, dict) else None
        if not isinstance(generic, dict):
            errors.append('PlatformInfo/Generic is missing')
        else:
            serial = generic.get('SystemSerialNumber')
            mlb = generic.get('MLB')
            identifier = generic.get('SystemUUID')
            # OpCore-Simplify has a fallback serial generator if macserial
            # fails. Never publish those placeholder identities as production.
            if not isinstance(serial,str) or not serial.strip() or serial == 'A' + '0'*10 + '9':
                errors.append('SMBIOS serial is missing or uses the upstream fallback placeholder')
            if not isinstance(mlb,str) or not mlb.strip() or mlb == 'A' + '0'*15 + 'Z':
                errors.append('SMBIOS MLB is missing or uses the upstream fallback placeholder')
            try:
                if not isinstance(identifier,str) or uuid.UUID(identifier).int == 0:
                    raise ValueError('empty or zero UUID')
            except (TypeError,ValueError,AttributeError):
                errors.append('SMBIOS SystemUUID is missing or invalid')
            rom = generic.get('ROM')
            if not isinstance(rom,bytes) or len(rom) != 6:
                errors.append('SMBIOS ROM must be six bytes')
    # The 15-port workaround is documented to cause boot loops on macOS
    # 11.3+; a proper USB map is required instead of retaining this quirk.
    if target_darwin is not None and _kernel_version_tuple(target_darwin) >= (20, 4, 0):
        kernel = data.get('Kernel', {})
        quirks = kernel.get('Quirks', {}) if isinstance(kernel, dict) else {}
        if isinstance(quirks, dict) and quirks.get('XhciPortLimit') is True:
            errors.append('XhciPortLimit is unsafe for macOS 11.3+; disable it and generate a USB map')

    acpi = enabled_rows('ACPI','Add')
    drivers = enabled_rows('UEFI','Drivers')
    kexts = enabled_rows('Kernel','Add')
    if target_darwin is not None:
        active = []
        for row in kexts:
            try:
                arch = row.get('Arch', 'Any')
                if not isinstance(arch, str) or arch not in ('Any', 'x86_64', 'i386'):
                    errors.append('Invalid kext Arch value: ' + repr(arch))
                    continue
                if arch == 'i386':
                    # All supported versions use x86_64; a silently ignored
                    # enabled kext may be crucial for booting the machine.
                    errors.append('Enabled i386-only kext cannot load on x86_64 macOS: ' +
                                  str(row.get('BundlePath','unknown')))
                    continue
                if _applies_to_kernel(row, target_darwin):
                    active.append(row)
            except (ValueError, TypeError) as exc:
                errors.append('Invalid kext MinKernel/MaxKernel: ' + str(exc))
        kexts = active
    tools = enabled_rows('Misc','Tools')
    seen_paths = defaultdict(set)
    def get_path(row, field, folder):
        rel = row.get(field)
        if not _safe_relative(rel):
            errors.append(f'Invalid {folder} reference: {rel!r}')
            return None, None
        folded = rel.replace('\\','/').casefold()
        if folded in seen_paths[folder]:
            errors.append(f'Duplicate enabled {folder} reference: {rel}')
        seen_paths[folder].add(folded)
        path = oc/folder/rel.replace('\\','/')
        if _linked(path):
            errors.append(f'Linked {folder} component: {rel}')
            return None, rel
        return path, rel
    for row in acpi:
        path, rel = get_path(row, 'Path','ACPI')
        if path is None: continue
        if path.suffix.casefold() != '.aml' or not path.is_file():
            errors.append(f'ACPI patch is missing or not .aml: {rel}')
        else:
            issue = _acpi_table(path)
            if issue: errors.append(f'ACPI/{rel}: {issue}')
            else: inventory['ssdt'] += 1
    driver_names = set()
    for row in drivers:
        path, rel = get_path(row,'Path','Drivers')
        if path is None: continue
        driver_names.add(Path(rel).name.casefold())
        if path.suffix.casefold() != '.efi' or not path.is_file():
            errors.append(f'UEFI driver missing or not .efi: {rel}')
        else:
            issue = _uefi_x64(path)
            if issue: errors.append(f'UEFI driver {rel}: {issue}')
            else: inventory['drivers'] += 1
    if 'openruntime.efi' not in driver_names:
        errors.append('OpenRuntime.efi is not enabled')
    hfs_drivers = driver_names.intersection({'hfsplus.efi','openhfsplus.efi','hfspluslegacy.efi'})
    if not hfs_drivers:
        errors.append('No enabled HFS+ filesystem driver for macOS Recovery')
    elif len(hfs_drivers) > 1:
        # Competing filesystem drivers can attach to the same volumes. Dortania
        # explicitly warns against mixing them, even when each binary is valid.
        errors.append('Multiple HFS+ filesystem drivers enabled; select exactly one: ' +
                      ', '.join(sorted(hfs_drivers)))
    for row in tools:
        path, rel = get_path(row, 'Path', 'Tools')
        if path is None:
            continue
        if path.suffix.casefold() != '.efi' or not path.is_file():
            errors.append(f'OpenCore tool missing or not .efi: {rel}')
        else:
            issue = _uefi_x64(path)
            if issue:
                errors.append(f'OpenCore tool {rel}: {issue}')
            else:
                inventory['tools'] += 1
    info_by_id = {}
    enabled_bundle_names = set()
    for index, row in enumerate(kexts):
        path, rel = get_path(row,'BundlePath','Kexts')
        if path is None: continue
        if path.suffix.casefold() != '.kext' or not path.is_dir():
            errors.append(f'Kext bundle is missing: {rel}')
            continue
        enabled_bundle_names.add(path.name.casefold())
        plist_rel = row.get('PlistPath')
        if not _safe_relative(plist_rel):
            errors.append(f'Kext {rel}: invalid PlistPath')
            continue
        info_path = path/plist_rel.replace('\\','/')
        if not info_path.is_file() or _linked(info_path):
            errors.append(f'Kext {rel}: missing Info.plist')
            continue
        try:
            if info_path.stat().st_size > 4 * 1024 * 1024:
                raise ValueError('Info.plist exceeds 4 MiB safety limit')
            with info_path.open('rb') as src: info=plistlib.load(src)
            if not isinstance(info,dict): raise ValueError('not a dictionary')
        except (OSError, TypeError, ValueError, plistlib.InvalidFileException):
            errors.append(f'Kext {rel}: malformed Info.plist')
            continue
        bundle_id = info.get('CFBundleIdentifier')
        if not isinstance(bundle_id,str) or not bundle_id.strip():
            errors.append(f'Kext {rel}: missing CFBundleIdentifier')
        elif bundle_id.casefold() in info_by_id:
            errors.append(f'Duplicate enabled kext identifier: {bundle_id}')
        else:
            info_by_id[bundle_id.casefold()] = (index, rel, info)
        binary_rel = row.get('ExecutablePath')
        expected_binary = info.get('CFBundleExecutable')
        if expected_binary:
            if not _safe_relative(binary_rel):
                errors.append(f'Kext {rel}: missing or invalid executable path')
            else:
                executable = path/binary_rel.replace('\\','/')
                if not executable.is_file() or executable.stat().st_size == 0 or _linked(executable):
                    errors.append(f'Kext {rel}: executable is missing, linked, or empty')
                elif executable.name != expected_binary:
                    errors.append(f'Kext {rel}: executable name differs from Info.plist')
                else:
                    issue = _macho_x64(executable)
                    if issue:
                        errors.append(f'Kext {rel}: {issue}')
        elif binary_rel:
            errors.append(f'Kext {rel}: config references an executable absent from Info.plist')
        inventory['kexts'] += 1
    for bundle_id,(index,rel,info) in info_by_id.items():
        dependencies = info.get('OSBundleLibraries', {})
        if not isinstance(dependencies,dict):
            errors.append(f'Kext {rel}: malformed OSBundleLibraries')
            continue
        for dependency, dependency_version in dependencies.items():
            if not isinstance(dependency, str) or not dependency:
                errors.append(f'Kext {rel}: invalid dependency identifier')
                continue
            if not isinstance(dependency_version, str):
                errors.append(f'Kext {rel}: invalid dependency version')
                continue
            entry = info_by_id.get(dependency.casefold())
            if entry:
                if entry[0] >= index:
                    errors.append(f'Kext order: {entry[1]} must load before {rel}')
                # The correct dependency name is not sufficient: the loaded
                # kext must also meet the consumer's minimum bundle version.
                required = _numeric_bundle_version(dependency_version)
                installed_text = entry[2].get('CFBundleVersion')
                installed = _numeric_bundle_version(installed_text)
                if required is not None and installed is not None and installed < required:
                    errors.append(f'Kext {rel}: {entry[1]} version {installed_text} is older than required {dependency_version}')
                elif required is None or installed is None:
                    warnings.append(f'Kext {rel}: cannot compare {dependency} dependency versions automatically')
            elif not dependency.casefold().startswith('com.apple.'):
                # Third-party libraries are not provided by macOS. They must
                # exist as enabled kexts for this Darwin target.
                errors.append(f'Kext {rel}: missing enabled dependency {dependency}')
    if 'utbmap.kext' in enabled_bundle_names:
        if 'usbtoolbox.kext' not in enabled_bundle_names:
            errors.append('UTBMap.kext requires enabled USBToolBox.kext')
        else:
            names = [str(row.get('BundlePath', '')).casefold() for row in kexts]
            if names.index('usbtoolbox.kext') >= names.index('utbmap.kext'):
                errors.append('USBToolBox.kext must load before UTBMap.kext')

    if 'lilu.kext' not in enabled_bundle_names:
        errors.append('Required Lilu.kext is missing or disabled')
    if 'virtualsmc.kext' not in enabled_bundle_names:
        errors.append('Required VirtualSMC.kext is missing or disabled')
    if 'utbdefault.kext' in enabled_bundle_names and 'utbmap.kext' in enabled_bundle_names:
        errors.append('UTBDefault.kext and UTBMap.kext are both enabled; remove the fallback map')
    elif 'utbdefault.kext' in enabled_bundle_names:
        warnings.append('Temporary USB mapping (UTBDefault): individual ports still require verification')
    else:
        warnings.append('USB ports require a tested map; EFI validation alone cannot certify port behavior')
    if target_darwin is not None and _kernel_version_tuple(str(target_darwin))[0] >= 25:
        if 'applealc.kext' in enabled_bundle_names:
            warnings.append('macOS 26+ removes AppleHDA: AppleALC alone cannot provide ordinary analog audio without additional changes')
    warnings.append('Online Recovery requires a supported, working network adapter during installation')
    warnings.append('SSDT, kext and UEFI file checks do not prove hardware or macOS boot compatibility')
    return {'errors':errors, 'warnings':warnings, 'inventory':inventory}
