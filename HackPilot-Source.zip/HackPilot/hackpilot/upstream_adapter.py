"""Non-interactive adapter to the BSD-3-Clause OpCore-Simplify engine.

Refuses unknown/multi-device or security-risk selections rather than silently guessing.
This is an integration against an independently maintained upstream: it is *not* guaranteed
for every upstream version. Failed builds never replace an existing validated output.
"""
import importlib.util
import json
import hashlib
import os
from pathlib import Path
import shutil
import sys
import tempfile

try:
    from hackpilot.efi import validate_efi
except ModuleNotFoundError:
    from efi import validate_efi


def select_native_target(native, suggested, requested, parse_version):
    """Use upstream native range ordering: oldest first, newest last."""
    if not native or len(native) < 2 or not suggested:
        raise RuntimeError('No natively compatible macOS version identified')
    if requested != 'auto' and requested not in {str(v) for v in range(20, 26)}:
        raise RuntimeError('Requested macOS version is unsupported by the selector')
    if requested == 'auto':
        selected = suggested
        # The current documented Intel recovery profiles stop at Darwin 25.
        # A future upstream compatibility database must not silently push
        # this installer onto an unsupported or unprofiled macOS release.
        if parse_version(selected) >= parse_version('26.0.0'):
            selected = '25.0.0'
    else:
        # A major-version choice permits an available point release; it does not
        # require the fictional .99.99 release to be in the supported range.
        ceiling = requested + '.99.99'
        selected = min((ceiling, native[-1]), key=parse_version)
        if parse_version(selected) < parse_version(requested + '.0.0'):
            raise RuntimeError('Selected macOS version is outside upstream native compatibility range')
    if not (parse_version(native[0]) <= parse_version(selected) <= parse_version(native[-1])):
        raise RuntimeError('Selected macOS version is outside upstream native compatibility range')
    if not (parse_version('20.0.0') <= parse_version(selected) < parse_version('26.0.0')):
        raise RuntimeError('No verified Apple recovery profile for this macOS target')
    return selected


def bounded_device_combinations(indices):
    """Avoid upstream's exponential 2**N combination generator.

    HackPilot's guided GUI deliberately enables a single GPU at a time. Only
    singleton combinations can be chosen; enabling multi-GPU groups requires
    a future explicit topology-aware mode, not an automatic guess.
    """
    if not isinstance(indices, (set, list, tuple)):
        raise RuntimeError('Invalid GPU device group from EFI engine')
    if len(indices) > 1024 or any(type(x) != int or x < 0 for x in indices):
        raise RuntimeError('Too many or invalid GPU entries in upstream report')
    return [[index] for index in sorted(set(indices))]


def guided_device_choice(customizer, device_type, devices, device_groups, selections):
    """Choose a device AND disable the others, matching upstream behavior.

    The earlier adapter only returned the chosen name. Upstream's own selector
    also calls _disable_device on every other candidate. Omitting that action
    can cause unwanted GPUs/Wi-Fi/Bluetooth controllers to remain enabled.
    """
    if not isinstance(devices, dict) or not devices:
        raise RuntimeError('Upstream device choices are invalid')
    if len(devices) == 1:
        return list(devices)
    chosen = selections.get(device_type)
    if not chosen:
        raise RuntimeError(f'Select a {device_type} device in Hardware before generating EFI')
    if chosen not in devices:
        raise RuntimeError(f'Selected {device_type} device is not compatible with this macOS target')
    index = list(devices).index(chosen)
    if device_groups and not any(index in group for group in device_groups):
        raise RuntimeError(f'Selected {device_type} does not form an allowed combination')
    if not callable(getattr(customizer, '_disable_device', None)):
        raise RuntimeError('Upstream device-disable API changed; aborting safely')
    for other, properties in devices.items():
        if other != chosen:
            customizer._disable_device(device_type, other, properties)
    if isinstance(getattr(customizer, 'selected_devices', None), dict):
        customizer.selected_devices[device_type] = {chosen: devices[chosen]}
    print(f'[HackPilot guided] {device_type}: {chosen}', flush=True)
    return [chosen]


def main():
    engine, report_file, acpi_dir, output_dir = map(Path,sys.argv[1:5])
    requested = sys.argv[5] if len(sys.argv)>5 else "auto"
    validator_dir = Path(sys.argv[6]) if len(sys.argv)>6 and sys.argv[6] else None
    selections = json.loads(sys.argv[7]) if len(sys.argv)>7 else {}
    usb_map_path = Path(sys.argv[8]) if len(sys.argv)>8 and sys.argv[8] else None
    if not isinstance(selections, dict) or any(k not in ('GPU','WiFi','Bluetooth') or not isinstance(v, str) for k,v in selections.items()):
        raise RuntimeError('Invalid hardware choices')
    if not (engine/'OpCore-Simplify.py').exists(): raise RuntimeError('Engine not installed')
    if not (Path(report_file).exists() and Path(acpi_dir).is_dir()): raise RuntimeError('Deep hardware report and ACPI dump required')
    try:
        from hackpilot.scan_seal import seal_scan, assert_scan_seal, require_valid_dsdt
    except ModuleNotFoundError:
        from scan_seal import seal_scan, assert_scan_seal, require_valid_dsdt
    input_seal = seal_scan(report_file, acpi_dir)
    require_valid_dsdt(acpi_dir)
    data=json.loads(report_file.read_text(encoding='utf-8-sig'))
    if not isinstance(data.get('CPU'),dict) or not data.get('GPU'):
        raise RuntimeError('Hardware Sniffer report missing CPU or GPU data')
    sys.path.insert(0,str(engine))
    # Avoid automatic upstream self-updates while building. The app pins its downloaded source.
    spec=importlib.util.spec_from_file_location('hackpilot_opcore_engine',engine/'OpCore-Simplify.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    from Scripts import utils
    seen=[]
    def safe_response(self,prompt=''):
        p=str(prompt).strip().lower()
        seen.append(p)
        if len(seen)>120:
            raise RuntimeError('Too many upstream prompts; stopping instead of risking a loop')
        print(f'[HackPilot prompt] {str(prompt)[:180]}',flush=True)
        if 'select' in p and ('gpu' in p or 'wifi device' in p or 'bluetooth' in p):
            raise RuntimeError('Multiple GPUs/Wi-Fi/Bluetooth devices require an explicit choice. Use guided/manual engine mode.')
        if 'continue with opencore legacy patcher' in p:
            raise RuntimeError('OCLP disables macOS security mechanisms; explicit manual approval is required')
        if 'build efi for uefi' in p:
            raise RuntimeError('Firmware is not UEFI. Please change BIOS settings before building.')
        if 'select' in p and ('device' in p or 'combination' in p):
            raise RuntimeError('Hardware selection required; use guided/manual engine mode')
        if 'yes/no' in p or '(y/n)' in p or '(yes/no)' in p:
            return 'no'
        if 'default:' in p:
            return ''
        if not p or 'press enter' in p or 'press any key' in p:
            return ''
        raise RuntimeError('Unrecognized upstream question: '+str(prompt)[:150])
    utils.Utils.request_input=safe_response
    obj=module.OCPE()
    # Upstream's own schema validator knows which report fields, device IDs
    # and platform types its EFI rules require. Do not bypass it.
    valid, report_errors, report_warnings, cleaned_report = obj.v.validate_report(str(report_file))
    if not valid or report_errors or not isinstance(cleaned_report, dict):
        raise RuntimeError('Hardware Sniffer report does not meet the EFI engine schema: ' + '; '.join(map(str, (report_errors or [])[:5])))
    data = cleaned_report
    def selected_device(device_type, devices, device_groups=None):
        return guided_device_choice(obj.h, device_type, devices, device_groups, selections)
    obj.h._select_device = selected_device
    obj.h._get_device_combinations = bounded_device_combinations
    print('[1/7] Checking hardware-specific compatibility',flush=True)
    report,native,oclp,suggested=obj.c.check_compatibility(data)
    suggested = select_native_target(native, suggested, requested, obj.u.parse_darwin_version)
    major=suggested.split('.')[0]
    if major not in {str(x) for x in range(17,27)}:
        raise RuntimeError('Unexpected target macOS version; require manual review: '+suggested)
    print('[2/7] Applying safe device choices for Darwin '+suggested,flush=True)
    customized,disabled,needs_oclp=obj.h.hardware_customization(report,suggested)
    if needs_oclp:
        raise RuntimeError('This build requires OpenCore Legacy Patcher; use guided mode after reviewing security implications')
    smbios=obj.s.select_smbios_model(customized,suggested)
    print('[3/7] Reading real ACPI tables',flush=True)
    obj.ac.read_acpi_tables(str(acpi_dir))
    if not obj.ac.ensure_dsdt(): raise RuntimeError('DSDT could not be decoded; refusing generic SSDT patches')
    obj.ac.select_acpi_patches(customized,disabled)
    print('[4/7] Choosing kexts and platform information',flush=True)
    needs_oclp=obj.k.select_required_kexts(customized,suggested,needs_oclp,obj.ac.patches)
    if needs_oclp: raise RuntimeError('Kext selection requires root patching; manual review required')
    obj.s.smbios_specific_options(customized,smbios,suggested,obj.ac.patches,obj.k)
    print('[5/7] Downloading OpenCore and version-matched kexts',flush=True)
    obj.o.gather_bootloader_kexts(obj.k.kexts,suggested)
    print('[6/7] Generating custom EFI',flush=True)
    obj.build_opencore_efi(customized,disabled,smbios,suggested,False)
    generated=Path(obj.result_dir)/'EFI'
    if not (generated/'OC'/'config.plist').exists(): raise RuntimeError('Upstream did not produce an EFI')
    final=Path(output_dir)
    final.parent.mkdir(parents=True,exist_ok=True)
    staged=Path(tempfile.mkdtemp(prefix='hackpilot-build-',dir=str(final.parent)))
    try:
        shutil.copytree(generated,staged/'EFI')
        if usb_map_path:
            try:
                from hackpilot.usb_mapping import inject_efi_map
            except ModuleNotFoundError:
                from usb_mapping import inject_efi_map
            inject_efi_map(staged, usb_map_path)
        if validator_dir:
            try:
                from hackpilot.engine import setup_validator
            except ModuleNotFoundError:
                from engine import setup_validator
            validator = setup_validator(validator_dir.parent, expected_opencore=staged/'EFI'/'OC'/'OpenCore.efi')
            validator_dir = Path(validator['root'])
        # Independently inspect every enabled .efi, SSDT, kext Info.plist,
        # executable and intra-EFI dependency before publishing the build.
        try:
            from hackpilot.efi_audit import audit_efi_components
        except ModuleNotFoundError:
            from efi_audit import audit_efi_components
        component_audit = audit_efi_components(staged, target_darwin=suggested)
        if component_audit['errors']:
            raise RuntimeError('Incomplete or inconsistent EFI: ' + '; '.join(component_audit['errors'][:8]))
        preliminary=validate_efi(staged, validator_dir)
        if not preliminary['valid']:
            raise RuntimeError('Generated EFI failed OpenCore validation: '+ '; '.join((preliminary['errors'] + preliminary['warnings'])[:5]))
        # Reject a mid-build replacement of the hardware report or ACPI dump.
        assert_scan_seal(report_file, acpi_dir, input_seal)
        # Bind the published manifest to the *exact* EFI tree, not merely
        # its component counts. An altered but structurally valid kext must
        # not be revalidated and presented as the original generated build.
        try:
            from hackpilot.efi import efi_tree_fingerprint
        except ModuleNotFoundError:
            from efi import efi_tree_fingerprint
        efi_sha256 = efi_tree_fingerprint(staged/'EFI')
        (staged/'build-manifest.json').write_text(json.dumps({'engine':'OpCore-Simplify','manifest_version':2,
            'efi_sha256':efi_sha256,'target_darwin':suggested,'smbios_model':smbios,'needs_oclp':False,
            'scan_seal': input_seal,
            'usb_map_sha256': (hashlib.sha256((staged/'EFI'/'OC'/'Kexts'/'UTBMap.kext'/'Contents'/'Info.plist').read_bytes()).hexdigest() if usb_map_path else None),
            'component_inventory':component_audit['inventory'],
            'component_warnings':component_audit['warnings']},indent=2),encoding='utf-8')
        print('[7/7] EFI assembled; final validator runs in HackPilot',flush=True)
        archived=None
        if final.exists():
            # Old output is retained separately; never delete an existing working EFI.
            import datetime
            archived=final.parent/(final.name+'-backup-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S%f'))
            final.rename(archived)
        try:
            staged.rename(final)
        except Exception:
            if archived and archived.exists() and not final.exists():
                archived.rename(final)
            raise
    finally:
        if staged.exists(): shutil.rmtree(staged,ignore_errors=True)
    print('Build complete: '+str(final),flush=True)

if __name__=='__main__':
    try: main()
    except Exception as exc:
        import traceback
        traceback.print_exc()
        sys.exit(2)
