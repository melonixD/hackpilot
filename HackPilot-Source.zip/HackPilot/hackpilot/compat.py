"""Conservative *triage*; upstream Hardware Sniffer/engine makes the version-specific decision."""
import re
from .hardware_scale import unsupported_gpu, network_preflight


def _names(items):
    return [str((x or {}).get('name', '')) for x in (items or []) if isinstance(x, dict)]


def assess(report):
    if not isinstance(report, dict) or not isinstance(report.get('cpu'), dict) or not report['cpu']:
        return {'status':'unscanned','headline':'Scan your hardware to begin','findings':[], 'can_attempt':False}
    findings = []
    add = lambda level, label, detail: findings.append({'level':level,'label':label,'detail':detail})
    cpu = str(report.get('cpu',{}).get('name','')).lower()
    gpus = [name.lower() for name in _names(report.get('gpus'))]
    fw = report.get('firmware') or {}
    if not isinstance(fw, dict): fw = {}
    if not cpu or cpu == 'unknown cpu':
        add('block','Unknown processor','Unable to choose CPU patches safely.')
    elif 'snapdragon' in cpu or 'qualcomm' in cpu or 'arm' in cpu or 'apple m' in cpu:
        add('block','Unsupported CPU architecture','This OpenCore x86_64 builder cannot produce a supported macOS installer for ARM PCs.')
    elif 'amd' in cpu or 'ryzen' in cpu or 'athlon' in cpu or 'threadripper' in cpu:
        add('review','AMD CPU patches required','AMD kernels require precise patches for the chosen macOS release.')
    elif 'intel' in cpu or 'core' in cpu or 'xeon' in cpu or 'pentium' in cpu:
        add('review','Intel platform detected','CPU generation, features and board must be verified against the target macOS release.')
    else:
        add('review','Unrecognized CPU family','Requires upstream compatibility analysis; do not assume support.')
    probable_acceleration = []
    if not gpus:
        add('block','Graphics not identified','A bootable EFI cannot be promised without graphics identification.')
    else:
        for gpu in gpus:
            if unsupported_gpu(gpu):
                probable_acceleration.append(False)
            elif 'microsoft basic display' in gpu:
                probable_acceleration.append(False)
            else:
                probable_acceleration.append(None)
        if probable_acceleration and all(v is False for v in probable_acceleration):
            add('block','No known natively accelerated GPU','All detected graphics devices appear unsupported for native acceleration. A boot-only experimental mode is not an everyday-ready install.')
        if any('rtx' in gpu or 'gtx 16' in gpu or re.search(r'gtx\s*10\d\d', gpu) for gpu in gpus):
            add('review','Recent NVIDIA graphics','No standard macOS acceleration. Experimental community drivers are not treated as supported.')
        elif any('radeon' in gpu or 'rx ' in gpu for gpu in gpus):
            add('review','AMD Radeon graphics','Exact PCI device ID and macOS version determine support; some GPUs need patches or are unsupported.')
        elif any('intel' in gpu for gpu in gpus):
            add('review','Intel graphics','iGPU generation and display connections determine compatibility; newer generations may need experimental solutions.')
        else:
            add('review','Graphics require verification','No safe general GPU compatibility claim can be made from the display name alone.')
    if str(fw.get('type','')).lower() == 'legacy':
        add('block','Legacy boot detected','This unattended builder requires UEFI. Change firmware mode only after reviewing Windows boot implications.')
    if str(fw.get('secure_boot','')).lower() == 'true':
        add('review','Windows Secure Boot enabled','BIOS changes must be reviewed; save your BitLocker recovery key before firmware changes.')
    network = network_preflight(report.get('network'))
    if not network['candidate']:
        add('review','Internet recovery may not work',network['reason'] + '. A supported physical NIC is needed.')
    # An online Recovery image is not a full offline installer. Detecting a
    # physical NIC in Windows is not the same as confirming a macOS driver.
    physical_network = [d for d in (report.get('network') or []) if isinstance(d,dict)]
    if network['candidate'] and not any(
            ('ethernet' in str(d.get('name','')).lower() or
             'gigabit' in str(d.get('name','')).lower() or
             'gbe' in str(d.get('name','')).lower() or
             re.search(r'\b(?:i21[0-9]|i22[0-9]|rtl81[0-9]{2})\b',str(d.get('name','')).lower()))
            for d in physical_network):
        add('review','Internet recovery network path unverified',
            'Only Wi-Fi or an unidentified adapter appears available. Apple Recovery must have a working macOS-compatible network driver; Ethernet is preferable.')
    storage = [str(d.get('name','')).lower() for d in (report.get('storage') or [])
               if isinstance(d,dict)]
    if any(re.search(r'\b(?:vmd|intel\s+rst|rapid\s+storage|raid|optane)\b',name)
           for name in storage):
        add('review','Storage controller requires BIOS review',
            'VMD, Intel RST, RAID or Optane storage may hide the target drive from macOS. Changing storage settings may make Windows unbootable without preparation.')
    if not report.get('audio'):
        add('review','Audio hardware not detected','Audio codecs and layout IDs may require manual verification.')
    add('review','USB mapping still required','Port mapping may need physical plug/unplug testing on the actual machine.')
    blocked = any(x['level']=='block' for x in findings)
    return {'status':'blocked' if blocked else 'review',
            'headline':'Hardware blockers detected' if blocked else 'Needs hardware-specific verification',
            'findings':findings, 'can_attempt':not blocked,
            'graphics_acceleration':'unsupported' if probable_acceleration and all(x is False for x in probable_acceleration) else 'unverified',
            'note':'This is a conservative preliminary check, not certification. Boot success cannot be guaranteed.'}
