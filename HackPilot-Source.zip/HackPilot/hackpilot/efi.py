"""EFI consistency and ocvalidate checks. Validation is not a promise of bootability."""
import hashlib
import json
import os
import plistlib
import re
import stat
import subprocess
from pathlib import Path


def _safe_relative(path):
    if not isinstance(path, str) or not path.strip() or '\x00' in path:
        return False
    clean = path.replace('\\', '/')
    if clean.startswith('/') or re.match(r'^[a-zA-Z]:', clean):
        return False
    components = clean.split('/')
    if any(not component or component in ('.', '..') or
           component.endswith((' ', '.')) or
           re.search(r'[<>:"|?*\x00-\x1f]', component) or
           re.fullmatch(r'(?:CON|PRN|AUX|NUL|COM[1-9¹²³]|LPT[1-9¹²³])(?:\.[^.]*)?', component, re.I)
           for component in components):
        return False
    return True


def _linked(path):
    if path.is_symlink():
        return True
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    return bool(getattr(info, 'st_file_attributes', 0) &
                getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0))


# An EFI normally contains a few hundred MB at most. Refuse pathological
# trees before spending minutes hashing a malformed or unexpectedly enormous
# build. Limits are conservative and do not affect ordinary OpenCore installs.
MAX_EFI_FILES = 20_000
MAX_EFI_BYTES = 1024 * 1024 * 1024
# The generic tree digest also validates Apple Recovery folders on removable
# drives. Those may legitimately exceed 1 GiB; apply the stricter cap ONLY to
# EFI builds, never to the recovery DMG.
MAX_TRANSFER_TREE_BYTES = 8 * 1024 * 1024 * 1024


def efi_tree_fingerprint(root, *, max_bytes=MAX_TRANSFER_TREE_BYTES):
    """Unambiguous, bounded fingerprint of EFI paths, types, sizes and bytes.

    The old digest wrote file bytes immediately before the next filename tag,
    without recording the preceding file's size. That admitted *different*
    sets of file contents which produced identical byte streams for hashing.
    v2 adds a domain separator, count limits, and an 8-byte file length.
    """
    root = Path(root)
    if not root.is_dir() or _linked(root):
        raise RuntimeError('EFI folder missing or linked')
    digest = hashlib.sha256(b'HackPilot-EFI-tree-v2\0')
    from itertools import islice
    files = list(islice(root.rglob('*'), MAX_EFI_FILES + 1))
    if len(files) > MAX_EFI_FILES:
        raise RuntimeError('EFI contains too many files or folders')
    files.sort(key=lambda p: p.relative_to(root).as_posix())
    if not files:
        raise RuntimeError('EFI folder is empty')
    seen = set()
    total_bytes = 0
    for path in files:
        if _linked(path):
            raise RuntimeError('Linked files or folders are not allowed in EFI')
        rel = path.relative_to(root).as_posix()
        if not _safe_relative(rel):
            raise RuntimeError('EFI contains a filename unsupported on FAT32: ' + rel)
        folded = rel.casefold()
        if folded in seen:
            raise RuntimeError('Case-insensitive EFI filename collision: ' + rel)
        seen.add(folded)
        encoded = rel.encode('utf-8')
        if not path.is_file():
            if not path.is_dir():
                raise RuntimeError('Unexpected EFI file type')
            digest.update(b'D' + len(encoded).to_bytes(4, 'big') + encoded)
            continue
        size = path.stat().st_size
        if size > max_bytes or total_bytes + size > max_bytes:
            raise RuntimeError('Tree exceeds its safety size limit')
        total_bytes += size
        digest.update(b'F' + len(encoded).to_bytes(4, 'big') + encoded)
        digest.update(size.to_bytes(8, 'big'))
        with path.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(chunk)
    return digest.hexdigest()


def efi_fingerprint(build_dir):
    return efi_tree_fingerprint(Path(build_dir) / 'EFI', max_bytes=MAX_EFI_BYTES)


MAX_BUILD_MANIFEST_BYTES = 512 * 1024


def load_build_manifest(build_dir):
    """Read a generated manifest without trusting linked or unbounded files.

    The manifest lives outside the EFI directory and is editable after build.
    Never allow it to turn a GUI status check into an unbounded disk read.
    """
    path = Path(build_dir) / 'build-manifest.json'
    if _linked(path) or not path.is_file():
        raise RuntimeError('Build manifest is missing or linked')
    try:
        if not 2 <= path.stat().st_size <= MAX_BUILD_MANIFEST_BYTES:
            raise RuntimeError('Build manifest is empty or exceeds safety size limit')
        with path.open('rb') as stream:
            raw = stream.read(MAX_BUILD_MANIFEST_BYTES + 1)
        if len(raw) > MAX_BUILD_MANIFEST_BYTES:
            raise RuntimeError('Build manifest exceeds safety size limit')
        data = json.loads(raw.decode('utf-8'))
        if not isinstance(data, dict):
            raise RuntimeError('Build manifest must be a JSON object')
        return data
    except (OSError, ValueError, UnicodeError, TypeError) as exc:
        raise RuntimeError('Build manifest is unreadable or malformed') from exc


def validate_efi(build_dir, engine_dir=None):
    root = Path(build_dir) / 'EFI'
    oc = root / 'OC'
    errors, warnings = [], []
    for file in [root/'BOOT'/'BOOTx64.efi', oc/'OpenCore.efi', oc/'config.plist']:
        if _linked(file) or not file.is_file() or file.stat().st_size == 0:
            errors.append('Missing, linked, or empty ' + str(file.relative_to(root)))
    fingerprint = None
    try:
        fingerprint = efi_fingerprint(build_dir)
    except (OSError, RuntimeError) as e:
        errors.append(str(e))
    data = None
    plist = oc / 'config.plist'
    if plist.is_file() and not _linked(plist):
        try:
            # Parse only bounded configuration files. The component audit has
            # its own limit, but this earlier parser ran before that audit.
            if plist.stat().st_size > 8 * 1024 * 1024:
                raise ValueError('OpenCore config.plist exceeds 8 MiB safety limit')
            with plist.open('rb') as stream:
                data = plistlib.load(stream)
            if not isinstance(data, dict):
                raise ValueError('Configuration root is not a dictionary')
            for field in ('ACPI', 'Kernel', 'UEFI', 'Misc', 'PlatformInfo'):
                if not isinstance(data.get(field), dict):
                    errors.append('Missing or invalid config.plist key ' + field)
        except (OSError, ValueError, TypeError, plistlib.InvalidFileException) as e:
            errors.append('config.plist cannot be parsed: ' + str(e))
    if isinstance(data, dict):
        def section(key):
            value = data.get(key)
            return value if isinstance(value, dict) else {}
        def file_check(folder, entries, path_field):
            if not isinstance(entries, list):
                errors.append('Invalid config.plist section: ' + folder)
                return
            for item in entries:
                if not isinstance(item, dict):
                    errors.append('Invalid entry in ' + folder)
                    continue
                if not item.get('Enabled', True):
                    continue
                rel = item.get(path_field)
                if not _safe_relative(rel):
                    errors.append('Invalid file reference: ' + str(rel))
                    continue
                target = oc / folder / rel.replace('\\', '/')
                correct_type = target.is_dir() if folder == 'Kexts' else target.is_file()
                if not correct_type or _linked(target):
                    errors.append('Referenced file missing/linked or wrong type: ' + folder + '/' + rel)
        file_check('ACPI', section('ACPI').get('Add', []), 'Path')
        file_check('Drivers', section('UEFI').get('Drivers', []), 'Path')
        kexts = section('Kernel').get('Add', [])
        file_check('Kexts', kexts, 'BundlePath')
        if isinstance(kexts, list):
            for item in kexts:
                if not isinstance(item, dict) or not item.get('Enabled', True):
                    continue
                bundle = item.get('BundlePath', '')
                if not _safe_relative(bundle):
                    continue
                for field in ('ExecutablePath', 'PlistPath'):
                    rel = item.get(field)
                    if rel:
                        if not _safe_relative(rel):
                            errors.append(f'Unsafe kext {bundle} {field}: {rel}')
                        elif (not (oc/'Kexts'/bundle/rel.replace('\\', '/')).is_file() or
                              _linked(oc/'Kexts'/bundle/rel.replace('\\', '/'))):
                            errors.append(f'Kext {bundle} missing/linked {field}: {rel}')
        generic = section('PlatformInfo').get('Generic', {})
        if not isinstance(generic, dict):
            generic = {}
        if not generic.get('SystemSerialNumber'):
            errors.append('SMBIOS serial not generated')
        if not generic.get('SystemUUID'):
            errors.append('SMBIOS UUID not generated')
    # Full component audit applies to builds published by HackPilot. Legacy or
    # imported hand-made EFI fixtures still receive the basic consistency scan.
    component_audit = None
    if ((Path(build_dir) / 'build-manifest.json').exists() or
        (Path(build_dir) / 'build-manifest.json').is_symlink()):
        from .efi_audit import audit_efi_components
        try:
            build_info = load_build_manifest(build_dir)
            target = build_info.get('target_darwin') if isinstance(build_info, dict) else None
            if not target:
                errors.append('Build manifest does not identify the target macOS version')
            if isinstance(build_info, dict) and build_info.get('engine') == 'OpCore-Simplify':
                if (build_info.get('needs_oclp') is not False or
                    not isinstance(build_info.get('smbios_model'), str) or
                    not build_info.get('smbios_model') or
                    not isinstance(build_info.get('component_inventory'), dict) or
                    not isinstance(build_info.get('scan_seal'), dict)):
                    errors.append('HackPilot build manifest is missing machine-specific generation evidence')
                if build_info.get('manifest_version') != 2:
                    errors.append('Older EFI manifest cannot attest exact generated files; rebuild this EFI')
                pinned = build_info.get('efi_sha256')
                if (not isinstance(pinned, str) or len(pinned) != 64 or
                    any(c not in '0123456789abcdef' for c in pinned)):
                    errors.append('Generated EFI manifest is missing a valid EFI content hash')
                elif fingerprint and fingerprint != pinned:
                    errors.append('EFI contents no longer match the machine-bound build manifest')
        except (OSError, ValueError, TypeError, RuntimeError):
            target = None
            errors.append('Build manifest is malformed, missing or unsafe')
        component_audit = audit_efi_components(build_dir, target_darwin=target)
        errors.extend(component_audit['errors'])
        warnings.extend(component_audit['warnings'])
    binary = None
    if engine_dir:
        engine = Path(engine_dir)
        if engine.is_dir():
            candidates = (list(engine.rglob('ocvalidate.exe')) if os.name == 'nt' else list(engine.rglob('ocvalidate')))
            binary = next((candidate for candidate in candidates if candidate.is_file()), None)
    output = ''
    validator_ok = False
    validator_ran = False
    if binary and plist.is_file():
        try:
            manifest_file = Path(engine_dir) / 'validator-manifest.json'
            if _linked(manifest_file) or not manifest_file.is_file():
                errors.append('Validator identity is unverified: missing or linked version manifest')
                raise ValueError('Missing safe validator manifest')
            if not 2 <= manifest_file.stat().st_size <= 128 * 1024:
                raise ValueError('Validator manifest is empty or exceeds 128 KiB safety limit')
            with manifest_file.open('rb') as stream:
                raw_manifest = stream.read(128 * 1024 + 1)
            if len(raw_manifest) > 128 * 1024:
                raise ValueError('Validator manifest is oversized')
            manifest = json.loads(raw_manifest.decode('utf-8'))
            if not isinstance(manifest, dict):
                raise ValueError('Validator manifest must be a JSON object')
            def sha256(file):
                with Path(file).open('rb') as stream:
                    return hashlib.file_digest(stream, 'sha256').hexdigest()
            if manifest.get('binary_sha256') != sha256(binary):
                errors.append('Validator binary checksum differs from its recorded release')
                raise ValueError('Validator binary checksum mismatch')
            expected_opencore = manifest.get('opencore_sha256')
            if not expected_opencore or expected_opencore != sha256(oc/'OpenCore.efi'):
                errors.append('OpenCore binary does not match validator release; regenerate or update matching tools')
                raise ValueError('OpenCore / ocvalidate version mismatch')
            for key, component in (('bootx64_sha256', root/'BOOT'/'BOOTx64.efi'),
                                   ('openruntime_sha256', oc/'Drivers'/'OpenRuntime.efi')):
                expected_component = manifest.get(key)
                if expected_component and (not component.is_file() or sha256(component) != expected_component):
                    errors.append(f'{component.name} does not match the selected OpenCore release')
                    raise ValueError('Mismatched OpenCore boot component')
            result = subprocess.run([str(binary), str(plist)], capture_output=True, timeout=30)
            validator_ran = True
            output = (result.stdout + result.stderr).decode(errors='replace')[-5000:]
            validator_ok = result.returncode == 0
            if not validator_ok:
                errors.append('OpenCore ocvalidate reported errors')
        except (OSError, ValueError, TypeError, subprocess.TimeoutExpired) as e:
            errors.append('ocvalidate could not run safely: ' + str(e))
    else:
        warnings.append('ocvalidate not found; EFI has NOT been fully validated')
    return {'valid':not errors and validator_ok, 'structural_valid':not errors,
            'validator_ran':validator_ran, 'errors':errors, 'warnings':warnings,
            'validator_output':output, 'fingerprint':fingerprint,
            'components':component_audit}
