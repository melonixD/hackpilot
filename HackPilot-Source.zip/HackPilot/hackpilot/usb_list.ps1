$ErrorActionPreference='SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
$results = @()
Get-Disk | Where-Object { $_.BusType -eq 'USB' -and -not $_.IsBoot -and -not $_.IsSystem -and -not $_.IsOffline -and -not $_.IsReadOnly } | ForEach-Object {
  $disk=$_
  Get-Partition -DiskNumber $disk.Number | Where-Object {$_.DriveLetter} | ForEach-Object {
    $partition=$_
    $vol=$partition | Get-Volume
    if ($vol) {
      $results += [pscustomobject]@{
        drive_letter=[string]$partition.DriveLetter
        filesystem=[string]$vol.FileSystem
        name=[string]$disk.FriendlyName
        disk_number=[int]$disk.Number
        disk_unique_id=[string]$disk.UniqueId
        partition_number=[int]$partition.PartitionNumber
        partition_offset=[string]$partition.Offset
        volume_id=[string]$vol.UniqueId
        capacity=[double]$disk.Size
        free_bytes=[double]$vol.SizeRemaining
      }
    }
  }
}
ConvertTo-Json -InputObject @($results) -Compress
