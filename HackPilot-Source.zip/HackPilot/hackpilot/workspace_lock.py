"""Advisory cross-process lock for the machine-specific build workspace.

Each desktop window has its own in-memory state.  Locking only a USB letter
is insufficient: two windows can otherwise race while updating the same
hardware report, cached EFI engine or LatestBuild folder.
"""
import os
import stat
from pathlib import Path
from contextlib import contextmanager


@contextmanager
def workspace_lock(home):
    path = Path(home) / 'workspace.lock'
    path.parent.mkdir(parents=True, exist_ok=True)
    # A redirected lockfile could modify an unrelated file before an OS lock
    # is acquired. Do not follow symlinks or Windows reparse points.
    if path.is_symlink() or (path.exists() and bool(
        getattr(path.lstat(), 'st_file_attributes', 0) &
        getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0))):
        raise RuntimeError('Workspace lockfile is linked; repair the application folder')
    # Keep the file on disk. The OS releases its lock if the app crashes.
    with path.open('a+b') as stream:
        stream.seek(0, os.SEEK_END)
        if stream.tell() == 0:
            stream.write(b'\x00')
            stream.flush()
        stream.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, BlockingIOError) as exc:
            raise RuntimeError('Another HackPilot window is changing this workspace') from exc
        try:
            yield
        finally:
            stream.seek(0)
            if os.name == 'nt':
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
