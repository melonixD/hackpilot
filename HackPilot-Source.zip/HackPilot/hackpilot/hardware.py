"""Local, read-only hardware discovery. Never collects serial numbers or Wi-Fi credentials."""
import json
import platform
import subprocess
from pathlib import Path
from .hardware_scale import (bounded_devices, representative_devices, text_value,
    is_virtual_network, unsupported_gpu)

SCRIPT = Path(__file__).with_name('windows_scan.ps1')


def scan_windows():
    if platform.system() != 'Windows':
        raise RuntimeError('Live hardware scanning requires Windows. Use an imported report on this computer.')
    completed = subprocess.run(
        ['powershell.exe', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', str(SCRIPT)],
        capture_output=True, timeout=60, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
    )
    stdout = completed.stdout.decode('utf-8-sig', errors='replace')
    stderr = completed.stderr.decode('utf-8-sig', errors='replace')
    if completed.returncode:
        raise RuntimeError(f'Windows hardware scan failed: {stderr[-800:]}')
    try:
        data = json.loads(stdout)
    except json.JSONDecodeError as e:
        raise RuntimeError('Windows returned an unreadable hardware report') from e
    if not isinstance(data, dict) or not data.get('cpu'):
        raise RuntimeError('No CPU detected; scan was incomplete')
    data['origin'] = 'Windows hardware scan'
    return data


def imported_native(data):
    """Accept our own exported JSON or a basic canonical hardware report; never pretend it is Sniffer JSON."""
    if not isinstance(data, dict) or not isinstance(data.get('cpu'), dict):
        raise ValueError('Expected a HackPilot report containing CPU and hardware data')
    for field in ('gpus', 'network', 'audio', 'storage', 'usb'):
        value = data.get(field, [])
        if not isinstance(value, list) or any(not isinstance(x, dict) for x in value):
            raise ValueError(f'Invalid hardware report: {field} must be a list of devices')
    for field in ('motherboard', 'firmware', 'system'):
        if not isinstance(data.get(field, {}), dict):
            raise ValueError(f'Invalid hardware report: {field} must be an object')
    result = {key: data.get(key) for key in ('cpu','motherboard','gpus','network','audio','storage','firmware','system','usb')}
    counts = {}
    for field in ('gpus', 'network', 'audio', 'storage', 'usb'):
        preferred = (lambda x: not unsupported_gpu(x.get('name'))) if field=='gpus' else (
            (lambda x: bool(x.get('name')) and not is_virtual_network(x)) if field=='network' else None)
        if preferred:
            items, counts[field] = representative_devices(result.get(field) or [], lambda _, x: x, preferred)
        else:
            items, counts[field] = bounded_devices(result.get(field) or [], lambda _, x: x)
        result[field] = items
    result['device_counts'] = counts
    result['origin'] = 'Imported HackPilot report'
    return result


def sniffer_summary(data):
    """Adapt the upstream Sniffer schema for display. Original report remains intact for the EFI engine."""
    if not isinstance(data, dict) or not isinstance(data.get('CPU'), dict):
        raise ValueError('This is not a recognized Hardware Sniffer report')
    cpu = data['CPU']
    board = data.get('Motherboard') or {}
    if not isinstance(board, dict):
        raise ValueError('Hardware Sniffer motherboard field is invalid')
    for field in ('GPU', 'Network', 'Sound', 'Storage Controllers'):
        values = data.get(field) or {}
        if not isinstance(values, dict) or any(not isinstance(v, dict) for v in values.values()):
            raise ValueError(f'Invalid Hardware Sniffer {field} section')
    if not isinstance(data.get('BIOS') or {}, dict):
        raise ValueError('Invalid Hardware Sniffer BIOS section')
    # The full Sniffer JSON remains untouched for the upstream EFI builder.
    # The GUI only needs a bounded, readable preview for even very large PCs.
    def limited(section, factory, preferred=None):
        source = data.get(section) or {}
        transform = lambda name, props: factory(name, props)
        return (representative_devices(source, transform, preferred) if preferred
                else bounded_devices(source, transform))

    gpus, gpu_count = limited('GPU', lambda name, p: {
        'name': text_value(name), 'vendor': text_value(p.get('Manufacturer')),
        'device_id': text_value(p.get('Device ID'))},
        preferred=lambda x: not unsupported_gpu(x.get('name')))
    network, network_count = limited('Network', lambda name, p: {
        'name': text_value(name), 'manufacturer': text_value(p.get('Manufacturer')),
        'device_id': text_value(p.get('Device ID'))},
        preferred=lambda x: bool(x.get('name')) and not is_virtual_network(x))
    audio, audio_count = limited('Sound', lambda name, p: {'name': text_value(name)})
    storage, storage_count = limited('Storage Controllers', lambda name, p: {'name': text_value(name)})
    return {
        'origin': 'Hardware Sniffer',
        'cpu': {'name': text_value(cpu.get('Processor Name'), 250) or 'Unknown CPU',
                'manufacturer': text_value(cpu.get('Manufacturer')),
                'cores': cpu.get('Core Count')},
        'motherboard': {'name': text_value(board.get('Name'), 250) or 'Unknown motherboard',
                        'manufacturer': text_value(board.get('Manufacturer')),
                        'platform': text_value(board.get('Platform'))},
        'gpus': gpus, 'network': network, 'audio': audio,
        'firmware': {'type': text_value((data.get('BIOS') or {}).get('Firmware Type')) or 'Unknown',
                     'secure_boot': text_value((data.get('BIOS') or {}).get('Secure Boot')) or 'Unknown'},
        'storage': storage, 'system': {}, 'usb': [],
        'device_counts': {'gpus': gpu_count, 'network': network_count,
                          'audio': audio_count, 'storage': storage_count, 'usb': 0},
    }
