$ErrorActionPreference='SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
function Objects($x) { return ,@($x | Where-Object { $null -ne $_ }) }
function NameList($class) {
  return ,@((Get-CimInstance $class | ForEach-Object {
    [pscustomobject]@{ name=[string]$_.Name; device_id=[string]$_.PNPDeviceID; manufacturer=[string]$_.Manufacturer }
  }))
}
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$board = Get-CimInstance Win32_BaseBoard | Select-Object -First 1
$system = Get-CimInstance Win32_ComputerSystem | Select-Object -First 1
$bios = Get-CimInstance Win32_BIOS | Select-Object -First 1
$gpu = @(Get-CimInstance Win32_VideoController | ForEach-Object {
  [pscustomobject]@{name=[string]$_.Name; vendor=[string]$_.AdapterCompatibility; device_id=[string]$_.PNPDeviceID}
})
$net = @(Get-CimInstance Win32_NetworkAdapter | Where-Object { $_.PhysicalAdapter -eq $true } | ForEach-Object {
  [pscustomobject]@{name=[string]$_.Name; device_id=[string]$_.PNPDeviceID; manufacturer=[string]$_.Manufacturer}
})
$aud = @(Get-CimInstance Win32_SoundDevice | ForEach-Object {
  [pscustomobject]@{name=[string]$_.Name; device_id=[string]$_.PNPDeviceID}
})
$storage = @(Get-CimInstance Win32_DiskDrive | ForEach-Object {
  [pscustomobject]@{name=[string]$_.Model; interface=[string]$_.InterfaceType; size_bytes=[double]$_.Size}
})
try { $secure = [string](Confirm-SecureBootUEFI -ErrorAction Stop) } catch { $secure = 'Unknown' }
try { $uefi = Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State' } catch { $uefi = $false }
$firmwareType = 'Unknown'
try {
  $fw = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name PEFirmwareType -ErrorAction Stop).PEFirmwareType
  if ($fw -eq 2) {$firmwareType='UEFI'} elseif ($fw -eq 1) {$firmwareType='Legacy'}
} catch { if ($uefi) {$firmwareType='UEFI'} }
$usb = @(Get-CimInstance Win32_USBController | ForEach-Object { [pscustomobject]@{name=[string]$_.Name;device_id=[string]$_.PNPDeviceID} })
[pscustomobject]@{
  cpu = @{name=[string]$cpu.Name;manufacturer=[string]$cpu.Manufacturer;cores=[int]$cpu.NumberOfCores;threads=[int]$cpu.NumberOfLogicalProcessors}
  motherboard = @{name=[string]$board.Product;manufacturer=[string]$board.Manufacturer;platform= $(if ($system.PCSystemType -eq 2) {'Laptop'} else {'Desktop'})}
  system = @{model=[string]$system.Model; manufacturer=[string]$system.Manufacturer; ram_bytes=[double]$system.TotalPhysicalMemory}
  gpus=$gpu;network=$net;audio=$aud;storage=$storage;usb=$usb
  firmware=@{type=$firmwareType;secure_boot=$secure;bios_version=[string]$bios.SMBIOSBIOSVersion}
} | ConvertTo-Json -Depth 7 -Compress
