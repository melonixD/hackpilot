"""Minimal user-visible hardware choices. Never silently disable a selected device."""

def available_choices(sniffer):
    if not isinstance(sniffer, dict):
        return {}
    result = {}
    for group, source in [('GPU', 'GPU'), ('WiFi', 'Network'), ('Bluetooth', 'Bluetooth')]:
        devices = sniffer.get(source)
        if not isinstance(devices, dict):
            continue
        names = []
        for key, props in devices.items():
            if not isinstance(key, str) or not isinstance(props, dict):
                continue
            if group == 'WiFi':
                description = (key + ' ' + str(props.get('Device Type', ''))).lower()
                if not any(term in description for term in ('wi-fi', 'wifi', 'wireless', '802.11', 'wlan')):
                    continue
            names.append(key)
        if len(names) > 1:
            result[group] = names
    return result


def validate_selections(choices, selections):
    if not isinstance(selections, dict):
        raise ValueError('Hardware choices must be an object')
    if any(key not in ('GPU', 'WiFi', 'Bluetooth') for key in selections):
        raise ValueError('Unknown hardware selection group')
    for group, selected in selections.items():
        if not isinstance(selected, str) or selected not in choices.get(group, []):
            raise ValueError(f'Invalid {group} choice; select a detected device')
    return {group: selections[group] for group in choices if group in selections}
