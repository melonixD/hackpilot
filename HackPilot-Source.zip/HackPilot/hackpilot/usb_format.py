"""Explicit whole-USB erase plans. Never invoked by ordinary EFI copying."""
import base64
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

INVENTORY = r'''
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding $false
$systemDisk=(Get-Partition -DriveLetter ($env:SystemDrive.Substring(0,1))).DiskNumber
$rows=@(Get-Disk | Where-Object { $_.BusType -eq 'USB' } | ForEach-Object {
 $d=$_
 $parts=@(); if($d.PartitionStyle -ne 'RAW' -and $d.NumberOfPartitions -gt 0) {$parts=@(Get-Partition -DiskNumber $d.Number -ErrorAction Stop)}
 $protected=($d.IsBoot -or $d.IsSystem -or $d.Number -eq $systemDisk -or @($parts | Where-Object {$_.IsBoot -or $_.IsSystem}).Count -gt 0)
 $reason=''
 if($protected){$reason='Windows or boot disk: formatting blocked'}
 elseif($d.IsOffline -or $d.IsReadOnly){$reason='Disk is offline or write-protected'}
 elseif(-not $d.UniqueId -or -not $d.Path){$reason='Disk identity cannot be verified'}
 elseif($d.Size -lt 2GB -or $d.Size -gt 2TB){$reason='Supported formatting capacity: 2 GiB to 2 TiB'}
 [pscustomobject]@{number=[int]$d.Number;unique_id=[string]$d.UniqueId;path=[string]$d.Path;serial=[string]$d.SerialNumber;size=[long]$d.Size;name=[string]$d.FriendlyName;reason=$reason;partitions=@($parts | ForEach-Object {
  $p=$_;$v=$p | Get-Volume -ErrorAction SilentlyContinue
  [pscustomobject]@{letter=[string]$p.DriveLetter;filesystem=[string]$v.FileSystem;size=[long]$p.Size}
 })}
})
ConvertTo-Json -InputObject @($rows) -Depth 5 -Compress
'''

FORMAT = r'''
$ErrorActionPreference='Stop'
function Check-Target {
 $d=Get-Disk -Number $request.number -ErrorAction Stop
 $systemDisk=(Get-Partition -DriveLetter ($env:SystemDrive.Substring(0,1))).DiskNumber
 if($d.BusType -ne 'USB' -or $d.IsBoot -or $d.IsSystem -or $d.Number -eq $systemDisk -or $d.IsOffline -or $d.IsReadOnly){throw 'Unsafe or unavailable disk; stopped'}
 if([string]$d.UniqueId -cne $request.unique_id -or [string]$d.Path -cne $request.path -or [string]$d.SerialNumber -cne $request.serial -or [long]$d.Size -ne $request.size){throw 'USB identity changed; stopped'}
 $parts=@(); if($d.PartitionStyle -ne 'RAW' -and $d.NumberOfPartitions -gt 0) {$parts=@(Get-Partition -DiskNumber $d.Number -ErrorAction Stop)}
 if(@($parts | Where-Object {$_.IsBoot -or $_.IsSystem}).Count -gt 0){throw 'Boot/system partition detected; stopped'}
 $letters=@($parts | Where-Object {$_.DriveLetter} | ForEach-Object {[string]$_.DriveLetter})
 foreach($letter in $protectedLetters) {
  if($letters -contains $letter){throw 'Disk contains HackPilot, its working folder or temporary files; move the app to Windows storage first'}
 }
 foreach($page in @(Get-CimInstance Win32_PageFileUsage -ErrorAction Stop)) {
  if($letters -contains $page.Name.Substring(0,1)){throw 'Disk contains a Windows page file; stopped'}
 }
 return $d
}
try {
 if($request.size -lt 2GB -or $request.size -gt 2TB){throw 'Unsupported disk capacity'}
 $d=Check-Target
 # These changes erase ALL partitions. No disk-selection strings reach a shell.
 if($d.PartitionStyle -ne 'RAW') {
  $null=Check-Target
  Clear-Disk -Number $request.number -RemoveData -RemoveOEM -Confirm:$false -ErrorAction Stop
 }
 $null=Check-Target
 Initialize-Disk -Number $request.number -PartitionStyle MBR -ErrorAction Stop | Out-Null
 $d=Check-Target
 $bytes=[long]([Math]::Min(30GB, $d.LargestFreeExtent))
 if($bytes -lt 1GB){throw 'Insufficient contiguous space after initialization'}
 $p=New-Partition -DiskNumber $request.number -Size $bytes -MbrType FAT32 -IsActive -AssignDriveLetter -ErrorAction Stop
 $null=Check-Target
 $fresh=Get-Partition -DiskNumber $request.number -PartitionNumber $p.PartitionNumber -ErrorAction Stop
 if($fresh.Offset -ne $p.Offset -or $fresh.Size -ne $p.Size -or -not $fresh.DriveLetter){throw 'Partition identity changed; stopped'}
 $v=$fresh | Format-Volume -FileSystem FAT32 -NewFileSystemLabel HACKPILOT -Confirm:$false -Force -ErrorAction Stop
 $null=Check-Target
 $v=Get-Partition -DiskNumber $request.number -PartitionNumber $p.PartitionNumber | Get-Volume -ErrorAction Stop
 if($v.FileSystem -ne 'FAT32' -or $v.SizeRemaining -lt 1GB){throw 'FAT32 verification failed'}
 $answer=@{ok=$true;letter=[string]$v.DriveLetter;filesystem=[string]$v.FileSystem;size=[long]$v.Size}
} catch { $answer=@{ok=$false;error=$_.Exception.Message} }
$answer | ConvertTo-Json -Compress | Set-Content -LiteralPath $resultPath -Encoding UTF8
if(-not $answer.ok){exit 1}
'''


def encoded(script):
    return base64.b64encode(script.encode('utf-16le')).decode('ascii')


def inventory():
    if os.name != 'nt':
        return []
    proc = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded(INVENTORY)],
                          capture_output=True, timeout=40, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if proc.returncode:
        raise RuntimeError('USB detection failed: ' + proc.stderr.decode(errors='replace')[-500:])
    data = json.loads(proc.stdout.decode('utf-8-sig'))
    if not isinstance(data, list) or any(not isinstance(row, dict) for row in data):
        raise RuntimeError('Invalid USB inventory')
    return data


def validate_disk(disk):
    if (not isinstance(disk, dict) or type(disk.get('number')) is not int or disk['number'] < 0 or
        type(disk.get('size')) is not int or not 2*1024**3 <= disk['size'] <= 2*1024**4 or
        not isinstance(disk.get('unique_id'), str) or not 1 <= len(disk['unique_id'].strip()) <= 1024 or
        not isinstance(disk.get('path'), str) or not 1 <= len(disk['path'].strip()) <= 1024 or
        not isinstance(disk.get('serial', ''), str) or len(disk.get('serial', '')) > 256 or disk.get('reason')):
        raise RuntimeError('USB is not eligible for formatting')
    return {key: disk.get(key, '') for key in ('number', 'unique_id', 'path', 'serial', 'size')}


def format_disk(expected):
    if os.name != 'nt':
        raise RuntimeError('USB formatting requires Windows')
    expected = validate_disk(expected)
    matches = [d for d in inventory() if d.get('number') == expected['number']]
    if len(matches) != 1 or validate_disk(matches[0]) != expected:
        raise RuntimeError('USB changed since confirmation; refresh and choose it again')
    with tempfile.TemporaryDirectory(prefix='hackpilot-format-') as temp:
        result = Path(temp) / 'result.json'
        payload = base64.b64encode(json.dumps(expected).encode('utf-8')).decode('ascii')
        path_payload = base64.b64encode(str(result).encode('utf-8')).decode('ascii')
        protected = sorted({p.drive[:1].upper() for p in (Path(sys.executable), Path.cwd(), Path(tempfile.gettempdir()), Path(__file__).resolve()) if p.drive})
        protected_payload = base64.b64encode(json.dumps(protected).encode('utf-8')).decode('ascii')
        script = ("$request=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + payload + "')) | ConvertFrom-Json\n"
                  "$resultPath=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + path_payload + "'))\n"
                  "$protectedLetters=@([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + protected_payload + "')) | ConvertFrom-Json)\n" + FORMAT)
        # Only the formatter is elevated. UAC cancellation cannot fall through
        # to an unprivileged attempt or silently choose another disk.
        launch = ("$ErrorActionPreference='Stop';try {$p=Start-Process powershell.exe -Verb RunAs -PassThru -Wait "
                  "-ArgumentList @('-NoProfile','-NonInteractive','-EncodedCommand','" + encoded(script) + "');exit $p.ExitCode} catch {exit 1223}")
        if len(launch) > 28000:
            raise RuntimeError('Disk identity is too large for a safe Windows formatter command')
        proc = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', launch],
                              capture_output=True, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        # Do not terminate a format mid-write just because a time budget elapsed.
        if not result.is_file():
            raise RuntimeError('Formatting was cancelled or could not start. No success was reported; refresh the USB list.')
        if result.stat().st_size > 16384:
            raise RuntimeError('Invalid formatter response; inspect the USB before retrying')
        response = json.loads(result.read_text(encoding='utf-8-sig'))
        if proc.returncode or not isinstance(response, dict) or response.get('ok') is not True:
            detail = response.get('error', 'Unknown formatting failure') if isinstance(response, dict) else 'Invalid response'
            raise RuntimeError('USB formatting stopped: ' + str(detail) + '. The USB may be partially formatted; refresh before retrying.')
        if response.get('filesystem') != 'FAT32' or not isinstance(response.get('letter'), str) or len(response['letter']) != 1 or not response['letter'].isascii() or not response['letter'].isalpha():
            raise RuntimeError('Formatted volume verification failed')
        return response
