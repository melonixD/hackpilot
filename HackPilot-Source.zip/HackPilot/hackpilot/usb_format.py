"""Explicit whole-USB erase plans. Never invoked by ordinary EFI copying."""
import base64
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import secrets
import threading
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from types import SimpleNamespace

INVENTORY = r'''
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding $false
$systemDisk=(Get-Partition -DriveLetter ($env:SystemDrive.Substring(0,1))).DiskNumber
$rows=@(Get-Disk | Where-Object { $_.BusType -eq 'USB' } | ForEach-Object {
 $d=$_
 $reason='';$parts=@();try {if($d.PartitionStyle -ne 'RAW' -and $d.NumberOfPartitions -gt 0) {$parts=@(Get-Partition -DiskNumber $d.Number -ErrorAction Stop)}} catch {$reason='Windows could not read partitions safely; try running HackPilot as administrator or use official Rufus'}
 $protected=($d.IsBoot -or $d.IsSystem -or $d.Number -eq $systemDisk -or @($parts | Where-Object {$_.IsBoot -or $_.IsSystem}).Count -gt 0)
 if($protected){$reason='Windows or boot disk: formatting blocked'}
 elseif($d.IsOffline -or $d.IsReadOnly){$reason='Disk is offline or write-protected'}
 elseif(-not $d.UniqueId -or -not $d.Path){$reason='Disk identity cannot be verified'}
 elseif($d.Size -lt 2GB -or $d.Size -gt 2TB){$reason='Supported formatting capacity: 2 GiB to 2 TiB'}
 [pscustomobject]@{number=[int]$d.Number;unique_id=[string]$d.UniqueId;path=[string]$d.Path;serial=[string]$d.SerialNumber;size=[long]$d.Size;name=[string]$d.FriendlyName;reason=$reason;partitions=@($parts | ForEach-Object {
  $p=$_;$v=$p | Get-Volume -ErrorAction SilentlyContinue
  [pscustomobject]@{number=[int]$p.PartitionNumber;letter=[string]$p.DriveLetter;filesystem=[string]$v.FileSystem;size=[long]$p.Size}
 })}
})
ConvertTo-Json -InputObject @($rows) -Depth 5 -Compress
'''

FORMAT = r'''
$ErrorActionPreference='Stop'
function Check-Target {
 $d=Get-Disk -Number $request.number -ErrorAction Stop
 $systemDisk=(Get-Partition -DriveLetter ($env:SystemDrive.Substring(0,1))).DiskNumber
 if($d.BusType -ne 'USB' -or $d.IsBoot -or $d.IsSystem -or $d.Number -eq $systemDisk -or $d.IsOffline -or $d.IsReadOnly){throw 'Unsafe or unavailable disk; stopped'}
 if([string]$d.UniqueId -cne $request.unique_id -or [string]$d.Path -cne $request.path -or [string]$d.SerialNumber -cne $request.serial -or [long]$d.Size -ne $request.size){throw 'USB identity changed; stopped'}
 $parts=@(); if($d.PartitionStyle -ne 'RAW' -and $d.NumberOfPartitions -gt 0) {$parts=@(Get-Partition -DiskNumber $d.Number -ErrorAction Stop)}
 if(@($parts | Where-Object {$_.IsBoot -or $_.IsSystem}).Count -gt 0){throw 'Boot/system partition detected; stopped'}
 $letters=@($parts | Where-Object {$_.DriveLetter} | ForEach-Object {[string]$_.DriveLetter})
 foreach($letter in $protectedLetters) {
  if($letters -contains $letter){throw 'Disk contains HackPilot, its working folder or temporary files; move the app to Windows storage first'}
 }
 foreach($page in @(Get-CimInstance Win32_PageFileUsage -ErrorAction Stop)) {
  if($letters -contains $page.Name.Substring(0,1)){throw 'Disk contains a Windows page file; stopped'}
 }
 return $d
}
try {
 if($request.filesystem -notin @('FAT32','NTFS','exFAT') -or $request.style -notin @('MBR','GPT')){throw 'Unsupported formatting settings'}
 if($request.size -lt 2GB -or $request.size -gt 2TB){throw 'Unsupported disk capacity'}
 $phase='preflight';$d=Check-Target
 # These changes erase ALL partitions. No disk-selection strings reach a shell.
 if($d.PartitionStyle -ne 'RAW') {
  $null=Check-Target
  $phase='erase partitions'; Clear-Disk -Number $request.number -RemoveData -RemoveOEM -Confirm:$false -ErrorAction Stop
 }
 $null=Check-Target
 $phase='initialize disk'; Initialize-Disk -Number $request.number -PartitionStyle $request.style -ErrorAction Stop | Out-Null
 $d=Check-Target
 $phase='create partition'
 $args=@{DiskNumber=$request.number;AssignDriveLetter=$true;ErrorAction='Stop'}
 if($request.filesystem -eq 'FAT32'){
  $bytes=[long]([Math]::Min(30GB,$d.LargestFreeExtent))
  if($bytes -lt 1GB){throw 'Insufficient free space after initialization'}
  $args.Size=$bytes
 } else {$args.UseMaximumSize=$true}
 if($request.style -eq 'MBR'){
  $args.MbrType=$(if($request.filesystem -eq 'FAT32'){'FAT32'}else{'IFS'})
  $args.IsActive=$true
 } else {$args.GptType='{EBD0A0A2-B9E5-4433-87C0-68B6B72699C7}'}
 $p=New-Partition @args
 $null=Check-Target
 $fresh=Get-Partition -DiskNumber $request.number -PartitionNumber $p.PartitionNumber -ErrorAction Stop
 if($fresh.Offset -ne $p.Offset -or $fresh.Size -ne $p.Size -or -not $fresh.DriveLetter){throw 'Partition identity changed; stopped'}
 $phase='format volume'; $v=$fresh | Format-Volume -FileSystem $request.filesystem -NewFileSystemLabel HACKPILOT -Confirm:$false -Force -ErrorAction Stop
 $null=Check-Target
 $v=Get-Partition -DiskNumber $request.number -PartitionNumber $p.PartitionNumber | Get-Volume -ErrorAction Stop
 $phase='verify volume'
 if($v.FileSystem -ne $request.filesystem -or $v.SizeRemaining -lt 1GB){throw 'Filesystem verification failed'}
 if(-not (Test-Path -LiteralPath ([string]$v.DriveLetter+':\') -PathType Container -ErrorAction Stop)){throw 'Formatted volume has no accessible mount point'}
 $answer=@{ok=$true;letter=[string]$v.DriveLetter;filesystem=[string]$v.FileSystem;size=[long]$v.Size}
} catch { $answer=@{ok=$false;error=$_.Exception.Message;phase=$phase} }
$json=$answer | ConvertTo-Json -Compress
$bytes=[Text.Encoding]::UTF8.GetBytes($json)
$client=[Net.HttpWebRequest]::Create($resultUrl)
$client.Proxy=$null;$client.Method='POST';$client.ContentType='application/json';$client.Timeout=15000;$client.ContentLength=$bytes.Length
$stream=$client.GetRequestStream();$stream.Write($bytes,0,$bytes.Length);$stream.Dispose()
$response=$client.GetResponse();$response.Dispose()
if(-not $answer.ok){exit 1}
'''


RESTORE = r'''
$ErrorActionPreference='Stop'
function Check-Target {
 $d=Get-Disk -Number $request.number -ErrorAction Stop
 $systemDisk=(Get-Partition -DriveLetter ($env:SystemDrive.Substring(0,1))).DiskNumber
 if($d.BusType -ne 'USB' -or $d.IsBoot -or $d.IsSystem -or $d.Number -eq $systemDisk -or $d.IsOffline -or $d.IsReadOnly){throw 'Unsafe or unavailable disk; stopped'}
 if([string]$d.UniqueId -cne $request.unique_id -or [string]$d.Path -cne $request.path -or [string]$d.SerialNumber -cne $request.serial -or [long]$d.Size -ne $request.size){throw 'USB identity changed; stopped'}
 $parts=@(); if($d.PartitionStyle -ne 'RAW' -and $d.NumberOfPartitions -gt 0) {$parts=@(Get-Partition -DiskNumber $d.Number -ErrorAction Stop)}
 if(@($parts | Where-Object {$_.IsBoot -or $_.IsSystem}).Count -gt 0){throw 'Boot/system partition detected; stopped'}
 $letters=@($parts | Where-Object {$_.DriveLetter} | ForEach-Object {[string]$_.DriveLetter})
 foreach($letter in $protectedLetters) {
  if($letters -contains $letter){throw 'Disk contains HackPilot, its working folder or temporary files; move the app to Windows storage first'}
 }
 foreach($page in @(Get-CimInstance Win32_PageFileUsage -ErrorAction Stop)) {
  if($letters -contains $page.Name.Substring(0,1)){throw 'Disk contains a Windows page file; stopped'}
 }
 return $d
}
$phase='restore access'
try {
 $d=Check-Target
 $parts=@();if($d.NumberOfPartitions -gt 0){$parts=@(Get-Partition -DiskNumber $request.number -ErrorAction Stop)}
 $usable=@($parts | Where-Object { -not $_.IsHidden -and (($_.MbrType -in @(6,11,12,14,7)) -or ([string]$_.GptType -eq '{EBD0A0A2-B9E5-4433-87C0-68B6B72699C7}')) } | ForEach-Object {
  $p=$_;$v=$p | Get-Volume -ErrorAction SilentlyContinue
  if($v -and $v.FileSystem -in @('FAT32','NTFS','exFAT')){$p}
 })
 if($usable.Count -ne 1){throw 'Expected one recognizable data volume. No erase was attempted. If partitions are missing or RAW, do not format if you need to recover files.'}
 $p=$usable[0]
 if(-not $p.DriveLetter){
  $used=@(Get-Volume | Where-Object {$_.DriveLetter} | ForEach-Object {[string]$_.DriveLetter})+@(Get-PSDrive -PSProvider FileSystem | ForEach-Object {$_.Name})
  $letter=@(68..90 | ForEach-Object {[string][char]$_} | Where-Object {$used -notcontains $_} | Select-Object -First 1)
  if($letter.Count -ne 1){throw 'No free drive letter available'}
  $null=Check-Target
  $p | Set-Partition -NewDriveLetter $letter[0] -ErrorAction Stop
 }
 $null=Check-Target
 $v=Get-Partition -DiskNumber $request.number -PartitionNumber $p.PartitionNumber | Get-Volume -ErrorAction Stop
 if(-not $v.DriveLetter -or $v.FileSystem -notin @('FAT32','NTFS','exFAT')){throw 'Volume did not become accessible'}
 if(-not (Test-Path -LiteralPath ([string]$v.DriveLetter+':\') -PathType Container -ErrorAction Stop)){throw 'Volume is still inaccessible; no filesystem changes were attempted'}
 $answer=@{ok=$true;letter=[string]$v.DriveLetter;filesystem=[string]$v.FileSystem;size=[long]$v.Size;restored=$true}
} catch {$answer=@{ok=$false;error=$_.Exception.Message;phase=$phase}}
$json=$answer | ConvertTo-Json -Compress
$bytes=[Text.Encoding]::UTF8.GetBytes($json)
$client=[Net.HttpWebRequest]::Create($resultUrl)
$client.Proxy=$null;$client.Method='POST';$client.ContentType='application/json';$client.Timeout=15000;$client.ContentLength=$bytes.Length
$stream=$client.GetRequestStream();$stream.Write($bytes,0,$bytes.Length);$stream.Dispose()
$response=$client.GetResponse();$response.Dispose()
if(-not $answer.ok){exit 1}
'''


def encoded(script):
    return base64.b64encode(script.encode('utf-16le')).decode('ascii')


def inventory():
    if os.name != 'nt':
        return []
    proc = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded(INVENTORY)],
                          capture_output=True, timeout=40, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if proc.returncode:
        raise RuntimeError('USB detection failed: ' + proc.stderr.decode(errors='replace')[-500:])
    data = json.loads(proc.stdout.decode('utf-8-sig'))
    if not isinstance(data, list) or any(not isinstance(row, dict) for row in data):
        raise RuntimeError('Invalid USB inventory')
    return data


def validate_disk(disk):
    if (not isinstance(disk, dict) or type(disk.get('number')) is not int or disk['number'] < 0 or
        type(disk.get('size')) is not int or not 2*1024**3 <= disk['size'] <= 2*1024**4 or
        not isinstance(disk.get('unique_id'), str) or not 1 <= len(disk['unique_id'].strip()) <= 1024 or
        not isinstance(disk.get('path'), str) or not 1 <= len(disk['path'].strip()) <= 1024 or
        not isinstance(disk.get('serial', ''), str) or len(disk.get('serial', '')) > 256 or disk.get('reason')):
        raise RuntimeError('USB is not eligible for formatting')
    return {key: disk.get(key, '') for key in ('number', 'unique_id', 'path', 'serial', 'size')}


@contextmanager
def result_channel():
    """Receive elevated results in memory; no elevated-owned temp files."""
    token=secrets.token_urlsafe(32)
    state={'result':None}
    lock=threading.Lock()
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def setup(self):
            super().setup();self.connection.settimeout(10)
        def do_POST(self):
            if self.path != '/'+token or self.headers.get('Host') != f'127.0.0.1:{self.server.server_port}' or self.headers.get('Origin') or self.headers.get('Transfer-Encoding'):
                self.send_error(403);return
            try:
                length=int(self.headers.get('Content-Length','0'))
                if not 1 <= length <= 16384 or self.headers.get_content_type() != 'application/json':
                    self.send_error(400);return
                data=json.loads(self.rfile.read(length))
                if not isinstance(data,dict) or type(data.get('ok')) is not bool:
                    self.send_error(400);return
                with lock:
                    if state['result'] is not None:
                        self.send_error(409);return
                    state['result']=data
                self.send_response(200);self.send_header('Content-Length','0');self.end_headers()
            except (ValueError, OSError, RecursionError):
                self.send_error(400)
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True)
    try:
        thread.start()
        yield SimpleNamespace(url=f'http://127.0.0.1:{server.server_port}/'+token,state=state)
    finally:
        if thread.is_alive():server.shutdown();thread.join(timeout=12)
        server.server_close()


def format_disk(expected, filesystem='FAT32', style='MBR', restore=False):
    if os.name != 'nt':
        raise RuntimeError('USB operations require Windows')
    if filesystem not in ('FAT32','NTFS','exFAT') or style not in ('MBR','GPT'):
        raise ValueError('Unsupported filesystem or partition scheme')
    identity=validate_disk(expected)
    matches=[d for d in inventory() if d.get('number') == identity['number']]
    if len(matches)!=1 or validate_disk(matches[0]) != identity:
        raise RuntimeError('USB changed since confirmation; refresh and choose it again')
    request={**identity,'filesystem':filesystem,'style':style}
    with result_channel() as channel:
        payload=base64.b64encode(json.dumps(request).encode('utf-8')).decode('ascii')
        protected=sorted({p.drive[:1].upper() for p in (Path(sys.executable),Path.cwd(),Path(tempfile.gettempdir()),Path(__file__).resolve()) if p.drive})
        protected_payload=base64.b64encode(json.dumps(protected).encode('utf-8')).decode('ascii')
        script=("$request=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+payload+"')) | ConvertFrom-Json\n"
                "$resultUrl='"+channel.url+"'\n"
                "$protectedLetters=@([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+protected_payload+"')) | ConvertFrom-Json)\n"+(RESTORE if restore else FORMAT))
        launch=("$ErrorActionPreference='Stop';try {$p=Start-Process powershell.exe -Verb RunAs -PassThru -Wait "
                "-ArgumentList @('-NoProfile','-NonInteractive','-EncodedCommand','"+encoded(script)+"');exit $p.ExitCode} catch {exit 1223}")
        if len(launch)>28000:raise RuntimeError('Disk identity is too large for a safe Windows command')
        proc=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',launch],capture_output=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        response=channel.state['result']
        if response is None:
            if proc.returncode==1223:
                raise RuntimeError('Administrator prompt was cancelled or could not start; no success was reported.')
            raise RuntimeError('USB tool exited without a status report. The disk may have changed. Refresh physical USB disks and try Restore access before considering another erase.')
        if proc.returncode or response.get('ok') is not True:
            raise RuntimeError('USB operation stopped at '+str(response.get('phase','unknown stage'))+': '+str(response.get('error','Unknown failure'))+'. Refresh the USB list. No automatic erase retry was attempted.')
        letter=response.get('letter')
        if (response.get('filesystem') not in ('FAT32','NTFS','exFAT') or (not restore and response['filesystem']!=filesystem) or
            not isinstance(letter,str) or len(letter)!=1 or not letter.isascii() or not letter.isalpha()):
            raise RuntimeError('USB volume verification failed; refresh and inspect the drive')
        return response
