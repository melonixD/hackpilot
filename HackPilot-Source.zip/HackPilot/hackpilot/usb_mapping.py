"""In-app Windows USB mapping using the USBToolBox discovery backend.

USBToolBox/tool is MIT licensed; HackPilot downloads a pinned commit on demand
and executes its usbdump enumerator in a short-lived local worker. No separate
USBToolBox UI is launched. Unobserved physical sockets are NEVER guessed to be
verified: users discover them by plugging a device and pressing Refresh.
"""
import copy
import hashlib
import json
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import sys
import tempfile
import uuid

from .engine import request_json, download, safe_unzip, _atomic_json
from .efi import efi_tree_fingerprint

REPO = 'USBToolBox/tool'
REQUIRED = ('LICENSE', 'Scripts/usbdump.py', 'Scripts/shared.py',
            'Scripts/_build.py', 'resources/usbdump.exe', 'resources/Info.plist')
TOOL_LIMIT = 120 * 1024 * 1024
PORT_TYPES = {0:'USB 2 Type-A',1:'Mini-AB',2:'ExpressCard',3:'USB 3 Type-A',
              4:'USB 3 Type-B',5:'Micro-B',6:'Micro-AB',7:'USB 3 Power-B',
              8:'USB-C (USB 2)',9:'USB-C (switch)',10:'USB-C (no switch)',255:'Internal'}


def _hash_file(path):
    result=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            result.update(chunk)
    return result.hexdigest()


def _backend_digest(root):
    root=Path(root)
    if not root.is_dir() or root.is_symlink() or bool(getattr(root.lstat(), 'st_file_attributes', 0) & 0x400):
        raise RuntimeError('USB mapping backend root is missing or linked')
    files=[]
    total_size = 0
    for rel in REQUIRED:
        p=root/rel
        if not p.is_file() or p.is_symlink():
            raise RuntimeError('USB mapping backend is incomplete or linked: '+rel)
    for item in root.rglob('*'):
        relative = item.relative_to(root)
        # Python can import a root-level file when this directory is inserted
        # into sys.path. Ignoring that file is a cache-bypass vulnerability.
        if item.is_symlink() or bool(getattr(item.lstat(), 'st_file_attributes', 0) & 0x400):
            raise RuntimeError('Linked USB mapping resources are forbidden')
        if '__pycache__' in relative.parts or item.suffix.lower() in ('.pyc', '.pyo'):
            raise RuntimeError('Unexpected executable bytecode in USB mapping resources')
        if not (item.is_file() or item.is_dir()):
            raise RuntimeError('Unexpected USB mapping resource type')
        if item.is_file():
            # This check runs during UI status refresh. Do not allow an
            # unexpectedly huge modified cache to hang the interface.
            total_size += item.stat().st_size
            if total_size > 200 * 1024 * 1024 or len(files) >= 20_000:
                raise RuntimeError('USB scanner cache exceeds safety bounds')
            # Include all regular files: newly added importable modules and
            # non-Python data files must invalidate the pinned cache too.
            files.append(item)
    result=hashlib.sha256()
    for p in sorted(set(files),key=lambda p:p.relative_to(root).as_posix()):
        result.update(p.relative_to(root).as_posix().encode()+b'\0')
        result.update(bytes.fromhex(_hash_file(p)))
    return result.hexdigest()


def backend_verified(cache):
    cache=Path(cache)
    try:
        manifest = cache/'usbtoolbox-manifest.json'
        if manifest.is_symlink() or not manifest.is_file() or not 2 <= manifest.stat().st_size <= 128 * 1024:
            return False
        info=json.loads(manifest.read_text(encoding='utf-8'))
        return (info.get('repository')==REPO and
                isinstance(info.get('commit'),str) and len(info['commit'])==40 and
                info.get('tree_sha256')==_backend_digest(cache/'usbtoolbox'))
    except (OSError, ValueError, TypeError, RuntimeError):
        return False


def install_backend(cache):
    """Transactionally install a pinned USBToolBox revision; never run mutable code."""
    cache=Path(cache)
    if backend_verified(cache):
        return {'root':str(cache/'usbtoolbox'),'cached':True}
    cache.mkdir(parents=True,exist_ok=True)
    commit=request_json('https://api.github.com/repos/USBToolBox/tool/commits/master').get('sha','')
    if not isinstance(commit,str) or len(commit)!=40 or any(x not in '0123456789abcdef' for x in commit.lower()):
        raise RuntimeError('Could not verify USBToolBox upstream commit')
    with tempfile.TemporaryDirectory(prefix='usbtoolbox-',dir=cache) as tmp:
        tmp=Path(tmp)
        archive=tmp/'source.zip'
        download(f'https://github.com/USBToolBox/tool/archive/{commit}.zip',archive,max_bytes=TOOL_LIMIT)
        unpack=tmp/'unpacked'
        safe_unzip(archive,unpack)
        candidates=[p for p in unpack.iterdir() if p.is_dir() and (p/'Scripts'/'usbdump.py').is_file()]
        if len(candidates)!=1:
            raise RuntimeError('USBToolBox source layout changed')
        staged=candidates[0]
        digest=_backend_digest(staged)
        root=cache/'usbtoolbox'
        manifest=cache/'usbtoolbox-manifest.json'
        old_root=cache/('usbtoolbox-prev-'+uuid.uuid4().hex)
        if manifest.is_symlink() or (manifest.is_file() and manifest.stat().st_size > 128 * 1024):
            raise RuntimeError('USBToolBox manifest is unsafe; repair its cache before updating')
        old_manifest=manifest.read_bytes() if manifest.is_file() else None
        if root.is_symlink():
            raise RuntimeError('Linked USB mapping backend must be repaired before updating')
        moved=False
        committed=False
        if root.exists():
            root.rename(old_root)
            moved=True
        try:
            staged.rename(root)
            _atomic_json(manifest,{'repository':REPO,'commit':commit,'tree_sha256':digest})
            committed=True
        except Exception as original_error:
            recovery_errors=[]
            try:
                if root.exists(): shutil.rmtree(root)
            except OSError as exc:
                recovery_errors.append('cannot remove failed new backend: '+str(exc))
            try:
                if moved and old_root.exists():
                    if root.exists():
                        raise RuntimeError('failed new backend still occupies destination')
                    old_root.rename(root)
            except (OSError, RuntimeError) as exc:
                recovery_errors.append('cannot restore previous backend: '+str(exc))
            try:
                if old_manifest is None:
                    manifest.unlink(missing_ok=True)
                else:
                    # Commit manifest restoration atomically as well.
                    fd, prior_tmp=tempfile.mkstemp(prefix='usbtoolbox-restore-', dir=str(cache))
                    try:
                        with os.fdopen(fd,'wb') as stream:
                            stream.write(old_manifest)
                            stream.flush()
                            os.fsync(stream.fileno())
                        os.replace(prior_tmp,manifest)
                    finally:
                        Path(prior_tmp).unlink(missing_ok=True)
            except OSError as exc:
                recovery_errors.append('cannot restore previous manifest: '+str(exc))
            if recovery_errors:
                raise RuntimeError('USB mapping update failed; backup retained at '+str(old_root)+
                                   '. Manual cache repair required: '+ '; '.join(recovery_errors)) from original_error
            raise
        finally:
            # Never destroy the *only* remaining previous backend after an
            # unsuccessful rollback. A failed cleanup after success leaves an
            # old, inert folder rather than endangering the active backend.
            if committed and old_root.exists():
                shutil.rmtree(old_root,ignore_errors=True)
    return {'root':str(root),'cached':False}


def discover_controllers(cache,timeout=70):
    if os.name!='nt':
        raise RuntimeError('Live USB port discovery requires Windows 10/11')
    if not backend_verified(cache):
        raise RuntimeError('USB mapping engine is missing or modified; install it again')
    script=Path(__file__).with_name('usb_mapping_worker.py')
    backend=str(Path(cache)/'usbtoolbox')
    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
    frozen=getattr(sys,'frozen',False)
    if frozen:
        # Avoid relying on stdout of a --windowed PyInstaller executable.
        with tempfile.TemporaryDirectory(prefix='hackpilot-usbscan-') as tmp:
            result_path=Path(tmp)/'result.json'
            errors_path=Path(tmp)/'errors.log'
            command=[sys.executable,'--worker-usb-map',backend,str(result_path),str(errors_path)]
            try:
                result=subprocess.run(command,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                                      timeout=timeout,env=env)
            except subprocess.TimeoutExpired as e:
                raise RuntimeError('USB port scan timed out. Disconnect problematic USB devices and retry.') from e
            if result.returncode:
                detail = ''
                if errors_path.is_file() and not errors_path.is_symlink():
                    with errors_path.open('rb') as log:
                        log.seek(0, os.SEEK_END)
                        log.seek(max(0, log.tell() - 2400))
                        detail = log.read(2400).decode('utf-8', errors='replace')[-550:]
                raise RuntimeError('USB scan failed: '+detail)
            if not result_path.is_file() or result_path.stat().st_size > 8*1024*1024:
                raise RuntimeError('USB port scan produced no valid bounded result')
            raw=result_path.read_text(encoding='utf-8')
    else:
        command=[sys.executable,'-u',str(script),backend]
        try:
            result=subprocess.run(command,capture_output=True,timeout=timeout,
                                  text=True,encoding='utf-8',errors='replace',env=env)
        except subprocess.TimeoutExpired as e:
            raise RuntimeError('USB port scan timed out. Disconnect problematic USB devices and retry.') from e
        if result.returncode:
            raise RuntimeError('USB scan failed: '+result.stderr.strip()[-550:])
        raw=result.stdout
    try:
        data=json.loads(raw)
        if not isinstance(data,list):raise ValueError('unexpected scan output')
        return data
    except (TypeError,ValueError) as e:
        raise RuntimeError('USBToolBox returned an invalid port report') from e


def _controller_id(controller):
    ids=controller.get('identifiers',{})
    if not isinstance(ids,dict):return None
    bdf=ids.get('bdf')
    if (isinstance(bdf,list) and len(bdf)==3 and
        all(type(x)==int for x in bdf) and
        0 <= bdf[0] <= 255 and 0 <= bdf[1] <= 31 and 0 <= bdf[2] <= 7):
        return 'bdf:'+':'.join(map(str,bdf))
    # Multiple controllers with the same vendor/device ID cannot be safely
    # distinguished without bus/device/function or unique ACPI information.
    path=ids.get('acpi_path')
    if isinstance(path,str) and path.strip():return 'acpi:'+path.strip()
    pci=ids.get('pci_id')
    if isinstance(pci,list) and len(pci)>=2 and all(isinstance(x,str) for x in pci):
        return 'pci:'+':'.join(pci[:2]).lower()
    return None


def normalize_snapshot(raw):
    """Keep stable controller/port facts, not device serials or raw WMI data."""
    if not isinstance(raw,list) or not raw or len(raw)>64:
        raise ValueError('No usable USB controllers found in Windows scan')
    result=[]
    seen=set()
    for controller in raw:
        if not isinstance(controller,dict):raise ValueError('Malformed USB controller')
        key=_controller_id(controller)
        if not key or key in seen:
            raise RuntimeError('USB controller identity is ambiguous; use a different PC or scan mode')
        seen.add(key)
        ports=controller.get('ports')
        if not isinstance(ports,list) or len(ports)>128:
            raise ValueError('Invalid USB port listing')
        ident=controller.get('identifiers',{})
        safe_ident={k:copy.deepcopy(v) for k,v in ident.items() if k in ('bdf','acpi_path','pci_id')}
        safe={'id':key,'name':str(controller.get('name') or 'USB controller')[:130],
              'hub':str(controller.get('hub_name') or '')[:130],
              'class':int(controller['class']) if type(controller.get('class'))==int else 9999,'identifiers':safe_ident,'ports':[]}
        indexes=set()
        for p in ports:
            if not isinstance(p,dict):raise ValueError('Invalid USB port record')
            index=p.get('index')
            if type(index)!=int or not 1<=index<=255 or index in indexes:
                raise ValueError('Duplicate or invalid USB port index')
            indexes.add(index)
            devices=p.get('devices') or []
            if not isinstance(devices,list):raise ValueError('Malformed USB devices')
            used=bool(devices)
            guessed=p.get('guessed')
            if type(guessed)!=int or guessed not in PORT_TYPES:guessed=None
            speed=p.get('class')
            comp=p.get('companion_info') or {}
            if not isinstance(comp,dict):comp={}
            comp_num=comp.get('port')
            safe['ports'].append({'index':index,'speed':int(speed) if type(speed)==int else 9999,
               'connector':guessed,'selected':used,'seen':used,'active':used,
               'physically_seen':used,
               'devices':[str(x.get('name') or 'USB device')[:90] if isinstance(x,dict) else 'USB device' for x in devices[:8]],
               'companion_hub':str(comp.get('hub') or '')[:130],
               'companion_port':comp_num if type(comp_num)==int and comp_num>0 else None,
               'user_selected':False})
        result.append(safe)
    return {'controllers':result,'ready':False}


def merge_snapshots(previous,current):
    """Retain previously seen ports; refresh connected devices and pair companions."""
    old={c['id']:c for c in (previous or {}).get('controllers',[]) if isinstance(c,dict) and isinstance(c.get('id'),str)}
    result=copy.deepcopy(current)
    for c in result['controllers']:
        # Windows can reuse the same BDF after a USB dock/controller swap.
        # A matching string ID is insufficient to trust historical physical
        # port observations. Preserve choices only for the same controller.
        historical=old.get(c['id'])
        if historical and (historical.get('identifiers') != c.get('identifiers') or
                           historical.get('class') != c.get('class') or
                           historical.get('hub') != c.get('hub')):
            historical=None
        previous_ports={p['index']:p for p in (historical or {}).get('ports',[])
                        if isinstance(p,dict) and type(p.get('index'))==int}
        for p in c['ports']:
            prior=previous_ports.get(p['index'])
            # A reused port index with a different USB speed is not the same
            # logical macOS port; don't mark it as physically verified.
            if prior and prior.get('speed') != p.get('speed'):
                prior=None
            if prior:
                p['seen']=p['seen'] or bool(prior.get('seen'))
                # 'seen' also includes inferred USB2/USB3 companions; only
                # a port actually hosting a detected device is physically
                # observed. Preserve this distinction across unplug/refresh.
                p['physically_seen']=(p.get('physically_seen', bool(p.get('active') and p.get('seen'))) or
                    bool(prior.get('physically_seen',
                                   bool(prior.get('active') and prior.get('seen')))))
                p['user_selected']=bool(prior.get('user_selected'))
                p['selected']=bool(prior.get('selected')) if p['user_selected'] else p['seen']
                if p['user_selected'] or p['connector'] is None:
                    if prior.get('connector') in PORT_TYPES:p['connector']=prior['connector']
            else:
                p['selected']=p['seen']
    # A hub name is not necessarily unique across different PCI controllers.
    # Never take the last matching hub from a dict: that can mark a completely
    # different physical controller's port as observed/selected.
    by_hub={}
    for controller in result['controllers']:
        if controller['hub']:
            by_hub.setdefault(controller['hub'],[]).append(controller)
    for c in result['controllers']:
        for p in c['ports']:
            hub_name=p.get('companion_hub')
            if not hub_name or not p.get('companion_port'):
                continue
            candidates=by_hub.get(hub_name,[])
            # When multiple hubs share the same name, prefer an explicitly
            # local companion; otherwise the match is ambiguous and is ignored.
            other = c if c in candidates else (candidates[0] if len(candidates)==1 else None)
            if other is None:
                continue
            matching=next((x for x in other['ports'] if x['index']==p['companion_port']),None)
            if matching is p:
                continue
            if matching and (p['seen'] or matching['seen']):
                p['seen']=matching['seen']=True
                if not p['user_selected']:p['selected']=True
                if not matching['user_selected']:matching['selected']=True
    return result


def update_port_selection(snapshot, controller_id, index, enabled, connector=None):
    if type(enabled)!=bool or type(index)!=int:
        raise ValueError('Invalid USB port choice')
    result=copy.deepcopy(snapshot)
    controller=next((c for c in result.get('controllers',[]) if c.get('id')==controller_id),None)
    if controller is None:raise ValueError('Unknown USB controller')
    port=next((p for p in controller['ports'] if p.get('index')==index),None)
    if port is None:raise ValueError('Unknown USB port')
    if connector is not None and (type(connector)!=int or connector not in PORT_TYPES):
        raise ValueError('Unknown USB connector type')
    port['selected']=enabled
    port['user_selected']=True
    if connector is not None:port['connector']=connector
    return result


def _matching_key(controller,ids,unique_acpi=False):
    # USBToolBox prefers a unique ACPI controller name when possible, as
    # firmware PCI BDFs may be renumbered between Windows and macOS.
    path=ids.get('acpi_path')
    if unique_acpi and isinstance(path,str) and path.strip():
        return {'IONameMatch':path.strip().rpartition('.')[2]}
    bdf=ids.get('bdf')
    if (isinstance(bdf,list) and len(bdf)==3 and
        all(type(x)==int for x in bdf) and
        0 <= bdf[0] <= 255 and 0 <= bdf[1] <= 31 and 0 <= bdf[2] <= 7):
        return {'IOPropertyMatch':{'pcidebug':':'.join(map(str,bdf))}}
    pci=ids.get('pci_id')
    if isinstance(pci,list) and len(pci)>=2:
        try:
            primary='0x'+f'{int(pci[1],16):04X}{int(pci[0],16):04X}'
        except ValueError as e:raise RuntimeError('Invalid PCI ID in USB map') from e
        return {'IOPCIPrimaryMatch':primary}
    raise RuntimeError('USB controller cannot be matched in macOS')


def generate_utbmap(snapshot, output_dir):
    """Generate an actual codeless UTBMap.kext using USBToolBox's matching format."""
    controllers=snapshot.get('controllers') if isinstance(snapshot,dict) else None
    if not valid_saved_snapshot(snapshot):
        raise RuntimeError('USB mapping scan is missing or malformed; scan ports again')
    if len({c['id'] for c in controllers})!=len(controllers):
        raise RuntimeError('Duplicate USB controllers')
    personalities={}
    acpi_names=[str(c.get('identifiers',{}).get('acpi_path','')).rpartition('.')[2] for c in controllers]
    selected_total=0
    for n,c in enumerate(controllers):
        ports=[p for p in c['ports'] if p.get('selected') is True]
        if not ports:continue
        if len(ports)>15:
            raise RuntimeError(f'{c["name"]}: {len(ports)} selected USB ports exceed the 15-port macOS limit')
        if c['class'] not in (0,16,32,48):
            raise RuntimeError(f'{c["name"]}: USB controller class is unknown; refresh the scan')
        if any(p['speed'] not in (1,2,3,4) for p in ports):
            raise RuntimeError(f'{c["name"]}: selected port speed is unknown; rescan this port')
        if len({p['index'] for p in ports})!=len(ports):
            raise RuntimeError('Duplicate USB port indices')
        chosen_ports={}
        counts={'HS':0,'SS':0,'PRT':0}
        highest=0
        for p in sorted(ports,key=lambda x:x['index']):
            connector=p.get('connector')
            if type(connector)!=int or connector not in PORT_TYPES:
                raise RuntimeError(f'USB port {p["index"]} needs a connector type')
            speed=p.get('speed')
            prefix=('SS' if c['class']==48 and speed in (3,4) else
                    'HS' if c['class']==48 and speed==2 else 'PRT')
            counts[prefix]+=1
            name=f'{prefix}{counts[prefix]:0{4-len(prefix)}d}'
            highest=max(highest,p['index'])
            chosen_ports[name]={'port':p['index'].to_bytes(4,'little'),'UsbConnector':connector}
            selected_total+=1
        personality={'CFBundleIdentifier':'com.dhinakg.USBToolBox.kext','IOClass':'USBToolBox',
                     'IOProviderClass':'IOPCIDevice','IOMatchCategory':'USBToolBox',
                     **_matching_key(c,c['identifiers'],unique_acpi=(bool(acpi_names[n]) and acpi_names.count(acpi_names[n])==1)),
                     'IOProviderMergeProperties':{'ports':chosen_ports,'port-count':highest.to_bytes(4,'little')}}
        personalities[f'HP_USB_{n:02d}']=personality
    if not selected_total:raise RuntimeError('No ports were selected')
    metadata={'CFBundleDevelopmentRegion':'English','CFBundleIdentifier':'com.dhinakg.USBToolBox.map',
              'CFBundleInfoDictionaryVersion':'6.0','CFBundleName':'UTBMap',
              'CFBundlePackageType':'KEXT','CFBundleShortVersionString':'1.1',
              'CFBundleVersion':'1.1','OSBundleRequired':'Root',
              'OSBundleLibraries':{'com.dhinakg.USBToolBox.kext':'1.0.0'},
              'IOKitPersonalities':personalities}
    output=Path(output_dir)
    output.mkdir(parents=True,exist_ok=True)
    staged=Path(tempfile.mkdtemp(prefix='map-',dir=output))
    try:
        bundle=staged/'UTBMap.kext'/'Contents'
        bundle.mkdir(parents=True)
        with (bundle/'Info.plist').open('wb') as out:plistlib.dump(metadata,out,sort_keys=True)
        target=output/'UTBMap.kext'
        previous=output/('UTBMap-old-'+uuid.uuid4().hex)
        if target.exists():target.rename(previous)
        try:(staged/'UTBMap.kext').rename(target)
        except Exception:
            if previous.exists():previous.rename(target)
            raise
        if previous.exists():shutil.rmtree(previous)
    finally:shutil.rmtree(staged,ignore_errors=True)
    return {'path':str(output/'UTBMap.kext'), 'ports':selected_total,'controllers':len(personalities),
            'sha256':_hash_file(output/'UTBMap.kext'/'Contents'/'Info.plist'),
            'unseen':sum(1 for c in controllers for p in c['ports'] if p['selected'] and not p.get('physically_seen', False))}


def inject_efi_map(stage, map_bundle):
    """Replace UTBDefault in a *staged* EFI, never in a verified live build."""
    oc=Path(stage)/'EFI'/'OC'
    original=oc/'config.plist'
    source=Path(map_bundle)
    if source.name!='UTBMap.kext' or not source.is_dir() or source.is_symlink():
        raise RuntimeError('Invalid USB map bundle')
    map_plist=source/'Contents'/'Info.plist'
    if not map_plist.is_file() or map_plist.is_symlink():raise RuntimeError('USB map Info.plist missing')
    # UTBMap is a codeless bundle. Reject extra files/links instead of
    # accidentally copying unexpected executable content into an EFI.
    for item in source.rglob('*'):
        if item.is_symlink() or item.is_file() and item!=map_plist:
            raise RuntimeError('Unexpected file or link in USB map bundle')
        if not (item.is_file() or item.is_dir()):
            raise RuntimeError('Unsupported USB map bundle entry')
    if not _saved_map_bundle_valid(source):
        raise RuntimeError('USB map bundle contains invalid files or metadata')
    with map_plist.open('rb') as f:map_data=plistlib.load(f)
    if map_data.get('CFBundleIdentifier')!='com.dhinakg.USBToolBox.map' or not map_data.get('IOKitPersonalities'):
        raise RuntimeError('USB map content is not valid')
    with original.open('rb') as f:cfg=plistlib.load(f)
    rows=cfg['Kernel']['Add']
    if not isinstance(rows,list):raise RuntimeError('Kernel/Add is not a list')
    core_index=next((i for i,r in enumerate(rows) if isinstance(r,dict) and
                    r.get('Enabled') and r.get('BundlePath','').casefold()=='usbtoolbox.kext'),None)
    if core_index is None or not (oc/'Kexts'/'USBToolBox.kext').is_dir():
        raise RuntimeError('EFI lacks enabled USBToolBox.kext; cannot use UTBMap')
    forbidden=('usbmap.kext','utbmap.kext')
    if any(isinstance(r,dict) and r.get('Enabled') and r.get('BundlePath','').casefold() in forbidden for r in rows):
        raise RuntimeError('An existing USB map is already enabled')
    rows[:]=[r for r in rows if not (isinstance(r,dict) and r.get('BundlePath','').casefold()=='utbdefault.kext')]
    core_index=next(i for i,r in enumerate(rows) if isinstance(r,dict) and r.get('BundlePath','').casefold()=='usbtoolbox.kext')
    rows.insert(core_index+1,{'Arch':'x86_64','BundlePath':'UTBMap.kext','Comment':'HackPilot USB map',
            'Enabled':True,'ExecutablePath':'','MinKernel':'','MaxKernel':'',
            'PlistPath':'Contents/Info.plist'})
    # The 15-port limit patch should not survive installing a proper map.
    # It can cause boot problems on Big Sur 11.3+ and is unnecessary here.
    quirks = cfg.get('Kernel', {}).get('Quirks', {})
    if isinstance(quirks, dict) and quirks.get('XhciPortLimit') is True:
        quirks['XhciPortLimit'] = False
    dest=oc/'Kexts'/'UTBMap.kext'
    if dest.exists():raise RuntimeError('USB map target already exists')
    shutil.copytree(source,dest,symlinks=False)
    old=oc/'Kexts'/'UTBDefault.kext'
    if old.exists():shutil.rmtree(old)
    tmp=original.with_suffix('.tmp')
    try:
        with tmp.open('wb') as f:plistlib.dump(cfg,f,sort_keys=False)
        os.replace(tmp,original)
    finally:tmp.unlink(missing_ok=True)
    return {'sha256':_hash_file(dest/'Contents'/'Info.plist')}


def valid_saved_snapshot(snapshot):
    """Treat cached USB discovery data as untrusted; reject malformed records.

    A broken ports.json must never crash the local GUI or trigger an unsafe
    map generation. This checks shape and bounds but not actual USB wiring.
    """
    if not isinstance(snapshot,dict) or not isinstance(snapshot.get('controllers'),list):
        return False
    controllers=snapshot['controllers']
    if not 1 <= len(controllers) <= 64:
        return False
    seen=set()
    for c in controllers:
        if not isinstance(c,dict) or not isinstance(c.get('id'),str) or not c['id'] or c['id'] in seen:
            return False
        seen.add(c['id'])
        if not isinstance(c.get('identifiers'),dict) or type(c.get('class'))!=int:
            return False
        ports=c.get('ports')
        if not isinstance(ports,list) or len(ports)>128:
            return False
        indexes=set()
        for port in ports:
            if not isinstance(port,dict) or type(port.get('index'))!=int or not 1 <= port['index'] <= 255 or port['index'] in indexes:
                return False
            indexes.add(port['index'])
            if type(port.get('selected'))!=bool or type(port.get('seen'))!=bool or type(port.get('speed'))!=int:
                return False
            if 'physically_seen' in port and type(port['physically_seen'])!=bool:
                return False
            if port.get('connector') is not None and (type(port['connector'])!=int or port['connector'] not in PORT_TYPES):
                return False
            if not isinstance(port.get('devices',[]),list):
                return False
    return True


def _saved_map_bundle_valid(bundle):
    bundle=Path(bundle)
    if not bundle.is_dir() or bundle.is_symlink():
        return False
    allowed_files={'Contents/Info.plist'}
    allowed_dirs={'Contents'}
    try:
        entries=list(bundle.rglob('*'))
        if len(entries)!=2:
            return False
        for entry in entries:
            if entry.is_symlink() or bool(getattr(entry.lstat(),'st_file_attributes',0) & 0x400):
                return False
            relative=entry.relative_to(bundle).as_posix()
            if entry.is_file() and relative not in allowed_files:
                return False
            if entry.is_dir() and relative not in allowed_dirs:
                return False
            if not (entry.is_file() or entry.is_dir()):
                return False
        file=bundle/'Contents'/'Info.plist'
        if not file.is_file() or file.stat().st_size > 1_000_000:
            return False
        with file.open('rb') as stream:
            data=plistlib.load(stream)
        return (isinstance(data,dict) and
                data.get('CFBundleIdentifier')=='com.dhinakg.USBToolBox.map' and
                data.get('CFBundlePackageType')=='KEXT' and
                isinstance(data.get('IOKitPersonalities'),dict) and
                bool(data['IOKitPersonalities']) and
                not data.get('CFBundleExecutable'))
    except (OSError,TypeError,ValueError,plistlib.InvalidFileException):
        return False


def map_is_ready(folder, snapshot):
    """Verify persisted user choices and generated map before EFI integration."""
    if not valid_saved_snapshot(snapshot):
        return False
    folder=Path(folder)
    manifest=folder/'usb-map-manifest.json'
    bundle=folder/'UTBMap.kext'
    plist=bundle/'Contents'/'Info.plist'
    try:
        if (not manifest.is_file() or manifest.is_symlink() or
            bool(getattr(manifest.lstat(), 'st_file_attributes', 0) & 0x400) or
            not _saved_map_bundle_valid(bundle)):
            return False
        if manifest.stat().st_size < 2 or manifest.stat().st_size > 128 * 1024:
            return False
        with manifest.open('rb') as source:
            raw = source.read(128 * 1024 + 1)
        if len(raw) > 128 * 1024:
            return False
        info=json.loads(raw.decode('utf-8'))
        if not isinstance(info, dict):
            return False
        return (info.get('sha256')==_hash_file(plist) and
                info.get('selection_sha256')==selection_hash(snapshot) and
                info.get('source')=='USBToolBox/tool')
    except (OSError,TypeError,ValueError):
        return False


def selection_hash(snapshot):
    """Bind choices to topology and types, not fluctuating device names."""
    rows=[]
    for c in snapshot.get('controllers',[]):
        rows.append([c['id'],c.get('class'),c.get('identifiers'),
            [[p['index'],p.get('speed'),p.get('selected'),p.get('connector')]
             for p in sorted(c['ports'],key=lambda p:p['index'])]])
    rows.sort(key=lambda x:x[0])
    return hashlib.sha256(json.dumps(rows,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def controller_topology(snapshot):
    """Bind the map to *which controllers*, not merely their Windows BDFs."""
    return sorted((c['id'],str(c.get('class')),
                   json.dumps(c.get('identifiers',{}),sort_keys=True),
                   tuple(sorted((p['index'],p.get('speed')) for p in c['ports'])))
                  for c in snapshot.get('controllers',[]))
