"""Apple recovery via OpenCore macrecovery; staged so failed downloads stay isolated."""
from pathlib import Path
import hashlib
import os
import json
import re
import struct
import plistlib
import shutil
import subprocess
import sys
import tempfile
from .engine import download, _atomic_json

# Pinned to a reviewed OpenCorePkg commit. Never execute a helper from a
# moving branch: upstream changes can break recovery or alter executed code.
MACRECOVERY_COMMIT = 'ebea824880706ac9faa8ee45604245de62be658b'
MACRECOVERY_BLOB_SHA1 = '5d53d2179bcea0f916bd6305d92db334b2e5737e'
MACRECOVERY_SHA256 = '3023a9b4ca79a5255d93c00f25ab5df37e6f938b729b797d9ecea56184b17aff'
URL = ('https://raw.githubusercontent.com/acidanthera/OpenCorePkg/'
       + MACRECOVERY_COMMIT + '/Utilities/macrecovery/macrecovery.py')
MIN_RECOVERY_DISK_FREE = 2 * 1024 * 1024 * 1024
MAX_RECOVERY_DOWNLOAD_ATTEMPTS = 2

# Version-appropriate representative recovery profiles published by OpenCorePkg.
# These select Apple's recovery download channel; they are NOT SMBIOS IDs and
# need not match the board model configured for the installed Hackintosh.
RECOVERY_PROFILES = {
    '20': ('Mac-2BD1B31983FE1663', 'default'),  # Big Sur
    '21': ('Mac-E43C1C25D4880AD6', 'default'),  # Monterey
    '22': ('Mac-B4831CEBD52A0C4C', 'default'),  # Ventura
    '23': ('Mac-827FAC58A8FDFA22', 'default'),  # Sonoma
    '24': ('Mac-7BA5B2D9E42DDD94', 'default'),  # Sequoia
    '25': ('Mac-CFF7D910A743CAAF', 'latest'), # Tahoe
}



def _git_blob_sha1(path):
    """Compare downloaded helper bytes to the GitHub source blob at our pin."""
    path = Path(path)
    with path.open('rb') as source:
        size = path.stat().st_size
        if size < 4096 or size > 2 * 1024 * 1024:
            return None
        hasher = hashlib.sha1(b'blob ' + str(size).encode('ascii') + b'\0')
        for block in iter(lambda: source.read(1024 * 1024), b''):
            hasher.update(block)
    return hasher.hexdigest()


def _recovery_disk_preflight(folder):
    """Avoid beginning a large download when disk capacity is obviously unsafe."""
    path = Path(folder)
    path.mkdir(parents=True, exist_ok=True)
    if path.is_symlink() or not path.is_dir():
        raise RuntimeError('Recovery destination must be a local, non-linked directory')
    available = shutil.disk_usage(path).free
    if available < MIN_RECOVERY_DISK_FREE:
        raise RuntimeError('Not enough free disk space for Apple Recovery; free at least 2 GiB and retry')


def _recovery_error_tail(log_path):
    """Provide actionable context without exposing unbounded external output."""
    try:
        with Path(log_path).open('rb') as source:
            source.seek(max(0, source.seek(0, os.SEEK_END) - 1400))
            tail = source.read().decode('utf-8', errors='replace')
        return ' '.join(tail.split())[-550:]
    except OSError:
        return ''


def profile_for_darwin(target):
    # A corrupted/editable build manifest must not select a recovery image by
    # matching only the prefix of an otherwise invalid kernel version.
    if not isinstance(target, str) or not re.fullmatch(r'[0-9]{2}(?:\.[0-9]{1,3}){0,2}', target):
        raise RuntimeError('Invalid Darwin release in build manifest')
    major = target.split('.', 1)[0]
    if major not in RECOVERY_PROFILES:
        raise RuntimeError('No documented Apple recovery download profile for Darwin ' + major)
    board, os_type = RECOVERY_PROFILES[major]
    return {'board_id': board, 'os_type': os_type, 'darwin_major': major}



def select_recovery_pair(folder):
    """Accept exactly one regular Apple recovery pair below a trusted stage."""
    folder = Path(folder)
    if folder.is_symlink() or not folder.is_dir():
        raise RuntimeError('Recovery download directory is missing or linked')
    matches = []
    for stem in ('BaseSystem', 'RecoveryImage'):
        for dmg in folder.rglob(stem + '.dmg'):
            chunklist = dmg.with_name(stem + '.chunklist')
            # Reject redirection through a symlinked intermediate directory.
            if (dmg.is_symlink() or chunklist.is_symlink() or
                any((folder / part).is_symlink() for part in dmg.relative_to(folder).parents)):
                raise RuntimeError('Recovery files are linked; download rejected')
            if (dmg.is_file() and chunklist.is_file() and
                dmg.stat().st_size > 0 and chunklist.stat().st_size > 0):
                matches.append((dmg, chunklist))
    if len(matches) != 1:
        raise RuntimeError('Expected exactly one matching Apple recovery DMG and chunklist')
    return matches[0]


def board_id_from_efi(build_dir):
    """Use a board ID only if OpenCore itself includes it; never guess one."""
    config=Path(build_dir)/'EFI'/'OC'/'config.plist'
    if not config.is_file() or config.is_symlink():
        return None
    try:
        # This reader is also used outside full EFI validation. Keep its
        # memory bound even if the file grows after the initial size check.
        limit = 8 * 1024 * 1024
        if not 1 <= config.stat().st_size <= limit:
            return None
        with config.open('rb') as stream:
            raw = stream.read(limit + 1)
        if len(raw) > limit:
            return None
        plist=plistlib.loads(raw)
        platform=plist.get('PlatformInfo',{}) if isinstance(plist,dict) else {}
        if not isinstance(platform,dict):return None
        for section,key in (('DataHub','BoardProduct'),('PlatformNVRAM','BID')):
            source=platform.get(section,{})
            board=source.get(key) if isinstance(source,dict) else None
            if isinstance(board,str) and re.fullmatch(r'Mac-[0-9A-Fa-f]{8,20}',board):
                return board
    except (OSError, ValueError, TypeError, RecursionError, plistlib.InvalidFileException):
        pass
    return None



# Apple RSA-2048 public key used by OpenCorePkg macrecovery for the CNKL
# recovery chunklist. Signature verification is separate from locally recorded
# SHA-256 checks, which anyone able to edit a cache could otherwise rewrite.
APPLE_RECOVERY_RSA_N = int(
    'C3E748CAD9CD384329E10E25A91E43E1A762FF529ADE578C935BDDF9B13F2179'
    'D4855E6FC89E9E29CA12517D17DFA1EDCE0BEBF0EA7B461FFE61D94E2BDF72C1'
    '96F89ACD3536B644064014DAE25A15DB6BB0852ECBD120916318D1CCDEA3C84C'
    '92ED743FC176D0BACA920D3FCF3158AFF731F88CE0623182A8ED67E650515F75'
    '745909F07D415F55FC15A35654D118C55A462D37A3ACDA08612F3F3F6571761E'
    'FCCBCC299AEE99B3A4FD6212CCFFF5EF37A2C334E871191F7E1C31960E010A54'
    'E86FA3F62E6D6905E1CD57732410A3EB0C6B4DEFDABE9F59BF1618758C751CD5'
    '6CEF851D1C0EAA1C558E37AC108DA9089863D20E2E7E4BF475EC66FE6B3EFDCF', 16)
_CHUNK_HEADER = struct.Struct('<4sIBBBxQQQ')
_CHUNK_ENTRY = struct.Struct('<I32s')
_SHA256_DER = bytes.fromhex('3031300d060960864801650304020105000420')


def verify_apple_recovery_assets(dmg_path, chunklist_path):
    """Verify Apple's signed CNKL index AND each DMG chunk independently.

    This rejects locally re-hashed or synthetically forged recovery files.
    Uses a public key only; it neither contacts Apple nor executes the DMG.
    Returns False for damaged, unsigned, truncated, or oversized inputs.
    """
    dmg_path, chunklist_path = Path(dmg_path), Path(chunklist_path)
    try:
        if (not dmg_path.is_file() or not chunklist_path.is_file() or
            dmg_path.is_symlink() or chunklist_path.is_symlink()):
            return False
        actual_dmg_size = dmg_path.stat().st_size
        actual_list_size = chunklist_path.stat().st_size
        if actual_dmg_size < 1 or not 292 <= actual_list_size <= 16 * 1024 * 1024:
            return False
        with chunklist_path.open('rb') as stream:
            head = stream.read(_CHUNK_HEADER.size)
            if len(head) != _CHUNK_HEADER.size:
                return False
            magic, head_size, version, chunk_method, sig_method, count, offset, signature_offset = _CHUNK_HEADER.unpack(head)
            if (magic != b'CNKL' or head_size != _CHUNK_HEADER.size or
                version != 1 or chunk_method != 1 or sig_method != 1 or
                count < 1 or count > 400_000 or offset != _CHUNK_HEADER.size or
                signature_offset != offset + count * _CHUNK_ENTRY.size or
                actual_list_size != signature_offset + 256):
                return False
            signed_hash = hashlib.sha256(head)
            # No assumption that the list can fit in memory: stream descriptors.
            pieces = []
            declared_bytes = 0
            for _ in range(count):
                raw = stream.read(_CHUNK_ENTRY.size)
                if len(raw) != _CHUNK_ENTRY.size:
                    return False
                signed_hash.update(raw)
                length, digest = _CHUNK_ENTRY.unpack(raw)
                if length <= 0 or declared_bytes + length > actual_dmg_size:
                    return False
                declared_bytes += length
                pieces.append((length, digest))
            if declared_bytes != actual_dmg_size:
                return False
            signature = stream.read(256)
            if len(signature) != 256 or stream.read(1):
                return False
        # PKCS#1 v1.5 SHA-256 DigestInfo, as checked by OpenCore macrecovery.
        encoded = (b'\x00\x01' + b'\xff' * (256 - 3 - len(_SHA256_DER) - 32) +
                   b'\x00' + _SHA256_DER + signed_hash.digest())
        decoded = pow(int.from_bytes(signature, 'little'), 65537, APPLE_RECOVERY_RSA_N)
        if decoded != int.from_bytes(encoded, 'big'):
            return False
        with dmg_path.open('rb') as image:
            for size, expected in pieces:
                chunk_hash = hashlib.sha256()
                remaining = size
                while remaining:
                    block = image.read(min(remaining, 1024 * 1024))
                    if not block:
                        return False
                    remaining -= len(block)
                    chunk_hash.update(block)
                if chunk_hash.digest() != expected:
                    return False
            if image.read(1):
                return False
        return True
    except (OSError, ValueError, OverflowError, struct.error):
        return False


def verify_recovery(folder, board_id=None, darwin=None, os_type=None,
                    require_apple_signature=False):
    """Trust only a complete, hash-matched Apple recovery pair for a known board ID.

    Local hashes detect changed files; optional signed CNKL verification
    additionally authenticates the chunklist and DMG using Apple's public key.
    """
    folder = Path(folder)
    info_path = folder.parent / 'recovery-info.json'
    if folder.is_symlink() or not folder.is_dir() or not info_path.is_file() or info_path.is_symlink():
        return False
    try:
        if not 2 <= info_path.stat().st_size <= 512 * 1024:
            return False
        # Only the two signed/referenced recovery assets belong on the USB.
        # Previously, extra untracked files were copied to USB despite never
        # having been included in the verification manifest.
        entries = list(folder.iterdir())
        if {entry.name for entry in entries} != {'BaseSystem.dmg', 'BaseSystem.chunklist'} or len(entries) != 2:
            return False
        if any(not entry.is_file() or entry.is_symlink() for entry in entries):
            return False
        with info_path.open('rb') as stream:
            raw = stream.read(512 * 1024 + 1)
        if len(raw) > 512 * 1024:
            return False
        metadata = json.loads(raw.decode('utf-8'))
        if not isinstance(metadata, dict) or not re.fullmatch(r'Mac-[0-9A-Fa-f]{8,20}', metadata.get('board_id') or ''):
            return False
        if board_id and metadata['board_id'].casefold() != board_id.casefold():
            return False
        if darwin and metadata.get('darwin_major') != str(darwin).split('.', 1)[0]:
            return False
        if os_type and metadata.get('os_type') != os_type:
            return False
        files = metadata.get('files')
        if not isinstance(files, dict) or set(files) != {'BaseSystem.dmg', 'BaseSystem.chunklist'}:
            return False
        for name, expected in files.items():
            file = folder/name
            if file.is_symlink() or not file.is_file() or not isinstance(expected, dict):
                return False
            if file.stat().st_size < 1 or file.stat().st_size != expected.get('size'):
                return False
            with file.open('rb') as stream:
                actual = hashlib.file_digest(stream, 'sha256').hexdigest()
            if actual != expected.get('sha256'):
                return False
        if require_apple_signature and not verify_apple_recovery_assets(
                folder/'BaseSystem.dmg', folder/'BaseSystem.chunklist'):
            return False
        return True
    except (ValueError, TypeError, OSError, RecursionError):
        return False


def _recovery_metadata(folder, board_id, darwin=None, os_type='default'):
    files = {}
    for name in ('BaseSystem.dmg', 'BaseSystem.chunklist'):
        file = Path(folder)/name
        with file.open('rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        files[name] = {'size':file.stat().st_size, 'sha256':digest}
    info = {'board_id':board_id, 'files':files, 'format':2, 'os_type':os_type}
    if darwin: info['darwin_major'] = str(darwin).split('.', 1)[0]
    return info

def download_recovery(cache, output, board_id, os_type="default", darwin=None):
    if not re.fullmatch(r'Mac-[0-9A-Fa-f]{8,20}', board_id or ''):
        raise ValueError('Enter a valid Mac board ID')
    if os_type not in ('default', 'latest'):
        raise ValueError('Unsupported Apple recovery channel')
    # A previously validated recovery image is already sufficient to prepare
    # the USB. Don't require an unnecessary network request just to refresh
    # the helper script; this also makes retries reliable during outages.
    out = Path(output)
    destination = out/'com.apple.recovery.boot'
    if verify_recovery(destination, board_id, darwin, os_type, require_apple_signature=True):
        return {'folder':str(destination), 'cached':True, 'note':'Previously verified recovery reused'}
    _recovery_disk_preflight(out)
    tool = Path(cache) / 'macrecovery.py'
    manifest = Path(cache) / 'macrecovery-manifest.json'
    trusted = False
    # A previously cached helper is trustworthy when its actual bytes match
    # the audited SHA-256 + Git blob, even if an older HackPilot wrote the
    # manifest with a moving-branch URL. Upgrade only the metadata; don't
    # strand offline users by insisting on another GitHub download.
    if tool.is_file() and not tool.is_symlink():
        try:
            with tool.open('rb') as file:
                actual = hashlib.file_digest(file, 'sha256').hexdigest()
            trusted = (actual == MACRECOVERY_SHA256 and
                       _git_blob_sha1(tool) == MACRECOVERY_BLOB_SHA1)
            if trusted:
                # A damaged metadata JSON file does not invalidate independently
                # authenticated helper bytes. Recover the metadata locally rather
                # than requiring GitHub access on an otherwise working install.
                current = None
                if manifest.is_file() and not manifest.is_symlink() and 2 <= manifest.stat().st_size < 64 * 1024:
                    try:
                        current = json.loads(manifest.read_text(encoding='utf-8'))
                    except (ValueError, UnicodeError):
                        current = None
                if (not isinstance(current, dict) or current.get('sha256') != actual or
                    current.get('url') != URL or current.get('commit') != MACRECOVERY_COMMIT):
                    _atomic_json(manifest, {'sha256': actual, 'bytes': tool.stat().st_size,
                                            'url': URL, 'commit': MACRECOVERY_COMMIT})
        except (ValueError, TypeError, OSError):
            trusted = False
    if not trusted:
        # Installing a tool and its integrity manifest is a two-part update.
        # Never strand a good, cached worker with the wrong checksum after a
        # failed metadata write or an interrupted download.
        incoming = tool.with_name(tool.name + '.incoming')
        previous = tool.with_name(tool.name + '.rollback')
        if previous.exists() or incoming.exists():
            raise RuntimeError('Interrupted macrecovery tool update detected; repair the cached tool first')
        # Never read an arbitrary-size or linked cache manifest while making
        # an update backup. A hostile/broken file must not cause an OOM or let
        # the rollback read from an unrelated location.
        if manifest.is_symlink():
            raise RuntimeError('Linked macrecovery manifest requires manual cache repair')
        if manifest.is_file() and manifest.stat().st_size > 64 * 1024:
            raise RuntimeError('Oversized macrecovery manifest requires manual cache repair')
        old_manifest = manifest.read_bytes() if manifest.is_file() else None
        had_tool = tool.is_file()
        try:
            info = download(URL, incoming, 2 * 1024 * 1024)
            # The download returns a digest; independently bind it to the staged file.
            with incoming.open('rb') as stream:
                digest = hashlib.file_digest(stream,'sha256').hexdigest()
            if not digest or digest != info.get('sha256') or digest != MACRECOVERY_SHA256:
                raise RuntimeError('Downloaded macrecovery script checksum mismatch')
            if _git_blob_sha1(incoming) != MACRECOVERY_BLOB_SHA1:
                raise RuntimeError('Downloaded macrecovery script does not match the pinned upstream revision')
            info = {**info, 'commit': MACRECOVERY_COMMIT}
            if had_tool:
                os.replace(tool, previous)
            try:
                os.replace(incoming, tool)
                _atomic_json(manifest, info)
            except Exception:
                tool.unlink(missing_ok=True)
                if had_tool and previous.exists():
                    os.replace(previous, tool)
                if old_manifest is None:
                    manifest.unlink(missing_ok=True)
                else:
                    restore = manifest.with_name(manifest.name + '.restore')
                    with restore.open('wb') as output:
                        output.write(old_manifest)
                        output.flush();os.fsync(output.fileno())
                    os.replace(restore,manifest)
                raise
        finally:
            incoming.unlink(missing_ok=True)
            if tool.is_file() and previous.is_file():
                previous.unlink()
    out = Path(output)
    out.mkdir(parents=True, exist_ok=True)
    destination = out/'com.apple.recovery.boot'
    if verify_recovery(destination, board_id, darwin, os_type, require_apple_signature=True):
        return {'folder':str(destination), 'cached':True, 'note':'Previously verified recovery reused'}
    staged = Path(tempfile.mkdtemp(prefix='macrecovery-', dir=str(out)))
    log_path = staged / 'macrecovery.log'
    try:
        if getattr(sys, 'frozen', False):
            args = [sys.executable, '--worker-recovery', str(tool), '-b', board_id,
                    '-m', '00000000000000000', 'download']
        else:
            args = [sys.executable, str(tool), '-b', board_id,
                    '-m', '00000000000000000', 'download']
        if os_type == 'latest':
            args[-1:-1] = ['-os', 'latest']
        if getattr(sys, 'frozen', False):
            args.extend(['--worker-log', str(log_path)])
        last_problem = ''
        for attempt_number in range(1, MAX_RECOVERY_DOWNLOAD_ATTEMPTS + 1):
            _recovery_disk_preflight(out)
            attempt_dir = staged / ('attempt-' + str(attempt_number))
            attempt_dir.mkdir()
            with log_path.open('a', encoding='utf-8') as log:
                log.write(f'\nApple recovery download attempt {attempt_number}/{MAX_RECOVERY_DOWNLOAD_ATTEMPTS}\n')
                log.flush()
                try:
                    proc = subprocess.run(args, cwd=str(attempt_dir), stdout=log,
                                          stderr=subprocess.STDOUT, timeout=1800)
                    if proc.returncode:
                        last_problem = f'macrecovery exited with code {proc.returncode}'
                        shutil.rmtree(attempt_dir, ignore_errors=True)
                        continue
                except (OSError, subprocess.TimeoutExpired) as exc:
                    last_problem = f'macrecovery did not complete: {type(exc).__name__}'
                    shutil.rmtree(attempt_dir, ignore_errors=True)
                    continue
            try:
                dmg, chunks = select_recovery_pair(attempt_dir)
            except (OSError, RuntimeError) as exc:
                last_problem = str(exc)
                shutil.rmtree(attempt_dir, ignore_errors=True)
                continue
            if not verify_apple_recovery_assets(dmg, chunks):
                last_problem = 'Apple recovery failed signed chunklist/DMG verification'
                shutil.rmtree(attempt_dir, ignore_errors=True)
                continue
            break
        else:
            detail = _recovery_error_tail(log_path)
            raise RuntimeError('Apple recovery download failed after ' +
                               str(MAX_RECOVERY_DOWNLOAD_ATTEMPTS) + ' attempts: ' +
                               last_problem + ('. Log: ' + detail if detail else '') +
                               '. Check internet access to Apple Recovery and retry.')
        dest_staged = staged / 'com.apple.recovery.boot'
        dest_staged.mkdir(exist_ok=True)
        for source, filename in ((dmg, 'BaseSystem.dmg'), (chunks, 'BaseSystem.chunklist')):
            target = dest_staged / filename
            if source != target:
                shutil.move(str(source), str(target))
        dest = out / 'com.apple.recovery.boot'
        # Hash BEFORE changing the current recovery, so a failed metadata write
        # cannot leave a newly installed image falsely associated with old data.
        new_metadata = _recovery_metadata(dest_staged, board_id, darwin, os_type)
        metadata_file = out / 'recovery-info.json'
        # Avoid loading untrusted, unbounded metadata into memory during an
        # update. A linked or absurdly large manifest requires explicit repair.
        if metadata_file.is_symlink():
            raise RuntimeError('Linked recovery metadata requires manual repair')
        if metadata_file.is_file() and metadata_file.stat().st_size > 512 * 1024:
            raise RuntimeError('Oversized recovery metadata requires manual repair')
        old_metadata = metadata_file.read_bytes() if metadata_file.is_file() else None
        previous = None
        if dest.exists():
            previous = out / ('recovery-backup-' + __import__('datetime').datetime.now().strftime('%Y%m%d-%H%M%S%f'))
            dest.rename(previous)
        try:
            dest_staged.rename(dest)
            _atomic_json(metadata_file, new_metadata)
            # Verify the *published* pair, not only the temporary download.
            # If storage changes a byte or a manifest write is incomplete,
            # restore the previous working files and metadata below.
            if not verify_recovery(dest, board_id, darwin, os_type,
                                   require_apple_signature=True):
                raise RuntimeError('Published Apple recovery failed read-back verification')
        except Exception:
            # Restore the previous *pair* of recovery files and metadata.
            # Do not call a half-written image ready after a failed commit.
            if dest.exists():
                failed = out / ('recovery-incomplete-' + __import__('datetime').datetime.now().strftime('%Y%m%d-%H%M%S%f'))
                dest.rename(failed)
            if previous and previous.exists():
                previous.rename(dest)
            if old_metadata is None:
                metadata_file.unlink(missing_ok=True)
            else:
                fd, staged_meta = tempfile.mkstemp(prefix='recovery-restore-', dir=str(out))
                try:
                    with os.fdopen(fd, 'wb') as stream:
                        stream.write(old_metadata)
                        stream.flush(); os.fsync(stream.fileno())
                    os.replace(staged_meta, metadata_file)
                finally:
                    Path(staged_meta).unlink(missing_ok=True)
            raise
        # The previous image is only needed until the newly published pair
        # passes signature and on-disk checks. Keeping every old multi-gigabyte
        # image permanently eventually exhausts the download volume.
        stale_backup = False
        if previous and previous.exists():
            try:
                shutil.rmtree(previous)
            except OSError:
                # Do not delete the verified current recovery if removal of an
                # obsolete backup fails. Tell the user about the space leak.
                stale_backup = True
        try:
            shutil.copy2(log_path, out / 'macrecovery.log')
        except OSError:
            pass
        return {'folder':str(dest), 'files':[(p.name,p.stat().st_size) for p in dest.iterdir() if p.is_file()],
                'note': ('Recovery verified; an old recovery backup needs cleanup to free disk space'
                         if stale_backup else 'Recovery downloaded and verified using OpenCore macrecovery')}
    finally:
        if (staged / 'macrecovery.log').is_file():
            try:
                shutil.copy2(staged / 'macrecovery.log', out / 'macrecovery.log')
            except OSError:
                pass
        shutil.rmtree(staged, ignore_errors=True)
