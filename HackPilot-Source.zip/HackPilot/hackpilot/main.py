import argparse
import json
from pathlib import Path
import threading
import webbrowser
import runpy
import sys
import traceback
from contextlib import redirect_stdout, redirect_stderr
from .server import State, create_server

def main():
    # The --windowed PyInstaller build has no guaranteed console/stdout.
    # Workers therefore write explicitly to supplied log/result files rather
    # than assuming a redirected Windows GUI executable can print to a pipe.
    if len(sys.argv) == 3 and sys.argv[1] == '--worker-smoke':
        from .runtime_check import check_runtime
        check_runtime()
        output = Path(sys.argv[2])
        output.write_text('hackpilot-worker-ok\n', encoding='ascii')
        return 0
    if len(sys.argv)>1 and sys.argv[1]=='--worker-adapter':
        from . import upstream_adapter
        args = sys.argv[2:]
        if len(args) >= 2 and args[-2] == '--worker-log':
            logfile = Path(args[-1])
            args = args[:-2]
            with logfile.open('a', encoding='utf-8', buffering=1) as log:
                with redirect_stdout(log), redirect_stderr(log):
                    sys.argv = ['upstream_adapter.py', *args]
                    try:
                        upstream_adapter.main()
                    except BaseException:
                        traceback.print_exc()
                        return 2
            return 0
        sys.argv = ['upstream_adapter.py', *args]
        upstream_adapter.main()
        return 0
    if len(sys.argv)>2 and sys.argv[1]=='--worker-usb-map':
        from . import usb_mapping_worker
        args = sys.argv[2:]
        if len(args) >= 3:
            error_path = Path(args[2])
            with error_path.open('a', encoding='utf-8', buffering=1) as errors:
                with redirect_stderr(errors):
                    sys.argv = ['usb_mapping_worker.py', *args[:2]]
                    try:
                        usb_mapping_worker.main()
                    except BaseException:
                        traceback.print_exc()
                        return 2
            return 0
        sys.argv = ['usb_mapping_worker.py', *args]
        usb_mapping_worker.main()
        return 0
    if len(sys.argv)>2 and sys.argv[1]=='--worker-recovery':
        script=sys.argv[2]
        args=sys.argv[3:]
        if len(args) >= 2 and args[-2] == '--worker-log':
            log_path = Path(args[-1]);args=args[:-2]
            with log_path.open('a', encoding='utf-8', buffering=1) as log:
                with redirect_stdout(log), redirect_stderr(log):
                    sys.argv = [script, *args]
                    try:
                        runpy.run_path(script, run_name='__main__')
                    except SystemExit as error:
                        # Preserve macrecovery's own success/failure exit code.
                        return error.code if isinstance(error.code, int) else (0 if error.code is None else 2)
                    except BaseException:
                        traceback.print_exc()
                        return 2
            return 0
        sys.argv=[script,*args]
        runpy.run_path(script,run_name='__main__')
        return 0
    p=argparse.ArgumentParser(description='HackPilot, local Windows EFI assistant')
    p.add_argument('--demo',action='store_true',help='Enable the clearly-labelled synthetic test report')
    p.add_argument('--self-test',action='store_true',help='Check bundled resources and exit (no network or disk writes)')
    p.add_argument('--version',action='version',version='HackPilot 1.21-usb-formatter')
    p.add_argument('--browser',action='store_true',help='Use default browser instead of embedded native window')
    args=p.parse_args()
    if args.self_test:
        from .server import STATIC
        from . import efi, engine, usb, guided, diagnostics
        required = [STATIC/'index.html',STATIC/'app.js',STATIC/'app.css',
                    Path(__file__).with_name('windows_scan.ps1'),
                    Path(__file__).with_name('usb_list.ps1')]
        missing = [str(item) for item in required if not item.is_file()]
        try:
            print(json.dumps({'version':'1.21-usb-formatter','ok':not missing,'missing':missing}))
        except (AttributeError, OSError, TypeError):
            # Windows --windowed executables may not have an attached stdout.
            pass
        return 1 if missing else 0
    server=create_server(State(demo=args.demo))
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    url=f'http://127.0.0.1:{server.server_port}'
    try:
        if not args.browser:
            try:
                import webview
                webview.create_window('HackPilot',url,width=1200,height=810,min_size=(960,650),background_color='#ffffff')
                webview.start(debug=False)
                return 0
            except Exception as exc:
                # Missing WebView2 or GUI initialization errors are not EFI
                # failures. The same local UI can run in the default browser.
                # --windowed builds may have no stdout/stderr attached.
                try:
                    if sys.stderr:
                        print('Native window unavailable; opening browser: ' + str(exc), file=sys.stderr)
                except (OSError, RuntimeError, ValueError):
                    pass
        if not webbrowser.open(url):
            raise RuntimeError('HackPilot could not open a native window or browser. '
                               'Install Microsoft Edge WebView2 or launch with --browser.')
        try:
            if sys.stdout:
                print('HackPilot running at '+url+'  |  Ctrl+C to close')
        except (OSError, RuntimeError, ValueError):
            pass
        thread.join()
        return 0
    finally:server.shutdown();server.server_close()

if __name__=='__main__':sys.exit(main())
