"""Explicit launcher for the official portable Rufus advanced USB tool."""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from .engine import download
from .usb_format import encoded

URL='https://github.com/pbatard/rufus/releases/download/v4.15/rufus-4.15p.exe'
SHA256='84c8a437f8af89257524478489e5c85f1edf25f761d299e2bcde46ac0afbe106'


def open_rufus(cache):
    if os.name!='nt':raise RuntimeError('Rufus requires Windows')
    root=Path(cache)/'official-rufus-4.15'
    root.mkdir(parents=True,exist_ok=True)
    if root.is_symlink() or getattr(root.lstat(),'st_file_attributes',0)&0x400:
        raise RuntimeError('Rufus cache is linked; repair the app cache')
    exe=root/'rufus-4.15p.exe'
    if exe.is_symlink():raise RuntimeError('Rufus executable is linked')
    def verified():
        return exe.is_file() and exe.stat().st_size<=16*1024*1024 and hashlib.sha256(exe.read_bytes()).hexdigest()==SHA256
    if not verified():
        download(URL,exe,max_bytes=16*1024*1024)
    if not verified():raise RuntimeError('Official Rufus download checksum did not match; launch refused')
    payload=base64.b64encode(str(exe).encode('utf-8')).decode('ascii')
    prefix="$path=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+payload+"'));"
    check=prefix+"$s=Get-AuthenticodeSignature -LiteralPath $path;@{status=[string]$s.Status;subject=[string]$s.SignerCertificate.Subject} | ConvertTo-Json -Compress"
    result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',encoded(check)],capture_output=True,timeout=45,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    try:signature=json.loads(result.stdout.decode('utf-8-sig'))
    except (ValueError,UnicodeError) as exc:raise RuntimeError('Rufus publisher signature could not be checked') from exc
    if result.returncode or not isinstance(signature,dict) or signature.get('status')!='Valid' or not re.search(r'(?:^|,\s*)CN=Akeo Consulting(?:,|$)',signature.get('subject','')):
        raise RuntimeError('Rufus does not have a valid expected publisher signature; launch refused')
    # Wait until the tool closes, keeping HackPilot disk operations disabled.
    launch=prefix+"try{$p=Start-Process -FilePath $path -Verb RunAs -PassThru -Wait;exit $p.ExitCode}catch{exit 1223}"
    result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',encoded(launch)],capture_output=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if result.returncode:raise RuntimeError('Rufus was cancelled or exited with an error; refresh USB disks before continuing')
    return {'closed':True,'version':'4.15','note':'Refresh USB disks to inspect changes made in Rufus'}
