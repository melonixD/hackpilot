# HackPilot v1.4 — Hardware-bound EFI preflight

This release is a **Windows source preview**, not a hardware-tested Hackintosh installer or compiled EXE. It retains the all-white, bold-black-text GUI and existing one-click FAT32 USB workflow.

## Fixed and improved

1. **Hardware report + ACPI binding:** A deep scan now produces deterministic SHA-256 fingerprints for the exported hardware report and every AML table. The generated EFI's manifest records these fingerprints. Changing an input during or after generation stops the build or USB-copy operation. After restarting, a manual copy of a hardware-bound EFI needs a fresh deep scan instead of assuming the old report belongs to the current PC.
2. **Real DSDT requirement:** The upstream EFI adapter now refuses an ACPI dump with no intact DSDT (correct signature, length, checksum). This prevents publishing generic ACPI patches when the machine-specific DSDT is unavailable.
3. **Upstream schema validation:** The adapter now uses OpCore-Simplify's hardware report validator before applying its compatibility, SMBIOS, kext and ACPI decisions, reducing crashes from missing or malformed chipset data.
4. **Kext dependency versions:** The component audit compares numeric CFBundleVersion values against non-Apple `OSBundleLibraries` minimum requirements. Outdated dependencies are errors; nonstandard version formats are surfaced as warnings rather than guessed.
5. **Offline recovery reuse:** If an Apple recovery cache has already been verified for the requested profile, the app reuses it before attempting to update/download the `macrecovery` helper. An unnecessary network outage can no longer block reuse of valid local recovery files.
6. **Regression suite:** 171 tests (including inherited tests), source compilation, and clean-package checks. The results only establish behavior covered by these checks, not successful macOS boots.

## What it does and doesn't automate

For hardware with a supported UEFI/CPU/GPU and an existing removable FAT32 USB volume, one action attempts: Hardware Sniffer + ACPI dump → upstream compatibility and device selection → OpenCore/kext/SSDT/SMBIOS assembly → independent EFI audit + version-matched `ocvalidate` → Apple internet-recovery download → checksum-verified USB copy. An unexpected selection or unsupported device is a **stop**, not an automatic guess.

**Not automatically solved:** physically checking USB port mapping, unsupported GPUs and Wi-Fi, BIOS settings and BitLocker recovery, first-boot/install steps, sleep/audio/graphics functional testing, or destructive disk formatting/partitioning. An EFI passing static checks is not proof a Hackintosh will boot. Internet recovery needs a working macOS-supported network interface and may deliver a recovery build chosen by Apple's service, not an offline installer of an exact point release.

The Windows GUI `.exe` build workflow is included but **no tested Windows EXE** is present. Hardware scan, USB write and boot success must be validated on physical Windows hardware before public distribution.
