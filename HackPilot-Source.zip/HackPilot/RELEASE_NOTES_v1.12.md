# HackPilot v1.12 — Hardware scan integrity and one-click failure handling

This is a Windows GUI **source preview** only, not a tested native EXE, tested USB installer, or certified hardware configuration.

## Reproducible issues addressed

1. **Hardware scanner checksum:** compare published release asset SHA-256 against downloaded bytes; detect a cached scanner that disagrees with publisher metadata, while supporting a previously verified offline cache.
2. **Stale success after scan failure:** remove prior EFI / USB readiness status before basic or deep rescans.
3. **Silent generic USB mapping:** if a saved USB map, manifest, or port snapshot exists but the entire map is invalid, abort generation.
4. **Unbound manual USB copies:** reject arbitrary/legacy `build-manifest.json` or builds lacking hardware-report/ACPI evidence, with explicit migration instructions.
5. **Mutable generated EFI:** version-2 manifest stores the exact EFI-tree SHA-256. `validate_efi` rejects an EFI whose contents differ, even when OpenCore structure still validates.
6. **Hardware-report size mismatch:** the 32-MiB scanner limit is now consistent with the scan-seal limit.
7. **Malformed metadata:** bound manifest sizes, refuse symlinks, reject malformed recovery metadata and inconsistent Darwin versions.
8. **Recovery integrity:** verify the recovery folder contains only the two expected hashed Apple files; extra files are not silently included in the USB copy.
9. **One-click false success:** a USB copier must explicitly report both EFI and Recovery present/copied before the app marks the USB as fully prepared.
10. **Misleading USB status:** distinguish directly visited physical ports from USB2/USB3 companion ports discovered indirectly. Previously inferred ports no longer count as physically tested.
11. **Windows FAT32 path compatibility:** reject extra superscript COM/LPT reserved device filename cases.
12. **Backwards compatibility:** old saved USB snapshots without the new `physically_seen` field do not crash refresh.

## Verification & limits

- 354 automated tests passed on Linux, including expanded regression scenarios for failures above.
- Python bytecode compilation, `python -m hackpilot.main --self-test`, and `node --check web/app.js` passed.
- The release ZIP was independently extracted and the full test suite rerun.
- **Regeneration required:** EFI builds produced before v1.12 lack the v2 content manifest and must be rebuilt before USB copy.
- **Unverified:** compiled Windows EXE, Windows USBToolBox/hardware scanning, actual Apple Recovery download, physical USB write/recovery, UEFI first boot and macOS installation.
- **No universal success guarantee:** chipset support, USB physical wiring, macOS driver behavior and BIOS settings can still prevent boot or peripheral operation.
