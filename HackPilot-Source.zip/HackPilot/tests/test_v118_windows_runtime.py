"""Runtime failures must preserve usable state and discovered USB topology."""
import json
import sys
from types import SimpleNamespace

import pytest

from hackpilot import server, usb_mapping_worker


def test_failed_thread_start_does_not_leave_app_busy(tmp_path, monkeypatch):
    state = server.State(home=tmp_path)
    def fail_start(self):
        raise RuntimeError('cannot start new thread')
    with monkeypatch.context() as patch:
        patch.setattr(server.threading.Thread, 'start', fail_start)
        with pytest.raises(RuntimeError, match='cannot start'):
            state.start('scan', lambda: pytest.fail('Must not run'))
    assert all(task['state'] == 'error' for task in state.tasks.values())
    state.assert_idle()


def test_wmi_provider_failure_preserves_discovered_usb_topology(tmp_path, monkeypatch):
    root = tmp_path / 'backend'
    (root / 'resources').mkdir(parents=True)
    (root / 'resources' / 'usbdump.exe').write_bytes(b'test only')
    output = tmp_path / 'result.json'
    rows = [{'identifiers': {'instance_id': 'PCI\\TEST'}, 'ports': []}]
    fake_subprocess = SimpleNamespace(run=lambda *args, **kwargs: None)
    original_run = fake_subprocess.run
    backend = SimpleNamespace(subprocess=fake_subprocess, get_controllers=lambda: rows)
    monkeypatch.setitem(sys.modules, 'Scripts', SimpleNamespace(usbdump=backend))
    def fail_wmi():
        raise Exception('WMI COM provider unavailable')
    monkeypatch.setitem(sys.modules, 'wmi', SimpleNamespace(WMI=fail_wmi))
    monkeypatch.setattr(usb_mapping_worker, 'os', SimpleNamespace(name='nt', chdir=lambda _: None, replace=__import__('os').replace))
    monkeypatch.setattr(sys, 'argv', ['worker', str(root), str(output)])
    monkeypatch.setattr(sys, 'path', list(sys.path))
    usb_mapping_worker.main()
    assert json.loads(output.read_text()) == rows
    assert fake_subprocess.run is original_run
