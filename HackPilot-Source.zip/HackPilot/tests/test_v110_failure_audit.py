"""v1.10: checks behavior previously hidden by successful USB copy tests."""
import hashlib
import json
import os
from pathlib import Path

import pytest

from hackpilot import usb, usb_mapping
from hackpilot.efi import efi_tree_fingerprint
from test_quality import make_usb


def make_backend(folder):
    root = folder / 'usbtoolbox'
    for required in usb_mapping.REQUIRED:
        target = root / required
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(b'trusted test data')
    return root


def test_usbtoolbox_root_executable_is_part_of_cache_integrity(tmp_path):
    root = make_backend(tmp_path)
    original = usb_mapping._backend_digest(root)
    (tmp_path/'usbtoolbox-manifest.json').write_text(json.dumps({
        'repository':usb_mapping.REPO, 'commit':'a'*40, 'tree_sha256':original}))
    assert usb_mapping.backend_verified(tmp_path)
    # A new root module can shadow other Python modules when the worker adds
    # USBToolBox's root directory to sys.path.
    (root/'untracked_module.py').write_text('raise RuntimeError("unexpected executable")')
    assert not usb_mapping.backend_verified(tmp_path)
    assert usb_mapping._backend_digest(root) != original


def test_usbtoolbox_root_bytecode_is_rejected(tmp_path):
    root = make_backend(tmp_path)
    (root/'__pycache__').mkdir()
    (root/'__pycache__'/'json.cpython-312.pyc').write_bytes(b'unknown bytecode')
    with pytest.raises(RuntimeError,match='bytecode'):
        usb_mapping._backend_digest(root)


def test_usbtoolbox_non_python_data_change_invalidates_cache(tmp_path):
    root = make_backend(tmp_path)
    config = root/'resources'/'device-rules.dat'
    config.write_bytes(b'first')
    first = usb_mapping._backend_digest(root)
    config.write_bytes(b'second')
    assert usb_mapping._backend_digest(root) != first


@pytest.mark.skipif(os.name == 'nt', reason='Windows cannot create reserved FAT32 names for this fixture')
@pytest.mark.parametrize('bad_name', ['CON', 'NUL.txt', 'bad?.efi', 'driver:stream'])
def test_unreferenced_invalid_efi_filename_rejected(tmp_path,bad_name):
    oc = tmp_path/'EFI'/'OC'
    oc.mkdir(parents=True)
    (oc/'config.plist').write_bytes(b'valid-looking')
    (oc/bad_name).write_bytes(b'unreferenced content')
    with pytest.raises(RuntimeError,match='filename unsupported on FAT32'):
        efi_tree_fingerprint(tmp_path/'EFI')


def test_reused_recovery_is_bound_into_receipt(tmp_path,monkeypatch):
    drive, build, recovery = make_usb(tmp_path,monkeypatch,recovery=True)
    usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups',recovery)
    (build/'EFI'/'OC'/'OpenCore.efi').write_bytes(b'new-build')
    expected = usb.efi_tree_fingerprint(recovery)
    captured = []
    original = usb.write_receipt
    def track(file,record):
        captured.append(dict(record))
        return original(file,record)
    monkeypatch.setattr(usb,'write_receipt',track)
    result = usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups',recovery)
    assert result['recovery_present'] and not result['copied_recovery']
    assert any(r['recovery_fingerprint']==expected for r in captured)
    assert (drive/'com.apple.recovery.boot'/'BaseSystem.dmg').read_bytes()==b'dmg'


def test_changed_reused_recovery_fails_commit_and_rolls_back_efi(tmp_path,monkeypatch):
    drive, build, recovery = make_usb(tmp_path,monkeypatch,recovery=True)
    usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups',recovery)
    original_efi=(drive/'EFI'/'OC'/'OpenCore.efi').read_bytes()
    (build/'EFI'/'OC'/'OpenCore.efi').write_bytes(b'new-build')
    original_rename = Path.rename
    tampered = {'done':False}
    def change_existing_recovery_at_commit(self,target):
        # Fault injection after preflight and staging but during commit.
        if self.name=='EFI.hackpilot-incoming' and not tampered['done']:
            tampered['done']=True
            (drive/'com.apple.recovery.boot'/'BaseSystem.dmg').write_bytes(b'corrupt-during-copy')
        return original_rename(self,target)
    monkeypatch.setattr(Path,'rename',change_existing_recovery_at_commit)
    with pytest.raises(RuntimeError,match='recovery verification after commit failed'):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups',recovery)
    assert tampered['done']
    assert (drive/'EFI'/'OC'/'OpenCore.efi').read_bytes() == original_efi
    assert usb.pending_receipts(tmp_path/'backups'/'transactions') == []


def make_saved_map_state(tmp_path,monkeypatch):
    from hackpilot.server import State
    from hackpilot import server
    from test_v15_usb_mapping import raw_device, snapshot
    state=State(home=tmp_path/'state')
    data=snapshot()
    state.mapping_dir.mkdir(parents=True,exist_ok=True)
    (state.mapping_dir/'ports.json').write_text(json.dumps(data))
    result=usb_mapping.generate_utbmap(data,state.mapping_dir)
    (state.mapping_dir/'usb-map-manifest.json').write_text(json.dumps({
        'source':usb_mapping.REPO,'sha256':result['sha256'],
        'selection_sha256':usb_mapping.selection_hash(data)}))
    assert usb_mapping.map_is_ready(state.mapping_dir,data)
    monkeypatch.setattr(server,'backend_verified',lambda *_:True)
    monkeypatch.setattr(server,'discover_controllers',lambda *_:raw_device())
    return state,data


def test_usb_map_update_manifest_write_failure_keeps_prior_map(tmp_path,monkeypatch):
    from hackpilot import engine
    state,data=make_saved_map_state(tmp_path,monkeypatch)
    saved_info=(state.mapping_dir/'UTBMap.kext'/'Contents'/'Info.plist').read_bytes()
    saved_manifest=(state.mapping_dir/'usb-map-manifest.json').read_bytes()
    original=engine._atomic_json
    def fail_manifest_write(path,payload):
        if Path(path).name=='usb-map-manifest.json':
            raise OSError('disk full while staging USB map manifest')
        return original(path,payload)
    monkeypatch.setattr(engine,'_atomic_json',fail_manifest_write)
    with pytest.raises(OSError,match='disk full'):
        state.generate_usb_map()
    assert (state.mapping_dir/'UTBMap.kext'/'Contents'/'Info.plist').read_bytes()==saved_info
    assert (state.mapping_dir/'usb-map-manifest.json').read_bytes()==saved_manifest
    assert usb_mapping.map_is_ready(state.mapping_dir,data)


def test_usb_map_second_publish_rename_failure_restores_old_pair(tmp_path,monkeypatch):
    state,data=make_saved_map_state(tmp_path,monkeypatch)
    saved_info=(state.mapping_dir/'UTBMap.kext'/'Contents'/'Info.plist').read_bytes()
    saved_manifest=(state.mapping_dir/'usb-map-manifest.json').read_bytes()
    original=Path.rename
    def fail_second_publish(self,target):
        if (self.name=='usb-map-manifest.json' and
            self.parent.name.startswith('hp-map-stage-')):
            raise OSError('simulated second rename failure')
        return original(self,target)
    monkeypatch.setattr(Path,'rename',fail_second_publish)
    with pytest.raises(OSError,match='second rename failure'):
        state.generate_usb_map()
    assert (state.mapping_dir/'UTBMap.kext'/'Contents'/'Info.plist').read_bytes()==saved_info
    assert (state.mapping_dir/'usb-map-manifest.json').read_bytes()==saved_manifest
    assert usb_mapping.map_is_ready(state.mapping_dir,data)
    assert not list(state.mapping_dir.parent.glob('hp-map-rollback-*'))


def test_usb_map_success_cleans_old_backup_folder(tmp_path,monkeypatch):
    state,data=make_saved_map_state(tmp_path,monkeypatch)
    result=state.generate_usb_map()
    assert result['status']['map_ready']
    assert Path(result['map']['path'])==(state.mapping_dir/'UTBMap.kext')
    assert not list(state.mapping_dir.parent.glob('hp-map-rollback-*'))


@pytest.mark.skipif(os.name == 'nt', reason='Windows symlink creation may require developer mode')
def test_usbtoolbox_linked_root_is_not_an_installation(tmp_path):
    original=make_backend(tmp_path/'upstream')
    link=tmp_path/'linked-tool'
    link.symlink_to(original,target_is_directory=True)
    with pytest.raises(RuntimeError,match='linked'):
        usb_mapping._backend_digest(link)


@pytest.mark.skipif(os.name == 'nt', reason='Windows symlink creation may require developer mode')
def test_opcore_linked_root_is_not_an_installation(tmp_path):
    from hackpilot.engine import engine_tree_hash
    source=tmp_path/'source'
    (source/'Scripts').mkdir(parents=True)
    (source/'OpCore-Simplify.py').write_text('print("fixture")')
    (source/'LICENSE').write_text('BSD test fixture')
    (source/'Scripts'/'sample.py').write_text('thing = 1')
    link=tmp_path/'linked-engine'
    link.symlink_to(source,target_is_directory=True)
    with pytest.raises(RuntimeError,match='linked'):
        engine_tree_hash(link)
