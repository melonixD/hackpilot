from pathlib import Path
from types import SimpleNamespace
import pytest
from hackpilot import diagnostics, scan_seal, server


def test_status_survives_nested_usb_mapping_record(tmp_path):
    state = server.State(home=tmp_path)
    (state.mapping_dir / 'ports.json').write_text('[' * 10000 + '0' + ']' * 10000)
    assert state.status()['usb_mapping']['map_ready'] is False


def test_status_survives_scan_changed_to_nested_json(tmp_path):
    state = server.State(home=tmp_path)
    report = tmp_path / 'changed.json'
    report.write_text('[' * 10000 + '0' + ']' * 10000)
    state.sniffer_file = str(report)
    assert state.status()['device_choices'] == {}


@pytest.mark.parametrize('message,problem', [
    ('Failed to load SSDT-EC.aml', 'Missing SSDT or ACPI reference'),
    ('OpenRuntime.efi is missing', 'Missing EFI driver'),
])
def test_diagnostics_recognizes_literal_file_extensions(message, problem):
    result = diagnostics.analyze_log(message)
    assert any(row['problem'] == problem for row in result['findings'])


def test_acpi_entry_limit_stops_enumeration_early(tmp_path, monkeypatch):
    def entries(self, pattern):
        for index in range(scan_seal.MAX_TABLES * 3 + 1):
            yield self / str(index)
        pytest.fail('Must stop consuming tree once limit is exceeded')
    monkeypatch.setattr(Path, 'rglob', entries)
    with pytest.raises(RuntimeError, match='too many entries'):
        scan_seal.require_valid_dsdt(tmp_path)


@pytest.mark.parametrize('kind', ['report', 'directory'])
def test_scan_seal_rejects_windows_reparse_roots(tmp_path, monkeypatch, kind):
    report = tmp_path / 'Report.json'; report.write_text('{}')
    directory = tmp_path / 'ACPI'; directory.mkdir()
    target = report if kind == 'report' else directory
    original = Path.lstat
    def flagged(self, *args, **kwargs):
        result = original(self, *args, **kwargs)
        if self == target:
            return SimpleNamespace(st_mode=result.st_mode, st_file_attributes=0x400)
        return result
    monkeypatch.setattr(Path, 'lstat', flagged)
    with pytest.raises(RuntimeError, match='linked'):
        scan_seal.seal_scan(report, directory)
