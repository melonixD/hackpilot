"""Additional safety, re-use, and restart regressions in HackPilot 0.7."""
import json
import os
import plistlib
import zipfile
from pathlib import Path

import pytest

from hackpilot import usb
from hackpilot.efi import _safe_relative, efi_fingerprint, validate_efi
from hackpilot.server import State
from test_quality import make_usb
from test_regressions import fixture_efi


def test_repeat_usb_copy_does_not_leave_stale_rollback(tmp_path, monkeypatch):
    drive, build, recovery = make_usb(tmp_path, monkeypatch, recovery=True)
    first = usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path/'backups', recovery)
    assert (drive/'EFI'/'OC'/'config.plist').is_file()
    assert not (drive/'EFI.hackpilot-previous').exists()
    assert (drive/'com.apple.recovery.boot'/'BaseSystem.dmg').is_file()
    assert first['backup'] and Path(first['backup']).is_file()
    (build/'EFI'/'OC'/'OpenCore.efi').write_bytes(b'second-build')
    second = usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path/'backups', recovery)
    assert second['copied_efi'] and second['recovery_present']
    assert not second['copied_recovery']  # Recovery already on USB; don't overwrite it.
    assert not (drive/'EFI.hackpilot-previous').exists()
    assert (drive/'EFI'/'OC'/'OpenCore.efi').read_bytes() == b'second-build'
    assert len(list((tmp_path/'backups').glob('*.zip'))) == 2


def test_different_recovery_cannot_overwrite_existing_recovery(tmp_path, monkeypatch):
    drive, build, recovery = make_usb(tmp_path, monkeypatch, recovery=True)
    usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path/'backups', recovery)
    original = (drive/'EFI'/'OC'/'config.plist').read_bytes()
    (recovery/'BaseSystem.dmg').write_bytes(b'changed')
    with pytest.raises(RuntimeError, match='different recovery image'):
        usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path/'backups', recovery)
    assert (drive/'EFI'/'OC'/'config.plist').read_bytes() == original


def test_backup_failure_does_not_modify_existing_efi(tmp_path, monkeypatch):
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    def fail_backup(*args, **kwargs):
        raise RuntimeError('backup corrupt')
    monkeypatch.setattr(usb, '_verified_backup', fail_backup)
    with pytest.raises(RuntimeError, match='backup corrupt'):
        usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path/'backups')
    assert (drive/'EFI'/'OC'/'config.plist').read_bytes() == b'original'
    assert not (drive/'EFI.hackpilot-incoming').exists()


def test_efi_fingerprint_checks_empty_directories(tmp_path):
    build = fixture_efi(tmp_path)
    old = efi_fingerprint(build)
    (build/'EFI'/'OC'/'ACPI').mkdir()
    assert efi_fingerprint(build) != old


@pytest.mark.skipif(os.name == 'nt', reason='NTFS is case-insensitive by default')
def test_efi_fingerprint_blocks_casefold_collisions(tmp_path):
    build = fixture_efi(tmp_path)
    oc = build/'EFI'/'OC'
    (oc/'CaseSensitive.efi').write_bytes(b'first')
    (oc/'casesensitive.efi').write_bytes(b'second')
    with pytest.raises(RuntimeError, match='collision'):
        efi_fingerprint(build)


@pytest.mark.parametrize('path', ['ACPI/../evil.aml','./DSDT.aml','OC//config.plist',
                                   'file.efi.','CON','NUL.txt','COM1.plist',
                                   'bad?.efi','file:stream','\\\\server\\share'])
def test_efi_references_are_fat32_safe(path):
    assert not _safe_relative(path)


def test_validator_rejects_directory_as_driver(tmp_path):
    build = fixture_efi(tmp_path)
    driver = build/'EFI'/'OC'/'Drivers'/'OpenRuntime.efi'
    driver.unlink()
    driver.mkdir()
    result = validate_efi(build)
    assert not result['structural_valid']
    assert any('wrong type' in error for error in result['errors'])


def test_validator_rejects_file_as_kext(tmp_path):
    build = fixture_efi(tmp_path)
    bundle = build/'EFI'/'OC'/'Kexts'/'VirtualSMC.kext'
    import shutil
    shutil.rmtree(bundle)
    bundle.write_bytes(b'not a kext')
    result = validate_efi(build)
    assert not result['structural_valid']
    assert any('wrong type' in error for error in result['errors'])


def test_validator_rejects_empty_bootloader(tmp_path):
    build = fixture_efi(tmp_path)
    (build/'EFI'/'BOOT'/'BOOTx64.efi').write_bytes(b'')
    result = validate_efi(build)
    assert not result['structural_valid']
    assert any('empty' in error for error in result['errors'])


def test_recovery_state_survives_app_restart(tmp_path):
    home = tmp_path/'data'
    recovery = home/'Output'/'Recovery'/'com.apple.recovery.boot'
    recovery.mkdir(parents=True)
    (recovery/'BaseSystem.dmg').write_bytes(b'macOS image')
    (recovery/'BaseSystem.chunklist').write_bytes(b'chunklist')
    s = State(home=home)
    assert s.recovery_dir == str(recovery)
    # Presence is not integrity: no metadata or verified hash exists.
    assert not s.status()['recovery_ready']
    (recovery/'BaseSystem.chunklist').unlink()
    assert not State(home=home).status()['recovery_ready']


def test_fat32_rejects_single_file_above_four_gigabytes(tmp_path):
    source = tmp_path/'source'
    source.mkdir()
    with (source/'too-big.dmg').open('wb') as file:
        file.truncate(4 * 1024**3)
    with pytest.raises(RuntimeError, match='4 GiB'):
        usb._checked_tree(source)


def test_unzip_rejects_duplicate_casefold_names_before_extraction(tmp_path):
    from hackpilot.engine import safe_unzip
    archive = tmp_path/'case.zip'
    with zipfile.ZipFile(archive, 'w') as z:
        z.writestr('source/README.md', 'one')
        z.writestr('source/readme.md', 'two')
    dest=tmp_path/'dest'
    with pytest.raises(ValueError, match='case-colliding'):
        safe_unzip(archive, dest)
    assert not list(dest.rglob('*'))


def test_unzip_rejects_mixed_separator_traversal(tmp_path):
    from hackpilot.engine import safe_unzip
    archive = tmp_path/'bad.zip'
    with zipfile.ZipFile(archive, 'w') as z:
        z.writestr('safe\\..\\..\\outside.txt', 'not safe')
    dest=tmp_path/'dest'
    with pytest.raises(ValueError, match='Unsafe'):
        safe_unzip(archive, dest)
    assert not (tmp_path/'outside.txt').exists()


def test_unzip_rejects_zip_symlink_before_extraction(tmp_path):
    from hackpilot.engine import safe_unzip
    from zipfile import ZipInfo
    archive = tmp_path/'symlink.zip'
    with zipfile.ZipFile(archive,'w') as z:
        z.writestr('regular.txt','okay')
        info=ZipInfo('linked.txt')
        info.create_system=3
        info.external_attr=(0o120777 << 16)
        z.writestr(info,'../outside.txt')
    dest=tmp_path/'dest'
    with pytest.raises(ValueError, match='symlinks'):
        safe_unzip(archive, dest)
    assert not list(dest.rglob('*'))


def test_recovery_marked_not_ready_if_file_disappears_during_session(tmp_path):
    home = tmp_path/'data'
    recovered = home/'Output'/'Recovery'/'com.apple.recovery.boot'
    recovered.mkdir(parents=True)
    (recovered/'BaseSystem.dmg').write_bytes(b'image')
    (recovered/'BaseSystem.chunklist').write_bytes(b'chunk')
    state = State(home=home)
    # Simulate a prior completed verification to test subsequent disappearance.
    state.recovery_verified = True
    assert state.status()['recovery_ready']
    (recovered/'BaseSystem.dmg').write_bytes(b'')
    assert not state.status()['recovery_ready']


def test_metadata_requests_block_non_https():
    from hackpilot.engine import request_json
    with pytest.raises(ValueError, match='HTTPS'):
        request_json('http://example.com/latest.json')
