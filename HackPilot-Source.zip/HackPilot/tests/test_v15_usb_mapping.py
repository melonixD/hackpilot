"""Tests for in-app USBToolBox-backed USB port mapping and EFI injection."""
import json
import plistlib
from pathlib import Path
import pytest
from hackpilot import usb_mapping as m
from hackpilot import server
from test_v12_component_audit import fixture, save_config, write_kext


def raw_device(connected=True):
    return [{
       'name':'Intel USB Controller',
       'identifiers':{'bdf':[0,20,0],'pci_id':['8086','A36D'], 'acpi_path':'\\_SB.PCI0.XHC'},
       'hub_name':'ROOT-HUB-1', 'class':48,
       'ports':[
          {'index':1,'class':2,'guessed':0,'devices':[{'name':'Keyboard'}] if connected else [],
           'companion_info':{'hub':'ROOT-HUB-1','port':2}},
          {'index':2,'class':3,'guessed':3,'devices':[],
           'companion_info':{'hub':'ROOT-HUB-1','port':1}},
          {'index':3,'class':2,'guessed':255,'devices':[{'name':'Bluetooth'}],
           'companion_info':{'hub':None,'port':0}},
          {'index':4,'class':3,'guessed':3,'devices':[],
           'companion_info':{'hub':None,'port':0}},
       ]}]


def snapshot():
    return m.merge_snapshots(None,m.normalize_snapshot(raw_device()))


def test_autoselects_seen_and_companion_but_not_unplugged():
    data=snapshot()
    ports=data['controllers'][0]['ports']
    assert [p['selected'] for p in ports]==[True,True,True,False]
    assert ports[1]['seen'] is True
    assert ports[3]['seen'] is False


def test_snapshot_does_not_store_device_serials():
    raw=raw_device()
    raw[0]['ports'][0]['devices'][0]['serial']='SENSITIVE-SERIAL'
    text=json.dumps(m.normalize_snapshot(raw))
    assert 'SENSITIVE-SERIAL' not in text


def test_port_preferences_survive_refresh():
    data=snapshot()
    data=m.update_port_selection(data,'bdf:0:20:0',4,True,3)
    updated=m.merge_snapshots(data,m.normalize_snapshot(raw_device(connected=False)))
    assert updated['controllers'][0]['ports'][3]['selected'] is True
    assert updated['controllers'][0]['ports'][0]['seen'] is True
    assert updated['controllers'][0]['ports'][0]['selected'] is True


def test_rejects_ambiguous_usb_controllers():
    rows=raw_device()
    rows.append(dict(rows[0]))
    with pytest.raises(RuntimeError,match='ambiguous'):
        m.normalize_snapshot(rows)


def test_rejects_unknown_usb_ports_and_connector_types():
    data=snapshot()
    with pytest.raises(ValueError,match='Unknown USB port'):
        m.update_port_selection(data,'bdf:0:20:0',999,True,3)
    with pytest.raises(ValueError,match='Unknown USB connector'):
        m.update_port_selection(data,'bdf:0:20:0',1,True,999)
    with pytest.raises(ValueError,match='Invalid USB port'):
        m.update_port_selection(data,'bdf:0:20:0',1,'true',3)


def test_utbmap_is_a_valid_plist_with_intel_controller_match(tmp_path):
    data=snapshot()
    result=m.generate_utbmap(data,tmp_path)
    assert result['ports']==3 and result['controllers']==1
    path=tmp_path/'UTBMap.kext'/'Contents'/'Info.plist'
    info=plistlib.loads(path.read_bytes())
    assert info['CFBundleIdentifier']=='com.dhinakg.USBToolBox.map'
    row=next(iter(info['IOKitPersonalities'].values()))
    assert row['IONameMatch']=='XHC'
    assert row['IOProviderMergeProperties']['ports']['HS01']['port']==b'\x01\0\0\0'
    assert row['IOProviderMergeProperties']['ports']['SS01']['UsbConnector']==3
    assert row['IOProviderMergeProperties']['port-count']==b'\x03\0\0\0'


def test_pci_fallback_is_used_without_acpi(tmp_path):
    data=snapshot()
    data['controllers'][0]['identifiers'].pop('acpi_path')
    m.generate_utbmap(data,tmp_path)
    info=plistlib.loads((tmp_path/'UTBMap.kext'/'Contents'/'Info.plist').read_bytes())
    row=next(iter(info['IOKitPersonalities'].values()))
    assert row['IOPropertyMatch']=={'pcidebug':'0:20:0'}


def test_unknown_connector_blocks_kext_generation(tmp_path):
    data=snapshot()
    data['controllers'][0]['ports'][0]['connector']=None
    with pytest.raises(RuntimeError,match='connector type'):
        m.generate_utbmap(data,tmp_path)
    assert not (tmp_path/'UTBMap.kext').exists()


def test_16_ports_per_controller_blocks_generation(tmp_path):
    data=snapshot()
    ports=data['controllers'][0]['ports']
    ports[:]=[dict(ports[0],index=i,selected=True) for i in range(1,17)]
    with pytest.raises(RuntimeError,match='15-port'):
        m.generate_utbmap(data,tmp_path)


def test_usb_map_manifest_binds_user_choices(tmp_path):
    data=snapshot()
    result=m.generate_utbmap(data,tmp_path)
    (tmp_path/'usb-map-manifest.json').write_text(json.dumps({
        'source':m.REPO,'sha256':result['sha256'],
        'selection_sha256':m.selection_hash(data)}))
    assert m.map_is_ready(tmp_path,data)
    changed=m.update_port_selection(data,'bdf:0:20:0',4,True,3)
    assert not m.map_is_ready(tmp_path,changed)
    (tmp_path/'UTBMap.kext'/'Contents'/'Info.plist').write_bytes(b'tampered')
    assert not m.map_is_ready(tmp_path,data)


def test_inject_map_disables_fallback_and_preserves_dependency_order(tmp_path):
    build,cfg=fixture(tmp_path)
    oc=build/'EFI'/'OC'
    cfg['Kernel']['Add'].append(write_kext(oc,'USBToolBox.kext','com.dhinakg.USBToolBox.kext'))
    cfg['Kernel']['Add'].append(write_kext(oc,'UTBDefault.kext','com.dhinakg.USBToolBox.default'))
    save_config(build,cfg)
    path=tmp_path/'maps'
    m.generate_utbmap(snapshot(),path)
    result=m.inject_efi_map(build,path/'UTBMap.kext')
    cfg=plistlib.loads((oc/'config.plist').read_bytes())
    names=[x['BundlePath'] for x in cfg['Kernel']['Add']]
    assert 'UTBDefault.kext' not in names
    assert names.index('UTBMap.kext') == names.index('USBToolBox.kext')+1
    assert not (oc/'Kexts'/'UTBDefault.kext').exists()
    assert (oc/'Kexts'/'UTBMap.kext'/'Contents'/'Info.plist').is_file()
    assert len(result['sha256'])==64


def test_injection_requires_usbtoolbox_parent_kext(tmp_path):
    build,cfg=fixture(tmp_path)
    path=tmp_path/'maps'
    m.generate_utbmap(snapshot(),path)
    before=(build/'EFI'/'OC'/'config.plist').read_bytes()
    with pytest.raises(RuntimeError,match='USBToolBox.kext'):
        m.inject_efi_map(build,path/'UTBMap.kext')
    assert before==(build/'EFI'/'OC'/'config.plist').read_bytes()


def test_state_status_and_port_updates(monkeypatch,tmp_path):
    state=server.State(home=tmp_path/'home')
    from hackpilot.engine import _atomic_json
    _atomic_json(state.mapping_dir/'ports.json',snapshot())
    info=state.usb_mapping_status()
    assert info['selected_ports']==3
    with pytest.raises(ValueError):state.choose_usb_port('not a controller',1,True,3)
    state.choose_usb_port('bdf:0:20:0',4,True,3)
    assert state.usb_mapping_status()['selected_ports']==4


def test_backend_not_automatically_trusted_from_folder_alone(tmp_path):
    (tmp_path/'usbtoolbox').mkdir()
    assert m.backend_verified(tmp_path) is False


def test_controller_topology_changes_detected():
    old=snapshot()
    new=snapshot()
    new['controllers'][0]['ports'].pop()
    assert m.controller_topology(new)!=m.controller_topology(old)


def test_controller_fingerprint_detects_different_pci_device_with_same_bdf():
    old=snapshot()
    new=snapshot()
    new['controllers'][0]['identifiers']['pci_id']=['8086','9999']
    assert m.controller_topology(new)!=m.controller_topology(old)


def test_injection_rejects_unexpected_files_in_codeless_map(tmp_path):
    build,cfg=fixture(tmp_path)
    oc=build/'EFI'/'OC'
    cfg['Kernel']['Add'].append(write_kext(oc,'USBToolBox.kext','com.dhinakg.USBToolBox.kext'))
    save_config(build,cfg)
    folder=tmp_path/'mapping'
    m.generate_utbmap(snapshot(),folder)
    extra=folder/'UTBMap.kext'/'Contents'/'MacOS'
    extra.mkdir()
    (extra/'evil').write_bytes(b'code')
    with pytest.raises(RuntimeError,match='Unexpected file'):
        m.inject_efi_map(build,folder/'UTBMap.kext')


def test_backend_install_cache_integrity_and_reuse(monkeypatch,tmp_path):
    import zipfile
    fake_commit='a'*40
    monkeypatch.setattr(m,'request_json',lambda _u:{'sha':fake_commit})
    names={
        'LICENSE':'MIT License',
        'Windows.py':'# backend',
        'base.py':'# base',
        'Scripts/__init__.py':'',
        'Scripts/usbdump.py':'# USB discovery source',
        'Scripts/shared.py':'# enums',
        'Scripts/_build.py':'BUILD=False',
        'resources/Info.plist':'<plist/>',
    }
    def fake_download(_url,target,**kwargs):
        with zipfile.ZipFile(target,'w') as z:
            for name,text in names.items():z.writestr('tool-'+fake_commit+'/'+name,text)
            z.writestr('tool-'+fake_commit+'/resources/usbdump.exe',b'MZ'+b'\0'*250)
    monkeypatch.setattr(m,'download',fake_download)
    a=m.install_backend(tmp_path)
    assert a['cached'] is False
    assert m.backend_verified(tmp_path)
    assert m.install_backend(tmp_path)['cached'] is True
    (tmp_path/'usbtoolbox'/'Scripts'/'usbdump.py').write_text('changed')
    assert not m.backend_verified(tmp_path)


def test_backend_install_rejects_missing_discovery_executable(monkeypatch,tmp_path):
    import zipfile
    monkeypatch.setattr(m,'request_json',lambda _u:{'sha':'f'*40})
    def bad_download(_url,target,**kwargs):
        with zipfile.ZipFile(target,'w') as z:
            z.writestr('tool-'+'f'*40+'/Scripts/usbdump.py','# no binary')
    monkeypatch.setattr(m,'download',bad_download)
    with pytest.raises(RuntimeError,match='incomplete'):
        m.install_backend(tmp_path)
    assert not m.backend_verified(tmp_path)


def test_no_controllers_is_a_scan_error_not_a_verified_empty_map():
    with pytest.raises(ValueError,match='No usable USB controllers'):
        m.normalize_snapshot([])
