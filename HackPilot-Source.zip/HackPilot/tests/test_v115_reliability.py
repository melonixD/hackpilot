"""v1.15: robust desktop startup, offline helper cache, and removable disk repair.

All USB devices here are tmp_path fakes. No real volume is accessed.
"""
import hashlib
import json
import shutil
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

from hackpilot import main as entry, recovery, usb
from hackpilot.usb_journal import pending_receipts, _valid_receipt
from test_quality import make_usb


def _local_recovery_worker(tmp_path, monkeypatch, broken_metadata):
    script = b'# fake pinned source\n' + b'# comment\n' * 520
    cache = tmp_path / 'cache'
    cache.mkdir()
    (cache / 'macrecovery.py').write_bytes(script)
    monkeypatch.setattr(recovery, 'MACRECOVERY_SHA256', hashlib.sha256(script).hexdigest())
    monkeypatch.setattr(recovery, '_git_blob_sha1', lambda _: recovery.MACRECOVERY_BLOB_SHA1)
    (cache / 'macrecovery-manifest.json').write_bytes(broken_metadata)

    def no_network(*args, **kwargs):
        pytest.fail('Authentic cached recovery helper must not require a GitHub download')

    monkeypatch.setattr(recovery, 'download', no_network)
    monkeypatch.setattr(recovery, 'verify_apple_recovery_assets', lambda *args: True)

    def mock_run(args, cwd, stdout, stderr, timeout):
        stage = Path(cwd)
        (stage / 'BaseSystem.dmg').write_bytes(b'valid-image-fixture')
        (stage / 'BaseSystem.chunklist').write_bytes(b'valid-chunklist-fixture')
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(recovery.subprocess, 'run', mock_run)
    return cache


@pytest.mark.parametrize('metadata', [b'{broken JSON', b'', b'a' * (64 * 1024 + 1)])
def test_cached_authentic_helper_recovers_bad_metadata_without_network(tmp_path, monkeypatch, metadata):
    cache = _local_recovery_worker(tmp_path, monkeypatch, metadata)
    result = recovery.download_recovery(cache, tmp_path / 'output',
                                        'Mac-7BA5B2D9E42DDD94')
    assert Path(result['folder'], 'BaseSystem.dmg').is_file()
    updated = json.loads((cache / 'macrecovery-manifest.json').read_text())
    assert updated['sha256'] == recovery.MACRECOVERY_SHA256
    assert updated['commit'] == recovery.MACRECOVERY_COMMIT


def test_invalid_helper_blocks_oversized_manifest_before_read(tmp_path, monkeypatch):
    cache = tmp_path / 'cache'; cache.mkdir()
    (cache / 'macrecovery-manifest.json').write_bytes(b'a' * (64 * 1024 + 1))
    monkeypatch.setattr(recovery, 'download', lambda *args, **kw: pytest.fail('Must reject before downloading'))
    with pytest.raises(RuntimeError, match='Oversized macrecovery manifest'):
        recovery.download_recovery(cache, tmp_path / 'output', 'Mac-7BA5B2D9E42DDD94')


def test_webview_failure_falls_back_to_browser(tmp_path, monkeypatch):
    class Server:
        server_port = 8765
        stopped = False
        closed = False
        def serve_forever(self): pass
        def shutdown(self): self.stopped = True
        def server_close(self): self.closed = True

    instance = Server()
    monkeypatch.setattr(entry, 'create_server', lambda *a: instance)
    monkeypatch.setattr(entry, 'State', lambda **kw: object())
    monkeypatch.setattr(sys, 'argv', ['hackpilot'])
    monkeypatch.setitem(sys.modules, 'webview', SimpleNamespace(
        create_window=lambda *a,**kw: None,
        start=lambda *a,**kw: (_ for _ in ()).throw(RuntimeError('WebView2 missing'))))
    opened = []
    monkeypatch.setattr(entry.webbrowser, 'open', lambda url: opened.append(url) or True)
    assert entry.main() == 0
    assert opened == ['http://127.0.0.1:8765']
    assert instance.stopped and instance.closed


def test_browser_failure_shuts_server_down(tmp_path, monkeypatch):
    class Server:
        server_port = 8765
        stopped = False
        closed = False
        def serve_forever(self): pass
        def shutdown(self): self.stopped = True
        def server_close(self): self.closed = True

    instance = Server()
    monkeypatch.setattr(entry, 'create_server', lambda *a: instance)
    monkeypatch.setattr(entry, 'State', lambda **kw: object())
    monkeypatch.setattr(sys, 'argv', ['hackpilot', '--browser'])
    monkeypatch.setattr(entry.webbrowser, 'open', lambda *_: False)
    with pytest.raises(RuntimeError, match='could not open'):
        entry.main()
    assert instance.stopped and instance.closed


def test_usb_rollback_preserves_recovery_that_preexisted_transfer(tmp_path, monkeypatch):
    drive, build, source = make_usb(tmp_path, monkeypatch, recovery=True)
    shutil.copytree(source, drive / 'com.apple.recovery.boot')
    original = usb.write_receipt

    def power_failure_after_new_efi(path, receipt):
        original(path, receipt)
        if receipt['phase'] == 'new_moved':
            raise SystemExit('simulated outage after replacing EFI')

    monkeypatch.setattr(usb, 'write_receipt', power_failure_after_new_efi)
    with pytest.raises(SystemExit):
        usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path / 'backups', source)
    monkeypatch.setattr(usb, 'write_receipt', original)
    (drive / 'EFI' / 'OC' / 'config.plist').write_bytes(b'corrupt new EFI')
    assert usb.repair_usb('Q', 'REPAIR Q:', tmp_path / 'backups')['action'] == 'restored'
    assert (drive / 'EFI' / 'OC' / 'config.plist').read_bytes() == b'original'
    assert (drive / 'com.apple.recovery.boot' / 'BaseSystem.dmg').read_bytes() == b'dmg'
    assert not list(drive.glob('com.apple.recovery.boot.hackpilot-failed-*'))


def test_usb_rollback_quarantines_new_recovery(tmp_path, monkeypatch):
    drive, build, source = make_usb(tmp_path, monkeypatch, recovery=True)
    original = usb.write_receipt

    def power_failure_after_commit(path, receipt):
        original(path, receipt)
        if receipt['phase'] == 'committed':
            raise SystemExit('simulated crash after recovery copying')

    monkeypatch.setattr(usb, 'write_receipt', power_failure_after_commit)
    with pytest.raises(SystemExit):
        usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path / 'backups', source)
    monkeypatch.setattr(usb, 'write_receipt', original)
    (drive / 'EFI' / 'OC' / 'config.plist').write_bytes(b'bad newly copied EFI')
    assert usb.repair_usb('Q', 'REPAIR Q:', tmp_path / 'backups')['action'] == 'restored'
    assert (drive / 'EFI' / 'OC' / 'config.plist').read_bytes() == b'original'
    assert not (drive / 'com.apple.recovery.boot').exists()
    assert len(list(drive.glob('com.apple.recovery.boot.hackpilot-failed-*'))) == 1


def test_corrupt_preexisting_recovery_indicator_rejected(tmp_path):
    receipt = {'letter':'Q','disk_number':5,'volume_id':'vol','phase':'staged',
               'expected_fingerprint':'a'*64,'had_original':False,
               'recovery_fingerprint':'b'*64,'recovery_preexisting':'yes'}
    assert not _valid_receipt(receipt, tmp_path/'usb-Q.json')
    receipt['recovery_preexisting'] = True
    assert _valid_receipt(receipt, tmp_path/'usb-Q.json')
    receipt['recovery_fingerprint'] = None
    assert not _valid_receipt(receipt, tmp_path/'usb-Q.json')


def test_failed_usb_stage_cleanup_requires_explicit_repair(tmp_path, monkeypatch):
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    real_copy = usb._verified_copy
    def stage_failure(source, target):
        Path(target).mkdir(parents=True)
        (Path(target) / 'incomplete').write_bytes(b'x')
        raise OSError('simulated staging error')

    monkeypatch.setattr(usb, '_verified_copy', stage_failure)
    real_rm = usb.shutil.rmtree
    def cleanup_failure(path, *args, **kwargs):
        if Path(path).name == 'EFI.hackpilot-incoming':
            raise OSError('USB write protection')
        return real_rm(path, *args, **kwargs)
    monkeypatch.setattr(usb.shutil, 'rmtree', cleanup_failure)
    with pytest.raises(RuntimeError, match='partial files require Repair USB'):
        usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path / 'backups')
    assert any(x['phase'] == 'cleanup_needed' for x in pending_receipts(tmp_path/'backups'/'transactions'))
    assert (drive/'EFI'/'OC'/'config.plist').read_bytes() == b'original'


def test_oversized_tool_manifests_rejected_without_reading(tmp_path, monkeypatch):
    from hackpilot import engine, usb_mapping
    large = b'x' * (128 * 1024 + 1)
    for name in ('engine-manifest.json', 'usbtoolbox-manifest.json'):
        (tmp_path / name).write_bytes(large)
    assert not engine.cached_engine_verified(tmp_path)
    assert not usb_mapping.backend_verified(tmp_path)
    with pytest.raises(RuntimeError, match='size limit'):
        engine._bounded_manifest_bytes(tmp_path / 'engine-manifest.json')


def test_prior_oversized_scan_is_not_loaded_into_gui(tmp_path, monkeypatch):
    from hackpilot import server
    report_dir = tmp_path / 'home' / 'SystemReport'
    (report_dir / 'ACPI').mkdir(parents=True)
    # A previous crash or corrupt file must not hang GUI startup.
    with (report_dir / 'Report.json').open('wb') as stream:
        stream.truncate(32 * 1024 * 1024 + 1)
    state = server.State(home=tmp_path / 'home')
    assert state.hardware is None
    assert state.sniffer_file is None
    assert not state.deep_scan_verified


def test_bounded_manifest_rejects_link_before_read(tmp_path):
    from hackpilot import engine
    sensitive = tmp_path / 'unrelated.json'
    sensitive.write_bytes(b'{}')
    alias = tmp_path / 'engine-manifest.json'
    try:
        alias.symlink_to(sensitive)
    except (OSError, NotImplementedError):
        pytest.skip('No symlink support')
    assert not engine.cached_engine_verified(tmp_path)
    with pytest.raises(RuntimeError, match='Linked cached-tool manifest'):
        engine._bounded_manifest_bytes(alias)


def test_packaged_worker_smoke_does_not_need_console(tmp_path, monkeypatch):
    output = tmp_path/'worker-smoke.txt'
    monkeypatch.setattr(sys, 'argv', ['HackPilot.exe', '--worker-smoke', str(output)])
    assert entry.main() == 0
    assert output.read_text(encoding='ascii') == 'hackpilot-worker-ok\n'


def test_frozen_recovery_worker_writes_explicit_log_without_console(tmp_path, monkeypatch):
    script=tmp_path/'fake_macrecovery.py'
    script.write_text("print('macrecovery running')\nraise SystemExit(3)\n", encoding='utf-8')
    logfile=tmp_path/'macrecovery.log'
    monkeypatch.setattr(sys,'argv',['HackPilot.exe','--worker-recovery',str(script),
                                    'download','--worker-log',str(logfile)])
    assert entry.main() == 3
    assert 'macrecovery running' in logfile.read_text()


def test_frozen_adapter_worker_writes_traceback_to_file(tmp_path, monkeypatch):
    from hackpilot import upstream_adapter
    def broken_builder():
        print('building EFI')
        raise RuntimeError('simulated upstream failure')
    monkeypatch.setattr(upstream_adapter, 'main', broken_builder)
    log=tmp_path/'build.log'
    monkeypatch.setattr(sys,'argv',['HackPilot.exe','--worker-adapter','filler',
                                    '--worker-log',str(log)])
    assert entry.main() == 2
    text=log.read_text()
    assert 'building EFI' in text
    assert 'simulated upstream failure' in text


def test_frozen_usb_mapper_worker_uses_output_file(tmp_path, monkeypatch):
    from hackpilot import usb_mapping_worker
    expected=tmp_path/'ports.json'
    errors=tmp_path/'errors.log'
    def fake_worker():
        assert sys.argv[1] == '/tool'
        Path(sys.argv[2]).write_text('[{"controller":1}]',encoding='utf-8')
    monkeypatch.setattr(usb_mapping_worker, 'main', fake_worker)
    monkeypatch.setattr(sys,'argv',['HackPilot.exe','--worker-usb-map','/tool',str(expected),str(errors)])
    assert entry.main() == 0
    assert json.loads(expected.read_text()) == [{'controller':1}]


def test_frozen_usb_mapper_parent_reads_output_without_stdout(tmp_path, monkeypatch):
    import os
    from hackpilot import usb_mapping
    monkeypatch.setattr(usb_mapping,'os', SimpleNamespace(name='nt',environ=dict(os.environ)))
    monkeypatch.setattr(usb_mapping.sys,'frozen',True,raising=False)
    monkeypatch.setattr(usb_mapping,'backend_verified',lambda cache:True)
    seen=[]
    def fake_run(command, **kwargs):
        seen.append((command,kwargs))
        assert command[1] == '--worker-usb-map'
        Path(command[-2]).write_text('[{"name":"xHCI","ports":[]}]', encoding='utf-8')
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(usb_mapping.subprocess,'run',fake_run)
    data=usb_mapping.discover_controllers(tmp_path/'cache')
    assert data == [{'name':'xHCI','ports':[]}]
    assert seen[0][1]['stdout'] == usb_mapping.subprocess.DEVNULL
    assert seen[0][1]['stderr'] == usb_mapping.subprocess.DEVNULL
