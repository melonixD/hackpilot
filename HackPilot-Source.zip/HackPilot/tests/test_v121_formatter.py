import copy
import os
import subprocess
from types import SimpleNamespace
import pytest
from hackpilot import usb_format, server


def disk(**changes):
    row={'number':2,'unique_id':'USB-123','path':'USB-PATH','serial':'123','size':64*1024**3,'name':'Test USB','reason':'','partitions':[{'letter':'E','filesystem':'NTFS','size':64*1024**3}]}
    return {**row, **changes}


@pytest.mark.parametrize('changes',[{'reason':'Windows disk'},{'unique_id':''},{'path':''},{'size':1024},{'number':True},{'number':-1},{'size':True}])
def test_unsafe_inventory_is_never_eligible(changes):
    with pytest.raises(RuntimeError):usb_format.validate_disk(disk(**changes))


def test_plan_names_whole_disk_and_does_not_format(tmp_path,monkeypatch):
    monkeypatch.setattr(usb_format,'inventory',lambda:[disk()])
    monkeypatch.setattr(usb_format,'format_disk',lambda _:pytest.fail('Planning must not write'))
    state=server.State(home=tmp_path)
    plan=state.plan_usb_format(2)
    assert plan['disk']['name']=='Test USB'
    assert plan['confirmation']=='ERASE USB 2'
    assert 'ALL partitions' in plan['note']


@pytest.mark.parametrize('case',['wrong_token','wrong_text','expired'])
def test_invalid_confirmation_cannot_reach_formatter(tmp_path,monkeypatch,case):
    monkeypatch.setattr(usb_format,'inventory',lambda:[disk()])
    monkeypatch.setattr(usb_format,'format_disk',lambda _:pytest.fail('Must not write'))
    state=server.State(home=tmp_path);plan=state.plan_usb_format(2)
    if case=='expired':state.format_plan['expires']=0
    with pytest.raises(ValueError):
        state.format_usb('bad' if case=='wrong_token' else plan['token'],'bad' if case=='wrong_text' else plan['confirmation'])
    assert state.format_plan is None


def test_plan_is_single_use_and_clears_stale_usb_ready(tmp_path,monkeypatch):
    monkeypatch.setattr(usb_format,'inventory',lambda:[disk()])
    calls=[]
    monkeypatch.setattr(usb_format,'format_disk',lambda expected:calls.append(expected) or {'ok':True,'letter':'F'})
    state=server.State(home=tmp_path);state.usb_prepared=True;state.usb_copied=True
    plan=state.plan_usb_format(2)
    assert state.format_usb(plan['token'],plan['confirmation'])['letter']=='F'
    assert not state.usb_prepared and not state.usb_copied
    with pytest.raises(ValueError):state.format_usb(plan['token'],plan['confirmation'])
    assert len(calls)==1


@pytest.mark.parametrize('changes',[{'unique_id':'SWAPPED'},{'serial':'OTHER'},{'size':32*1024**3},{'reason':'Now protected'}])
def test_device_swap_or_new_protection_stops_before_elevation(monkeypatch,changes):
    monkeypatch.setattr(usb_format,'os',SimpleNamespace(name='nt'))
    monkeypatch.setattr(usb_format,'inventory',lambda:[disk(**changes)])
    monkeypatch.setattr(usb_format.subprocess,'run',lambda *a,**kw:pytest.fail('Must not elevate'))
    with pytest.raises(RuntimeError):usb_format.format_disk(disk())


def test_demo_cannot_plan_or_format(tmp_path,monkeypatch):
    state=server.State(home=tmp_path,demo=True)
    monkeypatch.setattr(usb_format,'inventory',lambda:pytest.fail('Must not enumerate'))
    with pytest.raises(RuntimeError):state.plan_usb_format(2)
    with pytest.raises(RuntimeError):state.format_usb('x','ERASE USB 2')


@pytest.mark.skipif(os.name!='nt',reason='Windows PowerShell AST parser required')
def test_powershell_scripts_parse_without_executing_them():
    # Parse only. Never invoke the inventory/formatter on a physical disk.
    for script in (usb_format.INVENTORY,usb_format.FORMAT):
        import base64
        payload=base64.b64encode(script.encode('utf-8')).decode('ascii')
        command="$s=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+payload+"'));$t=$null;$e=$null;$null=[System.Management.Automation.Language.Parser]::ParseInput($s,[ref]$t,[ref]$e);if($e.Count){$e | Out-String | Write-Output;exit 1}"
        result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',usb_format.encoded(command)],capture_output=True,timeout=30)
        assert result.returncode==0,result.stdout.decode(errors='replace')


def test_uac_cancel_never_reports_format_success(monkeypatch):
    monkeypatch.setattr(usb_format,'os',SimpleNamespace(name='nt'))
    monkeypatch.setattr(usb_format,'inventory',lambda:[disk()])
    monkeypatch.setattr(usb_format.subprocess,'run',lambda *a,**kw:SimpleNamespace(returncode=1223))
    with pytest.raises(RuntimeError,match='cancelled or could not start'):
        usb_format.format_disk(disk())
