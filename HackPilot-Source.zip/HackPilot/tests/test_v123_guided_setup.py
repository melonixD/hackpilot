from pathlib import Path
import shutil
import subprocess
import pytest
from hackpilot.server import State


def test_frontend_workflow_transitions():
    node = shutil.which('node')
    if not node:
        pytest.skip('Node.js is required for frontend behavior checks')
    result = subprocess.run([node, '--test', str(Path(__file__).with_suffix('.cjs').with_name('test_v123_workflow.cjs'))], capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, result.stdout + result.stderr


def test_recovery_is_bound_to_current_efi_for_guided_copy(tmp_path, monkeypatch):
    state = State(home=tmp_path)
    monkeypatch.setattr(state, '_cached_recovery_present', lambda: True)
    expected = {'board_id': 'Mac-example', 'darwin_major': '24', 'os_type': 'default'}
    monkeypatch.setattr(state, 'expected_recovery_profile', lambda: expected)
    state.last_build = {'valid': True}
    state.recovery_profile = {**expected, 'darwin_major': '23'}
    assert state._recovery_for_current_efi() is False
    state.recovery_profile = expected.copy()
    assert state._recovery_for_current_efi() is True
    state.last_build = None
    assert state._recovery_for_current_efi() is False


def test_bad_manifest_does_not_unlock_guided_recovery(tmp_path, monkeypatch):
    state = State(home=tmp_path)
    state.last_build = {'valid': True}
    monkeypatch.setattr(state, '_cached_recovery_present', lambda: True)
    def bad_manifest():
        raise RuntimeError('Invalid target')
    monkeypatch.setattr(state, 'expected_recovery_profile', bad_manifest)
    assert state._recovery_for_current_efi() is False
