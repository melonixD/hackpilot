"""v1.7 regression tests for boot-driver conflicts and USB ambiguity."""
import copy
import pytest

from hackpilot import usb, usb_mapping as mapping
from hackpilot.efi_audit import audit_efi_components
from test_quality import make_usb
from test_v12_component_audit import fixture, save_config, write_pe
from test_v15_usb_mapping import raw_device


def test_two_valid_hfs_drivers_are_not_safe_together(tmp_path):
    build, cfg = fixture(tmp_path)
    oc = build / 'EFI' / 'OC'
    write_pe(oc / 'Drivers' / 'OpenHfsPlus.efi')
    cfg['UEFI']['Drivers'].append({'Enabled': True, 'Path': 'OpenHfsPlus.efi'})
    save_config(build, cfg)
    result = audit_efi_components(build, target_darwin='24.0.0')
    assert any('Multiple HFS+' in reason for reason in result['errors'])


def test_disabled_second_hfs_driver_is_allowed(tmp_path):
    build, cfg = fixture(tmp_path)
    oc = build / 'EFI' / 'OC'
    write_pe(oc / 'Drivers' / 'OpenHfsPlus.efi')
    cfg['UEFI']['Drivers'].append({'Enabled': False, 'Path': 'OpenHfsPlus.efi'})
    save_config(build, cfg)
    result = audit_efi_components(build, target_darwin='24.0.0')
    assert not any('Multiple HFS+' in reason for reason in result['errors'])


@pytest.mark.parametrize('missing', ['volume_id', 'disk_number'])
def test_manual_usb_copy_requires_stable_volume_identity(tmp_path, monkeypatch, missing):
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    disk={'drive_letter':'Q','filesystem':'FAT32','free_bytes':500_000_000,
          'disk_number':5,'volume_id':'volume-A'}
    disk[missing] = None
    monkeypatch.setattr(usb, 'list_usb', lambda: [disk.copy()])
    with pytest.raises(RuntimeError, match='identity'):
        usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path/'backups')
    assert (drive/'EFI'/'OC'/'config.plist').read_bytes()==b'original'
    assert not (drive/'EFI.hackpilot-incoming').exists()


def test_manual_usb_detects_identity_loss_after_preflight(tmp_path, monkeypatch):
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    disk={'drive_letter':'Q','filesystem':'FAT32','free_bytes':500_000_000,
          'disk_number':5,'volume_id':'volume-A'}
    count=[]
    def discover():
        count.append(1)
        return [{**disk, 'volume_id': None if len(count)>1 else disk['volume_id']}]
    monkeypatch.setattr(usb, 'list_usb', discover)
    with pytest.raises(RuntimeError, match='identity'):
        usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path/'backups')
    assert (drive/'EFI'/'OC'/'config.plist').read_bytes()==b'original'


def test_changed_source_is_rejected_before_writing(tmp_path, monkeypatch):
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    with pytest.raises(RuntimeError,match='changed after validation'):
        usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path/'backups',
                          expected_fingerprint='0'*64)
    assert not (drive/'EFI.hackpilot-incoming').exists()
    assert (drive/'EFI'/'OC'/'config.plist').read_bytes()==b'original'


def test_ambiguous_companion_hub_does_not_change_other_controller():
    first = raw_device()[0]
    first['ports'][1]['devices'] = []
    second = copy.deepcopy(first)
    second['identifiers']['bdf'] = [0,21,0]
    second['ports'] = [dict(second['ports'][1], devices=[], companion_info={'hub':'ROOT-HUB-1','port':1}),
                       dict(second['ports'][0], devices=[], companion_info={'hub':'ROOT-HUB-1','port':2})]
    source = mapping.normalize_snapshot([first, second])
    actual = mapping.merge_snapshots(None, source)
    observed_second = [p['seen'] for p in actual['controllers'][1]['ports']]
    assert observed_second == [False, False]
    assert actual['controllers'][0]['ports'][1]['seen'] is True


@pytest.mark.parametrize('bdf', [[0,32,0],[0,20,8],[256,0,0],[-1,20,0],['0',20,0]])
def test_invalid_usb_pci_bus_location_not_treated_as_valid_controller_id(bdf):
    device=raw_device()[0]
    device['identifiers']['bdf']=bdf
    # A valid and unique ACPI path can still identify the hardware even if
    # the BDF is invalid; the invalid BDF itself must never be trusted.
    assert not mapping._controller_id(device).startswith('bdf:')


def test_status_never_labels_unverified_recovery_as_downloaded(tmp_path):
    from hackpilot.server import State
    state=State(home=tmp_path/'home')
    folder=tmp_path/'Recovery'
    folder.mkdir()
    (folder/'BaseSystem.dmg').write_bytes(b'not a signed download')
    (folder/'BaseSystem.chunklist').write_bytes(b'not a valid chunklist')
    state.recovery_dir=str(folder)
    state.recovery_verified=False
    assert state.status()['recovery_ready'] is False
    state.recovery_verified=True
    assert state.status()['recovery_ready'] is True  # cached result; actual writes rehash


def test_map_rejects_unknown_usb_controller_class(tmp_path):
    data=mapping.normalize_snapshot(raw_device())
    data['controllers'][0]['class']=9999
    with pytest.raises(RuntimeError,match='class is unknown'):
        mapping.generate_utbmap(data,tmp_path)


def test_map_rejects_unknown_selected_port_speed(tmp_path):
    data=mapping.normalize_snapshot(raw_device())
    data['controllers'][0]['ports'][0]['speed']=9999
    with pytest.raises(RuntimeError,match='speed is unknown'):
        mapping.generate_utbmap(data,tmp_path)


def test_map_rejects_out_of_range_controller_bdf(tmp_path):
    data=mapping.normalize_snapshot(raw_device())
    data['controllers'][0]['identifiers'].pop('acpi_path',None)
    data['controllers'][0]['identifiers']['bdf']=[0,32,0]
    # Reject invalid BDF, and only use a PCI-ID fallback if it is valid.
    result=mapping.generate_utbmap(data,tmp_path)
    import plistlib
    info=plistlib.loads((tmp_path/'UTBMap.kext'/'Contents'/'Info.plist').read_bytes())
    row=next(iter(info['IOKitPersonalities'].values()))
    assert 'IOPropertyMatch' not in row
    assert 'IOPCIPrimaryMatch' in row


def test_usb_map_status_reports_selected_unobserved_ports(tmp_path):
    from hackpilot.server import State
    import json
    state=State(home=tmp_path/'home')
    data=mapping.normalize_snapshot(raw_device())
    data['controllers'][0]['ports'][3]['selected']=True
    data['controllers'][0]['ports'][3]['seen']=False
    (state.mapping_dir/'ports.json').write_text(json.dumps(data))
    result=state.usb_mapping_status()
    assert result['unseen_selected']==1
    assert result['selected_ports']==3


def test_usb_map_status_reports_all_observed_ports_separately(tmp_path):
    from hackpilot.server import State
    import json
    state=State(home=tmp_path/'home')
    data=mapping.normalize_snapshot(raw_device())
    (state.mapping_dir/'ports.json').write_text(json.dumps(data))
    result=state.usb_mapping_status()
    assert result['unseen_selected']==0
    assert result['selected_ports']==2
