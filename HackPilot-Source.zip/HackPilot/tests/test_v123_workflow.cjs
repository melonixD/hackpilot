'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8');
function app(){
  const nodes=Object.fromEntries(['toast','page','header-status','header-status-dot','app-version','current-label'].map(key=>[key,{style:{},focus(){},textContent:'',innerHTML:''}]));
  const handlers={};
  const context=vm.createContext({document:{querySelector:()=>({content:'test-session'}),querySelectorAll:()=>[],getElementById:key=>nodes[key]||null,addEventListener:(name,handler)=>handlers[name]=handler,activeElement:null},window:{scrollTo(){}},fetch:()=>new Promise(()=>{}),setInterval(){},setTimeout(){},clearTimeout(){},confirm:()=>true,prompt:()=>null,console,handlers});
  const run=code=>vm.runInContext(code,context);run(source);return {run,context,nodes};
}
function scanned(a){a.run("S={hardware:{origin:'Hardware Sniffer',cpu:{name:'Intel Core i5-7400'}},deep_scan_ready:true,compatibility:{can_attempt:true,status:'supported'},tasks:{},usb_mapping:{},device_choices:{}};render=()=>{};");}

test('all pages are accessible from first launch while the scan remains recommended',async()=>{
 const a=app();
 assert.equal(a.run('setupStage()'),0);
 for(const view of ['hardware','usbmap','build','usb','usbtools','diagnostics'])assert.equal(a.run(`viewAllowed('${view}')`),true);
 assert.match(a.run('overview()'),/Start with a hardware scan/);
 assert.doesNotMatch(a.run('overview()'),/data-action="navigate-[^"]+" disabled/);
 assert.doesNotMatch(a.run('overview()'),/id="usb-target"|id="macos-target"/);
 a.run('render=()=>{};get=async()=>({})');await a.run("switchView('usb')");assert.equal(a.run('view'),'usb');
});

test('demo pages remain accessible but real EFI generation stays disabled',()=>{
 const a=app();scanned(a);a.run("S.hardware.origin='Synthetic demo';S.demo=true;");
 assert.equal(a.run("viewAllowed('usbmap')"),true);
 assert.match(a.run('build()'),/data-action="auto-setup" disabled/);
});

test('mapping choices guide recommendations without locking other pages',async()=>{
 const a=app();scanned(a);
 assert.equal(a.run('setupStage()'),1);
 assert.equal(a.run("viewAllowed('build')"),true);
 assert.equal(a.run("viewAllowed('usb')"),true);
 a.run("confirm=()=>false;switchView=async()=>{};");await a.run("act('skip-mapping')");assert.equal(a.run('mappingSkipped'),false);
 a.run('confirm=()=>true');await a.run("act('skip-mapping')");
 assert.equal(a.run('setupStage()'),2);
});

test('compatibility blockers recommend review without redirecting navigation',()=>{
 const a=app();scanned(a);a.run("view='usb';S.compatibility={status:'blocked',can_attempt:false};S.usb_mapping={map_ready:true};S.last_build={valid:true};");
 assert.equal(a.run('setupStage()'),0);assert.equal(a.run("viewAllowed('usb')"),true);
 assert.match(a.run('build()'),/data-action="auto-setup" disabled/);
});

test('changed settings require a checked rebuild before copying, while USB stays accessible',async()=>{
 const a=app();scanned(a);a.run("S.usb_mapping={map_ready:true};S.last_build={valid:false};");
 assert.equal(a.run('setupStage()'),2);
 a.run('S.last_build.valid=true');assert.equal(a.run('setupStage()'),3);
 a.run("handlers.change({target:{id:'macos-target',value:'23',dataset:{}}})");
 assert.equal(a.run("viewAllowed('usb')"),true);assert.equal(a.run('efiReady()'),false);assert.equal(a.run('fields.target'),'23');
 assert.match(a.run('build()'),/Generate and check the EFI again/);
 a.run("post=async()=>{throw new Error('must not copy stale build')}");await a.run("act('usb-copy')");
 assert.match(a.nodes.toast.textContent,/Changed macOS or device choices require a rebuild/);
});

test('USB access recovery can start independently of a hardware scan',async()=>{
 const a=app();
 const original=a.context.document.getElementById;
 a.context.document.getElementById=key=>key==='format-disk'?{value:'2'}:original(key);
 a.run("render=()=>{};switchView=async()=>{};calls=[];prompt=()=> 'RESTORE USB 2';post=async(route,body)=>{calls.push({route,body});return route==='usb-format-plan'?{token:'plan',confirmation:'RESTORE USB 2',disk:{number:2,name:'Test USB',size:8000000000,partitions:[]},note:'No erase'}:{}};");
 await a.run("act('usb-restore-access')");
 assert.equal(a.run('calls[0].route'),'usb-format-plan');assert.equal(a.run('calls[0].body.restore'),true);
 assert.equal(a.run('calls[1].route'),'usb-format');assert.equal(a.run('calls[1].body.confirm'),'RESTORE USB 2');
});

test('starting directly in EFI explains and requests any required scan',async()=>{
 const a=app();a.run("render=()=>{};switchView=async()=>{};calls=[];confirm=message=>{consentText=message;return true};post=async(route,body)=>{calls.push({route,body});return {}};");
 await a.run("act('auto-setup')");assert.equal(a.run('calls[0].route'),'auto-setup');assert.equal(a.run('calls[0].body.consent'),true);
 assert.match(a.run('consentText'),/Hardware Sniffer/);assert.match(a.run('consentText'),/temporary USB configuration/);
});

test('cached recovery for another EFI cannot enable the guided copy',async()=>{
 const a=app();scanned(a);a.run("S.usb_mapping={map_ready:true};S.last_build={valid:true};S.recovery_ready=true;S.recovery_for_efi=false;usb=[{drive_letter:'E',filesystem:'FAT32'}];fields.drive='E';post=async()=>{throw new Error('must not copy')};");
 assert.match(a.run('usbView()'),/Download Apple recovery/);
 assert.match(a.run('usbView()'),/data-action="usb-copy" disabled/);
 await a.run("act('usb-copy')");assert.match(a.nodes.toast.textContent,/Download and verify/);
 a.run('S.recovery_for_efi=true');assert.doesNotMatch(a.run('usbView()'),/data-action="usb-copy" disabled/);
});

test('polling a completed build does not jump away from the review page',async()=>{
 const a=app();scanned(a);a.run("view='build';buildOptionsDirty=true;priorTasks={build:{state:'running'}};get=async()=>({...S,last_build:{valid:true},tasks:{build:{name:'Auto setup',state:'done'}}});");
 await a.run('refresh()');assert.equal(a.run('view'),'build');assert.equal(a.run('buildOptionsDirty'),false);
});

test('failed tasks leave their page open and show the error',async()=>{
 const a=app();scanned(a);a.run("view='hardware';priorTasks={scan:{state:'running'}};get=async()=>({...S,tasks:{scan:{name:'Deep hardware scan',state:'error',message:'Scan failed'}}});");
 await a.run('refresh()');assert.equal(a.run('view'),'hardware');assert.match(a.run('taskError()'),/Scan failed/);
});

test('request acceptance tracks fast tasks and invalidates an older status response',async()=>{
 const a=app();scanned(a);
 a.context.fetch=async()=>({ok:true,json:async()=>({task_id:'fast'})});
 await a.run("post('auto-setup',{consent:true})");
 assert.equal(a.run('priorTasks.fast.state'),'running');assert.equal(a.run('running().state'),'running');
 a.run("buildOptionsDirty=true;get=async()=>({...S,tasks:{fast:{name:'Auto setup',state:'done'}}});");await a.run('refresh()');assert.equal(a.run('buildOptionsDirty'),false);
 a.run('get=()=>new Promise(resolve=>{resolveOld=resolve})');const pending=a.run('refresh()');
 a.run('statusEpoch++;resolveOld({hardware:null,tasks:{}})');await pending;assert.equal(a.run('scanComplete()'),true);
});

test('in-flight operations reject repeated clicks without another request',async()=>{
 const a=app();scanned(a);a.run("pendingAction=true;post=async()=>{throw new Error('unexpected request')};");
 await a.run("performAction('deep-scan')");assert.equal(a.nodes.toast.textContent,'');
});


test('refreshing logs keeps the finished log visible after controls are restored',async()=>{
 const a=app();scanned(a);a.run("view='diagnostics';render=()=>{logValue='Loading…'};loadLog=async()=>{logValue='Latest log'};refresh=async()=>{};");
 await a.run("performAction('refresh-log')");assert.equal(a.run('logValue'),'Latest log');
});

test('opening USB tools during a storage task does not enumerate disks mid-operation',async()=>{
 const a=app();scanned(a);a.run("S.tasks={format:{state:'running',name:'Format USB'}};calls=[];get=async route=>{calls.push(route);return {}};");
 await a.run("switchView('usbtools')");assert.equal(a.run('calls.length'),0);
});
