"""One-click workflow regression tests: a complete USB or a safe refusal."""
import json
import os
from pathlib import Path

import pytest

from hackpilot import recovery, server, usb
from hackpilot.server import State


USB = {'drive_letter':'Q','filesystem':'FAT32','free_bytes':3 * 1024**3,
       'disk_number':9,'volume_id':'usb-volume-unique','name':'Test USB'}


def new_state(tmp_path, monkeypatch, usb_list=None):
    state = State(home=tmp_path/'home')
    monkeypatch.setattr(server, 'list_usb', lambda: list(usb_list or [USB.copy()]))
    return state


def test_one_click_refuses_demo_usb_and_wrong_confirmation(tmp_path, monkeypatch):
    state = new_state(tmp_path, monkeypatch)
    with pytest.raises(ValueError, match='Confirm'):
        state.one_click('Q', 'WRONG')
    with pytest.raises(ValueError, match='Select'):
        state.one_click('C:\\', 'PREPARE C:')
    demo=State(demo=True, home=tmp_path/'demo')
    with pytest.raises(RuntimeError, match='demo mode'):
        demo.one_click('Q','PREPARE Q:')


def test_one_click_does_not_touch_non_fat32_usb(tmp_path, monkeypatch):
    state = new_state(tmp_path, monkeypatch, [{**USB, 'filesystem':'NTFS'}])
    called=[]
    monkeypatch.setattr(state, 'deep_scan', lambda: called.append('scan'))
    with pytest.raises(RuntimeError, match='FAT32'):
        state.one_click('Q','PREPARE Q:')
    assert called == []


def test_one_click_blocks_usb_missing_identity_and_space(tmp_path, monkeypatch):
    state = new_state(tmp_path, monkeypatch, [{**USB, 'volume_id':''}])
    with pytest.raises(RuntimeError, match='identity'):
        state.one_click('Q', 'PREPARE Q:')
    monkeypatch.setattr(server, 'list_usb', lambda:[{**USB,'free_bytes':150_000_000}])
    with pytest.raises(RuntimeError, match='free space'):
        state.one_click('Q','PREPARE Q:')


def fake_setup(state, monkeypatch, blocked=False, failed_recovery=False, change_volume=False):
    """Mock only external side effects; keep the real orchestration logic."""
    calls=[]
    def deep_scan():
        calls.append('scan')
        state.deep_scan_verified=True
        state.hardware={'cpu':{'name':'Intel Core i7-9700K'},
                        'gpus':[{'name':'AMD Radeon RX 580'}],
                        'firmware':{'type':'UEFI'},
                        'network':[{'name':'Ethernet'}], 'audio':[{'name':'Audio'}]}
        if blocked:
            state.hardware['gpus']=[{'name':'NVIDIA RTX 5060'}]
    def install():
        calls.append('engine');state.engine_dir=str(state.cache/'opcore-simplify')
    def build(target, selections):
        calls.append('build')
        state.last_build={'valid':True,'fingerprint':'fake-fingerprint'}
        return {'validation':state.last_build}
    def download(board):
        calls.append('recovery')
        if failed_recovery:raise RuntimeError('mock download failed')
        state.recovery_dir=str(state.output/'Recovery'/'com.apple.recovery.boot')
    monkeypatch.setattr(state,'deep_scan',deep_scan)
    monkeypatch.setattr(state,'install_engine',install)
    monkeypatch.setattr(state,'build',build)
    monkeypatch.setattr(state,'recovery',download)
    monkeypatch.setattr(server,'cached_engine_verified',lambda _:True)
    monkeypatch.setattr(server,'board_id_from_efi',lambda _: 'Mac-7BA5B2D9E42DDD94')
    monkeypatch.setattr(server,'verify_recovery',lambda *_, **kw: True)
    monkeypatch.setattr(server,'efi_fingerprint',lambda _: 'fake-fingerprint')
    monkeypatch.setattr(server,'validate_efi',lambda *_:{'valid':True,'fingerprint':'fake-fingerprint'})
    if change_volume:
        iter_calls=[]
        def changing_list():
            iter_calls.append(1)
            if len(iter_calls)==1:return [USB.copy()]
            return [{**USB, 'volume_id':'USB-REPLACED'}]
        monkeypatch.setattr(server,'list_usb',changing_list)
    def fake_copy(*args,**kwargs):
        calls.append('copy')
        assert kwargs['expected_disk']['volume_id']=='usb-volume-unique'
        return {'copied_efi':True,'copied_recovery':True}
    monkeypatch.setattr(server,'safe_usb_copy',fake_copy)
    return calls


def test_one_click_runs_every_required_stage_in_order(tmp_path,monkeypatch):
    state=new_state(tmp_path,monkeypatch)
    calls=fake_setup(state,monkeypatch)
    result=state.one_click('Q','PREPARE Q:')
    assert result['prepared'] and result['efi_validated'] and result['recovery_verified']
    assert calls==['scan','engine','build','recovery','copy']
    assert state.status()['usb_prepared'] and state.status()['usb_copied']


def test_one_click_incompatible_hardware_never_writes_usb(tmp_path,monkeypatch):
    state=new_state(tmp_path,monkeypatch)
    calls=fake_setup(state,monkeypatch,blocked=True)
    with pytest.raises(RuntimeError,match='Incompatible hardware'):
        state.one_click('Q','PREPARE Q:')
    assert calls==['scan']
    assert not state.usb_prepared


def test_one_click_failed_recovery_never_writes_usb(tmp_path,monkeypatch):
    state=new_state(tmp_path,monkeypatch)
    calls=fake_setup(state,monkeypatch,failed_recovery=True)
    with pytest.raises(RuntimeError,match='mock download failed'):
        state.one_click('Q','PREPARE Q:')
    assert calls==['scan','engine','build','recovery']
    assert not state.usb_prepared


def test_one_click_usb_swap_never_writes_usb(tmp_path,monkeypatch):
    state=new_state(tmp_path,monkeypatch)
    calls=fake_setup(state,monkeypatch,change_volume=True)
    with pytest.raises(RuntimeError,match='USB identity changed'):
        state.one_click('Q','PREPARE Q:')
    assert 'copy' not in calls
    assert not state.usb_prepared


def test_verified_recovery_detects_tampering_and_wrong_board(tmp_path):
    out=tmp_path/'Recovery';folder=out/'com.apple.recovery.boot';folder.mkdir(parents=True)
    (folder/'BaseSystem.dmg').write_bytes(b'dmg-data')
    (folder/'BaseSystem.chunklist').write_bytes(b'chunk-data')
    board='Mac-7BA5B2D9E42DDD94'
    (out/'recovery-info.json').write_text(json.dumps(recovery._recovery_metadata(folder,board)))
    assert recovery.verify_recovery(folder,board)
    assert not recovery.verify_recovery(folder,'Mac-7BA5B2D9E42DDD95')
    (folder/'BaseSystem.dmg').write_bytes(b'BAD-data')
    assert not recovery.verify_recovery(folder,board)


def test_usb_identity_checked_before_write(tmp_path,monkeypatch):
    from test_quality import make_usb
    volume,build,_=make_usb(tmp_path,monkeypatch)
    with pytest.raises(RuntimeError,match='USB identity changed'):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups',
                          expected_disk={**USB,'volume_id':'wrong'})
    assert (volume/'EFI'/'OC'/'config.plist').read_text() == 'original'


def test_usb_post_commit_read_back_failure_restores_original(tmp_path,monkeypatch):
    from test_quality import make_usb
    volume,build,_=make_usb(tmp_path,monkeypatch)
    original=usb.efi_tree_fingerprint
    def fake_hash(root):
        root=Path(root)
        if root == volume/'EFI' and (root/'BOOT'/'BOOTx64.efi').is_file():
            return 'tampered'
        return original(root)
    monkeypatch.setattr(usb,'efi_tree_fingerprint',fake_hash)
    with pytest.raises(RuntimeError,match='verification after commit'):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups')
    assert (volume/'EFI'/'OC'/'config.plist').read_text() == 'original'


def test_recovery_manifest_update_failure_restores_previous_files(tmp_path,monkeypatch):
    from hackpilot import recovery as r
    import types
    folder=tmp_path/'Output'/'Recovery'/'com.apple.recovery.boot'
    folder.mkdir(parents=True)
    (folder/'BaseSystem.dmg').write_bytes(b'old-image')
    (folder/'BaseSystem.chunklist').write_bytes(b'old-list')
    old_board='Mac-7BA5B2D9E42DDD94'
    new_board='Mac-7BA5B2D9E42DDD95'
    manifest=folder.parent/'recovery-info.json'
    manifest.write_text(json.dumps(r._recovery_metadata(folder,old_board)))
    original=manifest.read_bytes()
    def fake_download(url,path,*args):
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        Path(path).write_bytes(b'fake-python-tool')
        return {'sha256':__import__('hashlib').sha256(b'fake-python-tool').hexdigest(),'bytes':16,'url':url}
    def fake_process(args,cwd,stdout,stderr,timeout):
        Path(cwd,'BaseSystem.dmg').write_bytes(b'new-image')
        Path(cwd,'BaseSystem.chunklist').write_bytes(b'new-list')
        return types.SimpleNamespace(returncode=0)
    monkeypatch.setattr(r,'download',fake_download)
    monkeypatch.setattr(r,'_git_blob_sha1',lambda *_: r.MACRECOVERY_BLOB_SHA1)
    monkeypatch.setattr(r,'MACRECOVERY_SHA256',__import__('hashlib').sha256(b'fake-python-tool').hexdigest())
    monkeypatch.setattr(r.subprocess,'run',fake_process)
    def fail_manifest(path,payload):
        raise OSError('simulated full disk')
    monkeypatch.setattr(r,'_atomic_json',fail_manifest)
    with pytest.raises(OSError, match='simulated full disk'):
        r.download_recovery(tmp_path/'cache',folder.parent,new_board)
    assert r.verify_recovery(folder,old_board)
    assert not r.verify_recovery(folder,new_board)
    assert manifest.read_bytes() == original
    assert (folder/'BaseSystem.dmg').read_bytes()==b'old-image'


def test_status_does_not_rehash_recovery_on_every_poll(tmp_path,monkeypatch):
    state=State(home=tmp_path/'home')
    calls=[]
    monkeypatch.setattr(server,'verify_recovery',lambda *_, **kw: calls.append(True) or True)
    for _ in range(30):
        state.status()
    assert calls == []


def test_one_click_requires_board_id_or_verified_manual_input(tmp_path,monkeypatch):
    state=new_state(tmp_path,monkeypatch)
    calls=fake_setup(state,monkeypatch)
    monkeypatch.setattr(server,'board_id_from_efi',lambda _:None)
    with pytest.raises(RuntimeError,match='board ID is unavailable'):
        state.one_click('Q','PREPARE Q:')
    assert 'recovery' not in calls and 'copy' not in calls
    result=state.one_click('Q','PREPARE Q:',board_id='Mac-7BA5B2D9E42DDD94')
    assert result['prepared']


def test_one_click_rejects_conflicting_manual_board_id(tmp_path,monkeypatch):
    state=new_state(tmp_path,monkeypatch)
    calls=fake_setup(state,monkeypatch)
    with pytest.raises(RuntimeError,match='does not match'):
        state.one_click('Q','PREPARE Q:',board_id='Mac-7BA5B2D9E42DDD95')
    assert 'recovery' not in calls and 'copy' not in calls


def test_usb_recovery_is_quarantined_when_final_readback_fails(tmp_path,monkeypatch):
    from test_quality import make_usb
    volume,build,recovery=make_usb(tmp_path,monkeypatch,recovery=True)
    real_rename=Path.rename
    def corrupt_recovery_after_commit(self,target):
        value=real_rename(self,target)
        if self.name=='com.apple.recovery.boot.hackpilot-incoming':
            (Path(target)/'BaseSystem.dmg').write_bytes(b'bad image after copy')
        return value
    monkeypatch.setattr(Path,'rename',corrupt_recovery_after_commit)
    with pytest.raises(RuntimeError,match='recovery verification after commit'):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups',recovery)
    assert (volume/'EFI'/'OC'/'config.plist').read_text()=='original'
    assert not (volume/'com.apple.recovery.boot').exists()
    assert list(volume.glob('com.apple.recovery.boot.hackpilot-failed-*'))


def test_one_click_api_requires_explicit_tool_execution_consent(tmp_path):
    import http.client
    import re
    import threading
    state=State(demo=True,home=tmp_path/'home')
    app=server.create_server(state)
    thread=threading.Thread(target=app.serve_forever,daemon=True);thread.start()
    connection=http.client.HTTPConnection('127.0.0.1',app.server_port,timeout=5)
    try:
        connection.request('GET','/')
        response=connection.getresponse()
        index=response.read().decode('utf-8')
        assert response.status==200
        token=re.search(r'name="hackpilot-token" content="([^"]+)"',index).group(1)
        connection.request('POST','/api/one-click',json.dumps({'letter':'Q','confirm':'PREPARE Q:'}),
                           {'Content-Type':'application/json','X-HackPilot-Token':token})
        response=connection.getresponse()
        payload=json.loads(response.read())
        assert response.status==400
        assert 'Consent' in payload['error']
        assert not state.tasks
    finally:
        connection.close();app.shutdown();app.server_close()
