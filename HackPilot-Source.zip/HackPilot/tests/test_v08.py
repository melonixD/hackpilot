"""v0.8 security and interrupted-transfer regressions."""
import hashlib
import json
import plistlib
from pathlib import Path
import stat
import os

import pytest

from hackpilot.compat import assess
from hackpilot.efi import validate_efi
from hackpilot.guided import available_choices, validate_selections
from hackpilot.usb_journal import pending_receipts
from hackpilot import usb
from test_app import _fixture_efi
from test_quality import make_usb


def test_malformed_plist_sections_fail_closed(tmp_path):
    out = _fixture_efi(tmp_path)
    config = out/'EFI'/'OC'/'config.plist'
    with config.open('rb') as handle:
        data = plistlib.load(handle)
    for field in ('ACPI', 'Kernel', 'UEFI', 'PlatformInfo'):
        broken = dict(data)
        broken[field] = 'incorrect type'
        with config.open('wb') as handle:
            plistlib.dump(broken,handle)
        verdict = validate_efi(out)
        assert not verdict['valid']
        assert any(field in err for err in verdict['errors'])


@pytest.mark.skipif(os.name=='nt', reason='POSIX shell validator fixture')
def test_fake_or_mismatched_validator_never_purports_valid(tmp_path):
    out = _fixture_efi(tmp_path)
    home = tmp_path/'validator'
    home.mkdir()
    executable = home/'ocvalidate'
    executable.write_text('#!/bin/sh\nexit 0\n')
    executable.chmod(executable.stat().st_mode|stat.S_IXUSR)
    verdict = validate_efi(out, home)
    assert not verdict['valid'] and any('manifest' in x.lower() for x in verdict['errors'])
    digest = hashlib.sha256(executable.read_bytes()).hexdigest()
    (home/'validator-manifest.json').write_text(json.dumps({'binary_sha256':digest,'opencore_sha256':'f'*64}))
    verdict = validate_efi(out, home)
    assert not verdict['valid'] and any('does not match' in x for x in verdict['errors'])
    (home/'validator-manifest.json').write_text(json.dumps({'binary_sha256':'0'*64,'opencore_sha256':'f'*64}))
    verdict = validate_efi(out, home)
    assert not verdict['valid'] and any('checksum' in x for x in verdict['errors'])


def test_gpu_rtx_only_is_blocked_but_hybrid_is_review():
    machine={'cpu':{'name':'AMD Ryzen 5 5600X'},'gpus':[{'name':'NVIDIA GeForce RTX 5060'}],'firmware':{'type':'UEFI'}}
    assert not assess(machine)['can_attempt']
    machine['gpus'].append({'name':'AMD Radeon RX 580'})
    assert assess(machine)['can_attempt']
    machine['firmware']['type']='Legacy'
    assert not assess(machine)['can_attempt']


def test_guided_selections_require_report_membership():
    raw={'GPU':{'Intel UHD 630':{'Device Type':'Integrated GPU'},'NVIDIA RTX':{'Device Type':'Discrete GPU'}},
         'Network':{'Intel Wi-Fi':{'Device Type':'Wireless'},'Ethernet':{'Device Type':'Ethernet'}},
         'Bluetooth':{'Intel BT':{},'Broadcom BT':{}}}
    choices=available_choices(raw)
    assert set(choices)=={'GPU','Bluetooth'}
    assert validate_selections(choices,{'GPU':'Intel UHD 630'})=={'GPU':'Intel UHD 630'}
    with pytest.raises(ValueError):validate_selections(choices,{'GPU':'Not detected'})
    with pytest.raises(ValueError):validate_selections(choices,{'USB':'anything'})


def test_interrupted_commit_repair_finishes_verified_new_efi(tmp_path, monkeypatch):
    drive,build,_=make_usb(tmp_path,monkeypatch)
    expected=usb.efi_tree_fingerprint(build/'EFI')
    original=usb.write_receipt
    def fail_after_old_moved(path, receipt):
        if receipt['phase']=='new_moved':
            raise SystemExit('simulated process termination')
        return original(path,receipt)
    monkeypatch.setattr(usb,'write_receipt',fail_after_old_moved)
    with pytest.raises(SystemExit):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups',expected_fingerprint=expected)
    assert (drive/'EFI.hackpilot-previous').exists()
    monkeypatch.setattr(usb,'write_receipt',original)
    pending=pending_receipts(tmp_path/'backups'/'transactions')
    assert len(pending)==1
    with pytest.raises(RuntimeError,match='Repair USB'):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups',expected_fingerprint=expected)
    fixed=usb.repair_usb('Q','REPAIR Q:',tmp_path/'backups')
    assert fixed['action']=='completed'
    assert not (drive/'EFI.hackpilot-previous').exists()
    assert usb.efi_tree_fingerprint(drive/'EFI')==expected
    assert not pending_receipts(tmp_path/'backups'/'transactions')


def test_interrupted_commit_repair_restores_old_efi(tmp_path,monkeypatch):
    drive,build,_=make_usb(tmp_path,monkeypatch)
    expected_original=(drive/'EFI'/'OC'/'config.plist').read_bytes()
    original=usb.write_receipt
    def fail_after_moving_old(path, receipt):
        if receipt['phase']=='old_moved':
            raise SystemExit('simulated power loss')
        return original(path,receipt)
    monkeypatch.setattr(usb,'write_receipt',fail_after_moving_old)
    with pytest.raises(SystemExit):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups')
    monkeypatch.setattr(usb,'write_receipt',original)
    assert not (drive/'EFI').exists()
    fixed=usb.repair_usb('Q','REPAIR Q:',tmp_path/'backups')
    assert fixed['action']=='restored'
    assert (drive/'EFI'/'OC'/'config.plist').read_bytes()==expected_original


def test_usb_requires_exact_typed_repair_confirmation(tmp_path,monkeypatch):
    make_usb(tmp_path,monkeypatch)
    with pytest.raises(ValueError,match='REPAIR Q:'):
        usb.repair_usb('Q','yes',tmp_path/'backups')


def test_version_matched_validator_selects_correct_release(tmp_path,monkeypatch):
    from hackpilot import engine
    import zipfile
    expected = tmp_path/'actual-opencore.efi'
    expected.write_bytes(b'RELEASE-2')
    validator_name = 'ocvalidate.exe' if os.name=='nt' else 'ocvalidate'
    archives = {}
    for index, boot in enumerate((b'RELEASE-1',b'RELEASE-2'),1):
        archive = tmp_path/f'archive-{index}.zip'
        with zipfile.ZipFile(archive,'w') as z:
            z.writestr('Release/Utilities/ocvalidate/'+validator_name,b'#!/bin/sh\n'+b'A'*25000)
            z.writestr('Release/X64/EFI/OC/OpenCore.efi',boot)
        archives[f'https://example.com/{index}.zip']=archive.read_bytes()
    feed={'OpenCorePkg':{'versions':[
        {'links':{'release':url},'hashes':{'release':{'sha256':hashlib.sha256(data).hexdigest()}}}
        for url,data in archives.items()]}}
    monkeypatch.setattr(engine,'request_json',lambda _:feed)
    calls=[]
    def downloader(url,target,*args,**kwargs):
        calls.append(url)
        contents=archives[url]
        Path(target).write_bytes(contents)
        return {'sha256':hashlib.sha256(contents).hexdigest()}
    monkeypatch.setattr(engine,'download',downloader)
    result=engine.setup_validator(tmp_path/'cache',expected_opencore=expected)
    manifest=json.loads((Path(result['root'])/'validator-manifest.json').read_text())
    assert manifest['opencore_sha256']==hashlib.sha256(b'RELEASE-2').hexdigest()
    assert len(calls)==2
    result=engine.setup_validator(tmp_path/'cache',expected_opencore=expected)
    assert result['cached'] and len(calls)==2


def test_first_install_interrupted_before_commit_can_be_cancelled(tmp_path,monkeypatch):
    drive,build,_=make_usb(tmp_path,monkeypatch,existing=False)
    original=usb.write_receipt
    def stop_during_staging(path,j):
        if j['phase']=='staged':raise SystemExit('simulated shutdown')
        return original(path,j)
    monkeypatch.setattr(usb,'write_receipt',stop_during_staging)
    with pytest.raises(SystemExit):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups')
    monkeypatch.setattr(usb,'write_receipt',original)
    assert (drive/'EFI.hackpilot-incoming').exists()
    assert usb.repair_usb('Q','REPAIR Q:',tmp_path/'backups')['action']=='cancelled'
    assert not (drive/'EFI.hackpilot-incoming').exists()
    assert not pending_receipts(tmp_path/'backups'/'transactions')


def test_repair_rejects_different_usb_identity(tmp_path,monkeypatch):
    drive,build,_=make_usb(tmp_path,monkeypatch)
    original=usb.write_receipt
    def stop(path,j):
        if j['phase']=='old_moved':raise SystemExit('shutdown')
        return original(path,j)
    monkeypatch.setattr(usb,'write_receipt',stop)
    with pytest.raises(SystemExit):usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups')
    monkeypatch.setattr(usb,'write_receipt',original)
    monkeypatch.setattr(usb,'list_usb',lambda:[{'drive_letter':'Q','filesystem':'FAT32','disk_number':22,'volume_id':'different'}])
    with pytest.raises(RuntimeError,match='identity changed'):
        usb.repair_usb('Q','REPAIR Q:',tmp_path/'backups')


def test_corrupt_usb_journal_is_visible_but_not_executable(tmp_path,monkeypatch):
    drive,build,_=make_usb(tmp_path,monkeypatch)
    location=tmp_path/'backups'/'transactions'
    location.mkdir(parents=True)
    (location/'usb-Q-corrupt.json').write_text('{not-json')
    pending=pending_receipts(location)
    assert len(pending)==1 and pending[0]['phase']=='corrupt'
    with pytest.raises(RuntimeError,match='ambiguous'):
        usb.repair_usb('Q','REPAIR Q:',tmp_path/'backups')


def test_boot_diagnostics_does_not_modify_files():
    from hackpilot.diagnostics import analyze_log
    result=analyze_log('[EB|#LOG:EXITBS:START]')
    assert result['recognized']
    assert any('firmware' in x['next_step'].lower() for x in result['findings'])
    assert not analyze_log('random unrelated text')['recognized']
    with pytest.raises(ValueError):analyze_log('')
    with pytest.raises(ValueError):analyze_log('A'*250_001)


def test_engine_cache_checks_entry_hash_before_use(tmp_path,monkeypatch):
    from hackpilot import engine
    cache=tmp_path/'cache'
    folder=cache/'opcore-simplify'
    (folder/'Scripts').mkdir(parents=True)
    (folder/'LICENSE').write_text('BSD-3')
    (folder/'Scripts'/'helper.py').write_text('example helper')
    (folder/'OpCore-Simplify.py').write_text('example')
    (cache/'engine-manifest.json').write_text(json.dumps({
      'repository':engine.ENGINE_REPO,'commit':'a'*40,
      'source_tree_sha256':engine.engine_tree_hash(folder)}))
    monkeypatch.setattr(engine,'request_json',lambda *_: (_ for _ in ()).throw(AssertionError('Network should not be used')))
    assert engine.setup_engine(cache)['cached']


def test_self_test_command_is_headless():
    import subprocess,sys
    from pathlib import Path
    project=Path(__file__).resolve().parents[1]
    result=subprocess.run([sys.executable,'-m','hackpilot.main','--self-test'],cwd=project,capture_output=True,text=True,timeout=15)
    assert result.returncode==0
    assert json.loads(result.stdout)['ok']


def test_modified_cached_source_is_refused(tmp_path):
    from hackpilot import engine
    cache=tmp_path/'cache'
    src=cache/'opcore-simplify'
    (src/'Scripts').mkdir(parents=True)
    (src/'LICENSE').write_text('BSD')
    (src/'Scripts'/'code.py').write_text('trusted')
    (src/'OpCore-Simplify.py').write_text('trusted')
    (cache/'engine-manifest.json').write_text(json.dumps({'repository':engine.ENGINE_REPO,
        'commit':'a'*40,'source_tree_sha256':engine.engine_tree_hash(src)}))
    assert engine.cached_engine_verified(cache)
    (src/'Scripts'/'code.py').write_text('tampered')
    assert not engine.cached_engine_verified(cache)


def test_engine_update_failure_rolls_back_existing_cache_and_manifest(tmp_path,monkeypatch):
    from hackpilot import engine
    import zipfile
    base=tmp_path/'cache'
    root=base/'opcore-simplify'
    (root/'Scripts').mkdir(parents=True)
    (root/'OpCore-Simplify.py').write_text('OLD')
    (root/'Scripts'/'helper.py').write_text('OLD')
    (root/'LICENSE').write_text('BSD')
    old_manifest={'repository':engine.ENGINE_REPO,'commit':'a'*40,
                  'source_tree_sha256':engine.engine_tree_hash(root)}
    (base/'engine-manifest.json').write_text(json.dumps(old_manifest))
    archive=tmp_path/'download.zip'
    with zipfile.ZipFile(archive,'w') as z:
        z.writestr('upstream/OpCore-Simplify.py','NEW')
        z.writestr('upstream/Scripts/helper.py','NEW')
        z.writestr('upstream/LICENSE','BSD')
    payload=archive.read_bytes()
    monkeypatch.setattr(engine,'request_json',lambda _:{'sha':'b'*40})
    def download(_url, dest,*args,**kwargs):
        Path(dest).write_bytes(payload)
        return {'sha256':hashlib.sha256(payload).hexdigest()}
    monkeypatch.setattr(engine,'download',download)
    def fail_manifest(_path, _data):raise OSError('disk full during manifest update')
    monkeypatch.setattr(engine,'_atomic_json',fail_manifest)
    with pytest.raises(OSError,match='disk full'):
        engine.setup_engine(base,refresh=True)
    assert (root/'OpCore-Simplify.py').read_text()=='OLD'
    assert engine.cached_engine_verified(base)
    assert json.loads((base/'engine-manifest.json').read_text())==old_manifest


def test_saved_deep_scan_requires_new_verification_after_restart(tmp_path):
    from hackpilot.server import State
    home=tmp_path/'data'
    report_dir=home/'SystemReport'
    (report_dir/'ACPI').mkdir(parents=True)
    report={'CPU':{'Processor Name':'Intel Core i7-8700K'},
            'GPU':{'Intel UHD 630':{'Device ID':'8086-3e92'}},
            'BIOS':{'Firmware Type':'UEFI'}}
    (report_dir/'Report.json').write_text(json.dumps(report))
    state=State(home=home)
    assert state.hardware and state.sniffer_file
    assert not state.status()['deep_scan_ready']
    assert not state.deep_scan_verified


def test_boot_log_diagnosis_api_requires_session_token(tmp_path):
    from hackpilot.server import State, create_server
    import http.client, re, threading
    server=create_server(State(demo=True,home=tmp_path/'local'))
    thread=threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    try:
        c=http.client.HTTPConnection('127.0.0.1',server.server_port)
        c.request('GET','/')
        html=c.getresponse().read().decode()
        token=re.search('name="hackpilot-token" content="([^"]+)"',html).group(1)
        c.request('POST','/api/diagnose',json.dumps({'log':'EXITBS:START'}),{'Content-Type':'application/json'})
        r=c.getresponse();assert r.status==403;r.read()
        c.request('POST','/api/diagnose',json.dumps({'log':'EXITBS:START'}),
                  {'Content-Type':'application/json','X-HackPilot-Token':token})
        r=c.getresponse();assert r.status==200
        assert json.loads(r.read())['recognized']
        c.close()
    finally:
        server.shutdown();server.server_close()


def test_board_id_can_be_read_only_from_valid_generated_efi(tmp_path):
    from hackpilot.recovery import board_id_from_efi
    build=_fixture_efi(tmp_path)
    config=build/'EFI'/'OC'/'config.plist'
    with config.open('rb') as stream: data=plistlib.load(stream)
    assert board_id_from_efi(build) is None
    data['PlatformInfo']['DataHub']={'BoardProduct':'Mac-7BA5B2D9E42DDD94'}
    with config.open('wb') as stream:plistlib.dump(data,stream)
    assert board_id_from_efi(build)=='Mac-7BA5B2D9E42DDD94'
    data['PlatformInfo']['DataHub']['BoardProduct']='Not a Mac model'
    with config.open('wb') as stream:plistlib.dump(data,stream)
    assert board_id_from_efi(build) is None
