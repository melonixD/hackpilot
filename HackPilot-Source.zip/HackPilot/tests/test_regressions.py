"""Regression checks for safety features added in HackPilot 0.5."""
import hashlib
import json
import os
import plistlib
from pathlib import Path
from types import SimpleNamespace

import pytest

import hackpilot.engine as engine
from hackpilot.efi import _safe_relative, efi_fingerprint, validate_efi
from hackpilot.server import State


def fixture_efi(tmp_path):
    build = tmp_path / 'LatestBuild'
    oc = build / 'EFI' / 'OC'
    (oc / 'Drivers').mkdir(parents=True)
    (oc / 'Kexts' / 'VirtualSMC.kext' / 'Contents').mkdir(parents=True)
    (build / 'EFI' / 'BOOT').mkdir(parents=True)
    for file in (build/'EFI'/'BOOT'/'BOOTx64.efi', oc/'OpenCore.efi',
                 oc/'Drivers'/'OpenRuntime.efi', oc/'Kexts'/'VirtualSMC.kext'/'Contents'/'Info.plist'):
        file.write_bytes(b'fixture')
    config = {'ACPI':{'Add':[]}, 'Kernel':{'Add':[
        {'Enabled':True,'BundlePath':'VirtualSMC.kext','ExecutablePath':'','PlistPath':'Contents/Info.plist'}]},
        'UEFI':{'Drivers':[{'Enabled':True,'Path':'OpenRuntime.efi'}]},
        'Misc':{}, 'PlatformInfo':{'Generic':{'SystemSerialNumber':'TEST','SystemUUID':'123'}}}
    with (oc/'config.plist').open('wb') as stream:
        plistlib.dump(config, stream)
    return build


def test_efi_fingerprint_changes_after_edit(tmp_path):
    build = fixture_efi(tmp_path)
    old = efi_fingerprint(build)
    (build/'EFI'/'OC'/'Drivers'/'OpenRuntime.efi').write_bytes(b'edited')
    assert efi_fingerprint(build) != old


def test_efi_fingerprint_refuses_symlinks(tmp_path):
    build = fixture_efi(tmp_path)
    try:
        (build/'EFI'/'OC'/'link').symlink_to(tmp_path, target_is_directory=True)
    except (NotImplementedError, OSError):
        pytest.skip('Symlinks unavailable')
    with pytest.raises(RuntimeError, match='Linked'):
        efi_fingerprint(build)


@pytest.mark.parametrize('path', ['../escape.aml', '/root/file.efi', 'C:/Windows/file.efi',
                                   'C:\\Windows\\file.efi', '//server/share', '', '..\\escape.aml'])
def test_file_references_reject_unsafe_paths(path):
    assert not _safe_relative(path)


def test_file_references_allow_normal_paths():
    assert _safe_relative('Contents/MacOS/Lilu')
    assert _safe_relative('SSDT-EC.aml')


def test_postvalidation_efi_tamper_blocks_usb(tmp_path, monkeypatch):
    s = State(home=tmp_path/'data')
    s.build_dir = fixture_efi(tmp_path)
    s.last_build = {'valid':True,'fingerprint':efi_fingerprint(s.build_dir)}
    (s.build_dir/'EFI'/'OC'/'OpenCore.efi').write_bytes(b'modified')
    copied = []
    monkeypatch.setattr('hackpilot.server.safe_usb_copy', lambda *a: copied.append(a))
    with pytest.raises(RuntimeError, match='changed after validation'):
        s.copy_usb('E','COPY TO E:')
    assert copied == []
    assert s.last_build is None


def test_invalid_import_does_not_invalidate_existing_efi(tmp_path):
    s = State(home=tmp_path/'data')
    original = {'valid':True,'fingerprint':'unchanged'}
    s.last_build = original
    with pytest.raises(ValueError):
        s.import_report({'not':'a hardware report'})
    assert s.last_build is original


def test_auto_setup_refuses_blocked_hardware_before_engine(tmp_path, monkeypatch):
    s = State(home=tmp_path/'data')
    s.sniffer_file = 'prepared.json'
    s.acpi_dir = 'ACPI'
    s.deep_scan_verified = True
    s.hardware = {'cpu':{'name':'Qualcomm Snapdragon X Elite'},'gpus':[{'name':'Adreno'}]}
    engine_runs = []
    monkeypatch.setattr(s,'install_engine',lambda:engine_runs.append(1))
    with pytest.raises(RuntimeError, match='blockers'):
        s.auto_setup()
    assert not engine_runs


def test_auto_setup_orchestrates_all_steps(tmp_path, monkeypatch):
    s = State(home=tmp_path/'data')
    calls = []
    def scan():
        calls.append('scan')
        s.sniffer_file, s.acpi_dir = 'r.json', 'ACPI'
        s.hardware = {'cpu':{'name':'Intel Core i7-9700K'},'gpus':[{'name':'AMD Radeon RX 580'}],
                      'network':[{'name':'ethernet'}],'audio':[{'name':'codec'}]}
    def prepare():
        calls.append('engine')
        s.engine_dir = '/engine'
    def build(target, selections=None):
        calls.append('build:'+target)
        s.last_build = {'valid':True}
        return {'validation':s.last_build}
    monkeypatch.setattr(s,'deep_scan',scan)
    monkeypatch.setattr(s,'install_engine',prepare)
    monkeypatch.setattr(s,'build',build)
    s.auto_setup('auto')
    assert calls == ['scan','engine','build:auto']


def test_failed_deep_scan_keeps_previous_report(tmp_path, monkeypatch):
    base = tmp_path/'cache'
    base.mkdir()
    binary = base/'Hardware-Sniffer-CLI.exe'
    binary.write_bytes(b'dummy binary')
    digest = hashlib.sha256(binary.read_bytes()).hexdigest()
    (base/'sniffer-manifest.json').write_text(json.dumps({'sha256':digest}))
    current = tmp_path/'SystemReport'
    (current/'ACPI').mkdir(parents=True)
    (current/'Report.json').write_text('{"important":"old"}')
    monkeypatch.setattr(engine,'os',SimpleNamespace(name='nt',urandom=os.urandom))
    monkeypatch.setattr(engine,'request_json',lambda *a:{'assets':[{'name':'Hardware-Sniffer-CLI.exe','browser_download_url':'https://example.com/cli.exe'}]})
    monkeypatch.setattr(engine.subprocess,'run',lambda *a,**kw:SimpleNamespace(returncode=1,stderr=b'failed'))
    with pytest.raises(RuntimeError,match='incomplete'):
        engine.deep_scan(base,current)
    assert (current/'Report.json').read_text() == '{"important":"old"}'
    assert (current/'ACPI').is_dir()


def test_failed_demo_not_allowed_preserves_validation(tmp_path):
    s = State(home=tmp_path/'data',demo=False)
    s.last_build = {'valid':True}
    with pytest.raises(ValueError,match='Demo mode'):
        s.demo_scan()
    assert s.last_build['valid']


def test_failed_engine_update_preserves_cached_engine(tmp_path, monkeypatch):
    base = tmp_path/'cache'
    root = base/'opcore-simplify'
    (root/'Scripts').mkdir(parents=True)
    (root/'OpCore-Simplify.py').write_text('old working engine')
    (root/'LICENSE').write_text('license')
    sha = 'a'*40
    monkeypatch.setattr(engine,'request_json',lambda *a: {'sha':sha})
    def corrupt_archive(url,target):
        Path(target).write_bytes(b'not a zip')
        return {'sha256':'fake','bytes':9,'url':url}
    monkeypatch.setattr(engine,'download',corrupt_archive)
    with pytest.raises(Exception):
        engine.setup_engine(base, refresh=True)
    assert (root/'OpCore-Simplify.py').read_text() == 'old working engine'


def test_recent_tasks_are_bounded(tmp_path):
    from threading import Event
    s = State(home=tmp_path/'data')
    # Retain completed task metadata only up to a small UI-friendly history.
    for _ in range(25):
        s.tasks[str(_)]={'name':'done','state':'done'}
    signal=Event()
    s.start('One more',lambda:signal.set())
    assert signal.wait(3)
    assert len(s.tasks) <= 12


def test_auto_setup_endpoint_requires_consent(tmp_path):
    import http.client
    import re
    import threading
    from hackpilot.server import create_server
    server = create_server(State(demo=True, home=tmp_path/'data'))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        conn = http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=3)
        conn.request('GET','/')
        html = conn.getresponse().read().decode()
        token = re.search(r'<meta name="hackpilot-token" content="([^"]+)">', html).group(1)
        conn.request('POST','/api/auto-setup',body='{}',
                     headers={'Content-Type':'application/json','X-HackPilot-Token':token})
        response = conn.getresponse()
        assert response.status == 400
        assert 'Consent' in response.read().decode()
        conn.close()
    finally:
        server.shutdown()
        server.server_close()


def test_upstream_darwin_range_is_oldest_to_newest():
    # The official OpCore-Simplify source uses native[0] <= target <= native[-1].
    from hackpilot.upstream_adapter import select_native_target
    parse = lambda value: tuple(map(int, value.split('.')))
    assert select_native_target(['20.0.0','25.99.99'], '24.5.0', '23', parse) == '23.99.99'
    assert select_native_target(['20.0.0','25.99.99'], '24.5.0', 'auto', parse) == '24.5.0'
    with pytest.raises(RuntimeError, match='outside'):
        select_native_target(['21.0.0','25.99.99'], '24.5.0', '20', parse)
    with pytest.raises(RuntimeError, match='outside'):
        select_native_target(['21.0.0','24.99.99'], '25.0.0', 'auto', parse)
