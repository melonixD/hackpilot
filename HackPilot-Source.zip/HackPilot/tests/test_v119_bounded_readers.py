"""Corrupted local files must fail closed without exhausting the GUI."""
from hackpilot import recovery, server


def test_oversized_board_config_is_rejected_before_parsing(tmp_path, monkeypatch):
    config = tmp_path / 'EFI' / 'OC' / 'config.plist'
    config.parent.mkdir(parents=True)
    with config.open('wb') as stream:
        stream.seek(8 * 1024 * 1024)
        stream.write(b'x')
    def forbidden(*args, **kwargs):
        raise AssertionError('Oversized config must not reach parser')
    monkeypatch.setattr(recovery.plistlib, 'loads', forbidden)
    assert recovery.board_id_from_efi(tmp_path) is None


def test_deeply_nested_recovery_metadata_is_rejected(tmp_path):
    folder = tmp_path / 'com.apple.recovery.boot'
    folder.mkdir()
    (folder / 'BaseSystem.dmg').write_bytes(b'image')
    (folder / 'BaseSystem.chunklist').write_bytes(b'index')
    (tmp_path / 'recovery-info.json').write_text('[' * 10000 + '0' + ']' * 10000)
    assert recovery.verify_recovery(folder) is False


def test_corrupt_nested_previous_scan_does_not_prevent_startup(tmp_path):
    report = tmp_path / 'SystemReport'
    report.mkdir()
    (report / "ACPI").mkdir()
    (report / 'Report.json').write_text('[' * 10000 + '0' + ']' * 10000)
    state = server.State(home=tmp_path)
    assert state.deep_scan_verified is False
