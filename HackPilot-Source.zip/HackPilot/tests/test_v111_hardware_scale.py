"""Large hardware inventories, cross-device identity and safe automatic choices."""
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from hackpilot.compat import assess
from hackpilot.hardware import sniffer_summary, imported_native
from hackpilot.hardware_scale import DISPLAY_LIMIT, network_preflight, unsupported_gpu
from hackpilot.upstream_adapter import bounded_device_combinations, guided_device_choice
from hackpilot.usb_mapping import merge_snapshots
from hackpilot.server import State


def large_sniffer():
    return {
        'CPU': {'Processor Name': 'Intel Core i9-10900K', 'Manufacturer': 'Intel'},
        'Motherboard': {'Name': 'Workstation', 'Platform': 'Desktop'},
        'BIOS': {'Firmware Type': 'UEFI'},
        'GPU': {**{f'GeForce RTX 5060 card #{i}': {'Manufacturer':'NVIDIA'} for i in range(250)},
                'AMD Radeon RX 6800': {'Manufacturer':'AMD', 'Device ID':'1002-73BF'}},
        'Network': {**{f'Hyper-V Virtual Ethernet Adapter #{i}': {'Device ID':'VIRTUAL'} for i in range(350)},
                    'Intel Ethernet I225-V': {'Manufacturer':'Intel','Device ID':'8086-15F3'}},
        'Sound': {f'Codec {i}': {} for i in range(420)},
        'Storage Controllers': {f'Storage {i}': {} for i in range(400)},
    }


def test_large_sniffer_preserves_device_counts_and_usable_candidates():
    raw=large_sniffer()
    summary=sniffer_summary(raw)
    assert len(summary['gpus']) == DISPLAY_LIMIT
    assert len(summary['network']) == DISPLAY_LIMIT
    assert len(summary['audio']) == DISPLAY_LIMIT
    assert summary['device_counts']['gpus'] == 251
    assert summary['device_counts']['network'] == 351
    assert summary['device_counts']['storage'] == 400
    assert any(x['name'] == 'AMD Radeon RX 6800' for x in summary['gpus'])
    assert any(x['name'] == 'Intel Ethernet I225-V' for x in summary['network'])
    assert network_preflight(summary['network'])['candidate']
    assert assess(summary)['can_attempt']
    assert len(raw['GPU']) == 251  # full report is never truncated for EFI generation


def test_large_native_import_keeps_rare_usable_adapters():
    data={'cpu':{'name':'Intel i7'},
          'gpus':[{'name':f'NVIDIA RTX 5060 #{i}'} for i in range(160)]+[{'name':'Radeon RX 6600'}],
          'network':[{'name':f'VirtualBox Host-Only Adapter #{i}'} for i in range(300)]+[{'name':'Realtek PCIe GBE'}]}
    summary=imported_native(data)
    assert len(summary['gpus'])==DISPLAY_LIMIT
    assert summary['gpus'][-1]['name']=='Radeon RX 6600'
    assert summary['network'][-1]['name']=='Realtek PCIe GBE'
    assert summary['device_counts']['gpus']==161
    assert summary['device_counts']['network']==301


@pytest.mark.parametrize('name', [
    'NVIDIA GeForce RTX 5060', 'AMD Radeon RX 7900 XTX', 'Radeon RX 7800 XT',
    'RX 6500 XT', 'AMD RX 6700 XT', 'Intel Arc A770', 'Intel Iris Xe',
    'NVIDIA Quadro RTX 5000', 'NVIDIA RTX A4000', 'AMD Radeon Pro W7900',
    'AMD Radeon RX 9070 XT',
])
def test_known_unsuitable_native_acceleration_never_classified_as_safe(name):
    assert unsupported_gpu(name)
    assert not assess({'cpu': {'name': 'Intel Core i7-10700'}, 'gpus':[{'name':name}]})['can_attempt']


def test_mixed_unsupported_and_potential_gpu_still_needs_review_not_total_block():
    h={'cpu':{'name':'Intel Core i7-10700'},
       'gpus':[{'name':'NVIDIA RTX 5060'},{'name':'Radeon RX 6800'}]}
    assert assess(h)['can_attempt']
    assert not unsupported_gpu('Radeon RX 6800')


def test_virtual_only_network_cannot_enable_one_click():
    devices=[{'name':'Hyper-V Virtual Ethernet Adapter'},
             {'name':'WireGuard VPN Tunnel'},{'name':'VirtualBox Host-Only Ethernet Adapter'}]
    assert not network_preflight(devices)['candidate']
    assert network_preflight(devices+[{'name':'Intel I225-V Ethernet'}])['candidate']


def test_large_gpu_groups_are_linear_instead_of_exponential():
    combos=bounded_device_combinations(set(range(350)))
    assert len(combos)==350
    assert combos[0]==[0] and combos[-1]==[349]
    assert all(len(group)==1 for group in combos)


@pytest.mark.parametrize('indices', [[-1, 2], '123', list(range(1025)), [True, 1]])
def test_invalid_upstream_device_groups_refuse_safely(indices):
    with pytest.raises(RuntimeError):
        bounded_device_combinations(indices)


def test_guided_gpu_disables_all_other_candidates():
    disabled=[]
    def disable(group, name, props):
        disabled.append((group,name))
    customizer=SimpleNamespace(_disable_device=disable,selected_devices={})
    devices={f'GPU {i}':{'Device ID':str(i)} for i in range(150)}
    chosen=guided_device_choice(customizer,'GPU',devices,None,{'GPU':'GPU 149'})
    assert chosen==['GPU 149']
    assert len(disabled)==149
    assert ('GPU','GPU 149') not in disabled
    assert list(customizer.selected_devices['GPU'])==['GPU 149']


def usb_controller(id_suffix='0', pci=None, speed=2, seen=False):
    return {'id':'bdf:0:20:'+id_suffix,'hub':'USB Root Hub','class':48,
            'identifiers':{'bdf':[0,20,int(id_suffix)], 'pci_id':pci or ['8086','A36D']},
            'ports':[{'index':1,'speed':speed,'selected':seen,'seen':seen,
                      'user_selected':seen,'connector':3,'devices':[],
                      'companion_hub':'','companion_port':None}]}


def test_usb_history_does_not_cross_replaced_controller_same_bdf():
    old={'controllers':[usb_controller(seen=True)]}
    new={'controllers':[usb_controller(pci=['1022','43D5'],seen=False)]}
    merged=merge_snapshots(old,new)
    assert not merged['controllers'][0]['ports'][0]['selected']
    assert not merged['controllers'][0]['ports'][0]['seen']


def test_usb_history_does_not_cross_changed_port_speed():
    old={'controllers':[usb_controller(seen=True)]}
    new={'controllers':[usb_controller(speed=3,seen=False)]}
    merged=merge_snapshots(old,new)
    assert not merged['controllers'][0]['ports'][0]['selected']
    assert not merged['controllers'][0]['ports'][0]['seen']


def test_usb_history_same_device_still_retains_visited_port():
    old={'controllers':[usb_controller(seen=True)]}
    new={'controllers':[usb_controller(seen=False)]}
    merged=merge_snapshots(old,new)
    assert merged['controllers'][0]['ports'][0]['selected']
    assert merged['controllers'][0]['ports'][0]['seen']


def test_cached_device_choices_avoid_reparsing_large_report(tmp_path,monkeypatch):
    state=State(home=tmp_path/'app')
    path=tmp_path/'report.json';path.write_text(json.dumps(large_sniffer()))
    state.sniffer_file=str(path)
    one=state.device_choices()
    assert 'GPU' in one and len(one['GPU'])==251
    # If re-read, this patched reader fails. Cache should serve same snapshot.
    import hackpilot.server as server
    original=server.json.loads
    def refuse(*args,**kwargs):
        raise AssertionError('unexpected repeated parsing')
    monkeypatch.setattr(server.json,'loads',refuse)
    assert state.device_choices()==one
    monkeypatch.setattr(server.json,'loads',original)
