"""v0.9 reliability: cache integrity, source recovery, and adversarial inputs."""
import hashlib
import json
import os
from pathlib import Path
import zipfile

import pytest

from hackpilot import engine
from hackpilot.compat import assess
from hackpilot.hardware import imported_native, sniffer_summary
from hackpilot.recovery import select_recovery_pair
from hackpilot.server import State
from hackpilot.upstream_adapter import select_native_target


def _parse_version(value):
    return tuple(int(x) for x in value.split('.'))


def test_major_version_accepts_compatible_point_release():
    actual = select_native_target(('20.0.0','25.2.0'),'24.5.0','25',_parse_version)
    assert actual == '25.2.0'
    with pytest.raises(RuntimeError):
        select_native_target(('20.0.0','24.6.0'),'24.5.0','25',_parse_version)


def test_major_version_rejects_pre_minimum_release():
    with pytest.raises(RuntimeError):
        select_native_target(('25.3.0','26.0.0'),'25.7.0','24',_parse_version)


def test_cached_engine_assets_are_fingerprinted(tmp_path):
    source = tmp_path/'cache'/'opcore-simplify'
    scripts = source/'Scripts'
    scripts.mkdir(parents=True)
    (source/'OpCore-Simplify.py').write_text('print("hello")')
    (source/'LICENSE').write_text('test license')
    (scripts/'component.py').write_text('from . import dataset')
    data = scripts/'dataset.json'
    data.write_text('{"gpu":"supported"}')
    digest = engine.engine_tree_hash(source)
    (tmp_path/'cache'/'engine-manifest.json').write_text(json.dumps({
        'repository':engine.ENGINE_REPO,
        'commit':'a'*40,
        'source_tree_sha256':digest,
    }))
    assert engine.cached_engine_verified(tmp_path/'cache')
    data.write_text('{"gpu":"unsupported"}')
    assert not engine.cached_engine_verified(tmp_path/'cache')


def test_engine_bytecode_removed_before_execute(tmp_path):
    scripts = tmp_path/'Scripts'
    stale = scripts/'__pycache__'
    stale.mkdir(parents=True)
    (stale/'component.cpython-312.pyc').write_bytes(b'malicious')
    (scripts/'component.py').write_text('print("safe")')
    engine.clean_engine_bytecode(tmp_path)
    assert not stale.exists()
    assert (scripts/'component.py').exists()


def test_plain_pyc_outside_cache_rejected(tmp_path):
    scripts = tmp_path/'Scripts'
    scripts.mkdir()
    (tmp_path/'OpCore-Simplify.py').write_text('print("hello")')
    (tmp_path/'LICENSE').write_text('license')
    (scripts/'valid.py').write_text('print(1)')
    (scripts/'rogue.pyc').write_bytes(b'rogue bytecode')
    with pytest.raises(RuntimeError,match='bytecode'):
        engine.engine_tree_hash(tmp_path)


def test_recovery_pair_rejects_mismatched_names(tmp_path):
    (tmp_path/'BaseSystem.dmg').write_bytes(b'fake-dmg')
    (tmp_path/'RecoveryImage.chunklist').write_bytes(b'fake-chunklist')
    with pytest.raises(RuntimeError,match='matching'):
        select_recovery_pair(tmp_path)


def test_recovery_pair_rejects_different_directories(tmp_path):
    d = tmp_path/'one'; c = tmp_path/'two'; d.mkdir(); c.mkdir()
    (d/'BaseSystem.dmg').write_bytes(b'fake-dmg')
    (c/'BaseSystem.chunklist').write_bytes(b'fake-chunklist')
    with pytest.raises(RuntimeError,match='matching'):
        select_recovery_pair(tmp_path)


def test_recovery_pair_selects_matching_bundle(tmp_path):
    (tmp_path/'BaseSystem.dmg').write_bytes(b'fake-dmg')
    (tmp_path/'RecoveryImage.dmg').write_bytes(b'fake-other-image')
    (tmp_path/'RecoveryImage.chunklist').write_bytes(b'fake-other-list')
    chosen = select_recovery_pair(tmp_path)
    assert chosen[0].name == 'RecoveryImage.dmg'
    assert chosen[1].name == 'RecoveryImage.chunklist'


def test_import_rejects_bad_json_shapes_and_keeps_prior_state(tmp_path):
    state=State(home=tmp_path/'home')
    state.hardware={'cpu':{'name':'Intel Core i7'},'gpus':[{'name':'AMD Radeon'}]}
    original=state.hardware
    with pytest.raises(ValueError,match='gpus'):
        state.import_report({'cpu':{'name':'Intel Core i7'},'gpus':['bad']})
    assert state.hardware is original
    assert state.status()['hardware'] is original


def test_import_rejects_bad_sniffer_sections():
    with pytest.raises(ValueError,match='GPU'):
        sniffer_summary({'CPU':{'Processor Name':'Intel'},'GPU':[{'name':'invalid'}]})


def test_compat_handles_corrupt_firmware_without_throwing():
    result=assess({'cpu':{'name':'Intel Core i5'}, 'gpus':[{'name':'AMD Radeon RX 580'}],
                   'firmware':['not-an-object']})
    assert result['can_attempt']
    assert not assess({'cpu':123, 'gpus':[]})['can_attempt']


def test_validator_manifest_failure_restores_previous_binary(tmp_path, monkeypatch):
    suffix = 'ocvalidate.exe' if os.name=='nt' else 'ocvalidate'
    cache = tmp_path/'cache'
    base = cache/'validator'
    base.mkdir(parents=True)
    validator = base/suffix
    validator.write_bytes(b'old-validator')
    manifest = base/'validator-manifest.json'
    original_manifest = b'{"old":true}'
    manifest.write_bytes(original_manifest)
    archive=tmp_path/'validator.zip'
    with zipfile.ZipFile(archive,'w') as z:
        z.writestr('Release/Utilities/ocvalidate/'+suffix,b'VALIDATOR\n'+b'x'*30000)
        z.writestr('Release/X64/EFI/OC/OpenCore.efi',b'NEW-OPENCORE')
    bytes_zip=archive.read_bytes()
    url='https://example.com/oc.zip'
    metadata={'OpenCorePkg':{'versions':[{'links':{'release':url},
                  'hashes':{'release':{'sha256':hashlib.sha256(bytes_zip).hexdigest()}},
                  'version':'1.0'}]}}
    monkeypatch.setattr(engine,'request_json',lambda _:metadata)
    monkeypatch.setattr(engine,'download',lambda _, target, **kw: (
        Path(target).write_bytes(bytes_zip) or {'sha256': hashlib.sha256(bytes_zip).hexdigest()}))
    # The fake download hook must return a receipt, not an integer.
    def downloader(_url,target,**kw):
        Path(target).write_bytes(bytes_zip)
        return {'sha256':hashlib.sha256(bytes_zip).hexdigest()}
    monkeypatch.setattr(engine,'download',downloader)
    old_atomic = engine._atomic_json
    def fail_manifest(path,payload):
        if Path(path)==manifest:
            raise OSError('disk full')
        return old_atomic(path,payload)
    monkeypatch.setattr(engine,'_atomic_json',fail_manifest)
    with pytest.raises(OSError,match='disk full'):
        engine.setup_validator(cache,refresh=True)
    assert validator.read_bytes() == b'old-validator'
    assert manifest.read_bytes() == original_manifest
    assert not (base/(suffix+'.rollback')).exists()
    assert not (base/(suffix+'.incoming')).exists()


def test_usb_repair_never_restores_corrupted_old_directory(tmp_path, monkeypatch):
    from hackpilot import usb
    from test_quality import make_usb
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    original = (drive/'EFI'/'OC'/'config.plist').read_bytes()
    real_write = usb.write_receipt

    def simulated_crash(path, data):
        if data['phase'] == 'old_moved':
            raise SystemExit('power loss')
        return real_write(path,data)

    monkeypatch.setattr(usb, 'write_receipt', simulated_crash)
    with pytest.raises(SystemExit):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups')
    monkeypatch.setattr(usb, 'write_receipt', real_write)
    # The original EFI has become damaged between disk transfer and restart.
    (drive/'EFI.hackpilot-previous'/'OC'/'config.plist').write_bytes(b'broken')
    result = usb.repair_usb('Q','REPAIR Q:',tmp_path/'backups')
    assert result['action'] == 'restored'
    assert (drive/'EFI'/'OC'/'config.plist').read_bytes() == original
    assert list(drive.glob('EFI.hackpilot-damaged-*'))
    assert not (drive/'EFI.hackpilot-previous').exists()
    assert not (drive/'EFI.hackpilot-restore').exists()


def test_usb_repair_aborts_when_both_original_and_backup_are_bad(tmp_path, monkeypatch):
    from hackpilot import usb
    from test_quality import make_usb
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    real_write = usb.write_receipt
    def simulated_crash(path, data):
        if data['phase'] == 'old_moved':
            raise SystemExit('power loss')
        return real_write(path, data)
    monkeypatch.setattr(usb,'write_receipt',simulated_crash)
    with pytest.raises(SystemExit):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups')
    monkeypatch.setattr(usb,'write_receipt',real_write)
    (drive/'EFI.hackpilot-previous'/'OC'/'config.plist').write_bytes(b'damaged')
    for backup in (tmp_path/'backups').glob('*.zip'):
        backup.write_bytes(b'corrupt')
    with pytest.raises(RuntimeError,match='no verified backup'):
        usb.repair_usb('Q','REPAIR Q:',tmp_path/'backups')
    assert not (drive/'EFI').exists()
    assert (drive/'EFI.hackpilot-previous').exists()


def test_versioned_validators_remain_available_when_other_version_is_installed(tmp_path, monkeypatch):
    cache=tmp_path/'cache'
    suffix='ocvalidate.exe' if os.name=='nt' else 'ocvalidate'
    packages={}
    for num in (1,2):
        path=tmp_path/f'package-{num}.zip'
        boot=f'OpenCore-{num}'.encode()
        with zipfile.ZipFile(path,'w') as z:
            z.writestr('Release/X64/EFI/OC/OpenCore.efi',boot)
            z.writestr('Release/Utilities/ocvalidate/'+suffix,b'#!/bin/sh\n'+str(num).encode()*30000)
        packages[num]=(path.read_bytes(),boot)
    def feed(_):
        return {'OpenCorePkg':{'versions':[
           {'links':{'release':f'https://example.com/{num}.zip'},
            'hashes':{'release':{'sha256':hashlib.sha256(packages[num][0]).hexdigest()}}}
           for num in (1,2)]}}
    def download(url,target,**_):
        num=int(url.split('/')[-1].split('.')[0])
        data=packages[num][0]
        Path(target).write_bytes(data)
        return {'sha256':hashlib.sha256(data).hexdigest()}
    monkeypatch.setattr(engine,'request_json',feed)
    monkeypatch.setattr(engine,'download',download)
    validator_dirs=[]
    for num in (1,2):
        boot=tmp_path/f'boot-{num}.efi'
        boot.write_bytes(packages[num][1])
        info=engine.setup_validator(cache,expected_opencore=boot)
        validator_dirs.append(Path(info['root']))
    assert validator_dirs[0] != validator_dirs[1]
    assert (validator_dirs[0]/suffix).is_file()
    assert (validator_dirs[1]/suffix).is_file()
    boot=tmp_path/'boot-1.efi'
    cached=engine.setup_validator(cache,expected_opencore=boot)
    assert cached['cached'] and Path(cached['root']) == validator_dirs[0]


def test_restart_selects_validator_matching_current_efi(tmp_path):
    state=State(home=tmp_path/'user')
    boot=state.build_dir/'EFI'/'OC'/'OpenCore.efi'
    boot.parent.mkdir(parents=True)
    boot.write_bytes(b'preserved-opencore')
    digest=hashlib.sha256(boot.read_bytes()).hexdigest()
    versioned=state.cache/'validators'/digest
    versioned.mkdir(parents=True)
    (versioned/('ocvalidate.exe' if os.name=='nt' else 'ocvalidate')).write_bytes(b'preserved-validator')
    fresh=State(home=tmp_path/'user')
    assert Path(fresh.validator_dir)==versioned


def test_archive_preserves_empty_directories_needed_for_efi_fingerprint(tmp_path):
    archive=tmp_path/'backup.zip'
    with zipfile.ZipFile(archive,'w') as z:
        z.writestr('EFI/',b'')
        z.writestr('EFI/OC/',b'')
        z.writestr('EFI/OC/Tools/',b'')
        z.writestr('EFI/OC/config.plist',b'test')
    output=tmp_path/'restored'
    engine.safe_unzip(archive,output)
    assert (output/'EFI'/'OC'/'Tools').is_dir()
    assert (output/'EFI'/'OC'/'config.plist').read_bytes()==b'test'
