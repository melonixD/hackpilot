"""P0 component and saved-mapping regressions uncovered by the v1.6 audit."""
import copy
import json
import plistlib
import struct
from pathlib import Path

import pytest

from hackpilot.efi_audit import audit_efi_components, _macho_x64, _uefi_x64
from hackpilot import server
from hackpilot import usb_mapping
from test_v12_component_audit import fixture, save_config
from test_v15_usb_mapping import snapshot


def _kext_bin(build):
    return build/'EFI'/'OC'/'Kexts'/'Lilu.kext'/'Contents'/'MacOS'/'Lilu'


def test_truncated_kext_with_valid_magic_and_cpu_no_longer_passes(tmp_path):
    build, _ = fixture(tmp_path)
    # This eight-byte prefix was previously accepted as a valid kext binary.
    _kext_bin(build).write_bytes(b'\xcf\xfa\xed\xfe'+struct.pack('<I',0x01000007))
    assert any('truncated Mach-O' in x for x in audit_efi_components(build)['errors'])


def test_macho_with_load_commands_extending_beyond_end_is_rejected(tmp_path):
    build, _ = fixture(tmp_path)
    binary = _kext_bin(build)
    raw=bytearray(binary.read_bytes())
    struct.pack_into('<I',raw,20,0xFFFFFFF0)  # sizeofcmds
    binary.write_bytes(raw)
    assert any('load commands' in x for x in audit_efi_components(build)['errors'])


def test_macho_with_zero_or_broken_load_command_length_is_rejected(tmp_path):
    build,_=fixture(tmp_path)
    binary=_kext_bin(build)
    raw=bytearray(binary.read_bytes())
    struct.pack_into('<I',raw,36,0)
    binary.write_bytes(raw)
    assert 'invalid Mach-O load command length' in _macho_x64(binary)


def test_valid_universal_macho_has_bounds_checked(tmp_path):
    build,_=fixture(tmp_path)
    thin=_kext_bin(build).read_bytes()
    # Fat header with one x86_64 slice, big-endian and aligned at byte 32.
    fat=bytearray(32+len(thin))
    fat[:4]=b'\xca\xfe\xba\xbe'
    struct.pack_into('>I',fat,4,1)
    struct.pack_into('>IIIII',fat,8,0x01000007,3,32,len(thin),2)
    fat[32:]=thin
    target=tmp_path/'fat.macho';target.write_bytes(fat)
    assert _macho_x64(target) is None
    struct.pack_into('>I',fat,20,10**7)  # declared FAT slice size
    target.write_bytes(fat)
    assert 'bounds' in _macho_x64(target)


def test_uefi_with_valid_signature_but_cut_section_table_is_rejected(tmp_path):
    build,_=fixture(tmp_path)
    image=build/'EFI'/'OC'/'Drivers'/'HfsPlus.efi'
    image.write_bytes(image.read_bytes()[:390])
    assert 'truncated PE optional header or section table' in _uefi_x64(image)


def test_uefi_with_section_beyond_file_is_rejected(tmp_path):
    build,_=fixture(tmp_path)
    image=build/'EFI'/'OC'/'Drivers'/'HfsPlus.efi'
    raw=bytearray(image.read_bytes());section=128+24+240
    struct.pack_into('<I',raw,section+16,10**7)
    image.write_bytes(raw)
    assert 'PE section extends beyond' in _uefi_x64(image)


def test_x86_only_lilu_cannot_satisfy_64bit_hackintosh(tmp_path):
    build,cfg=fixture(tmp_path)
    cfg['Kernel']['Add'][0]['Arch']='i386'
    save_config(build,cfg)
    errors=audit_efi_components(build,target_darwin='24.0.0')['errors']
    assert any('Required Lilu' in x for x in errors)
    assert any('missing enabled dependency' in x for x in errors)


def test_invalid_arch_never_silently_loads(tmp_path):
    build,cfg=fixture(tmp_path)
    cfg['Kernel']['Add'][0]['Arch']='arm64'
    save_config(build,cfg)
    assert any('Invalid kext Arch' in x for x in audit_efi_components(build,target_darwin='24.0.0')['errors'])


def test_reversed_kernel_window_cannot_hide_required_kext(tmp_path):
    build,cfg=fixture(tmp_path)
    cfg['Kernel']['Add'][0].update(MinKernel='25.0.0',MaxKernel='20.0.0')
    save_config(build,cfg)
    errors=audit_efi_components(build,target_darwin='24.0.0')['errors']
    assert any('MinKernel is newer' in x for x in errors)


@pytest.mark.parametrize('broken',[
    {'controllers':[{'id':'only'}]},
    {'controllers':[{'id':'dup','identifiers':{},'class':48,'ports':[]}, {'id':'dup','identifiers':{},'class':48,'ports':[]}]},
    {'controllers':[{'id':'bad','identifiers':{},'class':48,'ports':[{'index':1,'selected':'true','seen':True,'speed':2}]}]},
    {'controllers': 'not-an-array'},
    {'controllers':[{'id':'bad','identifiers':{},'class':48,'ports':[{'index':1,'selected':True,'seen':True,'speed':2,'connector':-1}]}]},
])
def test_corrupt_saved_usb_map_never_crashes_status_or_build(tmp_path,broken,monkeypatch):
    state=server.State(home=tmp_path)
    state.mapping_dir.joinpath('ports.json').write_text(json.dumps(broken))
    assert state._read_usb_map() is None
    status=state.status()
    assert not status['usb_mapping']['map_ready']
    # Stub only the unrelated preflight paths. An invalid map must stop the
    # build before the subprocess or live hardware is touched.
    state.deep_scan_verified=True
    state.sniffer_file=str(tmp_path/'Report.json')
    Path(state.sniffer_file).write_text('{"CPU": {}}')
    state.acpi_dir=str(tmp_path/'ACPI');Path(state.acpi_dir).mkdir()
    state.engine_dir=str(state.cache/'opcore-simplify')
    state.hardware={'cpu':{'name':'Intel Core i5'},'gpus':[{'name':'Intel HD 630'}]}
    monkeypatch.setattr(server,'cached_engine_verified',lambda cache:True)
    monkeypatch.setattr(server,'run_auto_builder',lambda *a,**kw:pytest.fail('No build must run'))
    with pytest.raises(RuntimeError,match='Saved USB mapping scan is damaged'):
        state.build()


def test_incomplete_usb_mapping_is_not_ignored_during_efi_generation(tmp_path,monkeypatch):
    data=snapshot()
    state=server.State(home=tmp_path)
    (state.mapping_dir/'ports.json').write_text(json.dumps(data))
    state.deep_scan_verified=True
    state.sniffer_file=str(tmp_path/'Report.json')
    Path(state.sniffer_file).write_text('{"CPU": {}}')
    state.acpi_dir=str(tmp_path/'ACPI');Path(state.acpi_dir).mkdir()
    state.engine_dir=str(state.cache/'opcore-simplify')
    state.hardware={'cpu':{'name':'Intel Core i5'},'gpus':[{'name':'Intel HD 630'}]}
    monkeypatch.setattr(server,'cached_engine_verified',lambda cache:True)
    monkeypatch.setattr(server,'run_auto_builder',lambda *a,**kw:pytest.fail('No build must run'))
    with pytest.raises(RuntimeError,match='USB mapping is incomplete'):
        state.build()

@pytest.mark.parametrize('name', ['CON', 'NUL.txt', 'COM1.cfg', 'folder./x.py', 'folder /x.py', 'folder:stream', 'bad<name>.py'])
def test_untrusted_upstream_archives_reject_windows_reserved_paths(tmp_path,name):
    import zipfile
    from hackpilot.engine import safe_unzip
    archive=tmp_path/'bad.zip'
    with zipfile.ZipFile(archive,'w') as zipf:
        zipf.writestr(name, b'payload')
    with pytest.raises(ValueError,match='Unsafe ZIP archive path'):
        safe_unzip(archive,tmp_path/'unpacked')


def test_standalone_engine_worker_can_extract_an_archive(tmp_path):
    """The adapter also imports engine.py outside the package context."""
    import subprocess,sys,zipfile
    root=Path(__file__).resolve().parents[1]
    with zipfile.ZipFile(tmp_path/'valid.zip','w') as zipf:
        zipf.writestr('upstream/Scripts/test.py',b'ok')
    command="""import sys;sys.path.insert(0,sys.argv[1]);import engine;engine.safe_unzip(sys.argv[2],sys.argv[3])"""
    result=subprocess.run([sys.executable,'-c',command,str(root/'hackpilot'),str(tmp_path/'valid.zip'),str(tmp_path/'unpack')],capture_output=True,text=True)
    assert result.returncode==0,result.stderr
    assert (tmp_path/'unpack'/'upstream'/'Scripts'/'test.py').read_bytes()==b'ok'


def test_non_kext_macho_is_rejected_even_with_valid_x86_header(tmp_path):
    build,_=fixture(tmp_path)
    executable=_kext_bin(build)
    binary=bytearray(executable.read_bytes())
    struct.pack_into('<I',binary,12,2)  # MH_EXECUTE is userland, not MH_KEXT_BUNDLE
    executable.write_bytes(binary)
    assert any('not a kernel extension bundle' in msg for msg in audit_efi_components(build)['errors'])


def test_oversize_mapping_file_is_not_loaded(tmp_path):
    state=server.State(home=tmp_path)
    (state.mapping_dir/'ports.json').write_bytes(b' '*(4*1024*1024+1))
    assert state._read_usb_map() is None
    assert state.status()['usb_mapping']['controllers']==[]
