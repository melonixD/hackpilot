"""v1.9: reject invalid local API payloads and stale EFI metadata."""
import http.client
import json
import re
import threading
from pathlib import Path

import pytest

from hackpilot.server import State, create_server
from hackpilot import usb_mapping
from hackpilot.efi_audit import audit_efi_components
from test_v12_component_audit import fixture, save_config
from test_v15_usb_mapping import snapshot


def _api(tmp_path, payload, headers=None, *, method='POST'):
    state=State(demo=True,home=tmp_path/'home')
    app=create_server(state)
    thread=threading.Thread(target=app.serve_forever,daemon=True)
    thread.start()
    try:
        conn=http.client.HTTPConnection('127.0.0.1',app.server_port,timeout=3)
        conn.request('GET','/')
        index=conn.getresponse().read().decode('utf-8')
        token=re.search(r'name="hackpilot-token" content="([^"]+)"',index).group(1)
        headers={'Content-Type':'application/json','X-HackPilot-Token':token, **(headers or {})}
        conn.request(method,'/api/diagnose',body=payload,headers=headers)
        response=conn.getresponse()
        status=response.status
        body=json.loads(response.read())
        conn.close()
        assert state.diagnosis is None
        return status,body
    finally:
        app.shutdown();app.server_close()


@pytest.mark.parametrize('payload',[b'[1,2,3]',b'"string"',b'null',b'3',b'true',b'{not-json'])
def test_invalid_json_types_and_syntax_return_readable_error(tmp_path,payload):
    status,body=_api(tmp_path,payload)
    assert status==400
    assert 'error' in body


def test_non_json_body_is_rejected(tmp_path):
    status,body=_api(tmp_path,b'{"log":"abc"}',{'Content-Type':'text/plain'})
    assert status==415
    assert body['error']=='Expected application/json'


def test_non_numeric_content_length_is_rejected_without_state_change(tmp_path):
    status,body=_api(tmp_path,b'',{'Content-Length':'garbage'})
    assert status==400
    assert body['error']=='Invalid Content-Length'


def test_status_survives_disappearing_recovery(tmp_path,monkeypatch):
    state=State(home=tmp_path/'home')
    recovery=tmp_path/'Recovery';recovery.mkdir()
    for name in ('BaseSystem.dmg','BaseSystem.chunklist'):
        (recovery/name).write_bytes(b'valid shape only')
    state.recovery_dir=str(recovery)
    state.recovery_verified=True
    assert state._cached_recovery_present()
    (recovery/'BaseSystem.dmg').unlink()
    assert not state._cached_recovery_present()
    assert state.status()['recovery_ready'] is False


def test_map_ready_rejects_unexpected_executable_even_with_valid_manifest(tmp_path):
    data=snapshot()
    result=usb_mapping.generate_utbmap(data,tmp_path)
    (tmp_path/'usb-map-manifest.json').write_text(json.dumps({
        'source':usb_mapping.REPO, 'sha256':result['sha256'],
        'selection_sha256':usb_mapping.selection_hash(data)}))
    assert usb_mapping.map_is_ready(tmp_path,data)
    (tmp_path/'UTBMap.kext'/'Contents'/'MacOS').mkdir()
    (tmp_path/'UTBMap.kext'/'Contents'/'MacOS'/'bad').write_bytes(b'not a codeless map')
    assert not usb_mapping.map_is_ready(tmp_path,data)


def test_map_ready_rejects_corrupt_plist_with_recalculated_hash(tmp_path):
    data=snapshot()
    result=usb_mapping.generate_utbmap(data,tmp_path)
    plist=tmp_path/'UTBMap.kext'/'Contents'/'Info.plist'
    plist.write_bytes(b'not a plist')
    (tmp_path/'usb-map-manifest.json').write_text(json.dumps({
        'source':usb_mapping.REPO, 'sha256':usb_mapping._hash_file(plist),
        'selection_sha256':usb_mapping.selection_hash(data)}))
    assert not usb_mapping.map_is_ready(tmp_path,data)


def test_i386_enabled_kext_is_error_instead_of_silent_omission(tmp_path):
    build,cfg=fixture(tmp_path)
    cfg['Kernel']['Add'][0]['Arch']='i386'
    save_config(build,cfg)
    errors=audit_efi_components(build,target_darwin='24.0.0')['errors']
    assert any('i386-only' in e for e in errors)


def test_second_app_cannot_modify_same_workspace(tmp_path):
    from hackpilot.workspace_lock import workspace_lock
    with workspace_lock(tmp_path):
        with pytest.raises(RuntimeError, match='Another HackPilot window'):
            with workspace_lock(tmp_path):
                pytest.fail('second app entered already locked workspace')
    with workspace_lock(tmp_path):
        assert (tmp_path/'workspace.lock').is_file()


def test_unrelated_apps_can_use_independent_workspaces(tmp_path):
    from hackpilot.workspace_lock import workspace_lock
    with workspace_lock(tmp_path/'a'):
        with workspace_lock(tmp_path/'b'):
            pass


def test_gui_worker_respects_other_instance_workspace_lock(tmp_path):
    from hackpilot.workspace_lock import workspace_lock
    import time
    state=State(home=tmp_path/'home')
    with workspace_lock(state.home):
        task_id=state.start('test operation', lambda: pytest.fail('must not run concurrently'))['task_id']
        for _ in range(200):
            if state.status()['tasks'][task_id]['state'] != 'running':
                break
            time.sleep(0.01)
        assert state.status()['tasks'][task_id]['state']=='error'
        assert 'Another HackPilot window' in state.status()['tasks'][task_id]['message']


def test_invalid_manifest_darwin_is_reported_not_raised(tmp_path):
    build,cfg=fixture(tmp_path)
    result=audit_efi_components(build,target_darwin='not-a-version')
    assert any('Invalid build manifest target_darwin' in item for item in result['errors'])


def test_extremely_long_darwin_number_is_rejected_quickly():
    from hackpilot.efi_audit import _kernel_version_tuple
    with pytest.raises(ValueError, match='out of range'):
        _kernel_version_tuple('9' * 7000 + '.0.0')


def test_extremely_long_bundle_version_does_not_crash():
    from hackpilot.efi_audit import _numeric_bundle_version
    assert _numeric_bundle_version('9' * 7000) is None


def test_excessively_large_ssdt_is_rejected_before_reading(tmp_path):
    from hackpilot.efi_audit import _acpi_table
    table=tmp_path/'SSDT-HUGE.aml'
    with table.open('wb') as output:
        output.truncate(16*1024*1024+1)
    assert 'exceeds' in _acpi_table(table)


def test_oversized_config_plist_does_not_make_audit_crash(tmp_path):
    build,_=fixture(tmp_path)
    plist=build/'EFI'/'OC'/'config.plist'
    with plist.open('wb') as output:
        output.truncate(8*1024*1024+1)
    result=audit_efi_components(build)
    assert 'Cannot inspect malformed config.plist' in result['errors']


def test_oversized_kext_plist_is_reported_not_loaded(tmp_path):
    build,_=fixture(tmp_path)
    plist=build/'EFI'/'OC'/'Kexts'/'Lilu.kext'/'Contents'/'Info.plist'
    with plist.open('wb') as output:
        output.truncate(4*1024*1024+1)
    result=audit_efi_components(build)
    assert any('malformed Info.plist' in item for item in result['errors'])
