"""Regression tests for hardware selection, kext/SSDT/driver audits and recovery."""
import json
import plistlib
import struct
from pathlib import Path
from types import SimpleNamespace
import pytest

from hackpilot.efi_audit import audit_efi_components
from hackpilot.upstream_adapter import guided_device_choice
from hackpilot.recovery import profile_for_darwin, _recovery_metadata, verify_recovery


def write_pe(path, machine=0x8664):
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = bytearray(1024)
    raw[0:2] = b'MZ'
    struct.pack_into('<I', raw, 0x3c, 128)
    raw[128:132] = b'PE\x00\x00'
    struct.pack_into('<H', raw, 132, machine)
    struct.pack_into('<H', raw, 134, 1)  # section count
    struct.pack_into('<H', raw, 148, 240)  # optional header size
    struct.pack_into('<H', raw, 150, 0x22)  # executable, large address aware
    struct.pack_into('<H', raw, 152, 0x20b)
    struct.pack_into('<H', raw, 128+24+68, 10)  # EFI_APPLICATION
    sec = 128+24+240
    raw[sec:sec+5] = b'.text'
    struct.pack_into('<I', raw, sec+16, 512)
    struct.pack_into('<I', raw, sec+20, 512)
    path.write_bytes(raw)


def write_acpi(path):
    data = bytearray(36)
    data[:4] = b'SSDT'
    struct.pack_into('<I', data, 4, len(data))
    data[8] = 2
    data[9] = (-sum(data)) % 256
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def write_kext(oc, name, ident, depends=None, executable=None):
    bundle = oc/'Kexts'/name
    folder = bundle/'Contents'
    folder.mkdir(parents=True, exist_ok=True)
    info = {'CFBundleIdentifier':ident,'CFBundleVersion':'1.0', 'OSBundleLibraries':depends or {}}
    if executable:
        info['CFBundleExecutable'] = executable
        (folder/'MacOS').mkdir()
        # Well-formed synthetic Mach-O with a valid 64-bit header and one
        # bounded load command. A magic/CPU prefix alone is not executable.
        mach = bytearray(64)
        mach[:4] = b'\xcf\xfa\xed\xfe'
        struct.pack_into('<IIIII',mach,4,0x01000007,3,11,1,8)
        struct.pack_into('<II',mach,32,0x1b,8)
        (folder/'MacOS'/executable).write_bytes(mach)
    with (folder/'Info.plist').open('wb') as out: plistlib.dump(info, out)
    return {'Enabled':True,'BundlePath':name,'PlistPath':'Contents/Info.plist',
            'ExecutablePath':('Contents/MacOS/'+executable) if executable else ''}


def fixture(tmp_path):
    root=tmp_path/'build'/'EFI'
    oc=root/'OC'
    write_pe(root/'BOOT'/'BOOTx64.efi')
    write_pe(oc/'OpenCore.efi')
    write_pe(oc/'Drivers'/'OpenRuntime.efi')
    write_pe(oc/'Drivers'/'HfsPlus.efi')
    write_acpi(oc/'ACPI'/'SSDT-EC.aml')
    kexts=[write_kext(oc,'Lilu.kext','as.vit9696.Lilu',executable='Lilu'),
           write_kext(oc,'VirtualSMC.kext','as.vit9696.VirtualSMC',
                      {'as.vit9696.Lilu':'1.0'}, executable='VirtualSMC')]
    config={'ACPI':{'Add':[{'Enabled':True,'Path':'SSDT-EC.aml'}]},
            'UEFI':{'Drivers':[{'Enabled':True,'Path':'OpenRuntime.efi'},
                                {'Enabled':True,'Path':'HfsPlus.efi'}]},
            'Kernel':{'Add':kexts},'Misc':{},
            'PlatformInfo':{'Generic':{'SystemSerialNumber':'TEST','SystemUUID':'00000000-0000-0000-0000-000000000001'}}}
    with (oc/'config.plist').open('wb') as out: plistlib.dump(config,out)
    return tmp_path/'build',config


def save_config(build, config):
    with (build/'EFI'/'OC'/'config.plist').open('wb') as out: plistlib.dump(config,out)


def test_complete_sample_efi_inventory(tmp_path):
    build,_ = fixture(tmp_path)
    result=audit_efi_components(build)
    assert result['errors']==[]
    assert result['inventory']=={'ssdt':1,'kexts':2,'drivers':2,'tools':0}


def test_missing_firmware_driver_and_wrong_architecture(tmp_path):
    build,config = fixture(tmp_path)
    config['UEFI']['Drivers'].pop()
    save_config(build,config)
    assert any('HFS+' in e for e in audit_efi_components(build)['errors'])
    write_pe(build/'EFI'/'BOOT'/'BOOTx64.efi', machine=0x14c)
    assert any('x86_64' in e for e in audit_efi_components(build)['errors'])


def test_corrupted_ssdt_and_malformed_kext_info(tmp_path):
    build,_=fixture(tmp_path)
    ssdt=build/'EFI'/'OC'/'ACPI'/'SSDT-EC.aml'
    data=bytearray(ssdt.read_bytes())
    data[-1]=1
    ssdt.write_bytes(data)
    info=build/'EFI'/'OC'/'Kexts'/'VirtualSMC.kext'/'Contents'/'Info.plist'
    info.write_bytes(b'not plist')
    errors=audit_efi_components(build)['errors']
    assert any('checksum' in e for e in errors)
    assert any('malformed Info.plist' in e for e in errors)


def test_kext_dependencies_order_and_duplicate_identifiers(tmp_path):
    build,config=fixture(tmp_path)
    config['Kernel']['Add'].reverse()
    save_config(build,config)
    assert any('must load before' in e for e in audit_efi_components(build)['errors'])
    save_config(build,config)
    path=build/'EFI'/'OC'/'Kexts'/'VirtualSMC.kext'/'Contents'/'Info.plist'
    with path.open('rb') as src: info=plistlib.load(src)
    info['CFBundleIdentifier']='as.vit9696.Lilu'
    with path.open('wb') as out: plistlib.dump(info,out)
    assert any('Duplicate enabled kext identifier' in e for e in audit_efi_components(build)['errors'])


def test_usb_default_is_marked_not_fully_mapped(tmp_path):
    build,config=fixture(tmp_path)
    oc=build/'EFI'/'OC'
    config['Kernel']['Add'].append(write_kext(oc,'UTBDefault.kext','com.dhinakg.USBToolBox.map'))
    save_config(build,config)
    result=audit_efi_components(build)
    assert result['errors']==[]
    assert any('Temporary USB mapping' in x for x in result['warnings'])
    config['Kernel']['Add'].append(write_kext(oc,'UTBMap.kext','com.dhinakg.USBToolBox.custommap'))
    save_config(build,config)
    assert any('both enabled' in x for x in audit_efi_components(build)['errors'])


def test_upstream_selector_disables_other_gpu():
    disabled=[]
    obj=SimpleNamespace(_disable_device=lambda kind,name,props:disabled.append((kind,name)))
    choices={'Intel UHD 630':{'Device Type':'Integrated GPU'},'NVIDIA GTX':{'Device Type':'Discrete GPU'}}
    result=guided_device_choice(obj,'GPU',choices,None,{'GPU':'Intel UHD 630'})
    assert result==['Intel UHD 630']
    assert disabled==[('GPU','NVIDIA GTX')]
    with pytest.raises(RuntimeError,match='Select a GPU'):
        guided_device_choice(obj,'GPU',choices,None,{})
    with pytest.raises(RuntimeError,match='not compatible'):
        guided_device_choice(obj,'GPU',choices,None,{'GPU':'unknown'})


def test_upstream_selector_disables_other_wifi_bluetooth():
    disabled=[]
    obj=SimpleNamespace(_disable_device=lambda kind,name,props:disabled.append((kind,name)))
    choices={'Intel Wi-Fi':{},'Broadcom Wi-Fi':{}}
    assert guided_device_choice(obj,'WiFi',choices,None,{'WiFi':'Broadcom Wi-Fi'})==['Broadcom Wi-Fi']
    assert disabled==[('WiFi','Intel Wi-Fi')]
    assert guided_device_choice(obj,'Bluetooth',{'A':{},'B':{}},[{0,1}],{'Bluetooth':'B'})==['B']
    assert ('Bluetooth','A') in disabled


def test_documented_recovery_profiles_and_target_binding(tmp_path):
    expected={'20':'Mac-2BD1B31983FE1663','21':'Mac-E43C1C25D4880AD6',
              '22':'Mac-B4831CEBD52A0C4C','23':'Mac-827FAC58A8FDFA22',
              '24':'Mac-7BA5B2D9E42DDD94','25':'Mac-CFF7D910A743CAAF'}
    for major,board in expected.items():
        profile=profile_for_darwin(major+'.99.99')
        assert profile['board_id']==board
        assert profile['os_type']==('latest' if major=='25' else 'default')
    with pytest.raises(RuntimeError): profile_for_darwin('26.0.0')
    folder=tmp_path/'com.apple.recovery.boot';folder.mkdir()
    (folder/'BaseSystem.dmg').write_bytes(b'example-recovery-data')
    (folder/'BaseSystem.chunklist').write_bytes(b'example-signature')
    meta=_recovery_metadata(folder,expected['24'],'24','default')
    (tmp_path/'recovery-info.json').write_text(json.dumps(meta))
    assert verify_recovery(folder,expected['24'],'24','default')
    assert not verify_recovery(folder,expected['24'],'25','default')


def test_bad_dependency_types_are_validation_errors_not_exceptions(tmp_path):
    build, _ = fixture(tmp_path)
    info = build/'EFI'/'OC'/'Kexts'/'VirtualSMC.kext'/'Contents'/'Info.plist'
    with info.open('rb') as file: data = plistlib.load(file)
    data['OSBundleLibraries'] = {'com.apple.kpi.libkern': 99, 'as.vit9696.Lilu': '1.0'}
    with info.open('wb') as file: plistlib.dump(data, file)
    assert any('invalid dependency version' in msg for msg in audit_efi_components(build)['errors'])


def test_manual_recovery_auto_selects_profile_from_generated_target(monkeypatch,tmp_path):
    import hackpilot.server as server
    state = server.State(home=tmp_path)
    state.build_dir.mkdir(parents=True, exist_ok=True)
    (state.build_dir/'build-manifest.json').write_text(json.dumps({'target_darwin':'24.7.0'}))
    seen = []
    def fake_download(cache, output, board, channel, major):
        seen.append((board, channel, major))
        return {'folder': str(tmp_path/'AppleRecovery')}
    def fake_verify(folder, board, major, channel, **kwargs):
        return (board, channel, major) == ('Mac-7BA5B2D9E42DDD94','default','24')
    monkeypatch.setattr(server, 'download_recovery', fake_download)
    monkeypatch.setattr(server, 'verify_recovery', fake_verify)
    state.recovery('')
    assert seen == [('Mac-7BA5B2D9E42DDD94','default','24')]
    assert state.recovery_verified


def test_undocumented_recovery_target_fails_before_download(monkeypatch,tmp_path):
    import hackpilot.server as server
    state = server.State(home=tmp_path)
    state.build_dir.mkdir(parents=True, exist_ok=True)
    (state.build_dir/'build-manifest.json').write_text(json.dumps({'target_darwin':'26.0.0'}))
    monkeypatch.setattr(server, 'download_recovery', lambda *x,**y:pytest.fail('No download expected'))
    with pytest.raises(RuntimeError,match='Cannot select Apple recovery'):
        state.recovery('')


def test_enabled_opencore_tools_are_checked(tmp_path):
    build, config = fixture(tmp_path)
    config['Misc']['Tools'] = [{'Enabled':True,'Path':'OpenShell.efi'}]
    save_config(build, config)
    assert any('OpenCore tool missing' in e for e in audit_efi_components(build)['errors'])
    write_pe(build/'EFI'/'OC'/'Tools'/'OpenShell.efi')
    result = audit_efi_components(build)
    assert result['errors'] == []
    assert result['inventory']['tools'] == 1


def test_generated_efi_manifest_enables_component_audit(tmp_path):
    from hackpilot.efi import validate_efi
    build, config = fixture(tmp_path)
    (build/'build-manifest.json').write_text(json.dumps({'target_darwin':'24.0.0'}))
    (build/'EFI'/'OC'/'Drivers'/'HfsPlus.efi').unlink()
    result = validate_efi(build)
    assert not result['structural_valid']
    assert result['components'] is not None
    assert any('HfsPlus' in e for e in result['errors'])


def test_fake_windows_executable_is_not_accepted_as_uefi_driver(tmp_path):
    build, _ = fixture(tmp_path)
    driver = build/'EFI'/'OC'/'Drivers'/'HfsPlus.efi'
    raw=bytearray(driver.read_bytes())
    struct.pack_into('<H',raw,128+24+68,2)  # Windows GUI PE subsystem
    driver.write_bytes(raw)
    assert any('not EFI firmware' in e for e in audit_efi_components(build)['errors'])


def test_corrupt_or_wrong_architecture_kext_is_rejected(tmp_path):
    build, _ = fixture(tmp_path)
    binary=build/'EFI'/'OC'/'Kexts'/'VirtualSMC.kext'/'Contents'/'MacOS'/'VirtualSMC'
    binary.write_bytes(b'plain text executable not Mach-O')
    assert any('not a recognized' in e for e in audit_efi_components(build)['errors'])
    binary.write_bytes(b'\xcf\xfa\xed\xfe' + struct.pack('<I',7) + b'\0'*64)
    assert any('wrong Mach-O CPU' in e for e in audit_efi_components(build)['errors'])
