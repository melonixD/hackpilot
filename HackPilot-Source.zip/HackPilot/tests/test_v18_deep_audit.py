"""v1.8: trust-boundary and transactional scanner regression tests."""
import hashlib
import json
import os
from pathlib import Path
from types import SimpleNamespace

import pytest
from hackpilot import engine, usb_mapping


def make_backend(folder):
    root = folder / 'usbtoolbox'
    for path in usb_mapping.REQUIRED:
        dest = root / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(b'test fixture')
    return root


def test_backend_cache_refuses_untracked_python_bytecode(tmp_path):
    root = make_backend(tmp_path)
    clean_hash = usb_mapping._backend_digest(root)
    (tmp_path/'usbtoolbox-manifest.json').write_text(json.dumps({
        'repository': usb_mapping.REPO, 'commit': 'a'*40, 'tree_sha256': clean_hash}))
    assert usb_mapping.backend_verified(tmp_path)
    folder = root / 'Scripts' / '__pycache__'
    folder.mkdir()
    (folder / 'usbdump.cpython-312.pyc').write_bytes(b'possibly malicious code')
    assert not usb_mapping.backend_verified(tmp_path)
    with pytest.raises(RuntimeError, match='bytecode'):
        usb_mapping._backend_digest(root)


def test_backend_cache_refuses_direct_compiled_module(tmp_path):
    root = make_backend(tmp_path)
    (root/'Scripts'/'usbdump.pyc').write_bytes(b'bytecode')
    with pytest.raises(RuntimeError, match='bytecode'):
        usb_mapping._backend_digest(root)


def test_engine_cache_removes_root_and_nested_bytecode(tmp_path):
    root = tmp_path/'opcore-simplify'
    (root/'Scripts'/'datasets'/'__pycache__').mkdir(parents=True)
    (root/'__pycache__').mkdir()
    (root/'__pycache__'/'updater.cpython-312.pyc').write_bytes(b'cached')
    (root/'Scripts'/'datasets'/'__pycache__'/'dataset.cpython-312.pyc').write_bytes(b'cached')
    (root/'updater.pyc').write_bytes(b'old root module')
    engine.clean_engine_bytecode(root)
    assert not (root/'__pycache__').exists()
    assert not (root/'Scripts'/'datasets'/'__pycache__').exists()
    assert not (root/'updater.pyc').exists()


def test_engine_cache_refuses_linked_bytecode_folder(tmp_path):
    root = tmp_path/'opcore-simplify'
    (root/'Scripts').mkdir(parents=True)
    real = tmp_path/'elsewhere'
    real.mkdir()
    try:
        (root/'Scripts'/'__pycache__').symlink_to(real, target_is_directory=True)
    except (OSError, NotImplementedError):
        pytest.skip('symlinks not available on this filesystem')
    with pytest.raises(RuntimeError, match='linked'):
        engine.clean_engine_bytecode(root)
    assert real.is_dir()


def windows_environment(monkeypatch):
    # Windows-only code path without changing the process-wide real os.name.
    monkeypatch.setattr(engine, 'os', SimpleNamespace(
        name='nt', path=os.path, replace=os.replace, fdopen=os.fdopen,
        fsync=os.fsync, unlink=os.unlink, urandom=os.urandom))


def fake_report_process(staging):
    staging = Path(staging)
    (staging/'ACPI').mkdir(parents=True)
    (staging/'ACPI'/'DSDT.aml').write_bytes(b'DSDT captured from this test PC')
    (staging/'Report.json').write_text(json.dumps({
        'CPU': {'Processor Name': 'Intel Core i7', 'Manufacturer': 'Intel'},
        'GPU': {'Intel Graphics': {'Manufacturer': 'Intel'}},
        'Motherboard': {'Name': 'Test board'}}))
    return SimpleNamespace(returncode=0, stderr=b'')


def prepare_sniffer(tmp_path, tag='v1'):
    cache = tmp_path/'cache'
    cache.mkdir()
    binary = cache/'Hardware-Sniffer-CLI.exe'
    binary.write_bytes(b'old trusted Windows scanner')
    digest = hashlib.sha256(binary.read_bytes()).hexdigest()
    manifest = cache/'sniffer-manifest.json'
    manifest.write_text(json.dumps({'tag': tag, 'sha256': digest, 'url': 'https://example.org/old'}))
    return cache, binary, manifest


def test_sniffer_manifest_failure_restores_previous_executable(tmp_path, monkeypatch):
    windows_environment(monkeypatch)
    cache, binary, manifest = prepare_sniffer(tmp_path)
    old_binary, old_manifest = binary.read_bytes(), manifest.read_bytes()
    monkeypatch.setattr(engine, 'request_json', lambda *_: {
        'tag_name': 'v2', 'assets': [{'name': 'Hardware-Sniffer-CLI.exe',
                                    'browser_download_url': 'https://example.org/new'}]})
    def download_new(_url, target, _max_bytes):
        Path(target).write_bytes(b'new Windows scanner')
        return {'sha256': hashlib.sha256(Path(target).read_bytes()).hexdigest()}
    monkeypatch.setattr(engine, 'download', download_new)
    def break_manifest(*_a):
        raise OSError('simulated disk full during manifest write')
    monkeypatch.setattr(engine, '_atomic_json', break_manifest)
    with pytest.raises(OSError, match='disk full'):
        engine.deep_scan(cache, tmp_path/'report')
    assert binary.read_bytes() == old_binary
    assert manifest.read_bytes() == old_manifest
    assert not (cache/'Hardware-Sniffer-CLI.exe.incoming').exists()
    assert not (cache/'Hardware-Sniffer-CLI.exe.rollback').exists()


def test_verified_sniffer_still_scans_when_github_offline(tmp_path, monkeypatch):
    windows_environment(monkeypatch)
    cache, binary, manifest = prepare_sniffer(tmp_path)
    monkeypatch.setattr(engine, 'request_json', lambda *_: (_ for _ in ()).throw(OSError('offline')))
    monkeypatch.setattr(engine, 'download', lambda *_a,**_kw: pytest.fail('should reuse cache'))
    def fake_run(args, **kwargs):
        return fake_report_process(args[-1])
    monkeypatch.setattr(engine.subprocess, 'run', fake_run)
    result = engine.deep_scan(cache, tmp_path/'report')
    assert result['sniffer']['cached']
    assert (tmp_path/'report'/'Report.json').exists()
    assert binary.read_bytes() == b'old trusted Windows scanner'


def test_offline_scan_refuses_unverified_binary(tmp_path, monkeypatch):
    windows_environment(monkeypatch)
    cache, binary, manifest = prepare_sniffer(tmp_path)
    binary.write_bytes(b'tampered scanner')
    monkeypatch.setattr(engine, 'request_json', lambda *_: (_ for _ in ()).throw(OSError('offline')))
    with pytest.raises(RuntimeError, match='no verified cache'):
        engine.deep_scan(cache, tmp_path/'report')


def test_incomplete_sniffer_update_blocks_execution(tmp_path, monkeypatch):
    windows_environment(monkeypatch)
    cache, binary, manifest = prepare_sniffer(tmp_path)
    (cache/'Hardware-Sniffer-CLI.exe.rollback').write_bytes(b'interrupted state')
    monkeypatch.setattr(engine, 'request_json', lambda *_: pytest.fail('no network request before checking rollback'))
    with pytest.raises(RuntimeError, match='Interrupted Hardware Sniffer'):
        engine.deep_scan(cache, tmp_path/'report')

@pytest.mark.parametrize('payload', [
    {'phase': 'old_moved', 'letter': 'Q'},
    {'phase': 'complete', 'letter': 'Q'},
    {'phase': 'unknown', 'letter': 'Q'},
    {'phase': 'old_moved', 'letter': 'Q', 'disk_number': -1, 'volume_id': 'volume'},
    {'phase': 'old_moved', 'letter': 'Q', 'disk_number': 5, 'volume_id': 'volume',
     'expected_fingerprint': 'x'*64, 'had_original': True},
])
def test_malformed_parseable_usb_receipts_are_never_trusted(tmp_path, payload):
    from hackpilot.usb_journal import pending_receipts
    directory = tmp_path/'transactions'
    directory.mkdir()
    (directory/'usb-Q-bad.json').write_text(json.dumps(payload))
    pending = pending_receipts(directory)
    assert len(pending) == 1 and pending[0]['phase'] == 'corrupt'


def test_oversized_usb_receipt_cannot_lock_up_status(tmp_path):
    from hackpilot.usb_journal import pending_receipts, MAX_RECEIPT_BYTES
    directory = tmp_path/'transactions'
    directory.mkdir()
    (directory/'usb-Q-huge.json').write_bytes(b' '*(MAX_RECEIPT_BYTES + 1))
    pending = pending_receipts(directory)
    assert len(pending) == 1 and pending[0]['phase'] == 'corrupt'


def test_valid_receipt_is_still_recoverable(tmp_path):
    from hackpilot.usb_journal import pending_receipts, write_receipt
    directory = tmp_path/'transactions'
    name = directory/'usb-Q-valid.json'
    record = {'letter':'Q', 'disk_number':5,'volume_id':'volume-123',
              'phase':'old_moved','expected_fingerprint':'a'*64,
              'original_fingerprint':'b'*64,'had_original':True,
              'recovery_fingerprint':None,'backup':'/tmp/archive.zip',
              'backup_sha256':'c'*64}
    write_receipt(name, record)
    assert pending_receipts(directory)[0]['letter'] == 'Q'
    record['phase'] = 'complete'
    write_receipt(name, record)
    assert pending_receipts(directory) == []


def test_two_app_windows_cannot_write_same_usb_simultaneously(tmp_path):
    from hackpilot.usb import _transfer_lock, safe_usb_copy, repair_usb
    backups = tmp_path/'Backups'
    with _transfer_lock(backups, 'Q'):
        with pytest.raises(RuntimeError, match='Another HackPilot window'):
            safe_usb_copy(tmp_path/'build', 'Q', 'COPY TO Q:', backups)
        with pytest.raises(RuntimeError, match='Another HackPilot window'):
            repair_usb('Q', 'REPAIR Q:', backups)
    # The lock file persists, but an exited app no longer holds its OS lock.
    with _transfer_lock(backups, 'Q'):
        assert (backups/'transactions'/'usb-Q.lock').is_file()


def test_different_usb_drives_can_have_independent_locks(tmp_path):
    from hackpilot.usb import _transfer_lock
    with _transfer_lock(tmp_path/'Backups', 'Q'):
        with _transfer_lock(tmp_path/'Backups', 'R'):
            pass


def test_usb_lock_path_cannot_be_escaped(tmp_path):
    from hackpilot.usb import _transfer_lock
    with pytest.raises(ValueError, match='Invalid USB drive letter'):
        with _transfer_lock(tmp_path, '../../Windows'):
            pytest.fail('unsafe drive letter reached lock body')


def _prepared_build_state(tmp_path, monkeypatch, manifest_payload=None):
    from hackpilot.server import State
    from hackpilot.scan_seal import seal_scan
    from hackpilot import server
    state = State(home=tmp_path/'home')
    report = tmp_path/'Report.json'
    report.write_text(json.dumps({
        'CPU': {'Processor Name':'Intel Core i7', 'Manufacturer':'Intel'},
        'GPU': {'Intel Graphics': {'Device ID':'0x1234'}},
        'Motherboard': {'Name':'Test board'}}))
    acpi = tmp_path/'ACPI';acpi.mkdir()
    (acpi/'DSDT.aml').write_bytes(b'fake test fixture DSDT')
    state.sniffer_file = str(report)
    state.acpi_dir = str(acpi)
    state.deep_scan_verified = True
    state.scan_seal = seal_scan(report, acpi)
    state.engine_dir = str(state.cache/'opcore-simplify')
    state.hardware = {'cpu':{'name':'Intel Core i7-9700K'},
                      'gpus':[{'name':'AMD Radeon RX 580'}],
                      'network':[{'name':'Ethernet'}]}
    monkeypatch.setattr(server,'cached_engine_verified', lambda _cache: True)
    def fake_engine(*_args,**_kw):
        state.build_dir.mkdir(parents=True, exist_ok=True)
        if manifest_payload is not None:
            content = manifest_payload(state) if callable(manifest_payload) else manifest_payload
            (state.build_dir/'build-manifest.json').write_text(json.dumps(content))
        return {'output':str(state.build_dir)}
    monkeypatch.setattr(server,'run_auto_builder', fake_engine)
    monkeypatch.setattr(server,'setup_validator',lambda *_args,**_kw:{'root':str(tmp_path/'validator')})
    monkeypatch.setattr(server,'validate_efi',lambda *_args,**_kw:{'valid':True, 'fingerprint':'a'*64})
    return state


def test_missing_generated_build_manifest_cannot_pass(monkeypatch, tmp_path):
    state = _prepared_build_state(tmp_path, monkeypatch)
    with pytest.raises(RuntimeError, match='no hardware-bound build manifest'):
        state.build()
    assert state.last_build is None


def test_generated_manifest_cannot_omit_scan_seal(monkeypatch, tmp_path):
    state = _prepared_build_state(tmp_path, monkeypatch,
        {'engine':'OpCore-Simplify','needs_oclp':False,'target_darwin':'24.0.0',
         'smbios_model':'iMac20,1','component_inventory':{}})
    with pytest.raises(RuntimeError, match='incomplete'):
        state.build()


def test_generated_manifest_cannot_reference_another_scan(monkeypatch, tmp_path):
    state = _prepared_build_state(tmp_path, monkeypatch,
        lambda s:{'engine':'OpCore-Simplify','needs_oclp':False,
                  'target_darwin':'24.0.0','smbios_model':'iMac20,1',
                  'component_inventory':{},'scan_seal':{
                      **s.scan_seal, 'report_sha256':'0'*64}})
    with pytest.raises(RuntimeError, match='changed'):
        state.build()


def test_properly_bound_build_manifest_reaches_validator(monkeypatch, tmp_path):
    state = _prepared_build_state(tmp_path, monkeypatch,
        lambda s:{'engine':'OpCore-Simplify','needs_oclp':False,
                  'target_darwin':'24.0.0','smbios_model':'iMac20,1',
                  'component_inventory':{},'scan_seal':s.scan_seal})
    result = state.build()
    assert result['validation']['valid']
