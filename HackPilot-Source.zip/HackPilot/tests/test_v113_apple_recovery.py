"""Independent Apple chunklist validation. Synthetic RSA test vector.

No Apple assets are included; the RSA modulus is replaced with a synthetic
2048-bit test public key. Production always uses the embedded Apple key.
"""
import hashlib
import json
import struct

import pytest

from hackpilot import recovery

TEST_PUBLIC_MODULUS = int(
    "e6ee305d0058400fd0af4219fc3bea6142f902667fc457723072752930fcb8e6b99b2101738e66492370d70bd947b4620e65fa0ea728cd190e1eba1ba153b1ad27e78e0013c6808931d281710bf334534e50fd6e9b165eba2f259ea5729808ddde5aaa64ce3b3fd54896c1f49a1ebfeb1b9419c24894cb571c22b3a536deea04a59073f9b446bae00852dbd7b30897864332af0317aaae1cd7d5d30f6c2d22709eedfbbe65027267e025e08bf78af780a6ad9b84843aa3c250a91b129be90aa1607434495801e2b17a388f9cdc89a9918a718ad1c64632646e2a8770a54d7770bdb4df33646e6734ee0b76367e610747ee00fe3a3b3dd7d54a51401720254255", 16)
TEST_SIGNATURE_LITTLE_ENDIAN = bytes.fromhex(
    "4193a5ceadcdd1225e8645fa3ace4777e599c3a05ad9bc5e7742a2d4bb0eb77613331d7b39e5400709ba1e5609fcdd772a294a1836c0f8e990f019f98208821b56a473346b50d984e48f4dfc0ec2a48b0334ed893b785521bc26a1c906636a9ef9dcbe263f05d1185e8570e445438be21d283806adcb9985e805f570df4ffa007f1c619bc722b3797e99322043a874922a6ed6fcd080c3f8cd8aae92fa0963950ac04d8967c2c2696c047197f521fb76025e60cdb8f2142e20a0cb8e831126c47d97f4693ca304e95e5c176747fa4ab01888b752c2fef4d78456c5803c82d6bc44a96d2bf813e99e9533193328350b0f37c6ba9f030b181be099e36ac6518050")


def signed_example(tmp_path, monkeypatch):
    monkeypatch.setattr(recovery, 'APPLE_RECOVERY_RSA_N', TEST_PUBLIC_MODULUS)
    folder = tmp_path / 'com.apple.recovery.boot'
    folder.mkdir()
    dmg = folder / 'BaseSystem.dmg'
    chunklist = folder / 'BaseSystem.chunklist'
    payload = b'Apple-chunklist-structure-unit-test'
    header = struct.pack('<4sIBBBxQQQ', b'CNKL', 36, 1, 1, 1, 1, 36, 72)
    chunks = struct.pack('<I32s', len(payload), hashlib.sha256(payload).digest())
    dmg.write_bytes(payload)
    chunklist.write_bytes(header + chunks + TEST_SIGNATURE_LITTLE_ENDIAN)
    return folder


def test_signed_chunklist_and_payload_are_verified(tmp_path, monkeypatch):
    folder = signed_example(tmp_path, monkeypatch)
    assert recovery.verify_apple_recovery_assets(folder/'BaseSystem.dmg', folder/'BaseSystem.chunklist')
    board = 'Mac-7BA5B2D9E42DDD94'
    (tmp_path/'recovery-info.json').write_text(json.dumps(recovery._recovery_metadata(folder, board, '24')))
    assert recovery.verify_recovery(folder, board, '24', 'default', require_apple_signature=True)


def test_forged_local_checksum_does_not_bypass_apple_signature(tmp_path):
    folder = tmp_path / 'com.apple.recovery.boot'
    folder.mkdir()
    (folder/'BaseSystem.dmg').write_bytes(b'fake image')
    (folder/'BaseSystem.chunklist').write_bytes(b'fake chunklist')
    board = 'Mac-7BA5B2D9E42DDD94'
    (tmp_path/'recovery-info.json').write_text(json.dumps(recovery._recovery_metadata(folder, board, '24')))
    assert recovery.verify_recovery(folder, board, '24')  # historical local hash check
    assert not recovery.verify_recovery(folder, board, '24', require_apple_signature=True)


@pytest.mark.parametrize('corrupt', ['image', 'signature', 'bad_header', 'unsigned', 'trailing', 'oversized_chunk'])
def test_corrupted_apple_assets_are_rejected(tmp_path, monkeypatch, corrupt):
    folder = signed_example(tmp_path, monkeypatch)
    dmg, chunklist = folder/'BaseSystem.dmg', folder/'BaseSystem.chunklist'
    if corrupt == 'image':
        dmg.write_bytes(b'corrupted-contents-of-equal-size' + b' ' * 2)
    elif corrupt == 'signature':
        data = bytearray(chunklist.read_bytes())
        data[-20] ^= 1
        chunklist.write_bytes(data)
    elif corrupt == 'bad_header':
        data = bytearray(chunklist.read_bytes())
        data[0] = ord('X')
        chunklist.write_bytes(data)
    elif corrupt == 'unsigned':
        data = bytearray(chunklist.read_bytes())
        data[10] = 2  # signature_method = 2
        chunklist.write_bytes(data)
    elif corrupt == 'trailing':
        with chunklist.open('ab') as stream:
            stream.write(b'extra')
    elif corrupt == 'oversized_chunk':
        data = bytearray(chunklist.read_bytes())
        data[36:40] = (2000000).to_bytes(4,'little')
        chunklist.write_bytes(data)
    assert not recovery.verify_apple_recovery_assets(dmg, chunklist)


def test_real_apple_key_is_not_synthetic_test_key(tmp_path, monkeypatch):
    # Simulated RSA signature cannot be accepted as an actual Apple download.
    folder = signed_example(tmp_path, monkeypatch)
    monkeypatch.undo()
    assert not recovery.verify_apple_recovery_assets(folder/'BaseSystem.dmg', folder/'BaseSystem.chunklist')


def test_production_apple_key_is_complete_2048_bits():
    # Prevent a copy/paste-truncated modulus from silently rejecting every
    # legitimate recovery image (caught during this audit).
    assert recovery.APPLE_RECOVERY_RSA_N.bit_length() == 2048
