"""Additional hardening regressions for early failures and packaged launcher."""
import json
import runpy
from pathlib import Path

import pytest

from hackpilot import usb, server
from hackpilot.usb_journal import pending_receipts
from test_quality import make_usb


def test_backup_failure_never_marks_usb_as_interrupted(tmp_path, monkeypatch):
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    before = usb.efi_tree_fingerprint(drive/'EFI')
    original = usb._verified_backup

    def fail_backup(*_):
        raise OSError('simulated backup disk full')

    monkeypatch.setattr(usb, '_verified_backup', fail_backup)
    with pytest.raises(OSError, match='disk full'):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups')
    assert usb.efi_tree_fingerprint(drive/'EFI') == before
    assert not pending_receipts(tmp_path/'backups'/'transactions')
    receipts = list((tmp_path/'backups'/'transactions').glob('*.json'))
    assert len(receipts) == 1
    assert json.loads(receipts[0].read_text())['phase'] == 'preflight_failed'

    monkeypatch.setattr(usb,'_verified_backup',original)
    result = usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups')
    assert result['copied_efi']


def test_corrupt_journal_blocks_new_copy_even_when_letter_is_unknown(tmp_path, monkeypatch):
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    before = usb.efi_tree_fingerprint(drive/'EFI')
    folder = tmp_path/'backups'/'transactions'
    folder.mkdir(parents=True)
    (folder/'usb-X-broken.json').write_text('{corrupt')
    with pytest.raises(RuntimeError, match='Unfinished USB transfer'):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups')
    assert usb.efi_tree_fingerprint(drive/'EFI') == before


def test_windows_executable_launcher_propagates_exit_code(monkeypatch):
    import hackpilot.main
    monkeypatch.setattr(hackpilot.main, 'main', lambda: 7)
    launcher = Path(__file__).resolve().parents[1]/'hackpilot_launcher.py'
    with pytest.raises(SystemExit) as event:
        runpy.run_path(str(launcher), run_name='__main__')
    assert event.value.code == 7


def test_corrupt_saved_report_is_not_trusted_after_restart(tmp_path):
    report = tmp_path/'data'/'SystemReport'
    (report/'ACPI').mkdir(parents=True)
    (report/'Report.json').write_text(json.dumps({'CPU': {'Processor Name':'Intel i7'}, 'GPU': {'NVIDIA':[]}}))
    state = server.State(home=tmp_path/'data')
    assert not state.status()['deep_scan_ready']
    assert not state.status()['hardware']


def test_failed_new_build_clears_old_success(tmp_path, monkeypatch):
    state = server.State(home=tmp_path/'home')
    state.deep_scan_verified = True
    state.hardware={'cpu':{'name':'Intel Core i7-9700K'},
                    'gpus':[{'name':'AMD Radeon RX 580'}],
                    'firmware':{'type':'UEFI'}}
    (tmp_path/'report.json').write_text('{}')
    (tmp_path/'ACPI').mkdir()
    state.sniffer_file=str(tmp_path/'report.json')
    state.acpi_dir=str(tmp_path/'ACPI')
    state.engine_dir=str(tmp_path/'engine')
    state.last_build={'valid':True,'fingerprint':'previous'}
    state.usb_prepared=True
    monkeypatch.setattr(server,'cached_engine_verified', lambda _:True)
    monkeypatch.setattr(server,'validate_selections',lambda choices, sel: {})

    def broken_build(*_args, **_kwargs):
        raise RuntimeError('upstream engine failed')

    monkeypatch.setattr(server,'run_auto_builder', broken_build)
    with pytest.raises(RuntimeError,match='upstream engine failed'):
        state.build()
    status = state.status()
    assert status['last_build'] is None
    assert not status['usb_prepared']


def test_engine_hash_covers_root_level_updater_module(tmp_path):
    from hackpilot.engine import engine_tree_hash
    engine = tmp_path/'engine'
    scripts = engine/'Scripts'
    scripts.mkdir(parents=True)
    (engine/'LICENSE').write_text('BSD-3')
    (engine/'OpCore-Simplify.py').write_text('import updater')
    (engine/'updater.py').write_text('def run(): return True')
    (scripts/'utils.py').write_text('class Utils: pass')
    first = engine_tree_hash(engine)
    (engine/'updater.py').write_text('def run(): return False')
    assert engine_tree_hash(engine) != first
    # Newly added root-level Python modules must also change the digest.
    before = engine_tree_hash(engine)
    (engine/'extra.py').write_text('print("changed")')
    assert engine_tree_hash(engine) != before
