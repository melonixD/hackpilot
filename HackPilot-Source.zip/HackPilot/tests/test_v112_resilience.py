"""v1.12: failures observable only at real hardware and download trust boundaries.

Tests simulate component failures but never write to an actual USB drive.
"""
import hashlib
import json
from pathlib import Path
import pytest

from hackpilot import engine, server
from hackpilot.efi import _safe_relative, efi_fingerprint, validate_efi
from hackpilot.scan_seal import seal_scan
from test_v18_deep_audit import windows_environment, prepare_sniffer, fake_report_process
from test_regressions import fixture_efi
from test_v12_component_audit import fixture


def _triage_ready(state, tmp_path):
    state.deep_scan_verified = True
    report=tmp_path/'Report.json'
    report.write_text('{"CPU":{}}')
    acpi=tmp_path/'ACPI';acpi.mkdir(exist_ok=True)
    state.sniffer_file = str(report)
    state.acpi_dir = str(acpi)
    state.engine_dir = 'upstream-dir'
    state.hardware={'cpu':{'name':'Intel Core i7'},'gpus':[{'name':'Intel UHD 630'}]}


@pytest.mark.parametrize('operation', ['deep_scan', 'scan'])
def test_failed_rescan_does_not_preserve_old_verified_state(tmp_path, monkeypatch, operation):
    state=server.State(home=tmp_path/'home')
    state.deep_scan_verified=True
    state.scan_seal={'report_sha256':'old'}
    state.last_build={'valid':True,'fingerprint':'stale'}
    state.usb_copied=True
    state.usb_prepared=True
    state._device_choices_cache=('old', {})
    def fail(*_args):raise RuntimeError('scanner failed')
    monkeypatch.setattr(server,'scan_windows' if operation == 'scan' else 'deep_scan',fail)
    with pytest.raises(RuntimeError, match='scanner failed'):
        getattr(state,operation)()
    assert not state.deep_scan_verified
    assert state.scan_seal is None and state.last_build is None
    assert not state.usb_prepared and not state.usb_copied
    assert state._device_choices_cache is None


@pytest.mark.parametrize('artifact', ['UTBMap.kext', 'usb-map-manifest.json'])
def test_orphaned_usb_mapping_artifact_stops_builder(tmp_path,monkeypatch,artifact):
    state=server.State(home=tmp_path/'home')
    _triage_ready(state,tmp_path)
    monkeypatch.setattr(server,'cached_engine_verified',lambda _:True)
    monkeypatch.setattr(server,'run_auto_builder',lambda *args,**kw:pytest.fail('Must not build with orphaned map'))
    if artifact.endswith('.kext'):
        (state.mapping_dir/artifact).mkdir()
    else:
        (state.mapping_dir/artifact).write_text('{}')
    with pytest.raises(RuntimeError,match='Saved USB mapping scan is damaged'):
        state.build()


def test_unbound_legacy_efi_cannot_be_manually_transferred(tmp_path,monkeypatch):
    state=server.State(home=tmp_path/'home')
    state.build_dir=fixture_efi(tmp_path)
    fingerprint=efi_fingerprint(state.build_dir)
    state.last_build={'valid':True,'fingerprint':fingerprint}
    monkeypatch.setattr(server,'validate_efi',lambda *_a,**_kw:{'valid':True,'fingerprint':fingerprint})
    monkeypatch.setattr(server,'safe_usb_copy',lambda *args,**kw:pytest.fail('USB must not be modified'))
    with pytest.raises(RuntimeError,match='machine-bound content manifest'):
        state.copy_usb('Q','COPY TO Q:')
    assert not state.usb_copied


def test_generated_manifest_binds_exact_efi_contents(tmp_path):
    build,_=fixture(tmp_path)
    root=build/'EFI'
    manifest={'engine':'OpCore-Simplify','manifest_version':2,'efi_sha256':efi_fingerprint(build),
              'target_darwin':'24.0.0','smbios_model':'iMac20,1',
              'needs_oclp':False,'scan_seal':{'report_sha256':'a'*64,'acpi_sha256':'b'*64,'acpi_tables':1},
              'component_inventory':{}}
    (build/'build-manifest.json').write_text(json.dumps(manifest))
    original=validate_efi(build)
    assert not any('no longer match' in e for e in original['errors'])
    # A syntactically valid, noncritical file change also invalidates the
    # machine-specific attestation. ocvalidate alone would not catch this.
    (root/'OC'/'Kexts'/'Lilu.kext'/'Contents'/'extra.txt').write_text('changed')
    changed=validate_efi(build)
    assert any('no longer match' in e for e in changed['errors'])


def test_old_opcore_manifest_requires_rebuild(tmp_path):
    build,_=fixture(tmp_path)
    (build/'build-manifest.json').write_text(json.dumps({
        'engine':'OpCore-Simplify','target_darwin':'24.0.0','smbios_model':'iMac20,1',
        'needs_oclp':False,'scan_seal':{},'component_inventory':{}}))
    checked=validate_efi(build)
    assert any('Older EFI manifest' in e for e in checked['errors'])


@pytest.mark.parametrize('unsafe',["COM¹.efi","LPT².txt","drivers/COM³.bin","lpt¹/boot.efi"])
def test_windows_unicode_reserved_device_names_rejected(unsafe):
    assert not _safe_relative(unsafe)


def test_hardware_report_between_old_and_new_limits_can_be_sealed(tmp_path):
    report=tmp_path/'Report.json'
    report.write_bytes(b' '*(13*1024*1024))
    acpi=tmp_path/'ACPI';acpi.mkdir()
    (acpi/'DSDT.aml').write_bytes(b'acpi report for seal test')
    result=seal_scan(report,acpi)
    assert len(result['report_sha256'])==64


def test_hardware_scanner_publisher_digest_mismatch_preserves_old_cache(tmp_path,monkeypatch):
    windows_environment(monkeypatch)
    cache,binary,manifest=prepare_sniffer(tmp_path)
    old= binary.read_bytes(), manifest.read_bytes()
    new=b'unexpected scanner contents'
    expected=hashlib.sha256(b'official scanner contents').hexdigest()
    monkeypatch.setattr(engine,'request_json',lambda *_:{'tag_name':'v2','assets':[
        {'name':'Hardware-Sniffer-CLI.exe','browser_download_url':'https://example.org/new',
         'digest':'sha256:'+expected}]})
    def mock_download(_url,target,_limit):
        Path(target).write_bytes(new)
        return {'sha256':hashlib.sha256(new).hexdigest()}
    monkeypatch.setattr(engine,'download',mock_download)
    monkeypatch.setattr(engine.subprocess,'run',lambda *_a,**_kw: pytest.fail('Never execute mismatched download'))
    with pytest.raises(RuntimeError,match='published SHA-256'):
        engine.deep_scan(cache,tmp_path/'Report')
    assert (binary.read_bytes(),manifest.read_bytes()) == old
    assert not (cache/'Hardware-Sniffer-CLI.exe.incoming').exists()


def test_hardware_scanner_invalid_publisher_digest_rejected(tmp_path,monkeypatch):
    windows_environment(monkeypatch)
    cache,binary,manifest=prepare_sniffer(tmp_path)
    monkeypatch.setattr(engine,'request_json',lambda *_:{'tag_name':'v2','assets':[
        {'name':'Hardware-Sniffer-CLI.exe','browser_download_url':'https://example.org/new',
         'digest':'sha256:not-a-real-hash'}]})
    monkeypatch.setattr(engine,'download',lambda *_a,**_kw: pytest.fail('Must reject metadata before download'))
    with pytest.raises(RuntimeError,match='malformed publisher'):
        engine.deep_scan(cache,tmp_path/'Report')


def test_matching_official_digest_reuses_cached_scanner(tmp_path,monkeypatch):
    windows_environment(monkeypatch)
    cache,binary,manifest=prepare_sniffer(tmp_path)
    actual=hashlib.sha256(binary.read_bytes()).hexdigest()
    monkeypatch.setattr(engine,'request_json',lambda *_:{'tag_name':'v1','assets':[
        {'name':'Hardware-Sniffer-CLI.exe','browser_download_url':'https://example.org/old',
         'digest':'sha256:'+actual}]})
    monkeypatch.setattr(engine,'download',lambda *_a,**_kw: pytest.fail('Use verified cache'))
    monkeypatch.setattr(engine.subprocess,'run',lambda args,**kw:fake_report_process(args[-1]))
    result=engine.deep_scan(cache,tmp_path/'Report')
    assert result['sniffer']['cached']
    assert result['scan_seal']['acpi_tables']==1

@pytest.mark.parametrize('payload', [b'[]',b'null',b'{broken',b' '*(512*1024+1)])
def test_build_manifest_reader_rejects_malformed_or_oversize(tmp_path,payload):
    from hackpilot.efi import load_build_manifest
    (tmp_path/'build-manifest.json').write_bytes(payload)
    with pytest.raises(RuntimeError, match='Build manifest'):
        load_build_manifest(tmp_path)


def test_linked_manifest_is_never_trusted(tmp_path):
    from hackpilot.efi import load_build_manifest
    original=tmp_path/'good.json'
    original.write_text('{"target_darwin":"24.0.0"}')
    manifest=tmp_path/'build-manifest.json'
    try:
        manifest.symlink_to(original)
    except (OSError,NotImplementedError):
        pytest.skip('Symlinks unsupported')
    with pytest.raises(RuntimeError, match='linked'):
        load_build_manifest(tmp_path)


def test_valid_manifest_reader_roundtrip(tmp_path):
    from hackpilot.efi import load_build_manifest
    expected={'engine':'OpCore-Simplify','target_darwin':'24.0.0'}
    (tmp_path/'build-manifest.json').write_text(json.dumps(expected))
    assert load_build_manifest(tmp_path)==expected


def test_oversized_manifest_exposes_error_in_efi_validator(tmp_path):
    build,_=fixture(tmp_path)
    (build/'build-manifest.json').write_bytes(b' '*(512*1024+1))
    result=validate_efi(build)
    assert not result['valid']
    assert any('Build manifest is malformed' in problem for problem in result['errors'])


def test_oversized_manifest_cannot_pick_recovery(tmp_path):
    state=server.State(home=tmp_path/'home')
    state.build_dir.mkdir(parents=True)
    (state.build_dir/'build-manifest.json').write_bytes(b' '*(512*1024+1))
    with pytest.raises(RuntimeError,match='Cannot select Apple recovery'):
        state.expected_recovery_profile()

@pytest.mark.parametrize('bad_target', ['24.x.0', '24.2oops', '24.2.0.extra', 24, None, ' 24.2.0', '024.2.0'])
def test_recovery_profile_rejects_malformed_darwin_target(bad_target):
    from hackpilot.recovery import profile_for_darwin
    with pytest.raises(RuntimeError):
        profile_for_darwin(bad_target)


def test_one_click_never_claims_prepared_if_usb_copy_did_not_confirm_recovery(tmp_path,monkeypatch):
    from test_one_click import new_state, fake_setup
    state=new_state(tmp_path,monkeypatch)
    fake_setup(state,monkeypatch)
    monkeypatch.setattr(server,'safe_usb_copy',lambda *_a,**_kw:{'copied_efi':True,'copied_recovery':False,'recovery_present':False})
    with pytest.raises(RuntimeError, match='did not confirm both'):
        state.one_click('Q','PREPARE Q:')
    assert not state.usb_copied and not state.usb_prepared

@pytest.mark.parametrize('extra', ['injected.efi','README.txt','injected-directory'])
def test_recovery_refuses_unverified_extra_contents(tmp_path,extra):
    from hackpilot.recovery import _recovery_metadata,verify_recovery
    folder=tmp_path/'com.apple.recovery.boot';folder.mkdir()
    (folder/'BaseSystem.dmg').write_bytes(b'dmg')
    (folder/'BaseSystem.chunklist').write_bytes(b'chunklist')
    board='Mac-7BA5B2D9E42DDD94'
    (tmp_path/'recovery-info.json').write_text(json.dumps(_recovery_metadata(folder,board)))
    assert verify_recovery(folder,board)
    if extra.endswith('directory'):
        (folder/extra).mkdir()
    else:
        (folder/extra).write_bytes(b'not verified')
    assert not verify_recovery(folder,board)


def test_recovery_rejects_oversized_integrity_metadata(tmp_path):
    from hackpilot.recovery import verify_recovery
    folder=tmp_path/'com.apple.recovery.boot';folder.mkdir()
    (folder/'BaseSystem.dmg').write_bytes(b'dmg')
    (folder/'BaseSystem.chunklist').write_bytes(b'chunk')
    (tmp_path/'recovery-info.json').write_bytes(b' '*(512*1024+1))
    assert not verify_recovery(folder)


def test_usb_companion_inference_is_not_a_physical_port_test(tmp_path):
    from hackpilot import usb_mapping as mapping
    from test_v15_usb_mapping import raw_device
    snapshot=mapping.merge_snapshots(None,mapping.normalize_snapshot(raw_device()))
    keyboard,companion,bluetooth=snapshot['controllers'][0]['ports'][:3]
    assert keyboard['physically_seen'] and bluetooth['physically_seen']
    assert companion['seen'] and companion['selected']
    assert companion['physically_seen'] is False
    built=mapping.generate_utbmap(snapshot,tmp_path)
    assert built['unseen']==1


def test_physically_tested_port_persists_after_disconnection():
    from hackpilot import usb_mapping as mapping
    from test_v15_usb_mapping import raw_device
    scan=mapping.merge_snapshots(None,mapping.normalize_snapshot(raw_device()))
    updated=mapping.merge_snapshots(scan,mapping.normalize_snapshot(raw_device(connected=False)))
    keyboard=updated['controllers'][0]['ports'][0]
    assert not keyboard['active'] and keyboard['physically_seen'] is True
    assert keyboard['seen'] and keyboard['selected']


def test_status_counts_only_physically_observed_usb_ports(tmp_path):
    from hackpilot import usb_mapping as mapping
    from hackpilot.engine import _atomic_json
    from test_v15_usb_mapping import raw_device
    state=server.State(home=tmp_path/'home')
    snapshot=mapping.merge_snapshots(None,mapping.normalize_snapshot(raw_device()))
    _atomic_json(state.mapping_dir/'ports.json',snapshot)
    status=state.usb_mapping_status()
    assert status['selected_ports']==3
    assert status['verified_ports']==2
    assert status['unseen_selected']==1
