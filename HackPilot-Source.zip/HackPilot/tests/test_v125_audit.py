import http.client
import json
import re
import threading

import pytest
from hackpilot import server
from hackpilot.server import State


def test_busy_rufus_request_preserves_prior_usb_state(tmp_path, monkeypatch):
    state=State(home=tmp_path/'home')
    state.usb_copied=True;state.usb_prepared=True
    state.tasks={'busy':{'state':'running','name':'Another operation'}}
    monkeypatch.setattr(server.rufus_tool,'open_rufus',lambda *_:pytest.fail('Must not launch Rufus'))
    app=server.create_server(state)
    thread=threading.Thread(target=app.serve_forever,daemon=True);thread.start()
    connection=http.client.HTTPConnection('127.0.0.1',app.server_port,timeout=5)
    try:
        connection.request('GET','/')
        index=connection.getresponse().read().decode()
        token=re.search(r'name="hackpilot-token" content="([^"]+)"',index)[1]
        connection.request('POST','/api/rufus',json.dumps({'consent':True}),{'Content-Type':'application/json','X-HackPilot-Token':token})
        response=connection.getresponse();body=json.loads(response.read())
        assert response.status==400 and 'Another operation' in body['error']
        assert state.usb_copied and state.usb_prepared
    finally:
        connection.close();app.shutdown();app.server_close()


def test_failed_repair_does_not_keep_old_usb_ready_badge(tmp_path, monkeypatch):
    state=State(home=tmp_path)
    state.usb_copied=True;state.usb_prepared=True
    def fail(*_):raise RuntimeError('Transfer receipt is damaged')
    monkeypatch.setattr(server,'repair_usb',fail)
    with pytest.raises(RuntimeError):state.repair_usb('Q','REPAIR Q:')
    assert not state.usb_copied and not state.usb_prepared


def test_unreadable_copy_manifest_does_not_keep_old_usb_ready_badge(tmp_path, monkeypatch):
    state=State(home=tmp_path)
    state.usb_copied=True;state.usb_prepared=True
    state.build_dir.mkdir(parents=True)
    (state.build_dir/'build-manifest.json').write_text('{}')
    def fail(*_):raise RuntimeError('Invalid manifest')
    monkeypatch.setattr(server,'load_build_manifest',fail)
    with pytest.raises(RuntimeError):state.copy_usb('Q','COPY TO Q:')
    assert not state.usb_copied and not state.usb_prepared
