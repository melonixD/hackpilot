"""Release-blocking v1.3 tests for the end-to-end installer guardrails."""
import hashlib
import json
import plistlib
import uuid
from pathlib import Path

import pytest

from hackpilot import recovery, server
from hackpilot.efi_audit import audit_efi_components
from test_v12_component_audit import fixture, save_config
from test_one_click import new_state, fake_setup


def valid_smbios(config):
    config['PlatformInfo']['Generic'].update({
        'SystemSerialNumber':'C02TQHACHH27',
        'SystemUUID':str(uuid.uuid4()),
        'MLB':'C02815401CDTESTING',
        'ROM':b'\x02\x12\x34\x56\x78\x9a',
    })


def test_required_kext_with_minkernel_after_target_is_not_usable(tmp_path):
    build,config = fixture(tmp_path)
    valid_smbios(config)
    config['Kernel']['Add'][0]['MinKernel'] = '25.0.0'
    save_config(build,config)
    result = audit_efi_components(build,target_darwin='24.7.0')
    assert any('Required Lilu.kext' in e for e in result['errors'])
    result = audit_efi_components(build,target_darwin='25.1.0')
    assert not any('Required Lilu.kext' in e for e in result['errors'])


def test_maxkernel_prevents_virtualsmc_loading(tmp_path):
    build,config=fixture(tmp_path)
    valid_smbios(config)
    config['Kernel']['Add'][1]['MaxKernel']='23.99.99'
    save_config(build,config)
    result=audit_efi_components(build,target_darwin='24.0.0')
    assert any('Required VirtualSMC.kext' in e for e in result['errors'])


def test_malformed_kernel_range_fails_cleanly(tmp_path):
    build,config=fixture(tmp_path)
    valid_smbios(config)
    config['Kernel']['Add'][0]['MinKernel'] = [22, 0, 0]
    save_config(build,config)
    result = audit_efi_components(build,target_darwin='24.0.0')
    assert any('Invalid kext MinKernel' in e for e in result['errors'])


def test_fallback_smbios_placeholder_and_bad_uuid_rejected(tmp_path):
    build,config=fixture(tmp_path)
    valid_smbios(config)
    config['PlatformInfo']['Generic'].update({
        'SystemSerialNumber':'A'+'0'*10+'9',
        'MLB':'A'+'0'*15+'Z',
        'SystemUUID':'00000000-0000-0000-0000-000000000000',
        'ROM':b'wrong',
    })
    save_config(build,config)
    errors=audit_efi_components(build,target_darwin='24.0.0')['errors']
    assert any('serial' in e for e in errors)
    assert any('MLB' in e for e in errors)
    assert any('SystemUUID' in e for e in errors)
    assert any('ROM' in e for e in errors)


def test_versioned_efi_valid_identity_passes_component_audit(tmp_path):
    build,config=fixture(tmp_path)
    valid_smbios(config)
    save_config(build,config)
    assert audit_efi_components(build,target_darwin='24.0.0')['errors']==[]


def test_manual_usb_copy_rejects_recovery_for_another_macos(monkeypatch,tmp_path):
    state=server.State(home=tmp_path)
    state.build_dir.mkdir(parents=True)
    (state.build_dir/'build-manifest.json').write_text(json.dumps({'target_darwin':'24.7.0'}))
    state.last_build={'valid':True, 'fingerprint':'fake'}
    state.recovery_dir=str(tmp_path/'Recovery'/'com.apple.recovery.boot')
    (Path(state.recovery_dir)).mkdir(parents=True)
    monkeypatch.setattr(server,'efi_fingerprint',lambda *_:'fake')
    monkeypatch.setattr(server,'validate_efi',lambda *_:{'valid':True,'fingerprint':'fake'})
    monkeypatch.setattr(server,'safe_usb_copy',lambda *_a,**_kw:pytest.fail('USB copy must not run'))
    seen=[]
    def version_check(folder,board,major,channel, **kwargs):
        seen.append((board,major,channel))
        return False
    monkeypatch.setattr(server,'verify_recovery',version_check)
    with pytest.raises(RuntimeError,match='does not match'):
        state.copy_usb('Q','COPY TO Q:')
    assert seen==[('Mac-7BA5B2D9E42DDD94','24','default')]


def test_manual_recovery_refuses_conflicting_board_id(monkeypatch,tmp_path):
    state=server.State(home=tmp_path)
    state.build_dir.mkdir(parents=True)
    (state.build_dir/'build-manifest.json').write_text(json.dumps({'target_darwin':'24.0.0'}))
    monkeypatch.setattr(server,'download_recovery',lambda *_a,**_kw:pytest.fail('download must not start'))
    with pytest.raises(RuntimeError,match='conflicts'):
        state.recovery('Mac-CFF7D910A743CAAF')


def test_one_click_without_network_refuses_before_engine_and_usb(monkeypatch,tmp_path):
    state=new_state(tmp_path,monkeypatch)
    calls=fake_setup(state,monkeypatch)
    original_scan=state.deep_scan
    def scan_without_network():
        original_scan()
        state.hardware['network']=[]
    monkeypatch.setattr(state,'deep_scan',scan_without_network)
    with pytest.raises(RuntimeError,match='No network adapter detected'):
        state.one_click('Q','PREPARE Q:')
    assert calls==['scan']


def test_recovery_worker_update_failure_restores_old_tool_and_manifest(monkeypatch,tmp_path):
    cache=tmp_path/'cache';cache.mkdir()
    old_bytes=b'old macrecovery worker'
    tool=cache/'macrecovery.py';tool.write_bytes(old_bytes)
    old_meta={'sha256':hashlib.sha256(old_bytes).hexdigest(),'url':'original'}
    manifest=cache/'macrecovery-manifest.json';manifest.write_text(json.dumps(old_meta))
    def valid_download(url,path,maxsize):
        Path(path).write_bytes(b'new tool')
        return {'sha256':hashlib.sha256(b'new tool').hexdigest(),'url':url}
    monkeypatch.setattr(recovery,'download', valid_download)
    monkeypatch.setattr(recovery,'_git_blob_sha1',lambda *_: recovery.MACRECOVERY_BLOB_SHA1)
    monkeypatch.setattr(recovery,'MACRECOVERY_SHA256',hashlib.sha256(b'new tool').hexdigest())
    # Force refresh of an initially cached tool by giving a different checksum
    manifest.write_text(json.dumps({'sha256':'bad','url':'original'}))
    previous_manifest=manifest.read_bytes()
    monkeypatch.setattr(recovery,'_atomic_json',lambda *_: (_ for _ in ()).throw(OSError('disk full')))
    with pytest.raises(OSError, match='disk full'):
        recovery.download_recovery(cache,tmp_path/'Recovery','Mac-7BA5B2D9E42DDD94')
    assert tool.read_bytes()==old_bytes
    assert manifest.read_bytes()==previous_manifest
    assert not (cache/'macrecovery.py.rollback').exists()
    assert not (cache/'macrecovery.py.incoming').exists()


def test_recovery_worker_hash_mismatch_does_not_replace_existing(monkeypatch,tmp_path):
    cache=tmp_path/'cache';cache.mkdir()
    tool=cache/'macrecovery.py';tool.write_bytes(b'old')
    def invalid_download(url,path,size):
        Path(path).write_bytes(b'new')
        return {'sha256':'invalid'}
    monkeypatch.setattr(recovery,'download',invalid_download)
    with pytest.raises(RuntimeError,match='checksum mismatch'):
        recovery.download_recovery(cache,tmp_path/'Recovery','Mac-7BA5B2D9E42DDD94')
    assert tool.read_bytes()==b'old'


def test_missing_nonapple_kext_dependency_is_blocked(tmp_path):
    build,config=fixture(tmp_path)
    valid_smbios(config)
    kext=build/'EFI'/'OC'/'Kexts'/'VirtualSMC.kext'/'Contents'/'Info.plist'
    with kext.open('rb') as f: info=plistlib.load(f)
    info['OSBundleLibraries']['com.example.RequiredSupport']='1.0.0'
    with kext.open('wb') as f:plistlib.dump(info,f)
    errors=audit_efi_components(build,target_darwin='24.0.0')['errors']
    assert any('missing enabled dependency com.example.RequiredSupport' in x for x in errors)


def test_builtin_apple_kext_dependency_is_not_falsely_blocked(tmp_path):
    build,config=fixture(tmp_path)
    valid_smbios(config)
    save_config(build,config)
    kext=build/'EFI'/'OC'/'Kexts'/'VirtualSMC.kext'/'Contents'/'Info.plist'
    with kext.open('rb') as f: info=plistlib.load(f)
    info['OSBundleLibraries']['com.apple.kpi.libkern']='20.0.0'
    with kext.open('wb') as f:plistlib.dump(info,f)
    assert audit_efi_components(build,target_darwin='24.0.0')['errors']==[]


def test_opencore_release_components_are_checked_before_validator(monkeypatch,tmp_path):
    import os
    from hackpilot import efi as e
    from test_v12_component_audit import write_pe
    build,config=fixture(tmp_path)
    valid_smbios(config)
    save_config(build,config)
    (build/'build-manifest.json').write_text(json.dumps({'target_darwin':'24.0.0'}))
    validator=tmp_path/'validator';validator.mkdir()
    binary=validator/('ocvalidate.exe' if os.name=='nt' else 'ocvalidate')
    binary.write_bytes(b'fake-ocvalidate')
    boot=build/'EFI'/'OC'/'OpenCore.efi'
    def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    (validator/'validator-manifest.json').write_text(json.dumps({
        'binary_sha256':sha(binary), 'opencore_sha256':sha(boot),
        'bootx64_sha256':'f'*64, 'openruntime_sha256':sha(build/'EFI'/'OC'/'Drivers'/'OpenRuntime.efi')
    }))
    monkeypatch.setattr(e.subprocess,'run',lambda *_a,**_kw:pytest.fail('Bad boot must stop before validator'))
    result=e.validate_efi(build,validator)
    assert not result['valid']
    assert any('BOOTx64.efi does not match' in x for x in result['errors'])


def test_tahoe_analog_audio_does_not_get_certified(tmp_path):
    from test_v12_component_audit import write_kext
    build,config=fixture(tmp_path)
    valid_smbios(config)
    config['Kernel']['Add'].append(write_kext(build/'EFI'/'OC','AppleALC.kext','as.vit9696.AppleALC',{'as.vit9696.Lilu':'1.0'},executable='AppleALC'))
    save_config(build,config)
    result=audit_efi_components(build,target_darwin='25.0.0')
    assert result['errors']==[]
    assert any('AppleALC' in warning and 'analog audio' in warning for warning in result['warnings'])


def test_auto_target_does_not_follow_upstream_into_unprofiled_macos():
    from hackpilot.upstream_adapter import select_native_target
    def v(s): return tuple(map(int,s.split('.')))
    target=select_native_target(['20.0.0','26.99.99'],'26.0.0','auto',v)
    assert target=='25.0.0'
    with pytest.raises(RuntimeError,match='native compatibility'):
        select_native_target(['26.0.0','26.99.99'],'26.0.0','auto',v)


def test_manual_target_cannot_choose_unprofiled_macos():
    from hackpilot.upstream_adapter import select_native_target
    def v(s): return tuple(map(int,s.split('.')))
    with pytest.raises(RuntimeError,match='unsupported'):
        select_native_target(['20.0.0','26.99.99'],'26.0.0','26',v)
