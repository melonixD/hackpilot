"""v1.16: verify bad outcomes are rejected, not merely successful examples."""
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from hackpilot import recovery, server

BOARD_OLD = 'Mac-7BA5B2D9E42DDD94'
BOARD_NEW = 'Mac-7BA5B2D9E42DDD95'


def _mock_apple_download(tmp_path, monkeypatch):
    """No network or macOS dependency: signed-image validator is stubbed."""
    content = b'# test-only mock worker\n' + b'# sample\n'*550
    monkeypatch.setattr(recovery, 'MACRECOVERY_SHA256', hashlib.sha256(content).hexdigest())
    monkeypatch.setattr(recovery, '_git_blob_sha1', lambda _p: recovery.MACRECOVERY_BLOB_SHA1)
    monkeypatch.setattr(recovery, 'verify_apple_recovery_assets', lambda *a: True)

    def fake_download(url, dst, maximum):
        dst = Path(dst)
        dst.parent.mkdir(exist_ok=True, parents=True)
        dst.write_bytes(content)
        return {'sha256': hashlib.sha256(content).hexdigest(), 'url': url}

    def fake_run(args, cwd, stdout, stderr, timeout):
        (Path(cwd) / 'BaseSystem.dmg').write_bytes(b'new-image')
        (Path(cwd) / 'BaseSystem.chunklist').write_bytes(b'new-signature')
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(recovery, 'download', fake_download)
    monkeypatch.setattr(recovery.subprocess, 'run', fake_run)
    return tmp_path / 'cache'


def _old_recovery(output):
    directory = output / 'com.apple.recovery.boot'
    directory.mkdir(parents=True)
    (directory / 'BaseSystem.dmg').write_bytes(b'old-image')
    (directory / 'BaseSystem.chunklist').write_bytes(b'old-signature')
    metadata = recovery._recovery_metadata(directory, BOARD_OLD, '24', 'default')
    (output / 'recovery-info.json').write_text(json.dumps(metadata))
    return directory, (output / 'recovery-info.json').read_bytes()


def test_verified_new_recovery_cleans_old_multi_gigabyte_backup(tmp_path, monkeypatch):
    cache = _mock_apple_download(tmp_path, monkeypatch)
    output = tmp_path / 'recovery'
    _old_recovery(output)
    result = recovery.download_recovery(cache, output, BOARD_NEW, 'default', '24')
    assert (output/'com.apple.recovery.boot'/'BaseSystem.dmg').read_bytes() == b'new-image'
    assert 'verified' in result['note']
    assert not list(output.glob('recovery-backup-*'))
    assert recovery.verify_recovery(output/'com.apple.recovery.boot', BOARD_NEW,
                                    '24', 'default', require_apple_signature=True)


def test_published_recovery_verification_failure_restores_previous_good_image(tmp_path, monkeypatch):
    cache = _mock_apple_download(tmp_path, monkeypatch)
    output = tmp_path / 'recovery'
    _old, old_manifest = _old_recovery(output)
    real_verify = recovery.verify_recovery
    def reject_new_published(folder, *a, **kw):
        if Path(folder) == output / 'com.apple.recovery.boot' and (Path(folder)/'BaseSystem.dmg').read_bytes() == b'new-image':
            return False
        return real_verify(folder, *a, **kw)
    monkeypatch.setattr(recovery, 'verify_recovery', reject_new_published)
    with pytest.raises(RuntimeError, match='read-back verification'):
        recovery.download_recovery(cache, output, BOARD_NEW, 'default', '24')
    assert (output/'com.apple.recovery.boot'/'BaseSystem.dmg').read_bytes() == b'old-image'
    assert (output/'recovery-info.json').read_bytes() == old_manifest
    assert not list(output.glob('recovery-backup-*'))


def test_recovery_failure_during_publish_restores_existing_image(tmp_path, monkeypatch):
    cache = _mock_apple_download(tmp_path, monkeypatch)
    output = tmp_path / 'recovery'
    _old, old_manifest = _old_recovery(output)
    real_atomic = recovery._atomic_json
    def broken_metadata(path, data):
        if Path(path).name == 'recovery-info.json':
            raise OSError('write permission denied')
        return real_atomic(path, data)
    monkeypatch.setattr(recovery, '_atomic_json', broken_metadata)
    with pytest.raises(OSError, match='write permission denied'):
        recovery.download_recovery(cache, output, BOARD_NEW, 'default', '24')
    assert (output/'com.apple.recovery.boot'/'BaseSystem.dmg').read_bytes() == b'old-image'
    assert (output/'recovery-info.json').read_bytes() == old_manifest
    assert not list(output.glob('recovery-backup-*'))


def test_build_log_tail_handles_gigantic_log_without_unbounded_read(tmp_path, monkeypatch):
    file = tmp_path/'build.log'
    with file.open('wb') as out:
        out.seek(50 * 1024 * 1024)
        out.write(b'LAST RECOVERY ERROR\n')
    real_open = Path.open
    observed = []
    def guarded_open(path, mode='r', *args, **kwargs):
        f = real_open(path, mode, *args, **kwargs)
        if Path(path) == file and mode == 'rb':
            class Guard:
                def __enter__(self): return self
                def __exit__(self, *exc): f.close()
                def seek(self, *args): return f.seek(*args)
                def tell(self): return f.tell()
                def read(self, size=-1):
                    observed.append(size)
                    assert 0 <= size <= 56000, 'Must never read the entire log'
                    return f.read(size)
            return Guard()
        return f
    monkeypatch.setattr(Path, 'open', guarded_open)
    assert 'LAST RECOVERY ERROR' in server._bounded_text_tail(file)
    assert observed and max(observed) <= 56000
    assert server._bounded_text_tail(tmp_path/'missing.log') == ''


def test_usb_refresh_invalidates_old_build_readiness(tmp_path, monkeypatch):
    state = server.State(home=tmp_path)
    state.last_build = {'valid': True}
    state.usb_copied = state.usb_prepared = True
    monkeypatch.setattr(server, 'install_backend', lambda *a: {})
    monkeypatch.setattr(server, 'discover_controllers', lambda *_: [])
    monkeypatch.setattr(server, 'normalize_snapshot', lambda *_: {'controllers': []})
    monkeypatch.setattr(server, 'merge_snapshots', lambda *_: {'controllers': []})
    monkeypatch.setattr(state, 'usb_mapping_status', lambda: {})
    state.scan_usb_ports()
    assert state.last_build is None
    assert not state.usb_copied and not state.usb_prepared


def test_failed_build_preflight_invalidates_old_success(tmp_path):
    state = server.State(home=tmp_path)
    state.last_build = {'valid': True}
    state.usb_copied = state.usb_prepared = True
    with pytest.raises(ValueError, match='Unsupported macOS selection'):
        state.build('malformed-target')
    assert state.last_build is None
    assert not state.usb_copied and not state.usb_prepared


def test_failing_efi_revalidation_clears_previous_usb_ready(tmp_path, monkeypatch):
    state = server.State(home=tmp_path)
    state.last_build = {'valid': True}
    state.usb_copied = state.usb_prepared = True
    monkeypatch.setattr(server, 'validate_efi', lambda *a: {'valid': False, 'errors': ['bad kext']})
    result = state.validate()
    assert not result['valid']
    assert not state.usb_prepared and not state.usb_copied


def test_usb_backend_update_failure_restores_previous_files(tmp_path, monkeypatch):
    from hackpilot import usb_mapping
    cache = tmp_path/'cache'; cache.mkdir()
    old = cache/'usbtoolbox'; old.mkdir(); (old/'previous.py').write_text('stable')
    manifest = cache/'usbtoolbox-manifest.json'; manifest.write_bytes(b'old metadata')
    monkeypatch.setattr(usb_mapping,'backend_verified', lambda _: False)
    monkeypatch.setattr(usb_mapping,'request_json',lambda *_:{'sha':'a'*40})
    monkeypatch.setattr(usb_mapping,'download',lambda *a,**kw: None)
    monkeypatch.setattr(usb_mapping,'_backend_digest',lambda _: 'file-tree-hash')
    def unpack(_archive,folder):
        content=folder/'source'; (content/'Scripts').mkdir(parents=True)
        (content/'Scripts'/'usbdump.py').write_text('new scanner')
    monkeypatch.setattr(usb_mapping,'safe_unzip',unpack)
    monkeypatch.setattr(usb_mapping,'_atomic_json',lambda *a: (_ for _ in ()).throw(OSError('metadata write failed')))
    with pytest.raises(OSError,match='metadata write failed'):
        usb_mapping.install_backend(cache)
    assert (old/'previous.py').read_text() == 'stable'
    assert manifest.read_bytes() == b'old metadata'
    assert not list(cache.glob('usbtoolbox-prev-*'))


def test_failed_usb_backend_rollback_preserves_last_working_copy(tmp_path, monkeypatch):
    from hackpilot import usb_mapping
    cache = tmp_path/'cache'; cache.mkdir()
    old = cache/'usbtoolbox'; old.mkdir(); (old/'previous.py').write_text('stable')
    manifest = cache/'usbtoolbox-manifest.json'; manifest.write_bytes(b'old metadata')
    monkeypatch.setattr(usb_mapping,'backend_verified',lambda _:False)
    monkeypatch.setattr(usb_mapping,'request_json',lambda *_:{'sha':'a'*40})
    monkeypatch.setattr(usb_mapping,'download',lambda *a,**kw:None)
    monkeypatch.setattr(usb_mapping,'_backend_digest',lambda _:'file-tree-hash')
    def unpack(_archive,folder):
        content=folder/'source'; (content/'Scripts').mkdir(parents=True)
        (content/'Scripts'/'usbdump.py').write_text('new scanner')
    monkeypatch.setattr(usb_mapping,'safe_unzip',unpack)
    monkeypatch.setattr(usb_mapping,'_atomic_json',lambda *a: (_ for _ in ()).throw(OSError('manifest write failed')))
    original_rename=Path.rename
    def interrupted_rollback(path,target):
        if path.name.startswith('usbtoolbox-prev-') and Path(target)==old:
            raise OSError('simulated antivirus file lock')
        return original_rename(path,target)
    monkeypatch.setattr(Path,'rename',interrupted_rollback)
    with pytest.raises(RuntimeError, match='backup retained'):
        usb_mapping.install_backend(cache)
    backups=list(cache.glob('usbtoolbox-prev-*'))
    assert len(backups)==1, 'Must not silently delete the only working backend'
    assert (backups[0]/'previous.py').read_text()=='stable'
    assert manifest.read_bytes()==b'old metadata'


def test_validator_manifest_size_limit_rejects_without_unbounded_read(tmp_path,monkeypatch):
    from hackpilot import efi
    from test_v12_component_audit import fixture
    build,_=fixture(tmp_path)
    validator=tmp_path/'validator';validator.mkdir()
    (validator/'ocvalidate').write_bytes(b'test-only binary')
    manifest=validator/'validator-manifest.json'
    with manifest.open('wb') as stream:
        stream.seek(1024*1024)
        stream.write(b'x')
    original_read_text=Path.read_text
    def read_text(path,*args,**kwargs):
        if Path(path)==manifest:
            pytest.fail('Oversized validator metadata must never be read unbounded')
        return original_read_text(path,*args,**kwargs)
    monkeypatch.setattr(Path,'read_text',read_text)
    result=efi.validate_efi(build,validator)
    assert not result['valid']
    assert any('128 KiB' in str(e) for e in result['errors'])


def test_worker_failure_log_is_read_from_bounded_tail(tmp_path,monkeypatch):
    from hackpilot import engine
    root=tmp_path/'engine';(root/'Scripts').mkdir(parents=True)
    log=tmp_path/'log'/'worker.log'
    def fail_worker(args,stdout,stderr,timeout,env):
        stdout.seek(1024*1024*32)
        stdout.write('ERROR: failed upstream component\n')
        return SimpleNamespace(returncode=2)
    monkeypatch.setattr(engine.subprocess,'run',fail_worker)
    original=Path.read_text
    def guarded_read(path,*args,**kwargs):
        if Path(path)==log:
            pytest.fail('Worker logs must not be loaded entirely')
        return original(path,*args,**kwargs)
    monkeypatch.setattr(Path,'read_text',guarded_read)
    with pytest.raises(RuntimeError,match='failed upstream component'):
        engine.run_auto_builder(root,tmp_path/'report.json',tmp_path/'ACPI',tmp_path/'out',log)


def test_symlinked_recovery_metadata_blocks_publish(tmp_path,monkeypatch):
    cache=_mock_apple_download(tmp_path,monkeypatch)
    output=tmp_path/'recovery';output.mkdir()
    external=tmp_path/'not-a-manifest';external.write_text('external data')
    manifest=output/'recovery-info.json'
    try: manifest.symlink_to(external)
    except (OSError, NotImplementedError): pytest.skip('Symlinks unavailable')
    with pytest.raises(RuntimeError,match='Linked recovery metadata'):
        recovery.download_recovery(cache,output,BOARD_NEW,'default','24')
    assert external.read_text()=='external data'
    assert not (output/'com.apple.recovery.boot').exists()


def test_linked_workspace_lock_refuses_redirect(tmp_path):
    from hackpilot.workspace_lock import workspace_lock
    target=tmp_path/'outside.txt';target.write_text('do not modify')
    path=tmp_path/'workspace.lock'
    try: path.symlink_to(target)
    except (OSError, NotImplementedError):pytest.skip('Symlinks unavailable')
    with pytest.raises(RuntimeError,match='lockfile is linked'):
        with workspace_lock(tmp_path): pass
    assert target.read_text() == 'do not modify'


def test_linked_usb_transfer_lock_refuses_redirect(tmp_path):
    from hackpilot import usb
    target=tmp_path/'outside.txt';target.write_text('do not modify')
    locks=tmp_path/'transactions';locks.mkdir()
    path=locks/'usb-Q.lock'
    try: path.symlink_to(target)
    except (OSError, NotImplementedError):pytest.skip('Symlinks unavailable')
    with pytest.raises(RuntimeError,match='lockfile is linked'):
        with usb._transfer_lock(tmp_path,'Q'): pass
    assert target.read_text() == 'do not modify'


def test_fat16_not_advertised_as_usb_install_target():
    app=(Path(__file__).parent.parent/'web'/'app.js').read_text(encoding='utf-8')
    assert "String(d.filesystem).toUpperCase()==='FAT32'" in app
    assert "['FAT32','FAT'].includes" not in app
    assert 'usb.length>1?' in app and 'Choose USB' in app


def test_display_version_comes_from_application_status():
    app=(Path(__file__).parent.parent/'web'/'app.js').read_text(encoding='utf-8')
    assert "S.version)id('app-version').textContent" in app
    index=(Path(__file__).parent.parent/'web'/'index.html').read_text(encoding='utf-8')
    assert 'id="app-version"' in index


def test_failed_old_recovery_backup_cleanup_reports_nonfatal_disk_usage(tmp_path,monkeypatch):
    cache=_mock_apple_download(tmp_path,monkeypatch)
    output=tmp_path/'recovery';_old_recovery(output)
    original= recovery.shutil.rmtree
    def deny_old_cleanup(folder,*args,**kwargs):
        if Path(folder).name.startswith('recovery-backup-'):
            raise OSError('simulated Windows antivirus lock')
        return original(folder,*args,**kwargs)
    monkeypatch.setattr(recovery.shutil,'rmtree',deny_old_cleanup)
    result=recovery.download_recovery(cache,output,BOARD_NEW,'default','24')
    assert 'old recovery backup needs cleanup' in result['note']
    assert (output/'com.apple.recovery.boot'/'BaseSystem.dmg').read_bytes()==b'new-image'
    assert len(list(output.glob('recovery-backup-*'))) == 1
