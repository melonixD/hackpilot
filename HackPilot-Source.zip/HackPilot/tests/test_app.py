import http.client
import json
import plistlib
from pathlib import Path
import stat
import os
import zipfile
import pytest

from hackpilot.compat import assess
from hackpilot.bios import checklist
from hackpilot.hardware import sniffer_summary, imported_native
from hackpilot.efi import validate_efi
from hackpilot.engine import safe_unzip
from hackpilot.server import State, create_server

SAMPLE={'cpu': {'name':'AMD Ryzen 5 5600X'}, 'gpus':[{'name':'NVIDIA GeForce RTX 5060'}],
        'firmware':{'type':'UEFI','secure_boot':'True'},'network':[{'name':'Intel Ethernet'}],
        'audio':[{'name':'Realtek Audio'}],'motherboard':{'name':'B550'}}

def test_compat_never_promises_universal_support():
    r=assess(SAMPLE)
    assert r['status']=='blocked' and not r['can_attempt']
    assert r['graphics_acceleration']=='unsupported'
    assert any('NVIDIA' in f['label'] for f in r['findings'])
    assert not any(f['level']=='pass' for f in r['findings'])

def test_cpu_architecture_blocks_and_no_gpu_blocks():
    r=assess({'cpu': {'name':'Qualcomm Snapdragon X Elite'},'gpus':[{'name':'Adreno'}]})
    assert not r['can_attempt']
    assert assess({'cpu':{'name':'Intel Core i7-9700K'},'gpus':[]})['status']=='blocked'

def test_sniffer_translation():
    raw={'CPU':{'Processor Name':'Ryzen 7','Core Count':8},'Motherboard':{'Name':'B650','Platform':'Desktop'},
         'GPU':{'AMD Radeon':{'Device ID':'1002-744C','Manufacturer':'AMD'}},'BIOS':{'Firmware Type':'UEFI'}}
    r=sniffer_summary(raw)
    assert r['cpu']['name']=='Ryzen 7' and r['gpus'][0]['name']=='AMD Radeon'
    assert r['firmware']['type']=='UEFI'

def test_import_invalid():
    with pytest.raises(ValueError): imported_native({'GPU':[]})

def _fixture_efi(tmp_path):
    root=tmp_path/'Output'/'EFI';oc=root/'OC'
    for p in [root/'BOOT',oc/'Kexts'/'VirtualSMC.kext'/'Contents',oc/'Drivers',oc/'ACPI']:
        p.mkdir(parents=True,exist_ok=True)
    for f in [root/'BOOT'/'BOOTx64.efi',oc/'OpenCore.efi',oc/'Drivers'/'OpenRuntime.efi',oc/'Kexts'/'VirtualSMC.kext'/'Contents'/'Info.plist']:
        f.write_bytes(b'fixture')
    config={'ACPI':{'Add':[]},'Kernel':{'Add':[{'Enabled':True,'BundlePath':'VirtualSMC.kext','ExecutablePath':'','PlistPath':'Contents/Info.plist'}]},
            'UEFI':{'Drivers':[{'Enabled':True,'Path':'OpenRuntime.efi'}]},'Misc':{},
            'PlatformInfo':{'Generic':{'SystemSerialNumber':'DEMO123','SystemUUID':'00000000-0000-0000-0000-000000000001'}}}
    with (oc/'config.plist').open('wb') as f:plistlib.dump(config,f)
    return tmp_path/'Output'

def test_validation_requires_real_ocvalidate(tmp_path):
    out=_fixture_efi(tmp_path)
    result=validate_efi(out)
    assert result['structural_valid'] and not result['valid']
    assert not result['validator_ran']

def test_validator_rejects_missing_kext(tmp_path):
    out=_fixture_efi(tmp_path)
    (out/'EFI'/'OC'/'Kexts'/'VirtualSMC.kext'/'Contents'/'Info.plist').unlink()
    result=validate_efi(out)
    assert not result['structural_valid']
    assert any('Info.plist' in err for err in result['errors'])

@pytest.mark.skipif(os.name=='nt', reason='POSIX shell validator test fixture')
def test_validator_success_with_mock_command(tmp_path):
    out=_fixture_efi(tmp_path)
    engine=tmp_path/'engine';engine.mkdir()
    executable=engine/'ocvalidate';executable.write_text('#!/bin/sh\necho Verified\nexit 0\n')
    executable.chmod(executable.stat().st_mode | stat.S_IXUSR)
    import hashlib
    validator_sha=hashlib.sha256(executable.read_bytes()).hexdigest()
    oc_sha=hashlib.sha256((out/'EFI'/'OC'/'OpenCore.efi').read_bytes()).hexdigest()
    (engine/'validator-manifest.json').write_text(json.dumps({'binary_sha256':validator_sha,'opencore_sha256':oc_sha}))
    result=validate_efi(out,engine)
    assert result['valid'] and result['validator_ran']

def test_safe_zip_extraction_prevents_traversal(tmp_path):
    z=tmp_path/'unsafe.zip'
    with zipfile.ZipFile(z,'w') as f:f.writestr('../../outside.txt','no')
    with pytest.raises(ValueError):safe_unzip(z,tmp_path/'unpacked')
    assert not (tmp_path/'outside.txt').exists()

def test_server_requires_csrf_for_mutations(tmp_path):
    s=State(demo=True,home=tmp_path/'data')
    server=create_server(s)
    import threading
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        c=http.client.HTTPConnection('127.0.0.1',server.server_port)
        c.request('GET','/api/status');res=c.getresponse()
        assert res.status==200;data=json.loads(res.read())
        assert data['demo'] and not data['build_exists']
        c.request('POST','/api/demo','{}',{'Content-Type':'application/json'})
        res=c.getresponse();assert res.status==403;res.read()
        c.close()
    finally:server.shutdown();server.server_close()

def test_demo_is_explicit(tmp_path):
    s=State(demo=False,home=tmp_path/'one')
    with pytest.raises(ValueError):s.demo_scan()
    demo=State(demo=True,home=tmp_path/'two')
    demo.demo_scan();assert demo.hardware['origin'].startswith('Synthetic')


def test_bios_guidance_is_read_only_and_mentions_storage():
    items=checklist(SAMPLE)
    assert any('Secure Boot' in x['title'] for x in items)
    assert any('Storage' in x['title'] for x in items)
    assert not any('disable every' in x['detail'].lower() for x in items)


def test_unexpected_macos_targets_are_refused(tmp_path):
    state=State(demo=False,home=tmp_path/'state')
    with pytest.raises(ValueError): state.build('unreviewed-system')
