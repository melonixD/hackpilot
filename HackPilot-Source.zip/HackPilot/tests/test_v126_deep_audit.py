"""Failure injection uses temporary files and simulated volumes only."""
import json
import os
import subprocess
import zipfile
from pathlib import Path

import pytest
from hackpilot import engine, usb_mapping, usb_journal, usb
from hackpilot.server import State
from test_quality import make_usb


@pytest.mark.parametrize('payload',[b'[]',b'null',b'true',b'123',b'"cache"'])
@pytest.mark.parametrize('name,check',[('engine-manifest.json',engine.cached_engine_verified),('usbtoolbox-manifest.json',usb_mapping.backend_verified)])
def test_nonobject_cache_metadata_is_untrusted_without_crashing(tmp_path,payload,name,check):
    (tmp_path/name).write_bytes(payload)
    assert check(tmp_path) is False


@pytest.mark.parametrize('phase',[[],{},['staged']])
def test_malformed_receipt_does_not_break_status_or_enable_repair(tmp_path,phase):
    home=tmp_path/'home';cache=home/'cache';cache.mkdir(parents=True)
    journal=home/'Backups'/'transactions';journal.mkdir(parents=True)
    (journal/'usb-Q-test.json').write_text(json.dumps({'phase':phase}))
    state=State(home=home)
    status=state.status()
    assert status['usb_recovery'][0]['phase']=='corrupt'
    with pytest.raises(RuntimeError,match='damaged or ambiguous'):
        usb.repair_usb('Q','REPAIR Q:',home/'Backups')


def test_excessive_json_nesting_in_receipt_does_not_break_status(tmp_path):
    journal=tmp_path/'Backups'/'transactions';journal.mkdir(parents=True)
    (journal/'usb-Q-deep.json').write_bytes(b'['*2000+b'0'+b']'*2000)
    assert State(home=tmp_path).status()['usb_recovery'][0]['phase']=='corrupt'


@pytest.mark.parametrize('payload',[b'[]',b'null',b'['*2000+b'0'+b']'*2000])
def test_validator_bad_cache_metadata_retries_lookup_safely(tmp_path,monkeypatch,payload):
    root=tmp_path/'validator';root.mkdir()
    binary=root/('ocvalidate.exe' if os.name=='nt' else 'ocvalidate')
    binary.write_bytes(b'old binary retained')
    (root/'validator-manifest.json').write_bytes(payload)
    def metadata(_):raise RuntimeError('Fresh validator lookup requested')
    monkeypatch.setattr(engine,'request_json',metadata)
    with pytest.raises(RuntimeError,match='Fresh validator lookup requested'):
        engine.setup_validator(tmp_path)
    assert binary.read_bytes()==b'old binary retained'


@pytest.mark.parametrize('names',[['parent','parent/child'],['Parent/child','parent'],['parent/','parent/child','PARENT/child/deeper']])
def test_file_directory_zip_collisions_are_rejected_before_extraction(tmp_path,names):
    archive=tmp_path/'conflict.zip'
    with zipfile.ZipFile(archive,'w') as z:
        for name in names:z.writestr(name,b'example')
    output=tmp_path/'output'
    with pytest.raises(ValueError,match='conflict'):
        engine.safe_unzip(archive,output)
    assert not list(output.iterdir())


@pytest.mark.parametrize('feed',[None,[],{'OpenCorePkg':[]},{'OpenCorePkg':{'versions':'invalid'}},{'OpenCorePkg':{'versions':[None]}}])
def test_malformed_validator_feed_stops_before_download(tmp_path,monkeypatch,feed):
    monkeypatch.setattr(engine,'request_json',lambda _:feed)
    monkeypatch.setattr(engine,'download',lambda *_a,**_kw:pytest.fail('No download from malformed metadata'))
    with pytest.raises(RuntimeError,match='validator'):
        engine.setup_validator(tmp_path)


def test_usb_swap_after_original_efi_rename_never_changes_replacement_volume(tmp_path,monkeypatch):
    drive,build,_=make_usb(tmp_path,monkeypatch)
    detached=tmp_path/'detached-original'
    actual_rename=Path.rename
    state={'swapped':False}
    def inventory():
        return [{'drive_letter':'Q','filesystem':'FAT32','free_bytes':500_000_000,'disk_number':5,'volume_id':'other-volume' if state['swapped'] else 'volume-A'}]
    monkeypatch.setattr(usb,'list_usb',inventory)
    def swap_after_old(self,target):
        result=actual_rename(self,target)
        if self==drive/'EFI' and Path(target)==drive/'EFI.hackpilot-previous':
            actual_rename(drive,detached)
            drive.mkdir()
            # A different USB may coincidentally have the same staging name.
            (drive/'EFI.hackpilot-incoming').mkdir()
            (drive/'EFI.hackpilot-incoming'/'unrelated.txt').write_text('preserve me')
            state['swapped']=True
        return result
    monkeypatch.setattr(Path,'rename',swap_after_old)
    with pytest.raises(RuntimeError,match='identity lost during commit'):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'Backups')
    assert not (drive/'EFI').exists()
    assert (drive/'EFI.hackpilot-incoming'/'unrelated.txt').read_text()=='preserve me'
    assert (detached/'EFI.hackpilot-previous'/'OC'/'config.plist').read_text()=='original'


def test_usb_enumeration_timeout_is_a_safe_identity_failure(tmp_path,monkeypatch):
    monkeypatch.setattr(usb,'list_usb',lambda:(_ for _ in ()).throw(subprocess.TimeoutExpired('powershell',30)))
    with pytest.raises(RuntimeError,match='identity'):
        usb._same_device('Q',{'disk_number':5,'volume_id':'original'})


def test_usb_identity_change_during_rollback_stops_remaining_renames(tmp_path,monkeypatch):
    drive,build,recovery=make_usb(tmp_path,monkeypatch,recovery=True)
    state={'swapped':False,'failed':False,'late_renames':[]}
    actual_rename=Path.rename
    original_fingerprint=usb.efi_tree_fingerprint
    def inventory():
        return [{'drive_letter':'Q','filesystem':'FAT32','free_bytes':500_000_000,'disk_number':5,'volume_id':'other' if state['swapped'] else 'volume-A'}]
    def corrupt_final_check(path,*args,**kwargs):
        if Path(path)==drive/'EFI' and (drive/'com.apple.recovery.boot').exists() and not state['failed']:
            state['failed']=True
            raise RuntimeError('Simulated read-back fault')
        return original_fingerprint(path,*args,**kwargs)
    def rename(self,target):
        if state['swapped']:state['late_renames'].append(str(self))
        value=actual_rename(self,target)
        if self==drive/'com.apple.recovery.boot' and '.hackpilot-failed-' in Path(target).name:
            state['swapped']=True
        return value
    monkeypatch.setattr(usb,'list_usb',inventory)
    monkeypatch.setattr(usb,'efi_tree_fingerprint',corrupt_final_check)
    monkeypatch.setattr(Path,'rename',rename)
    with pytest.raises(RuntimeError,match='rollback also failed'):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'Backups',recovery)
    assert state['swapped'] and not state['late_renames']
    assert (drive/'EFI.hackpilot-previous'/'OC'/'config.plist').read_text()=='original'


@pytest.mark.parametrize('limit,files',[(2,3),(0,1)])
def test_transfer_tree_entry_limit_stops_before_copy(tmp_path,monkeypatch,limit,files):
    monkeypatch.setattr(usb,'MAX_EFI_FILES',limit)
    for n in range(files):(tmp_path/str(n)).write_bytes(b'x')
    with pytest.raises(RuntimeError,match='too many'):
        usb._checked_tree(tmp_path)


def test_transfer_tree_total_size_is_bounded(tmp_path,monkeypatch):
    monkeypatch.setattr(usb,'MAX_TRANSFER_TREE_BYTES',5)
    (tmp_path/'file').write_bytes(b'123456')
    with pytest.raises(RuntimeError,match='size limit'):
        usb._checked_tree(tmp_path)


def test_gui_startup_and_status_survive_invalid_tool_cache_metadata(tmp_path):
    cache=tmp_path/'cache';cache.mkdir()
    (cache/'engine-manifest.json').write_text('[]')
    (cache/'usbtoolbox-manifest.json').write_text('null')
    state=State(home=tmp_path)
    result=state.status()
    assert result['engine_ready'] is False
    assert result['usb_mapping']['backend_ready'] is False


@pytest.mark.parametrize('failure',['elevation','timeout'])
def test_scanner_permission_and_timeout_errors_preserve_previous_report(tmp_path,monkeypatch,failure):
    from test_v18_deep_audit import windows_environment, prepare_sniffer
    windows_environment(monkeypatch)
    cache,_,_=prepare_sniffer(tmp_path)
    report=tmp_path/'report';report.mkdir()
    (report/'previous.txt').write_text('previous scan retained')
    monkeypatch.setattr(engine,'request_json',lambda _:(_ for _ in ()).throw(OSError('offline; use verified cache')))
    def scan(*_a,**_kw):
        if failure=='timeout':raise subprocess.TimeoutExpired('scanner',180)
        error=OSError('Elevation required');error.winerror=740
        raise error
    monkeypatch.setattr(engine.subprocess,'run',scan)
    with pytest.raises(RuntimeError,match='administrator' if failure=='elevation' else 'timed out'):
        engine.deep_scan(cache,report)
    assert (report/'previous.txt').read_text()=='previous scan retained'


@pytest.mark.parametrize('entry',['report','recovery','validator','bootloader','mapping'])
def test_inaccessible_optional_cache_does_not_crash_startup_or_status(tmp_path,monkeypatch,entry):
    denied={
        'report':tmp_path/'SystemReport'/'Report.json',
        'recovery':tmp_path/'Output'/'Recovery'/'com.apple.recovery.boot'/'BaseSystem.dmg',
        'validator':tmp_path/'cache'/'validator'/('ocvalidate.exe' if os.name=='nt' else 'ocvalidate'),
        'bootloader':tmp_path/'Output'/'LatestBuild'/'EFI'/'OC'/'OpenCore.efi',
        'mapping':tmp_path/'USBMapping'/'ports.json',
    }[entry]
    denied.parent.mkdir(parents=True,exist_ok=True);denied.write_text('{}')
    if entry=='report':(tmp_path/'SystemReport'/'ACPI').mkdir()
    real_stat=Path.stat
    def stat(self,*args,**kwargs):
        if self==denied:raise PermissionError('Simulated cache access denied')
        return real_stat(self,*args,**kwargs)
    monkeypatch.setattr(Path,'stat',stat)
    state=State(home=tmp_path)
    assert isinstance(state.status(),dict)


def test_inaccessible_recovery_folder_is_unverified_instead_of_raising(tmp_path,monkeypatch):
    from hackpilot.recovery import verify_recovery
    root=tmp_path/'com.apple.recovery.boot';root.mkdir()
    original=Path.stat
    def stat(self,*args,**kwargs):
        if self==root:raise PermissionError('Cannot read recovery directory')
        return original(self,*args,**kwargs)
    monkeypatch.setattr(Path,'stat',stat)
    assert verify_recovery(root) is False
