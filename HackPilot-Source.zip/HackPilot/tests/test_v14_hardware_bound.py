"""Machine-specific EFI binding and versioned-kext integrity regression tests."""
import json
import plistlib
from pathlib import Path

import pytest

from hackpilot.scan_seal import seal_scan, assert_scan_seal
from hackpilot import server
from hackpilot.efi_audit import audit_efi_components
from test_v12_component_audit import fixture, save_config


def make_scan(tmp_path):
    report = tmp_path / 'Report.json'
    report.write_text(json.dumps({'CPU': {'Processor Name': 'Intel Core i7-8700'}, 'GPU': {'iGPU': {}}}))
    acpi = tmp_path / 'ACPI'; acpi.mkdir()
    (acpi / 'DSDT.aml').write_bytes(b'DSDT example source')
    (acpi / 'SSDT1.aml').write_bytes(b'SSDT extra source')
    return report, acpi


def test_scan_hashes_are_stable_and_order_independent(tmp_path):
    report, acpi = make_scan(tmp_path)
    before = seal_scan(report, acpi)
    assert before['acpi_tables'] == 2
    assert seal_scan(report, acpi) == before
    assert assert_scan_seal(report, acpi, before) == before


def test_changed_acpi_table_is_rejected(tmp_path):
    report, acpi = make_scan(tmp_path)
    before = seal_scan(report, acpi)
    (acpi / 'SSDT1.aml').write_bytes(b'changed firmware table')
    with pytest.raises(RuntimeError, match='changed'):
        assert_scan_seal(report, acpi, before)


def test_changed_hardware_report_is_rejected(tmp_path):
    report, acpi = make_scan(tmp_path)
    before = seal_scan(report, acpi)
    report.write_text('{"CPU":{"Processor Name":"different PC"}}')
    with pytest.raises(RuntimeError, match='changed'):
        assert_scan_seal(report, acpi, before)


def test_scan_rejects_empty_missing_and_linked_inputs(tmp_path):
    report, acpi = make_scan(tmp_path)
    report.write_bytes(b'')
    with pytest.raises(RuntimeError, match='empty'):
        seal_scan(report, acpi)
    report.write_bytes(b'{}')
    (acpi / 'SSDT1.aml').unlink()
    (acpi / 'DSDT.aml').unlink()
    with pytest.raises(RuntimeError, match='No usable ACPI'):
        seal_scan(report, acpi)


def test_scan_rejects_symlinks(tmp_path):
    report, acpi = make_scan(tmp_path)
    (acpi / 'ALIAS.aml').symlink_to(acpi / 'DSDT.aml')
    with pytest.raises(RuntimeError, match='linked'):
        seal_scan(report, acpi)


def test_stale_scan_cannot_start_efi_build(monkeypatch, tmp_path):
    report, acpi = make_scan(tmp_path)
    state = server.State(home=tmp_path/'home')
    state.hardware={'cpu':{'name':'Intel Core i7-8700'},'gpus':[{'name':'Intel UHD 630'}]}
    state.deep_scan_verified=True
    state.sniffer_file=str(report)
    state.acpi_dir=str(acpi)
    state.scan_seal=seal_scan(report, acpi)
    state.engine_dir='upstream-dir'
    monkeypatch.setattr(server,'cached_engine_verified',lambda _:True)
    monkeypatch.setattr(server,'run_auto_builder',lambda *_a,**_kw:pytest.fail('Should not run builder'))
    (acpi/'DSDT.aml').write_bytes(b'altered')
    with pytest.raises(RuntimeError, match='changed'):
        state.build()


def test_usb_copy_of_hardware_bound_efi_requires_current_scan(tmp_path):
    report, acpi = make_scan(tmp_path)
    state = server.State(home=tmp_path/'home')
    state.build_dir.mkdir(parents=True)
    (state.build_dir/'build-manifest.json').write_text(json.dumps({'target_darwin':'24.0.0', 'scan_seal':seal_scan(report,acpi)}))
    state.last_build={'valid': True, 'fingerprint':'abc'}
    with pytest.raises(RuntimeError, match='Rescan this PC'):
        state.copy_usb('Q','COPY TO Q:')


def test_usb_copy_rejects_different_scan_even_if_revalidated(monkeypatch,tmp_path):
    report, acpi = make_scan(tmp_path)
    state = server.State(home=tmp_path/'home')
    state.build_dir.mkdir(parents=True)
    original=seal_scan(report,acpi)
    (state.build_dir/'build-manifest.json').write_text(json.dumps({'target_darwin':'24.0.0','scan_seal':original}))
    state.sniffer_file=str(report)
    state.acpi_dir=str(acpi)
    state.deep_scan_verified=True
    state.scan_seal=original
    (acpi / 'DSDT.aml').write_bytes(b'different ACPI')
    monkeypatch.setattr(server,'safe_usb_copy',lambda *_a,**_kw:pytest.fail('USB must be untouched'))
    with pytest.raises(RuntimeError,match='changed'):
        state.copy_usb('Q','COPY TO Q:')


def test_outdated_lilu_version_is_reported(tmp_path):
    build, config=fixture(tmp_path)
    info_path=build/'EFI'/'OC'/'Kexts'/'VirtualSMC.kext'/'Contents'/'Info.plist'
    with info_path.open('rb') as f:
        info=plistlib.load(f)
    info['OSBundleLibraries']['as.vit9696.Lilu']='1.7.0'
    with info_path.open('wb') as f:
        plistlib.dump(info,f)
    errors=audit_efi_components(build)['errors']
    assert any('older than required 1.7.0' in e for e in errors)


def test_sufficient_dependency_version_passes(tmp_path):
    build, config=fixture(tmp_path)
    info_path=build/'EFI'/'OC'/'Kexts'/'Lilu.kext'/'Contents'/'Info.plist'
    with info_path.open('rb') as f: info=plistlib.load(f)
    info['CFBundleVersion']='1.8.0'
    with info_path.open('wb') as f: plistlib.dump(info,f)
    virt_path=build/'EFI'/'OC'/'Kexts'/'VirtualSMC.kext'/'Contents'/'Info.plist'
    with virt_path.open('rb') as f: info=plistlib.load(f)
    info['OSBundleLibraries']['as.vit9696.Lilu']='1.7.0'
    with virt_path.open('wb') as f: plistlib.dump(info,f)
    assert not any('older than required' in e for e in audit_efi_components(build)['errors'])


def test_nonstandard_bundle_version_warns_instead_of_crashing(tmp_path):
    build, config=fixture(tmp_path)
    path=build/'EFI'/'OC'/'Kexts'/'Lilu.kext'/'Contents'/'Info.plist'
    with path.open('rb') as f: info=plistlib.load(f)
    info['CFBundleVersion']='vendor-build-alpha'
    with path.open('wb') as f: plistlib.dump(info,f)
    audit=audit_efi_components(build)
    assert audit['errors']==[]
    assert any('cannot compare' in x for x in audit['warnings'])


def make_real_dsdt(path, signature=b'DSDT'):
    import struct
    table = bytearray(36)
    table[:4] = signature
    struct.pack_into('<I', table, 4, len(table))
    table[8] = 2
    table[9] = (-sum(table)) % 256
    path.write_bytes(table)


def test_dsdt_verification_accepts_real_dsdt(tmp_path):
    from hackpilot.scan_seal import require_valid_dsdt
    folder = tmp_path/'ACPI'; folder.mkdir()
    make_real_dsdt(folder/'DSDT.aml')
    assert require_valid_dsdt(folder) == str(folder/'DSDT.aml')


def test_dsdt_verification_refuses_ssdt_only(tmp_path):
    from hackpilot.scan_seal import require_valid_dsdt
    folder = tmp_path/'ACPI'; folder.mkdir()
    make_real_dsdt(folder/'SSDT.aml', b'SSDT')
    with pytest.raises(RuntimeError, match='Valid DSDT'):
        require_valid_dsdt(folder)


def test_dsdt_verification_rejects_corrupt_checksum(tmp_path):
    from hackpilot.scan_seal import require_valid_dsdt
    folder = tmp_path/'ACPI'; folder.mkdir()
    make_real_dsdt(folder/'DSDT.aml')
    table=bytearray((folder/'DSDT.aml').read_bytes())
    table[-1]=1
    (folder/'DSDT.aml').write_bytes(table)
    with pytest.raises(RuntimeError, match='Valid DSDT'):
        require_valid_dsdt(folder)


def test_dsdt_verification_rejects_fake_length(tmp_path):
    from hackpilot.scan_seal import require_valid_dsdt
    folder = tmp_path/'ACPI'; folder.mkdir()
    make_real_dsdt(folder/'DSDT.aml')
    data=bytearray((folder/'DSDT.aml').read_bytes())
    data[4] = 32
    (folder/'DSDT.aml').write_bytes(data)
    with pytest.raises(RuntimeError, match='Valid DSDT'):
        require_valid_dsdt(folder)


def test_verified_recovery_reused_even_without_worker_or_network(monkeypatch,tmp_path):
    import hackpilot.recovery as recovery
    output=tmp_path/'Recovery'
    folder=output/'com.apple.recovery.boot'
    folder.mkdir(parents=True)
    (folder/'BaseSystem.dmg').write_bytes(b'downloaded base system')
    (folder/'BaseSystem.chunklist').write_bytes(b'downloaded chunklist')
    board='Mac-7BA5B2D9E42DDD94'
    metadata=recovery._recovery_metadata(folder,board,'24','default')
    (output/'recovery-info.json').write_text(json.dumps(metadata))
    # v1.13 now requires Apple's signed chunklist in addition to the local
    # SHA-256 cache receipt. Simulate that independent signature validation.
    monkeypatch.setattr(recovery,'verify_apple_recovery_assets',lambda *_:True)
    monkeypatch.setattr(recovery,'download',lambda *_a,**_kw:pytest.fail('Network should not be used'))
    result=recovery.download_recovery(tmp_path/'cache',output,board,'default','24')
    assert result['cached'] is True
    assert not (tmp_path/'cache'/'macrecovery.py').exists()


def test_dsdt_verification_accepts_uppercase_aml_extension(tmp_path):
    from hackpilot.scan_seal import require_valid_dsdt
    folder = tmp_path/'ACPI'; folder.mkdir()
    make_real_dsdt(folder/'DSDT.AML')
    assert require_valid_dsdt(folder) == str(folder/'DSDT.AML')
