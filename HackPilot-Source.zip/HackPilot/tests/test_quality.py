"""Quality and safety regressions for HackPilot 0.6."""
import hashlib
import http.client
import json
from pathlib import Path
import threading
import zipfile

import pytest

from hackpilot import engine, usb
from hackpilot.server import State, create_server
from hackpilot.efi import efi_fingerprint
from test_regressions import fixture_efi


def test_validator_archive_checksum_and_cache(tmp_path, monkeypatch):
    import os
    payload = b'#!/bin/sh\n' + b'A' * 20000
    executable = 'ocvalidate.exe' if os.name=='nt' else 'ocvalidate'
    archive = tmp_path/'fixture.zip'
    with zipfile.ZipFile(archive, 'w') as z:
        z.writestr('OpenCore-RELEASE/Utilities/ocvalidate/' + executable, payload)
        z.writestr('OpenCore-RELEASE/X64/EFI/OC/OpenCore.efi', b'bootloader')
    data = archive.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    calls = []
    monkeypatch.setattr(engine, 'request_json', lambda _: {'OpenCorePkg':{'versions':[
        {'links':{'release':'https://example.com/release.zip'},'hashes':{'release':{'sha256':sha}}}]}})
    def fake_download(url, target, *a, **kw):
        calls.append(url)
        Path(target).write_bytes(data)
        return {'sha256':sha,'bytes':len(data),'url':url}
    monkeypatch.setattr(engine,'download',fake_download)
    result = engine.setup_validator(tmp_path/'cache')
    assert Path(result['binary']).read_bytes() == payload
    assert not result['cached']
    again = engine.setup_validator(tmp_path/'cache')
    assert again['cached'] and len(calls) == 1


def test_validator_corrupt_archive_keeps_old_cache(tmp_path, monkeypatch):
    base=tmp_path/'cache'/'validator'
    base.mkdir(parents=True)
    old = base/'ocvalidate'
    old.write_bytes(b'old-valid-binary')
    (base/'validator-manifest.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(old.read_bytes()).hexdigest()}))
    monkeypatch.setattr(engine,'request_json', lambda _: {'OpenCorePkg':{'versions':[
        {'links':{'release':'https://example.com/release.zip'},'hashes':{'release':{'sha256':'a'*64}}}]}})
    def fake_download(url, target, *a, **kw):
        Path(target).write_bytes(b'not-the-expected-content')
        return {'sha256':'b'*64,'bytes':24,'url':url}
    monkeypatch.setattr(engine,'download', fake_download)
    with pytest.raises(RuntimeError, match='checksum'):
        engine.setup_validator(tmp_path/'cache', refresh=True)
    assert old.read_bytes() == b'old-valid-binary'


def make_usb(tmp_path, monkeypatch, existing=True, recovery=False):
    monkeypatch.chdir(tmp_path)
    drive = tmp_path/'fake-removable-volume'
    drive.mkdir()
    monkeypatch.setattr(usb, '_usb_volume_root', lambda _: drive)
    old = drive/'EFI'
    if existing:
        (old/'OC').mkdir(parents=True)
        (old/'OC'/'config.plist').write_text('original')
    fixture = fixture_efi(tmp_path)
    r = None
    if recovery:
        r = tmp_path/'Recovery'
        r.mkdir()
        (r/'BaseSystem.dmg').write_bytes(b'dmg')
        (r/'BaseSystem.chunklist').write_bytes(b'chunklist')
    disk = {'drive_letter':'Q','filesystem':'FAT32','free_bytes':500_000_000,'disk_number':5,'volume_id':'volume-A'}
    monkeypatch.setattr(usb, 'list_usb', lambda: [disk.copy()])
    return drive, fixture, r


def test_usb_stages_and_verifies_efi_and_recovery(tmp_path, monkeypatch):
    drive, build, recovery = make_usb(tmp_path, monkeypatch, recovery=True)
    result = usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups',recovery)
    assert result['copied_efi'] and result['copied_recovery']
    assert not (drive/'EFI.hackpilot-previous').exists()
    with zipfile.ZipFile(result['backup']) as saved:
        assert saved.read('EFI/OC/config.plist') == b'original'
    assert (drive/'EFI'/'OC'/'config.plist').read_bytes() == (build/'EFI'/'OC'/'config.plist').read_bytes()
    assert (drive/'com.apple.recovery.boot'/'BaseSystem.chunklist').read_bytes()==b'chunklist'
    assert list((tmp_path/'backups').glob('*.zip'))


def test_usb_incomplete_recovery_does_not_modify_old_efi(tmp_path,monkeypatch):
    drive, build, recovery=make_usb(tmp_path,monkeypatch,recovery=True)
    (recovery/'BaseSystem.chunklist').unlink()
    with pytest.raises(RuntimeError,match='incomplete'):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups',recovery)
    assert (drive/'EFI'/'OC'/'config.plist').read_text()=='original'
    assert not (drive/'EFI.hackpilot-incoming').exists()


def test_usb_volume_swap_prevents_commit(tmp_path,monkeypatch):
    drive, build, _=make_usb(tmp_path,monkeypatch)
    calls=[]
    def fake_list():
        calls.append(1)
        return [{'drive_letter':'Q','filesystem':'FAT32','free_bytes':500_000_000,
                 'disk_number':5,'volume_id':'volume-A' if len(calls)==1 else 'volume-B'}]
    monkeypatch.setattr(usb,'list_usb',fake_list)
    with pytest.raises(RuntimeError,match='identity changed'):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups')
    assert (drive/'EFI'/'OC'/'config.plist').read_text()=='original'
    assert not (drive/'EFI.hackpilot-incoming').exists()


def test_usb_copy_failure_rolls_back_original(tmp_path,monkeypatch):
    drive, build, recovery = make_usb(tmp_path,monkeypatch,recovery=True)
    original_rename = Path.rename
    def fail_recovery_commit(self,target):
        if self.name=='com.apple.recovery.boot.hackpilot-incoming':
            raise OSError('simulated device error')
        return original_rename(self,target)
    monkeypatch.setattr(Path,'rename',fail_recovery_commit)
    with pytest.raises(OSError,match='simulated'):
        usb.safe_usb_copy(build,'Q','COPY TO Q:',tmp_path/'backups',recovery)
    assert (drive/'EFI'/'OC'/'config.plist').read_text()=='original'
    assert any(d.name.startswith('EFI.hackpilot-failed-') for d in drive.iterdir())


def test_server_rejects_dns_rebinding_host(tmp_path):
    server=create_server(State(home=tmp_path/'data'))
    thread=threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    try:
        conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=3)
        conn.request('GET','/api/status',headers={'Host':'attacker.example'})
        res=conn.getresponse()
        assert res.status==403
        res.read()
        conn.close()
    finally:
        server.shutdown();server.server_close()


def test_demo_cannot_write_usb_or_download_recovery(tmp_path):
    state=State(demo=True,home=tmp_path/'data')
    with pytest.raises(RuntimeError,match='demo mode'):
        state.copy_usb('Q','COPY TO Q:')
    with pytest.raises(RuntimeError,match='demo mode'):
        state.recovery('Mac-1234567890')
    with pytest.raises(RuntimeError,match='demo mode'):
        state.build('auto')
