import json
import os
import re
import subprocess
import urllib.error
import urllib.request
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
import pytest
from hackpilot import server,usb_format,rufus_tool
from test_v121_formatter import disk


def post(url,data,headers=None):
    request=urllib.request.Request(url,data=json.dumps(data).encode(),headers={'Content-Type':'application/json',**(headers or {})})
    return urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=5)


def test_elevated_results_use_memory_not_temp_files(monkeypatch):
    monkeypatch.setattr(usb_format,'os',SimpleNamespace(name='nt'))
    monkeypatch.setattr(usb_format,'inventory',lambda:[disk()])
    monkeypatch.setattr(usb_format.tempfile,'TemporaryDirectory',lambda **kw:pytest.fail('Must not create elevated result files'))
    monkeypatch.setattr(Path,'read_text',lambda *a,**kw:pytest.fail('Must not read result.json'))
    def run(command,**kw):
        encoded=re.search(r"'-EncodedCommand','([^']+)'",command[-1])[1]
        import base64
        script=base64.b64decode(encoded).decode('utf-16le')
        url=re.search(r"\$resultUrl='([^']+)'",script)[1]
        with post(url,{'ok':True,'letter':'E','filesystem':'FAT32','size':1024**3}) as response:assert response.status==200
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(usb_format.subprocess,'run',run)
    assert usb_format.format_disk(disk())['letter']=='E'


@pytest.mark.parametrize('headers',[{'Origin':'https://example.com'},{'Host':'example.com'}])
def test_result_channel_rejects_cross_origin_or_wrong_host(headers):
    with usb_format.result_channel() as channel:
        with pytest.raises(urllib.error.HTTPError) as error:post(channel.url,{'ok':True},headers)
        assert error.value.code==403
        assert channel.state['result'] is None


def test_result_channel_is_one_use():
    with usb_format.result_channel() as channel:
        post(channel.url,{'ok':False,'phase':'preflight'}).close()
        with pytest.raises(urllib.error.HTTPError) as error:post(channel.url,{'ok':True})
        assert error.value.code==409
        assert channel.state['result']['ok'] is False


def test_restore_plan_cannot_be_used_with_erase_confirmation(tmp_path,monkeypatch):
    monkeypatch.setattr(usb_format,'inventory',lambda:[disk()])
    monkeypatch.setattr(usb_format,'format_disk',lambda *a,**kw:pytest.fail('Must not write'))
    state=server.State(home=tmp_path)
    plan=state.plan_usb_format(2,restore=True)
    assert plan['confirmation']=='RESTORE USB 2'
    assert 'No partition deletion' in plan['note']
    with pytest.raises(ValueError):state.format_usb(plan['token'],'ERASE USB 2')


@pytest.mark.parametrize('filesystem,style',[('NTFS','GPT'),('exFAT','MBR'),('FAT32','GPT')])
def test_format_options_bound_to_confirmed_plan(tmp_path,monkeypatch,filesystem,style):
    monkeypatch.setattr(usb_format,'inventory',lambda:[disk()])
    calls=[]
    monkeypatch.setattr(usb_format,'format_disk',lambda identity,**kwargs:calls.append(kwargs) or {'ok':True})
    state=server.State(home=tmp_path)
    plan=state.plan_usb_format(2,filesystem,style)
    state.format_usb(plan['token'],plan['confirmation'])
    assert calls==[{'filesystem':filesystem,'style':style,'restore':False}]


def test_restore_cannot_invoke_partition_erase_or_format():
    # The restore script must not gain a destructive fallback when mounting fails.
    assert 'Clear-Disk' not in usb_format.RESTORE
    assert 'Initialize-Disk' not in usb_format.RESTORE
    assert 'Format-Volume' not in usb_format.RESTORE
    assert 'New-Partition' not in usb_format.RESTORE


@pytest.mark.skipif(os.name!='nt',reason='Windows PowerShell required')
def test_real_powershell_posts_result_without_any_temp_file():
    with usb_format.result_channel() as channel:
        # Run only the response transport, no storage cmdlet or elevation.
        writer=usb_format.FORMAT[usb_format.FORMAT.index('$json=$answer'):]
        script="$resultUrl='"+channel.url+"';$answer=@{ok=$true;letter='E';filesystem='FAT32'};"+writer
        result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',usb_format.encoded(script)],capture_output=True,timeout=20)
        assert result.returncode==0,result.stderr.decode(errors='replace')
        assert channel.state['result']['letter']=='E'


@pytest.mark.skipif(os.name!='nt',reason='Windows PowerShell parser required')
def test_restore_powershell_parses_without_executing_storage_commands():
    import base64
    payload=base64.b64encode(usb_format.RESTORE.encode()).decode()
    script="$s=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+payload+"'));$t=$null;$e=$null;$null=[System.Management.Automation.Language.Parser]::ParseInput($s,[ref]$t,[ref]$e);if($e.Count){$e | Out-String | Write-Output;exit 1}"
    result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',usb_format.encoded(script)],capture_output=True,timeout=20)
    assert result.returncode==0,result.stdout.decode(errors='replace')


@pytest.mark.parametrize('status,subject',[('NotSigned','CN=Akeo Consulting'),('Valid','CN=Untrusted Publisher')])
def test_rufus_refuses_untrusted_signature(tmp_path,monkeypatch,status,subject):
    import hashlib
    root=tmp_path/'official-rufus-4.15';root.mkdir()
    (root/'rufus-4.15p.exe').write_bytes(b'test fixture')
    monkeypatch.setattr(rufus_tool,'SHA256',hashlib.sha256(b'test fixture').hexdigest())
    monkeypatch.setattr(rufus_tool,'os',SimpleNamespace(name='nt'))
    calls=[]
    def run(*args,**kwargs):
        calls.append(args)
        assert len(calls)==1,'Must not launch an untrusted executable'
        return SimpleNamespace(returncode=0,stdout=json.dumps({'status':status,'subject':subject}).encode())
    monkeypatch.setattr(rufus_tool.subprocess,'run',run)
    with pytest.raises(RuntimeError,match='publisher signature'):rufus_tool.open_rufus(tmp_path)


def test_rufus_refuses_checksum_mismatch(tmp_path,monkeypatch):
    monkeypatch.setattr(rufus_tool,'os',SimpleNamespace(name='nt'))
    monkeypatch.setattr(rufus_tool,'download',lambda url,path,**kw:path.write_bytes(b'wrong download'))
    monkeypatch.setattr(rufus_tool.subprocess,'run',lambda *a,**kw:pytest.fail('Must not run mismatched binary'))
    with pytest.raises(RuntimeError,match='checksum'):rufus_tool.open_rufus(tmp_path)
