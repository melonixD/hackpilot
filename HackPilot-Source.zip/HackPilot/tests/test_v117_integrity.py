"""Regression tests for EFI digest boundaries and bounded cache checks."""
import json
import hashlib
import plistlib
from pathlib import Path

import pytest
from hackpilot.efi import efi_tree_fingerprint, efi_fingerprint, MAX_EFI_BYTES, MAX_EFI_FILES, MAX_TRANSFER_TREE_BYTES
from hackpilot import usb_mapping, engine
from test_v15_usb_mapping import snapshot
from test_v12_component_audit import fixture, save_config, write_kext
from test_v110_failure_audit import make_backend


def legacy_digest(root):
    """v1.16 encoding, included only to demonstrate the known boundary flaw."""
    digest = hashlib.sha256()
    for path in sorted(Path(root).rglob('*'), key=lambda f: f.relative_to(root).as_posix()):
        rel = path.relative_to(root).as_posix().encode()
        if path.is_dir():
            digest.update(b'D' + rel + b'\0')
        else:
            digest.update(b'F' + rel + b'\0' + path.read_bytes())
    return digest.hexdigest()


def test_efi_hash_detects_file_boundary_shifting(tmp_path):
    one, two = tmp_path/'one', tmp_path/'two'
    one.mkdir(); two.mkdir()
    (one/'A').write_bytes(b'abcFB\0')
    (one/'B').write_bytes(b'xyz')
    (two/'A').write_bytes(b'abc')
    (two/'B').write_bytes(b'FB\0xyz')
    # The old digest literally hashes the same byte stream for *different*
    # contents. A correct fingerprint must distinguish them.
    assert legacy_digest(one) == legacy_digest(two)
    assert efi_tree_fingerprint(one) != efi_tree_fingerprint(two)


def test_efi_hash_changes_for_content_move_not_just_total_size(tmp_path):
    root=tmp_path/'EFI';root.mkdir()
    (root/'A').write_bytes(b'ab');(root/'B').write_bytes(b'cd')
    before=efi_tree_fingerprint(root)
    (root/'A').write_bytes(b'a');(root/'B').write_bytes(b'bcd')
    assert efi_tree_fingerprint(root)!=before


def test_efi_hash_rejects_oversized_individual_file_without_reading(tmp_path,monkeypatch):
    root=tmp_path/'EFI';root.mkdir()
    large=root/'huge.img'
    with large.open('wb') as file:
        file.truncate(MAX_EFI_BYTES + 1)
    with pytest.raises(RuntimeError,match='safety size limit'):
        efi_fingerprint(tmp_path)


def test_efi_hash_rejects_too_many_entries(tmp_path,monkeypatch):
    import hackpilot.efi as module
    monkeypatch.setattr(module,'MAX_EFI_FILES', 2)
    root=tmp_path/'EFI';root.mkdir()
    for name in 'ABC': (root/name).write_bytes(b'x')
    with pytest.raises(RuntimeError,match='too many'):
        efi_tree_fingerprint(root)


def _valid_map(tmp_path):
    data=snapshot()
    result=usb_mapping.generate_utbmap(data,tmp_path)
    manifest=tmp_path/'usb-map-manifest.json'
    manifest.write_text(json.dumps({'source':usb_mapping.REPO,
        'sha256':result['sha256'], 'selection_sha256':usb_mapping.selection_hash(data)}))
    assert usb_mapping.map_is_ready(tmp_path,data)
    return data,manifest


def test_usb_map_ready_rejects_oversized_metadata(tmp_path):
    data,manifest=_valid_map(tmp_path)
    manifest.write_bytes(b' ' * (128*1024+1))
    assert usb_mapping.map_is_ready(tmp_path,data) is False


def test_usb_map_ready_rejects_json_list_not_dict(tmp_path):
    data,manifest=_valid_map(tmp_path)
    manifest.write_text('[]')
    assert usb_mapping.map_is_ready(tmp_path,data) is False


def test_usb_backend_rejects_oversized_untracked_cache_file(tmp_path):
    root=make_backend(tmp_path)
    huge=root/'unexpected.bin'
    with huge.open('wb') as file: file.truncate(200*1024*1024 + 1)
    with pytest.raises(RuntimeError,match='safety bounds'):
        usb_mapping._backend_digest(root)


def test_engine_cache_rejects_oversized_untracked_script(tmp_path):
    root=tmp_path/'upstream';(root/'Scripts').mkdir(parents=True)
    (root/'LICENSE').write_text('test')
    (root/'OpCore-Simplify.py').write_text('# script')
    (root/'Scripts'/'helper.py').write_text('# helper')
    assert len(engine.engine_tree_hash(root))==64
    huge=root/'Scripts'/'untrusted.bin'
    with huge.open('wb') as file: file.truncate(600*1024*1024 + 1)
    with pytest.raises(RuntimeError,match='600 MiB'):
        engine.engine_tree_hash(root)


def test_inserting_usb_map_disables_unsafe_xhci_limit(tmp_path):
    build,cfg=fixture(tmp_path)
    oc=build/'EFI'/'OC'
    cfg['Kernel']['Add'].append(write_kext(oc,'USBToolBox.kext','com.dhinakg.USBToolBox.kext'))
    cfg['Kernel']['Quirks']={'XhciPortLimit':True}
    save_config(build,cfg)
    mapping=tmp_path/'map';usb_mapping.generate_utbmap(snapshot(),mapping)
    usb_mapping.inject_efi_map(build,mapping/'UTBMap.kext')
    latest=plistlib.loads((oc/'config.plist').read_bytes())
    assert latest['Kernel']['Quirks']['XhciPortLimit'] is False


def test_apple_recovery_uses_larger_transfer_tree_budget(tmp_path):
    # A recovery DMG can exceed 1 GiB even when the EFI itself is tiny. The
    # generic hash used by the USB readback must NOT inherit the EFI-only cap.
    assert MAX_TRANSFER_TREE_BYTES > MAX_EFI_BYTES
    root=tmp_path/'EFI';root.mkdir()
    (root/'sample').write_bytes(b'normal payload')
    assert efi_tree_fingerprint(root)==efi_tree_fingerprint(root,max_bytes=MAX_TRANSFER_TREE_BYTES)
    with pytest.raises(RuntimeError,match='safety size limit'):
        efi_tree_fingerprint(root,max_bytes=4)


def test_map_status_handles_manifest_disappearing_during_check(tmp_path,monkeypatch):
    data,manifest=_valid_map(tmp_path)
    original = Path.lstat
    calls={'n':0}
    def vanished(self,*args,**kwargs):
        if self == manifest:
            calls['n']+=1
            if calls['n']>=2:
                raise FileNotFoundError('unplugged or deleted')
        return original(self,*args,**kwargs)
    monkeypatch.setattr(Path,'lstat',vanished)
    assert usb_mapping.map_is_ready(tmp_path,data) is False


def test_map_injection_rejects_malformed_plist_without_changing_efi(tmp_path):
    build,cfg=fixture(tmp_path)
    oc=build/'EFI'/'OC'
    cfg['Kernel']['Add'].append(write_kext(oc,'USBToolBox.kext','com.dhinakg.USBToolBox.kext'))
    save_config(build,cfg)
    before=(oc/'config.plist').read_bytes()
    folder=tmp_path/'mapping'
    usb_mapping.generate_utbmap(snapshot(),folder)
    (folder/'UTBMap.kext'/'Contents'/'Info.plist').write_bytes(b'not a plist')
    with pytest.raises(RuntimeError,match='map bundle'):
        usb_mapping.inject_efi_map(build,folder/'UTBMap.kext')
    assert (oc/'config.plist').read_bytes()==before
