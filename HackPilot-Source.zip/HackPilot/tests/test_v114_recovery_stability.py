"""Recovery acquisition and predictable boot-risk blockers for v1.14."""
import hashlib
import json
import os
import subprocess
from pathlib import Path
from types import SimpleNamespace

import pytest

from hackpilot import recovery
from hackpilot.efi_audit import audit_efi_components
from test_v12_component_audit import fixture, save_config, write_kext


def _fake_pinned_worker(monkeypatch):
    content = b'# synthetic pinned worker\n' + b'# comment\n' * 520
    sha = hashlib.sha256(content).hexdigest()
    monkeypatch.setattr(recovery, 'MACRECOVERY_SHA256', sha)
    monkeypatch.setattr(recovery, '_git_blob_sha1', lambda *_: recovery.MACRECOVERY_BLOB_SHA1)

    def download(url, file, size):
        assert recovery.MACRECOVERY_COMMIT in url
        assert size <= 2 * 1024 * 1024
        file = Path(file)
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_bytes(content)
        return {'sha256': sha, 'bytes': len(content), 'url': url}

    monkeypatch.setattr(recovery, 'download', download)
    return content


def test_pinned_recovery_source_is_immutable():
    assert recovery.MACRECOVERY_COMMIT in recovery.URL
    assert '/master/' not in recovery.URL
    assert len(recovery.MACRECOVERY_SHA256) == 64
    assert len(recovery.MACRECOVERY_BLOB_SHA1) == 40


def test_disk_preflight_fails_before_attempt_when_not_enough_space(tmp_path, monkeypatch):
    monkeypatch.setattr(recovery.shutil, 'disk_usage',
                        lambda *_: SimpleNamespace(free=1024 * 1024 * 1024))
    with pytest.raises(RuntimeError, match='at least 2 GiB'):
        recovery.download_recovery(tmp_path/'cache', tmp_path/'recovery',
                                   'Mac-7BA5B2D9E42DDD94')
    assert not (tmp_path/'cache'/'macrecovery.py').exists()


def test_recovery_pair_rejects_ambiguous_candidates(tmp_path):
    for i in ('one', 'two'):
        folder = tmp_path/i
        folder.mkdir()
        (folder/'BaseSystem.dmg').write_bytes(b'fake')
        (folder/'BaseSystem.chunklist').write_bytes(b'fake')
    with pytest.raises(RuntimeError, match='exactly one'):
        recovery.select_recovery_pair(tmp_path)


def test_recovery_pair_rejects_linked_image(tmp_path):
    data = tmp_path/'data.bin'; data.write_bytes(b'data')
    folder = tmp_path/'download'; folder.mkdir()
    try:
        (folder/'BaseSystem.dmg').symlink_to(data)
    except (OSError, NotImplementedError):
        pytest.skip('Symlinks not supported on this test host')
    (folder/'BaseSystem.chunklist').write_bytes(b'fake')
    with pytest.raises(RuntimeError, match='linked'):
        recovery.select_recovery_pair(folder)


def test_recovery_retry_reuses_good_second_download(tmp_path, monkeypatch):
    _fake_pinned_worker(monkeypatch)
    monkeypatch.setattr(recovery, 'verify_apple_recovery_assets', lambda *args: True)
    runs = []

    def fake_run(args, cwd, stdout, stderr, timeout):
        runs.append(cwd)
        if len(runs) == 1:
            stdout.write('simulated temporary CDN failure\n')
            return SimpleNamespace(returncode=1)
        assert not Path(runs[0]).exists(), 'failed recovery assets must not linger'
        (Path(cwd)/'BaseSystem.dmg').write_bytes(b'signed-image-pretend')
        (Path(cwd)/'BaseSystem.chunklist').write_bytes(b'signed-chunklist-pretend')
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(recovery.subprocess, 'run', fake_run)
    output = tmp_path/'recovery'
    result = recovery.download_recovery(tmp_path/'cache', output,
                                        'Mac-7BA5B2D9E42DDD94', 'default', '24')
    assert len(runs) == 2
    assert Path(result['folder'], 'BaseSystem.dmg').read_bytes() == b'signed-image-pretend'
    assert (output/'recovery-info.json').is_file()
    assert 'attempt 2' in (output/'macrecovery.log').read_text()
    cached = json.loads((tmp_path/'cache'/'macrecovery-manifest.json').read_text())
    assert cached['commit'] == recovery.MACRECOVERY_COMMIT


def test_two_failed_recoveries_do_not_replace_existing_pair(tmp_path, monkeypatch):
    _fake_pinned_worker(monkeypatch)
    output = tmp_path/'recovery'
    target = output/'com.apple.recovery.boot'; target.mkdir(parents=True)
    (target/'BaseSystem.dmg').write_bytes(b'old-file')
    (target/'BaseSystem.chunklist').write_bytes(b'old-list')
    # Request a different board ID, requiring a new download.
    (output/'recovery-info.json').write_text(json.dumps(recovery._recovery_metadata(
        target, 'Mac-7BA5B2D9E42DDD94')))
    tries=[]

    def failed(args, cwd, stdout, stderr, timeout):
        tries.append(cwd)
        stdout.write('Network error\n')
        return SimpleNamespace(returncode=2)

    monkeypatch.setattr(recovery.subprocess, 'run', failed)
    with pytest.raises(RuntimeError, match='after 2 attempts'):
        recovery.download_recovery(tmp_path/'cache', output,
                                   'Mac-7BA5B2D9E42DDD95')
    assert len(tries) == 2
    assert (target/'BaseSystem.dmg').read_bytes() == b'old-file'
    assert recovery.verify_recovery(target, 'Mac-7BA5B2D9E42DDD94')
    assert not list(output.glob('macrecovery-*'))


def test_pinned_worker_sha_mismatch_stops_before_execution(tmp_path, monkeypatch):
    content = b'changed upstream script' * 100
    def fake_download(url, file, *_):
        Path(file).parent.mkdir(parents=True, exist_ok=True)
        Path(file).write_bytes(content)
        return {'url':url, 'sha256':hashlib.sha256(content).hexdigest()}
    monkeypatch.setattr(recovery, 'download', fake_download)
    monkeypatch.setattr(recovery.subprocess, 'run',
                        lambda *a,**kw: pytest.fail('Unverified helper must never execute'))
    with pytest.raises(RuntimeError, match='checksum mismatch'):
        recovery.download_recovery(tmp_path/'cache', tmp_path/'out',
                                   'Mac-7BA5B2D9E42DDD94')


def test_macos_newer_usb_limit_patch_is_blocked(tmp_path):
    build, config = fixture(tmp_path)
    config['Kernel']['Quirks'] = {'XhciPortLimit': True}
    save_config(build, config)
    assert any('XhciPortLimit' in x for x in
               audit_efi_components(build, target_darwin='24.0.0')['errors'])
    assert not any('XhciPortLimit' in x for x in
                   audit_efi_components(build, target_darwin='20.0.0')['errors'])


def test_usb_map_without_toolbox_is_blocked_and_order_checked(tmp_path):
    build, config = fixture(tmp_path)
    oc = build/'EFI'/'OC'
    config['Kernel']['Add'].append(write_kext(oc,'UTBMap.kext',
                                               'com.dhinakg.USBToolBox.map'))
    save_config(build, config)
    assert any('requires enabled USBToolBox.kext' in x for x in
               audit_efi_components(build)['errors'])
    config['Kernel']['Add'].append(write_kext(oc, 'USBToolBox.kext',
                                               'com.dhinakg.USBToolBox.kext',
                                               executable='USBToolBox'))
    save_config(build, config)
    assert any('must load before UTBMap.kext' in x for x in
               audit_efi_components(build)['errors'])
    config['Kernel']['Add'][-1], config['Kernel']['Add'][-2] = (
        config['Kernel']['Add'][-2], config['Kernel']['Add'][-1])
    save_config(build, config)
    assert audit_efi_components(build)['errors'] == []


def test_installation_risks_include_wifi_only_and_raid():
    from hackpilot.compat import assess
    report = {'cpu': {'name':'Intel Core i7-9700K'},
              'gpus':[{'name':'AMD Radeon RX 580'}],
              'network':[{'name':'Intel Wireless-AC 9260 Wi-Fi'}],
              'storage':[{'name':'Intel VMD Controller'}],
              'audio':[{'name':'Realtek HD Audio'}],
              'firmware': {'type':'UEFI'}}
    findings = assess(report)['findings']
    assert any('Internet recovery network path unverified' in f['label'] for f in findings)
    assert any('Storage controller requires BIOS review' in f['label'] for f in findings)


def test_wired_ethernet_avoids_wifi_only_warning():
    from hackpilot.compat import assess
    report = {'cpu': {'name':'Intel Core i7-9700K'},
              'gpus':[{'name':'AMD Radeon RX 580'}],
              'network':[{'name':'Intel I219-V Ethernet'}],
              'storage':[{'name':'SATA AHCI Controller'}],
              'audio':[{'name':'Realtek HD Audio'}],
              'firmware': {'type':'UEFI'}}
    findings = assess(report)['findings']
    assert not any('Internet recovery network path unverified' in f['label'] for f in findings)
    assert not any('Storage controller requires BIOS review' in f['label'] for f in findings)


def test_valid_pinned_worker_cache_upgraded_offline(tmp_path, monkeypatch):
    import hackpilot.recovery as r
    tool_bytes = _fake_pinned_worker(monkeypatch)
    cache = tmp_path/'cache'; cache.mkdir()
    (cache/'macrecovery.py').write_bytes(tool_bytes)
    (cache/'macrecovery-manifest.json').write_text(json.dumps({
        'sha256': hashlib.sha256(tool_bytes).hexdigest(),
        'url':'https://raw.githubusercontent.com/acidanthera/OpenCorePkg/master/Utilities/macrecovery/macrecovery.py'
    }))
    monkeypatch.setattr(r, 'download', lambda *args: pytest.fail('Pinned helper already cached; do not fetch GitHub'))
    monkeypatch.setattr(r, 'verify_apple_recovery_assets', lambda *args: True)

    def download_apple(args, cwd, stdout, stderr, timeout):
        (Path(cwd)/'BaseSystem.dmg').write_bytes(b'valid-apple-image')
        (Path(cwd)/'BaseSystem.chunklist').write_bytes(b'valid-apple-signature')
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(r.subprocess, 'run', download_apple)
    result = r.download_recovery(cache, tmp_path/'Recovery', 'Mac-7BA5B2D9E42DDD94')
    assert Path(result['folder'], 'BaseSystem.dmg').is_file()
    assert json.loads((cache/'macrecovery-manifest.json').read_text())['commit'] == r.MACRECOVERY_COMMIT


def test_temporary_recovery_timeout_is_retried(tmp_path, monkeypatch):
    _fake_pinned_worker(monkeypatch)
    monkeypatch.setattr(recovery, 'verify_apple_recovery_assets', lambda *args: True)
    calls = []

    def fake_run(args, cwd, stdout, stderr, timeout):
        calls.append(cwd)
        if len(calls) == 1:
            raise subprocess.TimeoutExpired(args, timeout)
        (Path(cwd)/'RecoveryImage.dmg').write_bytes(b'dmg')
        (Path(cwd)/'RecoveryImage.chunklist').write_bytes(b'signed-list')
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(recovery.subprocess, 'run', fake_run)
    result = recovery.download_recovery(tmp_path/'cache', tmp_path/'out',
                                        'Mac-7BA5B2D9E42DDD94')
    assert len(calls) == 2
    assert Path(result['folder'], 'BaseSystem.dmg').read_bytes() == b'dmg'


def test_two_invalid_signatures_never_publish(tmp_path, monkeypatch):
    _fake_pinned_worker(monkeypatch)
    monkeypatch.setattr(recovery, 'verify_apple_recovery_assets', lambda *args: False)
    calls = []

    def fake_run(args, cwd, stdout, stderr, timeout):
        calls.append(cwd)
        (Path(cwd)/'BaseSystem.dmg').write_bytes(b'forged')
        (Path(cwd)/'BaseSystem.chunklist').write_bytes(b'forged')
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(recovery.subprocess, 'run', fake_run)
    with pytest.raises(RuntimeError, match='signed chunklist'):
        recovery.download_recovery(tmp_path/'cache', tmp_path/'out',
                                   'Mac-7BA5B2D9E42DDD94')
    assert len(calls) == 2
    assert not (tmp_path/'out'/'com.apple.recovery.boot').exists()
    assert not (tmp_path/'out'/'recovery-info.json').exists()
