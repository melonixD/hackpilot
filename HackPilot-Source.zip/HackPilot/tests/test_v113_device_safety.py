"""v1.13: USB identity can change *during* rollback and cleanup.

These tests use a simulated volume, never a physical USB device.
"""
import json

import pytest

from hackpilot import usb, server
from hackpilot.efi import validate_efi
from hackpilot.usb_journal import pending_receipts
from test_quality import make_usb
from test_regressions import fixture_efi


def test_commit_identity_loss_stops_rollback_and_cleanup(tmp_path, monkeypatch):
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    original = usb._same_device
    calls = []

    def changing_device(letter, disk):
        calls.append(1)
        # The USB is replaced just after its previous EFI was relocated and
        # the new EFI committed, before the final verification.
        if len(calls) >= 4:
            raise RuntimeError('USB drive identity changed; transfer stopped')
        return original(letter, disk)

    monkeypatch.setattr(usb, '_same_device', changing_device)
    with pytest.raises(RuntimeError, match='identity lost during commit'):
        usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path / 'Backups')
    # A rollback attempt could mistakenly manipulate an unrelated drive now
    # mounted at the same letter; leave recovery to a deliberate repair.
    assert (drive / 'EFI.hackpilot-previous' / 'OC' / 'config.plist').read_bytes() == b'original'
    assert (drive / 'EFI' / 'OC' / 'config.plist').is_file()
    assert not any(p.name.startswith('EFI.hackpilot-failed-') for p in drive.iterdir())
    assert any(x['phase'] not in ('complete', 'rolled_back') for x in pending_receipts(tmp_path / 'Backups' / 'transactions'))


def test_staging_identity_loss_leaves_usb_paths_untouched(tmp_path, monkeypatch):
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    original = usb._same_device
    calls = []

    def disconnect_after_backup(letter, disk):
        calls.append(1)
        if len(calls) >= 2:
            raise RuntimeError('USB drive identity changed; transfer stopped')
        return original(letter, disk)

    monkeypatch.setattr(usb, '_same_device', disconnect_after_backup)
    with pytest.raises(RuntimeError, match='identity lost during staging'):
        usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path / 'Backups')
    assert (drive / 'EFI' / 'OC' / 'config.plist').read_bytes() == b'original'
    assert (drive / 'EFI.hackpilot-incoming').is_dir()  # cleanup deferred
    assert pending_receipts(tmp_path / 'Backups' / 'transactions')


def test_optional_disk_identity_detects_usb_swap(tmp_path, monkeypatch):
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    base = {'drive_letter': 'Q', 'filesystem': 'FAT32', 'free_bytes': 500_000_000,
            'disk_number': 5, 'volume_id': 'volume-A', 'disk_unique_id': 'USB-UNIQUE-1',
            'partition_number': 1, 'partition_offset': '1048576'}
    count = []

    def enumerate_disk():
        count.append(1)
        return [{**base, 'disk_unique_id': 'USB-UNIQUE-2' if len(count) >= 2 else 'USB-UNIQUE-1'}]

    monkeypatch.setattr(usb, 'list_usb', enumerate_disk)
    with pytest.raises(RuntimeError, match='identity'):
        usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path / 'Backups')
    assert (drive / 'EFI' / 'OC' / 'config.plist').read_bytes() == b'original'


def test_fat16_is_not_misidentified_as_fat32(tmp_path, monkeypatch):
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    monkeypatch.setattr(usb, 'list_usb', lambda: [{
        'drive_letter': 'Q', 'filesystem': 'FAT', 'free_bytes': 500_000_000,
        'disk_number': 5, 'volume_id': 'volume-A'}])
    with pytest.raises(RuntimeError, match='FAT32'):
        usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path / 'Backups')
    assert (drive / 'EFI' / 'OC' / 'config.plist').read_bytes() == b'original'


def test_oversized_plist_rejected_before_parsing(tmp_path, monkeypatch):
    build = fixture_efi(tmp_path)
    plist = build / 'EFI' / 'OC' / 'config.plist'
    plist.write_bytes(b'x' * (8 * 1024 * 1024 + 1))
    import plistlib

    def should_not_parse(*_args, **_kw):
        pytest.fail('Parser should never see oversized plist')

    monkeypatch.setattr(plistlib, 'load', should_not_parse)
    result = validate_efi(build)
    assert not result['valid']
    assert any('exceeds 8 MiB' in err for err in result['errors'])


@pytest.mark.parametrize('operation,scanner', [('scan', 'scan_windows'), ('deep_scan', 'deep_scan')])
def test_failed_scan_clears_old_pc_details(tmp_path, monkeypatch, operation, scanner):
    state = server.State(home=tmp_path / 'home')
    state.hardware = {'cpu': {'name': 'Previous Machine'}}
    state.sniffer_file = '/old/Report.json'
    state.acpi_dir = '/old/ACPI'
    state.deep_scan_verified = True

    def fail(*_):
        raise RuntimeError('Hardware Sniffer failed')

    monkeypatch.setattr(server, scanner, fail)
    with pytest.raises(RuntimeError, match='Hardware Sniffer failed'):
        getattr(state, operation)()
    assert state.hardware is None
    assert state.sniffer_file is None and state.acpi_dir is None
    assert not state.deep_scan_verified


def test_journal_keeps_extra_disk_identity_for_repair(tmp_path, monkeypatch):
    drive, build, _ = make_usb(tmp_path, monkeypatch)
    original_disk = {'drive_letter': 'Q', 'filesystem': 'FAT32', 'free_bytes': 500_000_000,
                     'disk_number': 5, 'volume_id': 'volume-A', 'disk_unique_id': 'stick-123',
                     'partition_number': 1, 'partition_offset': '1048576'}
    monkeypatch.setattr(usb, 'list_usb', lambda: [original_disk.copy()])
    real_receipt = usb.write_receipt

    def shutdown_after_backup(path, receipt):
        real_receipt(path, receipt)
        if receipt['phase'] == 'staged':
            raise SystemExit('simulated power failure')

    monkeypatch.setattr(usb, 'write_receipt', shutdown_after_backup)
    with pytest.raises(SystemExit):
        usb.safe_usb_copy(build, 'Q', 'COPY TO Q:', tmp_path/'Backups')
    monkeypatch.setattr(usb, 'write_receipt', real_receipt)
    receipt = pending_receipts(tmp_path/'Backups'/'transactions')[0]
    assert receipt['disk_unique_id'] == 'stick-123'
    assert receipt['partition_number'] == 1
    assert receipt['partition_offset'] == '1048576'
    monkeypatch.setattr(usb, 'list_usb', lambda: [{**original_disk, 'disk_unique_id': 'other-stick'}])
    with pytest.raises(RuntimeError, match='identity changed'):
        usb.repair_usb('Q', 'REPAIR Q:', tmp_path/'Backups')
    assert (drive/'EFI'/'OC'/'config.plist').read_bytes() == b'original'
    assert (drive/'EFI.hackpilot-incoming').exists()


@pytest.mark.parametrize('changed', [{'disk_unique_id': ['invalid']}, {'partition_number': False},
                                     {'partition_offset': '-123'}])
def test_corrupt_extra_identity_in_journal_is_blocked(tmp_path, changed):
    from hackpilot.usb_journal import _valid_receipt
    receipt={'phase':'staged','letter':'Q','disk_number':1,'volume_id':'volume-A',
             'expected_fingerprint':'a'*64,'had_original':False}
    receipt.update(changed)
    assert not _valid_receipt(receipt, tmp_path/'journal.json')
