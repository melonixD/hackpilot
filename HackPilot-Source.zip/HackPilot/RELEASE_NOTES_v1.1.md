# HackPilot v1.1 audit — changes from v1.0 Preview

This is a **source-based test preview**, not a certified universal macOS installer and **not** a precompiled EXE.

## Verified changes

- Backup-stage failure now closes the USB transfer receipt as `preflight_failed`. This keeps an untouched USB eligible for another attempt after the backup problem is fixed.
- If any USB transaction receipt is corrupt and its target is unknown, new USB writes and automated repair stop until it is inspected. A broken receipt can no longer be bypassed by changing drive letters.
- A new EFI build clears old validation / USB-ready status *before* invoking the upstream engine. Failure cannot leave an older “verified” result presented as the new build.
- Saved malformed hardware reports and device-choice content no longer break state initialization / rendering.
- Upstream engine cache hashing now includes root-level Python and configuration/binary assets, including `updater.py`. Previously some importable root-level files were not covered.
- The PyInstaller GUI launcher now propagates `main()`'s exit status, so a failed EXE self-test fails the Windows CI job instead of reporting success.
- A running operation has priority in the top-bar status display.
- Windows CI now checks JavaScript syntax, confirms the EXE size, and includes a SHA-256 checksum alongside its unsigned build artifact.

## Verification in this environment

- Python automated tests pass, including new bug regressions.
- Python compilation, `--self-test`, JS syntax, local API/static HTTP responses, and extracted-package tests pass.
- No Windows runner or macOS test machine is available in this environment. Native EXE launch, real USB transfers and actual macOS bootability **remain unverified**.

## Known release blockers

- The end-user EXE must be built and exercised on Windows. The included workflow builds an unsigned EXE but has not been executed here.
- Apple internet recovery is not a full offline installer, and a preformatted removable FAT32 volume is still required. HackPilot does not automatically erase or partition storage.
- Upstream OpCore-Simplify and external driver downloads may change. EFI validation cannot certify every GPU, USB controller, Wi-Fi chipset, BIOS setting, or macOS boot.
- Test matrices covering Windows 10/11, Intel/AMD desktops/laptops, multiple removable disks, sudden power removal, and real installer boots are still required.
