# HackPilot 1.23 — hardware-first guided setup

The starting page now asks for one full hardware scan. USB selection and macOS
choices no longer appear before the PC has been scanned. The numbered path is:

1. Scan hardware and review compatibility findings.
2. Test USB ports and build a map, or explicitly accept a temporary/untested configuration.
3. Select macOS, generate the EFI and validate it. This reuses the reviewed scan.
4. Download and verify recovery, then copy the installer files to a selected FAT32 USB.

Later pages stay locked until their prerequisites are met. Advanced controls are
collapsed; USB drive repair tools remain available after the hardware scan.
Task completion stays on the current page and presents a Continue action. Failed
tasks show their error without jumping away. Changed macOS/device choices require
a new build before proceeding. In-flight requests disable duplicate actions;
older status responses cannot overwrite a newly accepted task.

Guided copying requires recovery verified for the current EFI target, rather
than merely finding a verified recovery download left over from another target.
USB formatting and recovery retain their separate confirmations and safety checks.

Validation: frontend transition tests cover fresh, basic, synthetic, blocked,
failed and completed states, mapping decisions, changed build choices, mismatched
recovery, fast task completion and duplicate clicks. Backend regression tests
cover the recovery-to-EFI status binding. Windows packaging runs the complete
regression suite and packaged smoke checks. No physical USB or macOS boot was
tested. Local visual preview was unavailable under the browser access policy.
