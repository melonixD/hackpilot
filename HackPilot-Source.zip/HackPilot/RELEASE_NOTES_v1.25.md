# HackPilot 1.25 — refresh and USB state fixes

- Out-of-order status and USB inventory replies can no longer replace newer data.
- Replies from before an accepted operation are discarded, including synchronous
  changes such as importing a report or changing USB mapping choices.
- Slow periodic checks do not accumulate overlapping requests.
- USB inventory updates preserve current choices without restoring a disconnected
  drive selection from controls that belonged to the old inventory.
- Oversized hardware reports are rejected before the UI reads or parses them.
- A Rufus request rejected because another operation is running no longer clears
  the previous USB result. Rufus invalidation happens inside the accepted worker.
- Failed USB copy/repair attempts clear stale USB-ready claims, including failures
  while checking the hardware manifest or interrupted-transfer receipt.

All setup pages remain accessible. Disk identity checks, erase confirmations,
EFI validation, hardware binding and recovery verification remain enforced.

Verification: regression tests reproduce late network replies, a disconnected
selection, oversized report import, concurrent Rufus rejection and failed transfer
preflights. No tests format physical disks or open Rufus. Windows packaging runs
the regression suite, executable self-test and packaged worker checks.
