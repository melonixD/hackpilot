# HackPilot v1.3 — End-to-end installer consistency

## Implemented

- Validate required Lilu and VirtualSMC kexts against the generated target's Darwin `MinKernel`/`MaxKernel` range; reject malformed ranges and unresolved third-party kext dependencies.
- Refuse a generated EFI using upstream fallback SMBIOS identifiers, an invalid SystemUUID, or an invalid six-byte ROM.
- Audit generated OpenCore's BOOTx64 and OpenRuntime against the matching release hashes when validator release hashes are available.
- Bind manual USB copying to the generated macOS target and recovery metadata; reject stale recovery pairs from a different Darwin version/board/channel.
- Use a target-aware profile for standalone Apple recovery downloads; reject conflicting manually provided board identifiers.
- Require a detected network adapter before the one-click internet-recovery path can proceed. This is a minimum safeguard, not a guarantee of macOS network support.
- Refresh the cached macrecovery worker transactionally with rollback of its previous bytes and manifest on failure.
- Warn about unverified USB-port mapping and macOS Tahoe's analog-audio/AppleALC concerns.
- Restrict targets to the documented Darwin 20–25 recovery profiles. If a future upstream suggestion exceeds the range, auto mode falls back to a compatible Darwin 25 target or fails safely.
- Expand regression coverage; 154 tests pass on Linux.

## Unverified or not implemented

- No tested Windows `HackPilot.exe` binary has been produced in this environment. Windows GitHub Actions is configured, but the job has not been run here.
- The app does not format/partition an empty USB. A removable FAT32 volume must already exist.
- It creates an OpenCore EFI and Apple *internet recovery*, not a full offline macOS installer; the macOS Recovery interface still needs user actions.
- Apple may serve different recovery builds for a board profile over time. Hash-matching the downloaded pair is not cryptographic verification that its OS version equals the requested Darwin target. Real installer identification and boot testing are required.
- USB port mapping, firmware options, network drivers, graphics acceleration, Wi-Fi, audio and power management cannot be universally validated from a Windows scan. Some machines will require guided intervention or remain unsupported.

**Release classification:** source-only, pre-production preview; not a universal one-click installer.
