# HackPilot v1.17 — EFI Integrity & Mapping Audit (source preview)

**This is an unverified Windows-first source preview, not a shipped EXE or a guaranteed Hackintosh installer.** It uses the OpenCore/OpCore-Simplify ecosystem under their separate licenses. Hardware and macOS compatibility vary. macOS licensing restrictions may apply on non-Apple hardware.

## Main workflow

For a supported Windows x86-64 UEFI machine and an existing **removable FAT32 USB** volume:

1. Insert the FAT32 USB (at least 1 GiB free; more is recommended). HackPilot detects eligible volumes on Windows.
2. Select your USB (if several are connected) and optionally a macOS version. Click **Prepare USB** and confirm the named drive.
3. HackPilot performs a fresh Hardware Sniffer + ACPI scan, checks compatibility, downloads the upstream OpenCore generator as needed, assembles an EFI with available SSDTs/kexts/SMBIOS, runs matching `ocvalidate`, downloads the Apple recovery image, then stages and verifies EFI + recovery on USB.
4. Existing EFI files are backed up on the Windows machine before replacement; interrupted transfers can be recovered using **Repair USB**.

The app **does not format, partition, or erase disks automatically**. USBs formatted as exFAT/NTFS require manual FAT32 preparation before clicking Prepare USB. It cannot guarantee the EFI will boot, that all devices will function, or that macOS graphics acceleration is available. EFI + Apple internet recovery is **not a full offline macOS installer**; installation requires network access. For unusual hardware, an explicit guided device choice may still be required. HackPilot now selects the Apple recovery profile from the generated macOS version; it does not ask for a board ID during the normal one-click flow.

## Windows EXE

The repository includes `.github/workflows/windows-build.yml`, which runs the Python tests and builds the unsigned `HackPilot.exe` using a Windows runner, then uploads that EXE as a workflow artifact. **No compiled EXE is included here**, because this source was produced and tested in a Linux environment. Native Windows execution has not been verified.

Locally on Windows you can also run `Build-Windows-EXE.bat` as a developer build script. Its output is `dist\HackPilot.exe`, a GUI launcher. End users should receive the compiled EXE rather than installing Python.

## Verification and safeguards

- The integrated workflow refuses unrecognized USB volume identity, missing free space, unsupported hardware, an unknown recovery download profile, failed EFI validation, or unverified recovery *before changing USB files*.
- It checks USB volume/disk identity both before and after a long generation/download sequence, and the copier rechecks before commit.
- It compares on-device EFI and recovery content fingerprints after the copy, retaining existing EFI backups and journaling interrupted transactions.
- Recovery metadata is bound to a selected board ID and local file hashes, and the image is separately checked against Apple’s RSA-signed chunklist. This authenticates recovery bytes; it does **not** establish that the image will boot or is the intended point-release.
- Cached upstream tools are pinned to a downloaded revision and checked for local modification before execution. Upstream API changes can still break the adapter.
- No telemetry or remote control server. The local UI binds to `127.0.0.1` and requires a CSRF token to make changes.

## Development and tests

Python 3.11+ on Windows:

```powershell
py -3 -m pip install -r requirements.txt pytest
py -3 -m pytest -q
py -3 -m hackpilot.main --self-test
```

The expanded automated suite has **436 tests passing** in Linux, including simulated USB swaps, interrupted transfers, malformed configurations, validator integrity, and recovery rollback. Windows scanning, the PyInstaller executable, recovery downloads from Apple, a real OpenCore EFI build, and actual macOS boots remain untested here. Do not distribute it as a verified universal installer.

The interface is pure white with bold black text. Advanced choices are optional and hidden until needed. See `WINDOWS_TEST_CHECKLIST.md` and `SECURITY.md`.

## EFI component verification (v1.2 and v1.3)

Generated EFI bundles are audited independently of `ocvalidate` before they are published. The audit checks referenced SSDT/ACPI table headers, table lengths and checksums; x86_64 firmware architecture and EFI PE subsystems for OpenCore, BOOTx64, enabled UEFI drivers and OpenCore tools; kext bundle Info.plists, Intel Mach-O executables, duplicate bundle identifiers and dependency ordering; and whether OpenRuntime plus an HFS+ driver are configured for Apple Recovery. It also detects conflicting default/custom USB maps and flags USB ports that require physical mapping.

**Important:** These checks confirm file consistency, not that kexts, drivers or SSDTs will function on a particular motherboard. Hardware, firmware settings, kext compatibility and real installation/boot must be verified on physical machines. The automatic USB routine still needs a preformatted FAT32 drive. Apple recovery is not a full offline installer.

For details see [RELEASE_NOTES_v1.3.md](RELEASE_NOTES_v1.3.md) and [RELEASE_NOTES_v1.2.md](RELEASE_NOTES_v1.2.md), and see [RELEASE_NOTES_v1.1.md](RELEASE_NOTES_v1.1.md) for the earlier changes.


## Installer consistency safeguards (v1.3)

- A kext required for boot must be **enabled for the actual target Darwin kernel**; merely appearing in `config.plist` is insufficient when `MinKernel` or `MaxKernel` excludes that macOS version. Missing non-Apple kext dependencies stop generation.
- The generated SMBIOS cannot contain OpCore-Simplify's fallback serial/MLB placeholders; UUID and ROM formats are checked, without claiming the generated identity is guaranteed to work with Apple services.
- The chosen recovery profile is derived from the build's Darwin target for both the one-click and manual USB-copy paths. An earlier, mismatched recovery cache cannot be copied as the current installer.
- The adapter automatically keeps the selected Darwin major in the supported recovery-profile range **20–25** even if an upstream suggestion advances beyond it. There is no claim of macOS 27 Intel Hackintosh support.
- Recovery worker updates are transactional, as are changes to the installed OpenCore toolset. Before `ocvalidate`, optional SHA-256 checks confirm the generated BOOTx64/OpenRuntime components belong to the matching OpenCore release.
- Internet-recovery preparation refuses machines with no detected network adapters, but presence alone does not prove the network interface works in macOS.
- The report now warns about the known Tahoe analog-audio caveat and the need for real USB-port mapping on macOS. Neither is automatically certified.

**Hard boundary:** An assembled EFI/online recovery USB still needs BIOS configuration, usable macOS-supported hardware, network at installer boot, physical USB-map verification, and manual steps inside macOS Recovery. Do not mark an EFI as boot-tested based on static validation. An unsigned `.exe` has not been produced or tested in this environment.

See `COMPATIBILITY_AND_RELEASE_GATES.md` for concrete release-blocking tests.

## Hardware-specific safeguards added in v1.4

The machine-specific report and all AML ACPI inputs are SHA-256-bound to the generated EFI manifest; reusing an EFI with modified or stale scan data is refused. A valid DSDT is required before assembling SSDTs, upstream's full hardware-report schema is checked before device selection, and third-party kext dependency minimum versions are compared when numeric. Previously verified recovery files are reused without requiring a new helper download. These safeguards do not certify actual boot, graphics acceleration, Wi-Fi, USB port mapping, sleep or audio functionality. See `RELEASE_NOTES_v1.4.md`.

## USB mapping inside HackPilot (v1.5)

USB port discovery and `UTBMap.kext` generation are now integrated into the **USB Map** tab. No standalone USBToolBox program is launched. The app downloads a revision-pinned USBToolBox/tool Windows discovery backend on first scan (only with consent), enumerates controllers/ports, stores previously seen ports across refreshes, and lets the user choose connector types. **Build USB map** writes a codeless USBToolBox-compatible `UTBMap.kext`.

When a saved USB map matches a fresh Windows controller scan, the EFI builder copies it into `EFI/OC/Kexts`, removes `UTBDefault.kext`, adds `UTBMap.kext` after `USBToolBox.kext` in OpenCore `Kernel/Add`, then runs the independent EFI audit and matching `ocvalidate` before publishing. If topology changes or the map is edited, the build/copy stops rather than silently using stale settings.

**Physical port testing is required** for a reliable map. Users must move a USB device through each socket while using the Scan ports button; unobserved ports and USB-C orientations cannot reliably be inferred from Windows alone. This remains a Windows source preview, not a verified universal installer. See [RELEASE_NOTES_v1.5.md](RELEASE_NOTES_v1.5.md).

## v1.6 independent deep validation

The new EFI audit checks PE32+ x64 EFI section boundaries, Mach-O x86_64
load-command bounds and the `MH_KEXT_BUNDLE` file type, FAT/universal slice
ranges, active-kext architecture, and malformed or reversed `MinKernel` /
`MaxKernel` windows. USB mapping data is validated at rest and cannot silently
fall back to a generic map after a failed map build. Archive extraction rejects
Windows-reserved names and unsafe trailing-dot/space names, both when imported
as a module and when executed as a worker.

**Passing structural validation is not boot validation.** EFI generation may
still require physical USB-port discovery and BIOS settings. Not all hardware
supports accelerated macOS graphics, native Wi-Fi, audio, sleep, or installers.
This version **does not** guarantee hardware compatibility, create a fully
offline macOS installer, format a blank drive, or contain a compiled Windows EXE.
See `RELEASE_NOTES_v1.6.md` for verified changes and open blockers.

## v1.7 additional safeguards

- The EFI component audit rejects two enabled HFS+ firmware filesystem drivers (e.g. HfsPlus and OpenHfsPlus) instead of accepting them because both are individually valid. Use **one** HFS+ driver.
- Manual **and** one-click USB transfers refuse disks without a trustworthy volume ID and disk number. Every transfer rechecks the same identity before committing. Source EFIs are fingerprinted at the start and checked again after staging.
- USB companion ports are matched conservatively when multiple controllers share a hub name. Invalid PCI bus/device/function locations are ignored rather than trusted as a unique hardware identity.
- `UTBMap.kext` generation refuses unknown USB controller classes or selected ports with unknown speed, instead of building a misleading map.
- The UI reports selected ports that have **not** been physically observed as requiring review. A generated map is not proof that every physical port has been tested.
- Recovery files are no longer shown as `Downloaded` solely because they exist; the app must first complete its cached integrity verification. The actual copy still rechecks recovery before writing.

All changes have automated regression tests. Neither these checks nor `ocvalidate` prove that macOS will boot or that every kext functions on the target PC. A native Windows executable and real USB/boot tests remain release blockers.


## v1.8 deep audit — scanner, USB and EFI publication

- Hardware Sniffer tool updates are now transactional. If an update fails, the prior scanner executable and its checksum manifest are both restored. A checksum-verified cached scanner can run during a temporary GitHub outage; an altered cached executable cannot. Interrupted update leftovers block a new scan until reviewed.
- The USBToolBox discovery cache rejects unexpected `.pyc` and `__pycache__` content. The upstream OpenCore adapter also removes root-level `updater.py` bytecode caches, not just `Scripts/` caches.
- A cross-process USB lock prevents two HackPilot GUI instances from simultaneously copying EFI files to, or repairing, the same drive. The lock is automatically released by the operating system when the process terminates.
- USB transfer receipts now require consistent fields, recognized phases, SHA-256 fingerprints, bounded sizes, and stable disk identity. A malformed JSON object cannot be interpreted as a valid recovery instruction or a completed transfer.
- Builds must contain the hardware-bound manifest created by HackPilot's upstream adapter. A missing or malformed manifest, missing scan evidence, unapproved OCLP requirement or mismatched hardware report stops publication before the EFI is reported valid.

**Known limits are unchanged:** no shipped Windows EXE, no actual hardware/UEFI boot testing, no blank-drive formatting, no fully offline macOS installer, and no guarantee of graphics/audio/network/USB compatibility. A saved USB map is not proof that every physical port has been tested. See `RELEASE_NOTES_v1.8.md` and `WINDOWS_TEST_CHECKLIST.md`.

## v1.9 additional hardening

Additional protections cover invalid GUI API requests, interrupted recovery-status reads, invalid/extra files in saved `UTBMap.kext`, incompatible i386-only kext entries, oversized ACPI/plist inputs, malformed Darwin version strings, and simultaneous EFI builds from different GUI windows sharing the same application workspace. The new cross-process workspace lock complements the existing per-USB transfer lock. The Python test suite now passes **291 tests** on Linux. See `RELEASE_NOTES_v1.9.md`. These fixes do not prove a machine will boot macOS, and an unsigned Windows EXE has not been built or tested here.

## v1.10 failure-path audit

- **Reused Apple recovery:** when an existing recovery folder matches the source, its fingerprint is retained in the transfer journal and rechecked after the EFI commit. A mid-transfer change now stops completion and triggers EFI rollback instead of a false success.
- **USB mapping updates:** a new `UTBMap.kext` and its manifest are generated and verified together in staging. If publishing either fails, the previous map and manifest are restored together. Successful updates remove stale transaction backups.
- **USBToolBox integrity:** the cache digest now covers every regular file (including root-level Python modules and resource data), rejects bytecode caches anywhere in the backend and refuses linked backend roots.
- **OpCore cache integrity:** linked top-level engine directories are rejected.
- **FAT32 compatibility:** unexpected, unreferenced EFI files with reserved Windows names or invalid FAT32 paths fail validation before USB copying.
- The pure-white, black-text GUI is unchanged except for more accurate status wording.

The **291 Linux automated tests** exercise these cases with simulated drives, deliberate interruption and corrupted files. They do not establish real macOS bootability or Windows-native runtime correctness. No signed or compiled Windows EXE is included.


## v1.11 large-PC improvements

- Processes the complete Hardware Sniffer inventory for EFI generation while keeping GPU, audio, network, and storage lists bounded in the GUI. Device counts are preserved; potential GPU and network candidates are surfaced even when they occur after hundreds of other devices.
- Bounded GPU configuration choices avoid upstream exponential combination enumeration. Multiple graphics devices require an explicit selection; unchosen devices are disabled by the adapter.
- Rejects obviously unsuitable graphics for standard native macOS acceleration, including recent GeForce/Quadro RTX, Intel Arc/Iris Xe, newer unsupported AMD Radeon cards, and corresponding Radeon Pro models. Experimental graphics paths are not advertised as working.
- Virtual and tunnel-only network inventories do not satisfy the internet-recovery network preflight. A physical NIC candidate is **not** a guarantee that macOS Recovery has a working driver.
- USB history is invalidated when controller identifiers or logical-port speed changes, preventing stale port selections from silently following a changed controller.
- The larger tests are synthetic. Real boot compatibility, a compiled Windows EXE, and a physical USB transfer remain unverified.

See `RELEASE_NOTES_v1.11.md`.


## v1.12 deeper integrity & large-hardware reliability

- A failed ordinary or deep hardware scan now invalidates the previous scan's validated EFI and USB readiness status; no successful old build is displayed as the outcome of a failed new scan.
- Hardware Sniffer release updates compare the downloaded executable with the SHA-256 checksum **published by GitHub Release metadata**, when supplied. Cached bytes are also checked against a newly supplied publisher digest. This supplements local cache integrity without claiming the upstream publisher is independently authenticated.
- Hardware-report sealing now accepts the full **32 MiB** report size supported by the scanner. Previously, a larger valid scan could be rejected later during the EFI build.
- Every new HackPilot-generated EFI requires a **v2 content-bound manifest**: the machine's report/ACPI fingerprint plus a SHA-256 fingerprint of the exact EFI tree. An ELF/EFI/kext that still passes static syntax but has changed bytes cannot be revalidated as the *original* generated build without regenerating it.
- USB copy refuses a legacy, generic, or unbound EFI manifest. **Existing v1.11 and older EFIs must be regenerated with v1.12 before copying to USB.** The generator must have a fresh deep hardware scan and current controller/ACPI inputs.
- If any part of an earlier saved USB map is present but corrupt or missing, the build stops rather than silently using `UTBDefault.kext` or an obsolete map. USB-map GUI telemetry distinguishes ports directly observed with a plugged-in device from companion ports inferred indirectly. Legacy saved port records remain readable, but unproven ports are not marked physically tested.
- Manifest and recovery metadata readers reject oversized, malformed, and linked files. Recovery copy refuses any extra unverified files alongside the two hashed Apple recovery assets. FAT32 path checks now reject additional superscript-number Windows-reserved device filenames.
- One-click copy must explicitly confirm **both** a copied/verified EFI and a copied/verified recovery before claiming USB preparation succeeded. Invalid recovery-version input is rejected without raising unexpected type errors.

**Verification:** 354 tests passed on Linux in the build tree (and again after clean archive extraction), with Python compilation, GUI JavaScript syntax check, and CLI self-test. **This is a source preview:** Windows EXE building, actual USB writing, booting OpenCore/macOS, and physical driver/SSDT/port compatibility remain unverified; do not market near-zero installation failure rates. See `RELEASE_NOTES_v1.12.md`.


## v1.13 safer USB identity and Apple recovery

- A USB drive replaced during a failed copy is never automatically rolled back or cleaned by drive letter alone. Interruptions remain journaled for repair after the **original** device is reinserted. Additional Windows disk and partition identifiers are retained through repair.
- Only actual **FAT32** volumes are eligible; a drive reported as FAT (which may be FAT16) is not silently treated as FAT32.
- Previously scanned hardware is not displayed as current after a failed fresh scan, and malformed oversized OpenCore plists are rejected before parsing.
- Apple recovery must pass independent **RSA-signed CNKL verification and DMG chunk hashes** before it can be used in an actual installation path. Locally computed SHA-256 receipts alone are not sufficient. This does not prove the particular macOS version will boot on a specific PC.

See `RELEASE_NOTES_v1.13.md` for details. Real Windows EXE, USB and macOS boots remain unverified.


## v1.14: recovery download reliability and boot-risk preflight

- **Pinned macrecovery helper:** downloads OpenCorePkg `macrecovery.py` at commit `ebea824880706ac9faa8ee45604245de62be658b`; independently checks its audited SHA-256 (`3023a9b4ca79a5255d93c00f25ab5df37e6f938b729b797d9ecea56184b17aff`) and Git blob identity before executing. This pins the helper source to a fixed revision, so new upstream changes cannot silently break it. When upgrading an older cached copy with *exactly* these bytes, the tool is reused without requiring a fresh GitHub download.
- **Download recovery safely:** refuses to begin with under 2 GiB of free workspace disk space; performs up to two isolated download attempts for network/worker failures, missing files or failed signatures. Each unsuccessful attempt's files are discarded. Actionable error details and an attempt log are retained. A previously verified recovery is not overwritten on failure.
- **Recovery still requires connectivity:** First-time setup needs GitHub to fetch the pinned helper and Apple servers to deliver the signed Recovery DMG and chunklist. Apple server outages, DNS failures, incompatible proxies, insufficient USB space or unsupported OS channels remain possible. This is an *online Recovery image*, not a full macOS installer.
- **Stability preflight:** blocks `Kernel -> Quirks -> XhciPortLimit = True` on Darwin 20.4.0+ (macOS 11.3+), and requires `USBToolBox.kext` to be enabled *ahead of* `UTBMap.kext`. Hardware analysis warns about Wi-Fi-only/unidentified network adapters and Intel VMD/RST/RAID storage configurations requiring firmware review.
- **Version migration:** `HackPilot` reports `1.15-worker-reliability`; cached EFI builds must still match the v1.12+ machine-bound manifest, and already signed/verified recovery is reused where applicable.

**Scope:** These are code-level and simulated failure-path improvements. Successful downloads from Apple's live servers, execution on a physical Windows PC, and macOS boot/sleep/wake/graphics/audio/storage stability **have not been verified**. Apple recovery *channel profiles* are sourced from published OpenCore commands; a signed recovery alone does not prove its macOS version or driver compatibility. No installer can make unsupported hardware stable automatically. See `RELEASE_NOTES_v1.14.md` and `COMPATIBILITY_AND_RELEASE_GATES.md`.


## v1.15: Windows worker reliability and crash repair

- `--windowed` PyInstaller EXEs do not reliably expose stdout/stderr. The frozen EFI adapter and `macrecovery` worker now receive an explicit writable log file. Errors and upstream tracebacks remain visible in `build.log` / `macrecovery.log`; nonzero exit codes still stop USB preparation.
- The frozen USB mapping worker writes a bounded JSON result to a private temporary file instead of a potentially missing stdout pipe. Its errors go to an explicit log.
- The Windows Actions workflow exercises the compiled EXE's headless `--worker-smoke` path. It still **does not** perform real USB or Apple recovery tests and must not be treated as production release certification.
- An authentic cached `macrecovery.py` remains usable when its metadata JSON is broken or stale; HackPilot rebuilds the metadata locally instead of requiring GitHub. Linked or oversized metadata is rejected.
- Interrupted USB rollback distinguishes a pre-existing recovery folder from one that the interrupted operation copied. Repair preserves the former. If partial stage cleanup itself fails, the transaction stays flagged for explicit repair.
- Tool-cache and previously saved hardware manifests now have bounded startup reads, preventing unexpectedly large or linked files from exhausting the GUI.
- The Windows GUI falls back to the default browser if WebView2 initialization fails, instead of exiting with an unexplained error.

**Real hardware caveat:** The source tests run on Linux. The compiled Windows EXE, actual Apple download, target-system firmware/ACPI and post-install macOS stability remain unverified. Read `RELEASE_NOTES_v1.15.md` and `COMPATIBILITY_AND_RELEASE_GATES.md`.

## v1.16 — failure-proof recovery and backend updates

- After downloading Apple recovery, the published files and manifest must pass full read-back and Apple signature verification or the previous recovery is restored. Successful replacement removes its old multi-gigabyte backup, or warns when cleanup is blocked.
- When an updated USBToolBox backend and its rollback both fail, the old files are preserved for manual recovery instead of being deleted during cleanup.
- Failed/rescanned EFI builds invalidate stale success indicators. Oversized validator/recovery metadata, huge diagnostic logs, and redirected lockfiles are handled defensively.
- The USB picker no longer offers FAT16 as FAT32 and requires drive selection when more than one target is connected. The UI version is reported by the running backend.

**Verification:** 424 Linux-based automated tests passed and the unpacked ZIP was retested. There is no compiled Windows EXE in this archive and no physical Windows/USB/macOS boot test yet. A structurally verified EFI does not guarantee a stable macOS installation. See `RELEASE_NOTES_v1.16.md`.


## v1.17 — Integrity boundaries and cache safety

- **Changed EFI fingerprint encoding:** Each file now has a length-delimited path and content length in a domain-separated SHA-256 tree digest. Previous encoding was ambiguous: different per-file contents could produce the same serialized byte stream. This is covered by a reproducing regression test.
- **Separate size limits:** Generated EFI files are limited to a conservative 1 GiB total. USB transfer/read-back fingerprints use an 8 GiB tree budget so legitimate Apple Recovery DMGs above 1 GiB are not rejected. This matters when preparing recent macOS Recovery media.
- **Bounded cache verification:** A malformed USBToolBox or OpenCore engine cache cannot force the status screen to hash unlimited files/bytes. USB-map manifests are read with a 128 KiB upper bound.
- **USB-map injection:** Validates the saved codeless mapping bundle immediately before insertion and turns off `XhciPortLimit` when installing an explicit USB map.
- **Race safety:** A USB-map manifest disappearing between status checks yields `map_ready = false` instead of crashing the local request.
- **Regressions:** 436 Python tests pass on Linux, including new adversarial fingerprint, cache-size, mapping, and file-disappearance tests.

**Upgrade:** Regenerate all existing EFI builds with HackPilot v1.17. Their v1.16 content fingerprints use the obsolete encoding and deliberately will not match the new validator. A v1.17 validation result still cannot certify macOS boot or post-install stability.
