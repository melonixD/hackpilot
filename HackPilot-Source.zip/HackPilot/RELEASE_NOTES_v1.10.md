# HackPilot v1.10 — Failure-Path Audit

This is a source preview. Changes are limited to reproducible integrity and rollback failures; the EFI engine itself still requires physical hardware validation.

## Fixed

1. When an existing Apple recovery image is reused, its fingerprint is now present in the journal and verified **after** the new EFI is committed. If the recovery changes during staging, the app refuses to report USB success and restores the old EFI.
2. USB-map replacement is staged and transactional across `UTBMap.kext` and `usb-map-manifest.json`; a failed second rename or manifest write preserves the previously generated map.
3. Integrity checking of the USBToolBox backend now includes root-level Python modules and every resource file, and rejects surprise Python bytecode, symlinks and reparse-point roots.
4. OpCore-Simplify cache hashing rejects symlinked/junction root directories.
5. Full EFI file-tree verification now rejects unreferenced filenames which Windows/FAT32 cannot represent safely.
6. GUI labels clarify that USB verification is a **last successful copy**, not proof of physical macOS boot.

## Verification

- 291 unit/regression tests pass on Linux, up from 277.
- Python compile, frontend JavaScript syntax and local app self-test pass.
- Clean ZIP extraction and the complete 291-test suite pass again.

## Unresolved release blockers

- Windows GUI `HackPilot.exe` has not been compiled or exercised on physical Windows hardware.
- Firmware/ACPI behavior, real SSDT/kext functionality, physical USB-port mapping, recovery boot, and macOS installation have not been verified.
- Automatic FAT32 drive formatting and a full offline macOS installer are not implemented.
- Do not interpret these tests as a universal one-click Hackintosh guarantee.
