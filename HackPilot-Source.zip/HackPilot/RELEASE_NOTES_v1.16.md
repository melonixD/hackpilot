# HackPilot v1.16 — Failure-Proof Publishing & Windows USB Safety

Windows source preview. This is **not** a hardware-certified installer or a compiled EXE.

## Fixed / strengthened

1. **Post-download recovery verification.** A newly installed Apple recovery pair is independently re-read and checked against its metadata and Apple's RSA-signed chunklist *after publication*, not only in the temporary download directory. Failed publication rolls back to the previous image and its original metadata.
2. **Old recovery storage leak.** Successful replacement now removes the previous multi-gigabyte recovery directory. If Windows locks the old backup, the new authenticated recovery remains usable and the app reports that cleanup is needed rather than concealing the space usage.
3. **USBToolBox update data-loss bug.** If the scanner update and automatic rollback both fail, HackPilot preserves the previous backend in a named rollback folder. Earlier cleanup could delete the last remaining good copy in this failure mode.
4. **Stale validation state.** Starting a new EFI build, validation, or USB-controller rescan clears previously asserted build/USB readiness. A failed early preflight no longer inherits the preceding operation's successful state.
5. **Bounded validator metadata and logs.** Malformed or extremely large `validator-manifest.json` files are rejected without unbounded reads. Native worker log errors, the local GUI's build-log endpoint, and USB mapping worker errors now read bounded tails rather than loading entire files.
6. **Safer recovery metadata replacement.** Linked and oversized recovery metadata are rejected before attempted publication. An invalid recovery manifest cannot trigger an unbounded metadata backup read.
7. **Lockfile redirection.** Linked/reparse-point files cannot be used as app-workspace or USB-transfer lockfiles.
8. **Accurate USB UI.** FAT16 (`FAT`) volumes are no longer advertised as FAT32-compatible. Multiple drives require deliberate selection in both Overview and USB views. The app version displayed in the sidebar is driven by the backend instead of remaining stuck on v1.5.

## Tests performed

- **424 / 424 automated pytest tests passed** locally.
- JavaScript syntax check, Python compilation, and application self-test performed.
- Tests cover publication read-back failure, metadata-write failure, old-recovery cleanup failure, retained old USBToolBox backend after a simulated rollback failure, large logfile reading, USB scan and EFI status invalidation, validator metadata size, lockfile redirection, and USB UI options.
- Full suite rerun after extracting the distributable source ZIP into a clean folder.

## Still a release blocker

No actual Apple recovery download, native Windows EXE, USB writing to physical media, Hackintosh boot, or post-install stability test was possible in the Linux test environment. Static validation cannot establish compatibility for arbitrary firmware, GPU acceleration, USB-C wiring, audio, network, storage, sleep/wake, or specific ACPI implementations. Keep the one-click path restricted to hardware that passes real compatibility and boot tests. The tool intentionally does not format or erase USB drives.
