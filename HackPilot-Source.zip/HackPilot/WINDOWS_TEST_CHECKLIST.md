# Physical Windows release checklist (not yet completed)

Use disposable removable USBs and test PCs. Do not perform the initial destructive experiments on a machine holding important data.

- [ ] On Windows 10 and 11, run `py -3 -m pytest -q` and `py -3 -m hackpilot.main --self-test`.
- [ ] Build `HackPilot.exe` with `Build-Windows-EXE.bat`; confirm the bundled `--self-test` exits with code 0 and its native window launches.
- [ ] Cold launch, relaunch, and crash recovery with no Python installed on the tester PC.
- [ ] Intel desktop with supported iGPU and supported AMD dGPU: hardware report matches Windows Device Manager.
- [ ] AMD Ryzen desktop: CPU and ACPI identification; patches verified against upstream guidance.
- [ ] Hybrid GPU laptop: guided selection picks the intended macOS display device.
- [ ] Wi-Fi/Bluetooth with multiple adapters: confirm all choices and valid branch selection.
- [ ] Deliberately unsupported RTX-only PC: auto build stops safely.
- [ ] UEFI vs legacy mode and Secure Boot/BitLocker warnings accurately reflect firmware.
- [ ] Download official OpenCore release and ensure produced OpenCore.efi and `ocvalidate` pairing matches expected hash. Repeat with two different OpenCore versions; confirm the first validator is still usable.
- [ ] EFI generated and structural / `ocvalidate` checks pass, and it boots the macOS recovery environment on compatible test hardware.
- [ ] Physical removable FAT32 USB transfer: verify read-back contents, backup ZIP, repeat transfer and recovery reuse.
- [ ] Unplug USB at each simulated commit phase on disposable media; confirm the journal prompts to repair the matching device.
- [ ] Change USB drive letter, physical device, corrupt on-USB rollback EFI, and corrupt backup ZIP: confirm repair either selects a verified fallback or refuses unsafe assumptions.
- [ ] No other drive, especially the Windows boot volume, is ever modified.
- [ ] Apple recovery image downloaded, verified and recognized after app restart.
- [ ] Native UI: pure white with black text on desktop, laptop and small Windows tablet sizes; no invisible text or focus traps.
- [ ] Test boot-log triage using real anonymized OC logs without making config changes.
- [ ] Sign Windows release with a valid publisher certificate before public distribution; scan binaries for malware/false positives.

**Stop release if any actual disk-integrity, bootloader-version, unsupported-hardware, or auto-repair fault remains.**

## One-click Windows integration (not completed)

- [ ] Plug a clean FAT32 USB into a Windows desktop, confirm it appears without opening the USB tab.
- [ ] Insert two FAT32 USBs: the main action must require explicit selection, never default to the first.
- [ ] Leave a USB formatted as exFAT/NTFS: show a safe refusal without formatting or writing anything.
- [ ] Unplug/replug USB during Hardware Sniffer, EFI build, recovery download, and pre-commit; confirm volume identity changes are rejected.
- [ ] Download recovery with correct board ID and verify both files on USB via SHA-256. Test corrupted chunklist/image and failed manifest write.
- [ ] Verify old EFI survives failed replacement or power loss using Repair USB and fingerprint-verified backup.
- [ ] Verify end-to-end one-click flow with clean supported Intel and AMD test rigs, including actual boot into Apple recovery over working network.
- [ ] Verify no Windows OS, other USB drives, or internal partitions were changed.
- [ ] Test GitHub Actions built unsigned Windows EXE on a fresh Windows VM with no Python, including native GUI startup, USB enumeration and proper error messages.

## v1.2 EFI component and recovery cases (still require physical Windows testing)

- [ ] Verify `BOOTx64.efi`, `OpenCore.efi`, and configured UEFI drivers are x64 PE/COFF EFI binaries and match the release being used.
- [ ] Deliberately omit `OpenRuntime.efi` or the HFS+ filesystem driver; ensure the generated build refuses success before USB copy.
- [ ] Corrupt a copied SSDT checksum or truncate its compiled AML; ensure revalidation refuses to copy it.
- [ ] Corrupt a kext binary architecture/Info.plist or reverse dependency load order; ensure generated- and pre-transfer audits stop the operation.
- [ ] For laptops with two GPUs and two Wi-Fi adapters, select one. Verify upstream `customized_hardware` and `disabled_devices` contain the intended sets, with no accidental changes to unrelated devices.
- [ ] Check USBToolBox mapping on actual USB 2.0/3.x, Type-C and internal USB ports. A syntactically valid `UTBMap.kext` does **not** prove all physical ports work.
- [ ] Generate Tahoe, Sequoia and older supported targets and verify the Apple recovery download profile matches the actual generated Darwin target and is bootable.
- [ ] Test a system using non-default `Misc/Tools`, nested plugin kexts, and multiple storage/NVMe controllers.
- [ ] Build and exercise native HackPilot.exe on fresh Windows 10 and 11 installations without Python; test clean install, GUI launch and installer USB.


## v1.3 hardening cases (still require real-machine validation)

- [ ] Verify Lilu/VirtualSMC load ranges for each macOS target; reject mismatches and missing enabled third-party dependencies.
- [ ] Confirm macserial identifiers are real generated values, not upstream fallback placeholders.
- [ ] Modify BOOTx64.efi or OpenRuntime.efi after download; ensure version-matched validator release hashes catch the mismatch.
- [ ] Attempt manual USB copying with recovery cached for a different Darwin major; refuse and preserve the USB.
- [ ] Attempt one-click setup without a network device and with network hardware unsupported by macOS; do not claim an installable recovery.
- [ ] Confirm USB mapping at the real hardware level and verify analog audio support before suggesting a finished Hackintosh.
- [ ] Verify downloaded recovery OS version against the requested Darwin target in a real boot environment; `latest` is not an exact version guarantee.
- [ ] Confirm unsupported/unprofiled new macOS targets are refused early instead of generating unsuitable recovery media.

## v1.5 USB Map hardware tests (mandatory before claiming completion)

- [ ] Build and launch HackPilot.exe on Windows 10 and Windows 11 without Python installed; check first-run USBToolBox scanner download, checksums, and Windows Defender prompts.
- [ ] Compare detected USB root controllers and PCI/ACPI matches with the actual motherboard/Device Manager.
- [ ] Move a USB 2 device through every rear/front physical port; refresh the built-in USB Map after each insertion.
- [ ] On USB 3 sockets, verify paired HS/SS entries; test SuperSpeed with a USB 3 device where needed.
- [ ] Test both USB-C orientations and confirm connector type 9 vs 10; test internal Bluetooth, internal headers, USB hub ports, and Thunderbolt controllers.
- [ ] Check no controller selects more than 15 ports, and confirm unknown/ambiguous controllers fail safely.
- [ ] Generate UTBMap.kext and inspect the generated Info.plist on actual Windows machines.
- [ ] Generate the EFI, check UTBDefault is absent/disabled, UTBMap loads after USBToolBox, and ocvalidate passes.
- [ ] Boot macOS recovery and macOS, verify every mapped port and connector speed, and test sleep/wake/hotplug.
- [ ] Remove a mapped device or change motherboard/USB controller topology; confirm HackPilot refuses stale maps.
- [ ] Test offline scan reuse, interrupted downloads and backup/rollback of a previous EFI.


## v1.6 deep-binary checks (release blocking)

- [ ] On Windows, build the native EXE and run its `--self-test` on a clean user account.
- [ ] Generate EFI for known Intel desktop, Intel laptop, and AMD desktop targets.
- [ ] Confirm actual Lilu, VirtualSMC and other kext Mach-O bundles pass the new strict load-command checks.
- [ ] Confirm actual OpenRuntime, HfsPlus and BOOTx64 PE/COFF section bounds pass on Windows.
- [ ] Test macOS versions 11-26 with matching OpenCore `ocvalidate` from the same release.
- [ ] Simulate incomplete/stale USB mapping, corrupted saved port choices, and interrupted USB transfers on a sacrificial USB only.
- [ ] On physical hardware, boot Apple Recovery; test ports, storage, graphics, networking, audio, sleep/wake, Bluetooth and software updates.
- [ ] Block production release if the entire verified USB + recovery path fails on any advertised supported device class.

### v1.7 additional physical validation

- Test swapping a USB between volumes that reuse a drive letter; transfer must refuse any identity change.
- Test a system with multiple USB controllers having identical hub descriptions; the port map must not cross-match them.
- Confirm that the GUI flags selected USB ports never observed during discovery, and validate both USB 2 and USB 3 companion ports by physically connecting a device.
- Verify a generated EFI contains exactly one enabled HFS+ filesystem driver and no invalid USB-controller mappings.
- Restart the app with incomplete recovery files and no valid integrity metadata; the UI must not show Recovery ready.


## v1.8 release blockers

- [ ] Update Hardware Sniffer while network disconnects, disk is full, or Windows Defender quarantines the new binary: previous verified scanner and metadata must survive.
- [ ] Run two independent HackPilot.exe processes and attempt to copy or repair the same removable drive simultaneously: exactly one operation may proceed.
- [ ] Crash the process at each USB commit phase; verify the journal is sound and Repair USB chooses only a fingerprint-verified source.
- [ ] Tamper with `build-manifest.json` and the captured ACPI/Report.json inputs; publication and USB copying must stop.
- [ ] Verify root-level upstream Python bytecode caches and untracked USBToolBox bytecode never execute.
- [ ] Test the Windows GitHub Actions build artifact on clean Windows 10/11, on actual USB sticks, and boot the installer on supported hardware.

## v1.10 targeted Windows verification

- Build on Windows runner with a fresh Python environment, then test `HackPilot.exe --self-test` and launch the native GUI without Python installed.
- Test repeat EFI replacement on a FAT32 USB containing existing verified Apple recovery files. Remove/swap the device during staging, and verify the old EFI is restored without a success status.
- Generate a USB map; simulate interruption between writing `UTBMap.kext` and `usb-map-manifest.json`. Verify the old map remains usable.
- Test ACPI/USB/kext compatibility on multiple distinct Intel and AMD systems. Map every physical connector and test both USB-C orientations where applicable.


## v1.12 specific Windows release gates

- [ ] On a real Windows PC, verify Hardware Sniffer download with the published GitHub SHA-256, including offline cache and a deliberate hash mismatch.
- [ ] Attempt a failed deep scan after a successful EFI build: GUI must clear previous EFI/USB readiness.
- [ ] Scan a machine with a Hardware Sniffer report larger than 12 MiB; if below 32 MiB, sealing and build must agree.
- [ ] Create EFI, modify a structurally valid kext's bytes, rerun validation; require a new EFI build, not simply a passing ocvalidate.
- [ ] Upgrade from v1.11 with a previously generated EFI; require regeneration and explain why.
- [ ] Save a USB map, corrupt/delete only its manifest, generate EFI; app must not fall back to UTBDefault.
- [ ] Physically plug USB devices into each port; inferred companion ports must not count as directly tested.
- [ ] Verify USB FAT32 paths and readback of the two and only two expected Apple recovery assets.
- [ ] Verify one-click never claims success when the copier returns only EFI success or only recovery success.


### v1.13 signed recovery and device-swap tests

- Verify an authentic recovery image's Apple CNKL RSA signature and chunk hashes in the running native EXE.
- During staging, commit, and recovery repair, unplug/reinsert the USB and attach a different drive using the same letter. Verify the second drive is untouched.
- Reinsert the original drive, use Repair USB, and confirm boot files are recovered.
- Test the extra disk UniqueId and partition identity fields on real Windows devices; check filesystems reported as FAT16 are refused.


## v1.14 Apple Recovery live test

- [ ] On Windows, with 4+ GiB USB FAT32 and 2+ GiB work-disk free, run Prepare USB using an internet-connected, compatible PC.
- [ ] Confirm the pinned helper was fetched from the immutable OpenCorePkg Git revision and matches both source hashes.
- [ ] Verify an Apple-signed Recovery DMG and chunklist were downloaded, and the selected installer boots.
- [ ] Block GitHub and rerun with a pinned cached helper; confirm Apple download still works.
- [ ] Disconnect/reconnect network while downloading; confirm attempt logs, cleanup and retry, or clear terminal error.
- [ ] Simulate/observe Apple server timeouts and low disk space. Confirm previous verified recovery is unchanged.
- [ ] Confirm macOS 11.3+ with XhciPortLimit enabled fails the EFI audit.
- [ ] Confirm UTBMap.kext requires earlier USBToolBox.kext.
- [ ] Review VMD/RST/RAID and Wi-Fi-only risk notices; test actual storage and network accessibility in macOS Recovery.
- [ ] After install, test GPU acceleration, Wi-Fi/Ethernet, USB 2/3 and Type-C ports, sleep/wake, audio, Bluetooth, NVRAM and system updates.


## v1.15 executable worker validation

1. Build `HackPilot.exe` on Windows 10 and 11; verify `--self-test` and `--worker-smoke` and confirm the smoke output file is created.
2. Intentionally break WebView2 and confirm the browser fallback works without losing the local interface.
3. Exercise the EFI builder, macrecovery and USB mapping from the EXE, confirming errors and outputs appear in the expected files (no separate Python installation).
4. Test USB rollback with recovery that existed before the transfer, and separately with recovery freshly copied by the transfer.
5. Finish a real installer boot, peripheral checks and post-install macOS stability tests before distributing as a one-click solution.

### v1.16 additional Windows checks

1. Try selecting FAT16, FAT32 and exFAT USB media. The UI must offer only eligible FAT32 volumes; USB write and repair must still check unique disk/partition identities.
2. Verify a real Apple recovery download with a working Ethernet connection and compare its actual macOS version with the selected Darwin target; do not infer compatibility merely from a valid signature.
3. Interrupt recovery publication and USBToolBox updates under antivirus/file-lock conditions; confirm the prior usable files are retained and warnings are actionable.
4. Verify that an errored build or validation and a changed USB controller scan clear green readiness indicators.
5. Test the compiled GUI EXE and workers on a fresh Windows 10/11 system, then physical boot/install and post-install hardware stability.
